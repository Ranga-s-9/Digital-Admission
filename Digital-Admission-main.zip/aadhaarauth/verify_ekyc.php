<?php
/**
 * verify_ekyc.php
 * REST API endpoint for Aadhaar Offline e-KYC verification.
 */

header('Content-Type: application/json');

require_once 'eKycParser.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method Not Allowed. Use POST.'
    ]);
    exit;
}

try {
    // 1. Validate file upload presence
    if (!isset($_FILES['ekyc_file']) || $_FILES['ekyc_file']['error'] !== UPLOAD_ERR_OK) {
        $uploadError = $_FILES['ekyc_file']['error'] ?? 'No file provided';
        throw new Exception("File upload failed (Error Code: $uploadError). Please select a valid ZIP or XML file.");
    }

    $tempPath = $_FILES['ekyc_file']['tmp_name'];
    $originalName = $_FILES['ekyc_file']['name'];

    // 2. Retrieve form parameters
    $shareCode = isset($_POST['share_code']) ? trim($_POST['share_code']) : '';
    $phoneInput = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
    $emailInput = isset($_POST['email']) ? trim($_POST['email']) : '';

    // 3. Parse e-KYC file
    $result = eKycParser::parseFile($tempPath, $originalName, $shareCode);

    // 4. Perform mobile / email verification if plaintext values are supplied
    $mobileVerified = null;
    $emailVerified = null;

    if (!empty($phoneInput)) {
        if (!empty($result['mobileHash'])) {
            $mobileVerified = eKycParser::verifyHash($phoneInput, $result['mobileHash'], $shareCode, 'mobile');
        } else {
            $mobileVerified = false; // Mobile hash missing in XML, cannot verify
        }
    }

    if (!empty($emailInput)) {
        if (!empty($result['emailHash'])) {
            $emailVerified = eKycParser::verifyHash($emailInput, $result['emailHash'], $shareCode, 'email');
        } else {
            $emailVerified = false; // Email hash missing in XML, cannot verify
        }
    }

    // 5. Append matching results
    $result['mobile_verified'] = $mobileVerified;
    $result['email_verified'] = $emailVerified;

    echo json_encode([
        'success' => true,
        'message' => 'Aadhaar e-KYC identity details verified successfully.',
        'data' => $result
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

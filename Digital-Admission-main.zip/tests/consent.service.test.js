'use strict';

process.env.NODE_ENV = 'test';
process.env.DB_TYPE = 'sqlite';
process.env.DB_SQLITE_PATH = './test_consent_service.sqlite';

const consentService = require('../backend/services/ekyc/consent.service');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');
const fs = require('fs');
const path = require('path');

describe('Consent Service Integration Tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM ekyc_consents');
    await db.query('DELETE FROM users');
    await db.query(`INSERT INTO users (id, name, email, mobile, password_hash, role) VALUES (1, 'Alice', 'alice@test.com', '1234567890', 'hash', 'student')`);
  });

  afterAll(async () => {
    await db.close();

    const dbPath = path.resolve(process.cwd(), './test_consent_service.sqlite');
    if (fs.existsSync(dbPath)) {
      try {
        fs.unlinkSync(dbPath);
      } catch (e) { /* ignore */ }
    }
  });

  test('Records consent successfully and retrieves latest consent state', async () => {
    // Record first consent
    const record = await consentService.recordConsent({ studentId: 1, ipAddress: '127.0.0.1' });
    expect(record.id).toBeDefined();
    expect(record.consentVersion).toBe('1.0');

    // Retrieve consent state
    const state = await consentService.checkConsent(1);
    expect(state.hasConsent).toBe(true);
    expect(state.latestConsent).toBeDefined();
    expect(state.latestConsent.consent_version).toBe('1.0');
    expect(state.latestConsent.consented).toBe(1);
  });

  test('Returns false when checking consent for a student who has not consented', async () => {
    const state = await consentService.checkConsent(999);
    expect(state.hasConsent).toBe(false);
    expect(state.latestConsent).toBeNull();
  });

  test('Retrieves correct historic consent list', async () => {
    await consentService.recordConsent({ studentId: 1, ipAddress: '127.0.0.1' });
    await consentService.recordConsent({ studentId: 1, ipAddress: '127.0.0.2' });

    const history = await consentService.getConsentHistory(1);
    expect(history.length).toBe(2);
    expect(history[0].ip_address).toBe('127.0.0.2'); // DESC order by created_at
    expect(history[1].ip_address).toBe('127.0.0.1');
  });

});

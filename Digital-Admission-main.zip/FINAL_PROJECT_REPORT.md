# Canonical Project Report — Digital Student Admission System

This comprehensive report details the system architecture, implemented modules, database schema design, REST APIs, security safeguards, testing metrics, installation procedures, and usage guidelines for the **Digital Student Admission System**.

---

## 1. Project Overview & Business Value
The **Digital Student Admission System** is a modular, high-security web portal developed in compliance with Digital Public Infrastructure (DPI) principles. The system addresses the inefficiencies and security gaps of traditional student admission portals by providing a completely paperless, authenticated, and verifiable workflow. 

### Core Business Objectives:
* **Identity Verification (eKYC)**: Eliminates student identity fraud by matching uploaded offline Aadhaar XML files against registered profile details.
* **Academic Verification (DigiLocker)**: Connects directly with DigiLocker to retrieve authentic academic marksheets directly from issuing authorities (e.g. CBSE), preventing transcript tampering.
* **Paperless Signature (eSignzy)**: Enables students to sign application declarations digitally using eSignzy integration.
* **Optimized Review Workflow**: Implements a state machine for tracking applications from Draft to Approved/Rejected, including an interactive Professor review loop with correction requests.

---

## 2. System Architecture & Components
The system follows a modern decoupled architecture where the Node.js/Express.js backend serves static frontend assets (vanilla Single Page Application) and exposes RESTful API endpoints.

```mermaid
graph TD
    Client[SPA Client: HTML5 / CSS / Vanilla JS]
    Server[Node.js / Express Server]
    SQLite[SQLite Database: Local Dev]
    MySQL[MySQL / MariaDB: Production]
    eKYC[Aadhaar eKYC Mock/Real]
    DigiLocker[DigiLocker OAuth Gateway]
    eSignzy[eSignzy Signing Provider]

    Client -- HTTP Requests --> Server
    Server -- ORM / SQL Queries --> SQLite
    Server -- ORM / SQL Queries --> MySQL
    Server -- XML Parsing & Matches --> eKYC
    Server -- popup PostMessage OAuth --> DigiLocker
    Server -- REST Client --> eSignzy
```

### Components:
1. **Frontend SPA**: Clean HSL Glassmorphism UI utilizing responsive flex grids. Communicates with backend APIs via the `fetch` API.
2. **Backend Server**: Configured with Helmet headers, CORS filters, request-specific UUID tracing, and a centralized Express error handler.
3. **Database Connectivity Layer**: Connects dynamically to SQLite (local development) or MySQL/MariaDB (production) using environment variables. Exposes a unified `query()` promise interface.
4. **Adapter Services**: Implements abstract adapters for external services (eKYC, DigiLocker, eSignzy) to allow swapping mock adapters for real API interfaces seamlessly.

---

## 3. Technology Stack
* **Backend**: Node.js (v18+) & Express.js
* **Database**: SQLite3 (for zero-config local runs) & MySQL 5.7+ / MariaDB 10.4+ (XAMPP-compatible)
* **Security & Auth**: JWT (JSON Web Tokens) in HTTP-Only SameSite=Strict cookies, bcryptjs (password encryption), Helmet (security headers), and Cache Rate Limiters
* **Frontend**: Responsive HSL Glassmorphism using semantic HTML, Vanilla CSS, and JavaScript (no TailwindCSS or heavy JS frameworks)
* **Testing**: Jest (test runner) and Supertest (API HTTP assertions)

---

## 4. Normalized Database Schema
The database supports both SQLite and MySQL/MariaDB. It consists of 16 tables, with foreign keys, cascading deletes, unique constraints, and indexes to optimize lookup performance.

```mermaid
erDiagram
    users ||--o| student_profiles : "user_id (1:1)"
    users ||--o| admission_applications : "user_id (1:1)"
    users ||--o| ekyc_requests : "user_id (1:1)"
    users ||--o| digilocker_connections : "user_id (1:1)"
    users ||--o| esignzy_requests : "user_id (1:1)"
    users ||--o{ notifications : "user_id (1:N)"
    users ||--o{ audit_logs : "user_id (1:N)"
    
    users {
        int id PK
        string name
        string email UK
        string mobile UK
        string password_hash
        string role
        string status
        int failed_attempts
        bigint lockout_until
        timestamp created_at
    }
    
    student_profiles {
        int user_id PK, FK
        string dob
        string gender
        string guardian_name
        string address
        string state
        string pincode
        string degree
        string board
        int grad_year
        float percentage
        string photo_path
        int version
    }

    admission_applications {
        int id PK
        string application_id UK
        int user_id UK, FK
        string status
        string correction_message
        timestamp updated_at
    }
```

### Table Dictionary:
1. `roles`: Normalizes system permissions (`student`, `professor`, `admin`).
2. `users`: Stores core credentials, failed attempt counters, and lockout timestamps.
3. `captchas`: Ephemeral mathematical CAPTCHA challenges with expiration counters.
4. `otps`: Ephemeral 2FA OTP codes linked to user login requests.
5. `student_profiles`: Houses detailed student demographics and academic records. Supports optimistic concurrency version locks.
6. `admission_applications`: Tracks drafts, steps, finalized values, and review statuses.
7. `ekyc_requests` & `ekyc_audit_logs`: Records identity matching results and verification consent logs.
8. `digilocker_connections` & `digilocker_documents`: Logs authenticated links and academic transcript URIs.
9. `esignzy_requests` & `esignzy_audit_logs`: Stores eSign contract identifiers and digital signature states.
10. `workflow_audit_logs`: Tracks state changes and verifier review notes.
11. `notifications`: Handles system notifications with read/unread flags.
12. `audit_logs`: The centralized system log, automatically sanitizing passwords and OTP hashes.

---

## 5. API Reference Summary
All JSON responses return a standardized `{ success: true/false, message: "...", data: {} }` or `{ success: false, message: "...", error: {} }` structure.

| Endpoint | Method | Role | Description |
|---|---|---|---|
| `GET /api/auth/captcha` | GET | Public | Generates a new CAPTCHA equation |
| `POST /api/auth/register` | POST | Public | Registers a new user with CAPTCHA validation |
| `POST /api/auth/login` | POST | Public | Validates credentials, issues CAPTCHA, sends OTP |
| `POST /api/auth/verify-otp` | POST | Public | Validates OTP and places session JWT in cookie |
| `POST /api/auth/logout` | POST | Authenticated | Clears the HTTP-Only JWT session cookie |
| `GET /api/profile/:userId` | GET | Owner / Professor | Fetches a student's profile information |
| `PUT /api/profile/:userId` | PUT | Owner | Updates profile with optimistic lock version checks |
| `POST /api/ekyc/verify` | POST | Student | Compares uploaded Aadhaar XML with profile parameters |
| `POST /api/digilocker/documents/retrieve` | POST | Student | Fetches academic transcript from DigiLocker API |
| `POST /api/esignzy/sign` | POST | Student | Triggers the eSignzy digital signature flow |
| `POST /api/workflow/transition` | POST | Professor | Transitions application state (Approve, Reject, Correction) |
| `GET /api/audit-logs` | GET | Professor / Admin | Fetches system audit logs (sanitized output) |

---

## 6. Authentication & OTP (2FA) Flow
The login process uses a multi-layered security sequence:
1. **Credentials + CAPTCHA (Step 1)**: User inputs email, password, and solves the CAPTCHA. If correct, the backend generates a random 6-digit OTP code, stores its SHA-256 hash, and dispatches the code.
2. **OTP Verification (Step 2)**: User enters the 6-digit OTP code. If correct, a JWT access token is signed and placed in a secure HTTP-Only cookie `token` with `SameSite=Strict` and `Secure` flags.
3. **Lockout Policy**: Accounts are locked for 15 minutes after 5 consecutive failed login attempts. Generic errors are returned to prevent user/email enumeration.

---

## 7. eKYC Aadhaar & DigiLocker Integrations
* **eKYC Demographic Verification**: The student uploads an Aadhaar Offline XML file and enters a 4-digit share code. The server parses the XML, checks verification consent, and compares the demographic values (Name, Date of Birth, Gender, Pincode) against the student's profile.
* **DigiLocker Transcript Verification**: Uses a secure popup window to execute the OAuth 2.0 flow. Once authorized, a `postMessage` event passes tokens back to the parent window. The backend retrieves the CBSE Marksheet, verifying that the student name on the transcript matches the registered profile name before linking it.

---

## 8. Paperless Office Workflow State Machine
The application follows a strict state transition flow managed by the backend. Direct editing is disabled once an application is submitted, unless a Professor requests revisions.

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Submitted : Student submits
    Submitted --> DOCUMENT_VERIFICATION : Auto-promotion (DigiLocker linked)
    DOCUMENT_VERIFICATION --> IDENTITY_VERIFICATION : Auto-promotion (eKYC verified)
    IDENTITY_VERIFICATION --> PENDING_SIGNATURE : Professor reviews
    PENDING_SIGNATURE --> SIGNED : eSignzy completed
    SIGNED --> Approved : Professor approves
    SIGNED --> Rejected : Professor rejects
    SIGNED --> Draft : Professor requests correction
    DOCUMENT_VERIFICATION --> Draft : Professor requests correction
    IDENTITY_VERIFICATION --> Draft : Professor requests correction
```

### Revision Loops:
If any transcript or profile information is mismatched, the Professor can transition the application state back to `Draft` by providing mandatory correction notes. This unlocks editing on the Student Dashboard. The student corrects the data and clicks "Submit" to enter the review queue again.

---

## 9. Security Defenses & Hardening
* **SQLi Shielding**: Parameter-bound prepared statements in database wrappers ensure query values are never concatenated directly.
* **XSS Defenses**: All HTML outputs are escaped using `express-validator` sanitizer rules, and a strict Content Security Policy is managed via `helmet`.
* **IDOR Prevention**: Endpoint routes check the session cookie's `userId` against requested query parameters to prevent horizontal privilege escalation.
* **Centralized Sanitization**: Sensative credentials (passwords, OTP hashes, API keys) are redacted to `[REDACTED]` by the audit logging model before storage.
* **Error Hardening**: Centralized error middleware ensures that raw application stack traces are never exposed in API responses.

---

## 10. Automated & Regression Testing
* **Jest + Supertest**: The project contains 11 automated test suites comprising 84 tests.
* **100% Test Pass Rate**: Verified against SQLite (development) and MySQL (production/XAMPP).
* **Automated E2E Test**: `scratch/e2e_api_journey.js` programmatically walks through the entire 17-step user journey from registration, OTP, profile edits, document attachments, eSign signatures, and verifier approval.

---

## 11. Mock Mode & Sandbox Integrations
To support zero-config local setup, external APIs are run in **mock mode** by default:
1. **eSignzy**: Mock signatures are generated immediately (`ESIGNZY_MODE=mock`). Setting `ESIGNZY_MODE=production` activates the real API client, requiring an `ESIGNZY_API_KEY`.
2. **DigiLocker**: Simulates the OAuth login popup and returns mock CBSE transcript documents matching the student's name.
3. **eKYC Aadhaar**: The frontend features an interactive mock XML generator enabling students to create custom Aadhaar offline XML files matching their profile fields.
4. **OTP Dispatch**: OTP codes are written to the local filesystem at `scratch/mock_otp.txt` instead of calling real SMS gateways.

---

## 12. Installation & Setup
Follow these steps to set up a fresh local installation:

### Prerequisites:
* **Node.js** (v18+)
* **NPM** (packaged with Node.js)
* **MySQL / MariaDB** (Optional, e.g. bundled in XAMPP)

### Steps:
1. **Install Dependencies**:
   ```bash
   npm install
   ```
2. **Configure Environment Variables**:
   Create a local configuration file from the template:
   ```bash
   cp .env.example .env
   ```
   *(By default, `.env` runs zero-config SQLite mode, creating a local `database.sqlite` file).*
3. **Initialize Database** (For MySQL/MariaDB only):
   Ensure your MySQL server is running, create the database, and run migrations:
   ```bash
   node database/migrate.js
   ```
4. **Run the Application**:
   ```bash
   npm run dev
   ```
   The application is served at **http://localhost:3000**.

---

## 13. Usage Guide

### Demo User Accounts:
The system is seeded with two reference accounts for testing (Password: `Password@123`):
* **Student**: `student@dpi.edu` / Mobile: `9111122222`
* **Professor**: `prof@dpi.edu` / Mobile: `9444455555`

### Driving the Student Journey:
1. Open http://localhost:3000, select **Register**, solve the CAPTCHA, and create a Student account.
2. Sign in with the registered credentials and complete the CAPTCHA.
3. Open `scratch/mock_otp.txt` in the workspace to retrieve the generated OTP code, enter it, and submit.
4. On the Dashboard, go to **My Profile**, enter demographic details, upload the mock photo `scratch/bob_avatar.jpg`, and save.
5. In **Admission Application**, run through the pre-filled forms. Generate the mock Aadhaar XML file, upload it, and click verify. Link DigiLocker, approve consent in the popup, select CBSE Marksheet, and retrieve it.
6. Initiate digital signature, click sign, check the declaration, and submit.

### Reviewing as a Professor:
1. Log in with `prof@dpi.edu` / `Password@123`, retrieve OTP from `scratch/mock_otp.txt`, and log in.
2. Search for the student by name or filter by application status.
3. Click review, view demographic/marksheet files, and submit a decision (Approve, Reject, or Correction).

---

## 14. Known Limitations & Future Improvements
1. **OAuth Redirects**: DigiLocker OAuth popup relies on local postMessage events. In multi-domain production environments, callback routes must redirect to dedicated domain receivers.
2. **Memory Locks**: SQLite locks files during write sessions. Real production deployment requires transitioning to the MySQL/MariaDB connection pool.
3. **Audit Scaling**: Audit logs are written directly to database tables. For large institutions, a centralized stream processor (e.g., Elasticsearch or Google Cloud Logging) should ingest these logs.

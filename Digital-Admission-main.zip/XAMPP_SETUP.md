# XAMPP / Local MySQL Database Setup Guide

This document describes how to configure a local MySQL/MariaDB database using **XAMPP** (or any standalone MySQL installation) for the **Digital Student Admission System**.

---

## 1. Prerequisites
* Install [XAMPP](https://www.apachefriends.org/index.html) (with MySQL/MariaDB module).
* Ensure Node.js (v18+) is installed.

---

## 2. Configuration Steps

### Step 1: Boot MySQL Server in XAMPP
1. Open the **XAMPP Control Panel**.
2. Click the **Start** button next to the **MySQL** module (and **Apache** if you wish to use phpMyAdmin).
3. Verify the status indicator turns green (default port `3306`).

### Step 2: Create the Database
1. Open your web browser and go to: `http://localhost/phpmyadmin/`
2. Click on the **Databases** tab.
3. Under **Create database**, enter `dpi_student_admission`.
4. Select `utf8mb4_unicode_ci` as the collation/encoding.
5. Click **Create**.

### Step 3: Configure Environment Variables
In your project directory, open your `.env` file and set the following values:
```env
# Database Configuration
DB_TYPE=mysql

# MySQL Specific Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=                  # Default XAMPP password is empty
DB_NAME=dpi_student_admission
```

### Step 4: Run Migrations and Seeds
You can initialize the database tables and reference data automatically:

#### Method A: Programmatic Execution (Recommended)
Run the migration script:
```bash
node database/migrate.js
```
Followed by inserting seed data:
```bash
# Set DB_TYPE=mysql temporarily in command shell or run seeds manually
```
Wait! To seed the MySQL database easily, you can also import `database/schema.sql` and `database/seeds/seed.sql` directly.

#### Method B: Manual import via phpMyAdmin
1. Select the `dpi_student_admission` database in phpMyAdmin.
2. Go to the **Import** tab.
3. Choose the file `database/schema.sql` and click **Go** / **Import**.
4. Repeat the import process for the seed data file `database/seeds/seed.sql` to populate demo accounts.

---

## 3. Verify Local Development Setup
Run the startup command:
```bash
npm run dev
```
Open `http://localhost:3000` in your web browser. You should be able to log in using the seeded demo credentials:
* **Student**: `student@dpi.edu` / `Password@123`
* **Professor**: `prof@dpi.edu` / `Password@123`

---

## 4. Verified MySQL/MariaDB Compatibility (Module 21)

This project was run end-to-end against a real MySQL-compatible server (MariaDB 10.11) — not just SQLite — to confirm the dual-driver layer actually works, not merely that it compiles. That pass surfaced and fixed two real cross-driver bugs that would affect **any** MySQL/MariaDB backend, including a real XAMPP install:

1. **DATE columns**: `mysql2` returns `DATE`/`DATETIME`/`TIMESTAMP` columns as JS `Date` objects by default. Once serialized to JSON, a `DATE` value like `2005-12-01` becomes `2005-12-01T00:00:00.000Z` — inconsistent with SQLite (which returns the plain string) and prone to shifting by a day depending on server timezone. **Fix**: `backend/config/db.js` now creates the MySQL pool with `dateStrings: true`, so both drivers return plain date strings consistently.
2. **DECIMAL columns**: `mysql2` returns `DECIMAL` columns (e.g. profile completion `percentage`) as strings (e.g. `"85.50"`) to avoid floating-point precision loss — SQLite returns a number. **Fix**: `profileController.js` now explicitly coerces the `percentage` field to `Number(...)` before returning it, so the API response shape is identical regardless of which database is configured.

**Verification performed in this pass:**
- Ran the full Jest suite (11 suites / 84 tests) against a live MariaDB instance with `DB_TYPE=mysql` — all passing, matching the SQLite result exactly.
- Ran `scratch/e2e_api_journey.js` (the 17-step registration → approval user journey) against MySQL — all steps passed.
- Booted `backend/server.js` with `DB_TYPE=mysql` and drove it over real HTTP (`curl`): fetched a CAPTCHA, registered a user, and confirmed the row landed in the actual `users` table via a direct MySQL query — not just an API 200 response.

If you're setting this up in real XAMPP and see a date rendering oddly or a percentage value showing as a quoted string in raw API responses, make sure you're on this version of `backend/config/db.js` and `profileController.js`.

# Student–Professor Role-Based Authentication Module

## Purpose

This module separates **Student**, **Professor**, and optional **Admin** accounts in the Digital Student Admission System using PHP + MySQL on XAMPP.

The Module 2 notes specify a registration flow for **Student / Professor** and a common login flow of **existing Gmail ID → password → OTP authentication → dashboard**. This module implements that separation using a database `role` field and server-side access control.

> Source basis: `DPI_Module2_Notes.pdf` — Module 2 Project Work Stage. The notes require registration/login, mathematical CAPTCHA, OTP-based authentication, and dashboards.

---

## 1. Core Design

Use **one authentication system** with role-based authorization:

```text
                         LOGIN / REGISTRATION
                                  |
                         OTP AUTHENTICATION
                                  |
                         Check authenticated role
                                  |
              +-------------------+-------------------+
              |                   |                   |
           STUDENT             PROFESSOR            ADMIN
              |                   |                   |
       Student Dashboard    Professor Dashboard   Admin Dashboard
```

The important distinction is:

- Authentication answers: **Who is this user?**
- Authorization answers: **What is this user allowed to access?**

A student must never gain professor access merely by changing a URL.

---

## 2. Recommended Project Structure

```text
digital-student-admission/
│
├── index.php
│
├── config/
│   └── database.php
│
├── auth/
│   ├── register.php
│   ├── login.php
│   ├── send_otp.php
│   ├── verify_otp.php
│   ├── logout.php
│   └── captcha.php
│
├── includes/
│   ├── auth.php
│   ├── session.php
│   └── functions.php
│
├── student/
│   ├── dashboard.php
│   ├── profile.php
│   ├── ekyc.php
│   ├── digilocker.php
│   ├── admission.php
│   ├── documents.php
│   └── application_status.php
│
├── professor/
│   ├── dashboard.php
│   ├── students.php
│   ├── applications.php
│   ├── application_view.php
│   ├── verify_student.php
│   └── approve_application.php
│
├── admin/
│   └── dashboard.php
│
├── api/
│   ├── otp/
│   ├── ekyc/
│   ├── digilocker/
│   └── esign/
│
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
│
└── database/
    └── schema.sql
```

---

# 3. Database

Create the database:

```sql
CREATE DATABASE digital_admission
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE digital_admission;
```

## Users Table

```sql
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    name VARCHAR(100) NOT NULL,

    email VARCHAR(150) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    role ENUM('student', 'professor', 'admin')
        NOT NULL DEFAULT 'student',

    student_id VARCHAR(50) NULL UNIQUE,

    professor_id VARCHAR(50) NULL UNIQUE,

    otp_hash VARCHAR(255) NULL,

    otp_expiry DATETIME NULL,

    otp_attempts INT UNSIGNED NOT NULL DEFAULT 0,

    is_verified TINYINT(1) NOT NULL DEFAULT 0,

    status ENUM('active', 'inactive', 'pending')
        NOT NULL DEFAULT 'active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
);
```

### Role meanings

| Role | Purpose |
|---|---|
| `student` | Student admission activities |
| `professor` | Review and process student applications |
| `admin` | System/user administration |

For production-like security, professor accounts should preferably be approved by an administrator instead of allowing unrestricted public professor registration.

---

# 4. Applications Table

Student admission applications must be separate from authentication accounts.

```sql
CREATE TABLE applications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    student_id INT UNSIGNED NOT NULL,

    application_number VARCHAR(50) NOT NULL UNIQUE,

    course VARCHAR(150) NOT NULL,

    status ENUM(
        'draft',
        'submitted',
        'under_review',
        'approved',
        'rejected'
    ) NOT NULL DEFAULT 'draft',

    professor_id INT UNSIGNED NULL,

    professor_remarks TEXT NULL,

    submitted_at DATETIME NULL,

    reviewed_at DATETIME NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_application_student
        FOREIGN KEY (student_id)
        REFERENCES users(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT fk_application_professor
        FOREIGN KEY (professor_id)
        REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);
```

Relationship:

```text
users
 |
 +-- student
 |      |
 |      +---- applications
 |
 +-- professor
        |
        +---- reviews applications
```

---

# 5. Registration

## Student Registration

Recommended flow:

```text
Student
   |
   +-- Name
   +-- Student ID
   +-- Gmail/Email
   +-- Password
   +-- Confirm Password
   +-- Mathematical CAPTCHA
   |
   +-- Email OTP
   |
   +-- Verify OTP
   |
   +-- Create student account
```

The registration must store:

```text
role = student
```

## Professor Registration

Recommended flow:

```text
Professor
   |
   +-- Name
   +-- Professor ID
   +-- College Email
   +-- Password
   +-- Confirm Password
   +-- Mathematical CAPTCHA
   |
   +-- Email OTP
   |
   +-- Admin approval (recommended)
   |
   +-- Activate professor account
```

The account must store:

```text
role = professor
```

Do not trust a hidden HTML field such as:

```html
<input type="hidden" name="role" value="professor">
```

without server-side validation.

The server must decide whether the requested role is permitted.

---

# 6. Login

Use one common login page.

```text
+--------------------------------------+
|       Digital Admission Portal      |
|                                      |
| Email / Gmail                        |
| [____________________________]       |
|                                      |
| Password                             |
| [____________________________]       |
|                                      |
| Mathematical CAPTCHA                 |
| 7 + 5 = [________]                   |
|                                      |
|             [ SEND OTP ]             |
+--------------------------------------+
```

Login flow:

```text
Email
  |
Password verification
  |
CAPTCHA verification
  |
OTP generation
  |
OTP sent to registered email
  |
OTP verification
  |
Load user role
  |
+-----------+------------+----------+
| Student   | Professor  | Admin    |
+-----------+------------+----------+
      |           |           |
      v           v           v
 Student       Professor    Admin
 Dashboard     Dashboard    Dashboard
```

This follows the Module 2 notes' stated login sequence: existing Gmail ID, password, OTP authentication, and dashboard.

---

# 7. Password Security

Never store plain-text passwords.

During registration:

```php
$passwordHash = password_hash(
    $password,
    PASSWORD_DEFAULT
);
```

Store `$passwordHash` in the `password` column.

During login:

```php
if (!password_verify($password, $user['password'])) {
    // Invalid credentials
}
```

Never do:

```php
$password = $_POST['password'];
```

and store that value directly in MySQL.

---

# 8. PDO Database Connection

`config/database.php`

```php
<?php

declare(strict_types=1);

$host = '127.0.0.1';
$db   = 'digital_admission';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    error_log($e->getMessage());
    exit('Database connection failed.');
}
```

Use prepared statements for database queries.

---

# 9. Session Security

After successful login:

```php
session_regenerate_id(true);

$_SESSION['user_id'] = $user['id'];
$_SESSION['name']     = $user['name'];
$_SESSION['email']    = $user['email'];
$_SESSION['role']     = $user['role'];
```

Do not allow the browser to decide the user's role.

The role must come from the authenticated database record.

---

# 10. Role Protection

Create:

`includes/auth.php`

```php
<?php

declare(strict_types=1);

function requireLogin(): void
{
    if (
        !isset($_SESSION['user_id']) ||
        !isset($_SESSION['role'])
    ) {
        header('Location: ../auth/login.php');
        exit;
    }
}

function requireRole(string $requiredRole): void
{
    requireLogin();

    if ($_SESSION['role'] !== $requiredRole) {
        http_response_code(403);
        exit('Access denied.');
    }
}
```

Start the session before using these functions:

```php
session_start();
```

---

# 11. Student Dashboard Protection

`student/dashboard.php`

```php
<?php

session_start();

require_once '../includes/auth.php';

requireRole('student');

?>
```

This means only:

```text
role = student
```

can access the student dashboard.

---

# 12. Professor Dashboard Protection

`professor/dashboard.php`

```php
<?php

session_start();

require_once '../includes/auth.php';

requireRole('professor');

?>
```

This means only:

```text
role = professor
```

can access the professor dashboard.

---

# 13. Admin Dashboard Protection

`admin/dashboard.php`

```php
<?php

session_start();

require_once '../includes/auth.php';

requireRole('admin');

?>
```

---

# 14. Login Redirect

After password and OTP verification:

```php
session_regenerate_id(true);

$_SESSION['user_id'] = $user['id'];
$_SESSION['name'] = $user['name'];
$_SESSION['email'] = $user['email'];
$_SESSION['role'] = $user['role'];

switch ($user['role']) {

    case 'student':
        header('Location: ../student/dashboard.php');
        exit;

    case 'professor':
        header('Location: ../professor/dashboard.php');
        exit;

    case 'admin':
        header('Location: ../admin/dashboard.php');
        exit;

    default:
        session_destroy();
        header('Location: login.php?error=invalid_role');
        exit;
}
```

---

# 15. Student Dashboard

The student dashboard should contain functions such as:

```text
Student Dashboard

Welcome, [Student Name]

[ My Profile ]

[ eKYC Verification ]

[ DigiLocker ]

[ Admission Application ]

[ Documents ]

[ Application Status ]

[ Notifications ]

[ Logout ]
```

The student should be able to:

- Complete their profile
- Perform identity verification
- Use the supported document workflow
- Submit an admission application
- View application status
- View relevant notifications

---

# 16. Professor Dashboard

The professor dashboard should contain:

```text
Professor Dashboard

Welcome, [Professor Name]

Total Applications
Pending Review
Approved
Rejected

[ Student Applications ]

[ Pending Verification ]

[ Verified Students ]

[ View Documents ]

[ Approve / Reject ]

[ Notifications ]

[ Logout ]
```

The professor should be able to:

- View assigned/relevant student applications
- Review application information
- Review available verification/document status
- Add remarks
- Approve an application
- Reject an application
- View application status

---

# 17. Student-to-Professor Workflow

The student does not become a professor.

Instead:

```text
STUDENT
   |
   +--> Register
   |
   +--> Login + OTP
   |
   +--> Complete application
   |
   +--> Submit application
   |
   v
APPLICATION = submitted
   |
   v
PROFESSOR
   |
   +--> Login + OTP
   |
   +--> View application
   |
   +--> Review
   |
   +--> Approve / Reject
   |
   v
APPLICATION STATUS
   |
   v
STUDENT
```

Possible status transitions:

```text
draft
  |
  v
submitted
  |
  v
under_review
  |
  +-------> approved
  |
  +-------> rejected
```

---

# 18. Application Ownership

A student must only be able to access their own applications.

For example:

```sql
SELECT *
FROM applications
WHERE id = ?
AND student_id = ?
```

Do not use:

```sql
SELECT *
FROM applications
WHERE id = ?
```

and trust the URL parameter alone.

The authenticated student's ID must be included in the authorization check.

---

# 19. Professor Application Access

Professor access should also be authorized.

For example, if an application is assigned to a professor:

```sql
SELECT *
FROM applications
WHERE id = ?
AND professor_id = ?
```

If your project later allows any authorized professor to review applications, implement that rule explicitly rather than bypassing authorization.

---

# 20. Approval Logic

When a professor approves an application:

```text
Verify professor session
        |
Verify application exists
        |
Verify professor is authorized
        |
Update status
        |
Store professor remarks
        |
Store reviewed_at
        |
Return success
```

Example SQL:

```sql
UPDATE applications
SET
    status = 'approved',
    professor_id = ?,
    professor_remarks = ?,
    reviewed_at = NOW()
WHERE id = ?
AND status = 'under_review';
```

Use a transaction if multiple related records must be updated.

---

# 21. Rejection Logic

Similarly:

```sql
UPDATE applications
SET
    status = 'rejected',
    professor_id = ?,
    professor_remarks = ?,
    reviewed_at = NOW()
WHERE id = ?
AND status = 'under_review';
```

The professor should be required to provide a meaningful reason before rejection.

---

# 22. Logout

`auth/logout.php`

```php
<?php

session_start();

$_SESSION = [];

if (ini_get('session.use_cookies')) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

header('Location: login.php');
exit;
```

---

# 23. Security Requirements

The implementation must include:

- Password hashing using `password_hash()`
- Password verification using `password_verify()`
- PDO prepared statements
- Session regeneration after login
- Server-side role validation
- Server-side authorization on every protected page
- OTP expiry
- OTP attempt limits
- Secure session handling
- CSRF protection for state-changing forms
- Input validation
- Output escaping with `htmlspecialchars()`
- No passwords in logs
- No OTP values in logs
- No role decisions based only on client-side JavaScript
- No role decisions based only on hidden HTML fields

---

# 24. Important Role-Separation Test Cases

The implementation is not complete until these tests pass.

## Student tests

```text
[ ] Student can register
[ ] Student receives OTP
[ ] Student can verify OTP
[ ] Student can log in
[ ] Student is redirected to student/dashboard.php
[ ] Student can access student pages
[ ] Student cannot access professor dashboard
[ ] Student cannot access admin dashboard
[ ] Student can see their own application
[ ] Student cannot access another student's application
```

## Professor tests

```text
[ ] Professor account can be created through the approved flow
[ ] Professor receives OTP
[ ] Professor can log in
[ ] Professor is redirected to professor/dashboard.php
[ ] Professor can access professor pages
[ ] Professor cannot access student-only pages
[ ] Professor cannot access admin-only pages
[ ] Professor can review authorized applications
[ ] Professor can approve an application
[ ] Professor can reject an application
```

## Admin tests

```text
[ ] Admin can log in
[ ] Admin reaches admin dashboard
[ ] Admin can manage authorized users
[ ] Admin-only pages reject students
[ ] Admin-only pages reject professors
```

---

# 25. URL Tampering Tests

These tests are mandatory.

While logged in as a student, manually open:

```text
http://localhost/digital-student-admission/professor/dashboard.php
```

Expected:

```text
403 Access Denied
```

While logged in as a professor, open:

```text
http://localhost/digital-student-admission/student/dashboard.php
```

Expected:

```text
403 Access Denied
```

While logged in as a student, try another student's application ID.

Expected:

```text
Access denied / application not found
```

Do not expose another student's information.

---

# 26. UI Recommendation

Use a single modern authentication interface.

Registration:

```text
+-------------------------------------------+
|       Digital Student Admission System    |
|                                           |
|              Create Account               |
|                                           |
|        [ Student ] [ Professor ]          |
|                                           |
| Name                                      |
| [____________________________________]    |
|                                           |
| Student/Professor ID                      |
| [____________________________________]    |
|                                           |
| Gmail / College Email                     |
| [____________________________________]    |
|                                           |
| Password                                  |
| [____________________________________]    |
|                                           |
| Confirm Password                          |
| [____________________________________]    |
|                                           |
| CAPTCHA                                   |
| 8 + 4 = [________]                        |
|                                           |
|             [ Register ]                  |
+-------------------------------------------+
```

Login:

```text
+-------------------------------------------+
|       Digital Student Admission System    |
|                                           |
|                   Login                   |
|                                           |
| Email                                     |
| [____________________________________]    |
|                                           |
| Password                                  |
| [____________________________________]    |
|                                           |
| CAPTCHA                                   |
| 7 + 5 = [________]                        |
|                                           |
|              [ Send OTP ]                 |
|                                           |
| OTP                                       |
| [____________________________________]    |
|                                           |
|               [ Login ]                   |
+-------------------------------------------+
```

---

# 27. Implementation Order

Implement this module in the following order:

```text
PHASE 1
Database
   ↓
users table
   ↓
applications table

PHASE 2
Database connection
   ↓
PDO
   ↓
error handling

PHASE 3
Registration
   ↓
Student
   ↓
Professor
   ↓
validation
   ↓
password hashing

PHASE 4
Mathematical CAPTCHA
   ↓
server-side validation

PHASE 5
Email OTP
   ↓
generate OTP
   ↓
hash OTP
   ↓
expiry
   ↓
send email
   ↓
verify OTP
   ↓
attempt limit

PHASE 6
Login
   ↓
email lookup
   ↓
password verification
   ↓
OTP verification
   ↓
session creation

PHASE 7
Role-based redirect
   ↓
Student Dashboard
   ↓
Professor Dashboard
   ↓
Admin Dashboard

PHASE 8
Authorization
   ↓
requireLogin()
   ↓
requireRole()
   ↓
resource ownership checks

PHASE 9
Application workflow
   ↓
Student submits
   ↓
Professor reviews
   ↓
Approve / Reject
   ↓
Student sees status

PHASE 10
Security testing
   ↓
URL tampering
   ↓
session testing
   ↓
role testing
   ↓
application ownership testing
```

---

# 28. Acceptance Criteria

The module is considered complete only when:

1. Student and professor accounts are stored with different roles.
2. The same authentication mechanism can identify both roles.
3. Passwords are never stored in plain text.
4. OTP authentication is required according to the project's authentication flow.
5. A student is redirected to the student dashboard.
6. A professor is redirected to the professor dashboard.
7. An admin is redirected to the admin dashboard.
8. Students cannot access professor pages.
9. Professors cannot access student-only pages.
10. Students cannot access other students' private application data.
11. Professor application actions are authorized server-side.
12. Direct URL manipulation cannot bypass role restrictions.
13. Logout destroys the authenticated session.
14. Database operations use prepared statements.
15. All important authorization checks occur on the server.
16. The system remains compatible with the later eKYC, DigiLocker, and eSign/eSignzy modules.

---

# 29. Integration With the Rest of the DPI Project

This role system should be treated as the authentication/authorization foundation for the rest of the project:

```text
                 ROLE-BASED AUTHENTICATION
                           |
          +----------------+----------------+
          |                |                |
       STUDENT         PROFESSOR          ADMIN
          |                |                |
          v                v                v
        eKYC          Application        User
          |             Review          Management
          v                |
     DigiLocker            |
          |                |
          +-------+--------+
                  |
                  v
          Admission Workflow
                  |
                  v
             eSign/eSignzy
                  |
                  v
          Paperless Processing
```

Do not implement eKYC, DigiLocker, or signing permissions before the role and authorization layer is working correctly.

---

# 30. Developer Instruction

When implementing this module:

> Build the Student/Professor/Admin role-based authentication system for the existing XAMPP + PHP + MySQL Digital Student Admission System. Use one common authentication flow with email/Gmail, password, mathematical CAPTCHA, and email OTP, then determine the authenticated user's role from MySQL and redirect to the correct dashboard. Store roles server-side using `student`, `professor`, and `admin`. Hash passwords and OTPs, use PDO prepared statements, secure sessions, server-side authorization, CSRF protection, OTP expiry and attempt limits. Create separate protected student, professor, and admin areas. Implement the admission application relationship so students can only access their own applications and authorized professors can review and approve/reject applications. Never trust role values supplied by the browser. Test direct URL access, session tampering, role escalation, and cross-student application access. Do not proceed to the next DPI module until all acceptance criteria and security tests pass.

---

## Source Alignment

The supplied Module 2 notes identify:

- Registration with Student / Professor selection
- Necessary details
- Mathematical CAPTCHA
- OTP authentication
- Login using existing Gmail ID
- Password
- OTP authentication
- Dashboard
- Required registration/login
- Mathematical CAPTCHA
- OTP-based authentication
- Dashboard

These requirements are taken directly from the supplied `DPI_Module2_Notes.pdf`. The notes also identify the broader project as the **Digital Student Admission System using SSO, eKYC, DigiLocker and Paperless Office Modules**.

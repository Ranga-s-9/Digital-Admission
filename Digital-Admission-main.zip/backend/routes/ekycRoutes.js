const express = require('express');
const router = express.Router();
const path = require('path');
const multer = require('multer');
const authenticateToken = require('../middleware/auth');
const rateLimiter = require('../middleware/rateLimiter');
const {
  generateMockXml,
  recordConsent,
  uploadFile,
  verifyEkyc,
  getEkycStatusById,
  getEkycResultById,
  getEkycHistory,
  getEkycStatus,
  verifyExternalEkyc
} = require('../controllers/ekycController');
const {
  ekycGenerateRules,
  ekycConsentRules,
  ekycVerifyRules,
  validate
} = require('../middleware/validation');

// Configure rate limits
const uploadLimiter = rateLimiter({
  windowMs: 15 * 60 * 1000, // 15 mins
  max: 10,
  message: 'Too many identity document upload attempts. Please try again later.'
});

const verifyLimiter = rateLimiter({
  windowMs: 15 * 60 * 1000, // 15 mins
  max: 10,
  message: 'Too many eKYC verification attempts. Please try again later.'
});

// Configure Multer for secure memory storage
const maxFileSize = parseInt(process.env.MAX_EKYC_FILE_SIZE || '5242880', 10); // Default: 5MB
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxFileSize },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.zip') {
      const err = new Error('INVALID_FILE');
      err.code = 'LIMIT_FILE_TYPE';
      return cb(err, false);
    }
    cb(null, true);
  }
});

// Helper middleware to handle multer errors (like file size limit exceeded)
const handleUploadMiddleware = (req, res, next) => {
  // Support both 'ekycZip', 'ekycFile', and 'file'
  const uploadFields = upload.single('ekycZip');
  
  uploadFields(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          success: false,
          message: 'The uploaded file exceeds the maximum size limit of 5MB.',
          error: { global: 'FILE_TOO_LARGE' }
        });
      }
      return res.status(400).json({
        success: false,
        message: err.message || 'File upload failed.',
        error: { global: 'INVALID_FILE' }
      });
    }
    next();
  });
};

// 1. POST /api/ekyc/consent - Record consent
router.post('/consent', authenticateToken, ekycConsentRules, validate, recordConsent);

// 2. POST /api/ekyc/upload - Upload Offline e-KYC ZIP
router.post('/upload', authenticateToken, uploadLimiter, handleUploadMiddleware, uploadFile);

// 3. POST /api/ekyc/verify - Upload, parse and verify Aadhaar Offline XML
router.post('/verify', authenticateToken, verifyLimiter, ekycVerifyRules, validate, verifyEkyc);

// 4. GET /api/ekyc/status/:verificationId - Retrieve active student eKYC status details by ID
router.get('/status/:verificationId', authenticateToken, getEkycStatusById);

// 5. GET /api/ekyc/result/:verificationId - Retrieve final eKYC result details by ID
router.get('/result/:verificationId', authenticateToken, getEkycResultById);

// 6. GET /api/ekyc/history - Get student eKYC verification history
router.get('/history', authenticateToken, getEkycHistory);

// 7. GET /api/ekyc/status - Retrieve default student eKYC status details (backward compatible)
router.get('/status', authenticateToken, getEkycStatus);

// 8. POST /api/ekyc/generate-mock-xml - Generate Aadhaar Offline Secure XML
router.post('/generate-mock-xml', authenticateToken, ekycGenerateRules, validate, generateMockXml);

// 9. POST /api/ekyc/verify-external - Verify externally-validated Aadhaar eKYC (webcam scan / XML)
router.post('/verify-external', authenticateToken, verifyExternalEkyc);

module.exports = router;

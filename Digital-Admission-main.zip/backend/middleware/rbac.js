/**
 * Middleware to enforce Role-Based Access Control (RBAC)
 * Requires req.user to be populated by authenticateToken middleware
 */
function requireRole(allowedRoles) {
  const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
  
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Access denied: User is not authenticated',
        error: {
          auth: 'Authentication required'
        }
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Access denied: You do not have the required permissions to view this resource',
        error: {
          auth: 'Forbidden'
        }
      });
    }

    next();
  };
}

module.exports = {
  requireRole
};

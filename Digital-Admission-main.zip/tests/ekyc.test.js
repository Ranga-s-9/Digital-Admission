process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_ekyc.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('eKYC Verification API and Adapter tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM ekyc_requests');
    await db.query('DELETE FROM ekyc_audit_logs');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {
        // Ignored
      }
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_ekyc.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedUser(email, password, name = 'Alice Student') {
    const cap = await getValidCaptcha();
    const mobile = email === 'alice@student.com' ? '9111122222' : `9${Math.floor(100000000 + Math.random() * 900000000)}`;
    await request(app)
      .post('/api/auth/register')
      .send({
        name,
        email,
        mobile,
        password,
        confirmPassword: password,
        role: 'student',
        ...cap
      });

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });

    const cookie = verifyRes.headers['set-cookie'][0];
    const userId = verifyRes.body.data.userId;

    // Initialize student profile (required for eKYC match validation)
    await request(app)
      .put(`/api/profile/${userId}`)
      .set('Cookie', cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50,
        version: 1
      });

    return { userId, cookie };
  }

  // --- XML Test Helpers ---
  function makeXml(name, dob, gender, pc, shareCode = '1234') {
    return `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="${shareCode}">
  <UidData>
    <Poi name="${name}" dob="${dob}" gender="${gender}"/>
    <Poa co="Guardian" street="123 Main St" state="Delhi" pc="${pc}"/>
    <Pht>photo_data</Pht>
  </UidData>
  <Signature>trusted_root_signature</Signature>
</OfflinePaperlessKyc>`;
  }

  // --- TEST CASES ---

  test('1. Unauthorized requests are blocked from eKYC endpoints', async () => {
    const res = await request(app)
      .get('/api/ekyc/status');

    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
  });

  test('2. Successfully verify eKYC with matching profile data', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'Alice Student');

    const validXml = makeXml('Alice Student', '2005-05-15', 'Female', '110001');

    const res = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXml,
        shareCode: '1234',
        consent: true
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.status).toBe('VERIFIED');

    // Query status back
    const statusRes = await request(app)
      .get('/api/ekyc/status')
      .set('Cookie', student.cookie);

    expect(statusRes.statusCode).toBe(200);
    expect(statusRes.body.data.verified).toBe(true);
    expect(statusRes.body.data.status).toBe('VERIFIED');
    expect(statusRes.body.data.aadhaarMasked).toBe('XXXX-XXXX-9999');

    // Verify audit log has been recorded
    const auditLogs = await db.query('SELECT action, details FROM ekyc_audit_logs WHERE user_id = ? AND action = ?', [student.userId, 'VERIFY_SUCCESS']);
    expect(auditLogs.length).toBe(1);
  });

  test('3. Verification fails on identity field mismatch', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'Alice Student');

    // DOB Mismatch
    const mismatchXml = makeXml('Alice Student', '2004-05-15', 'Female', '110001');

    const res = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: mismatchXml,
        shareCode: '1234',
        consent: true
      });

    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('verification failed');

    // Check request status
    const statusRes = await request(app)
      .get('/api/ekyc/status')
      .set('Cookie', student.cookie);

    expect(statusRes.body.data.status).toBe('FAILED');
    expect(statusRes.body.data.verified).toBe(false);

    // Verify audit log recorded failed attempt
    const auditLogs = await db.query('SELECT action FROM ekyc_audit_logs WHERE user_id = ? AND action = ?', [student.userId, 'VERIFY_FAILED']);
    expect(auditLogs.length).toBe(1);
  });

  test('4. Rejects request with malformed XML', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    const res = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: '<OfflinePaperlessKyc shareCode="1234">Broken</NoClosingTag>',
        shareCode: '1234',
        consent: true
      });

    expect(res.statusCode).toBe(400);
    expect(res.body.message).toContain('Malformed XML');
  });

  test('5. Rejects request with missing consent or empty share code', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');
    const validXml = makeXml('Alice Student', '2005-05-15', 'Female', '110001');

    // Missing consent
    const resConsent = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXml,
        shareCode: '1234',
        consent: false
      });
    expect(resConsent.statusCode).toBe(400);
    expect(resConsent.body.message).toContain('Consent is mandatory');

    // Empty share code
    const resShare = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXml,
        shareCode: '',
        consent: true
      });
    expect(resShare.statusCode).toBe(400);
    expect(resShare.body.message).toContain('share code');
  });

  test('6. Propagates external failures and simulated timeouts correctly', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // External Failure simulation trigger
    const failXml = makeXml('Simulate External Failure', '2005-05-15', 'Female', '110001');
    const resFail = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: failXml,
        shareCode: '1234',
        consent: true
      });
    expect(resFail.statusCode).toBe(502);
    expect(resFail.body.message).toContain('gateway service is currently unavailable');

    // Timeout simulation trigger
    const timeoutXml = makeXml('Simulate Timeout', '2005-05-15', 'Female', '110001');
    const resTimeout = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: timeoutXml,
        shareCode: '1234',
        consent: true
      });
    expect(resTimeout.statusCode).toBe(504);
    expect(resTimeout.body.message).toContain('timed out');
  });

  test('7. Prevents duplicate verification on already verified accounts', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');
    const validXml = makeXml('Alice Student', '2005-05-15', 'Female', '110001');

    // First verification success
    await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXml,
        shareCode: '1234',
        consent: true
      });

    // Second verification request -> rejected as duplicate
    const resDup = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXml,
        shareCode: '1234',
        consent: true
      });

    expect(resDup.statusCode).toBe(400);
    expect(resDup.body.message).toContain('already been successfully completed');
  });

  test('8. Consent API endpoint records and validates consent correctly', async () => {
    const student = await getAuthenticatedUser('alice2@student.com', 'Password@123');
    
    // Consent true
    const resConsent = await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });
    expect(resConsent.statusCode).toBe(200);
    expect(resConsent.body.success).toBe(true);
    expect(resConsent.body.data.consentVersion).toBe('1.0');

    // Consent false
    const resConsentFalse = await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: false });
    expect(resConsentFalse.statusCode).toBe(400);
  });

  test('9. File upload endpoint checks consent, size, and ZIP extension', async () => {
    const student = await getAuthenticatedUser('alice3@student.com', 'Password@123');

    // Attempt upload without consent -> blocked
    const resNoConsent = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', Buffer.from('dummy'), 'test.zip');
    expect(resNoConsent.statusCode).toBe(400);
    expect(resNoConsent.body.error.global).toBe('CONSENT_REQUIRED');

    // Give consent
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    // Upload invalid extension -> rejected
    const resInvalidExt = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', Buffer.from('dummy'), 'test.txt');
    expect(resInvalidExt.statusCode).toBe(400);

    // Upload oversized file
    const largeBuffer = Buffer.alloc(6 * 1024 * 1024); // 6MB (limit is 5MB)
    const resOversized = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', largeBuffer, 'large.zip');
    expect(resOversized.statusCode).toBe(400);
    expect(resOversized.body.error.global).toBe('FILE_TOO_LARGE');
  });

  test('10. Safe ZIP extraction rejects invalid ZIP, missing XML, and traversal attempts', async () => {
    const student = await getAuthenticatedUser('alice4@student.com', 'Password@123');
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    const AdmZip = require('adm-zip');

    // Case A: Upload invalid ZIP file content
    const resBadZipUpload = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', Buffer.from('not a zip magic header'), 'broken.zip');
    expect(resBadZipUpload.statusCode).toBe(400);
    expect(resBadZipUpload.body.error.global).toBe('INVALID_ZIP');

    // Case B: Upload ZIP file missing XML
    const zipNoXml = new AdmZip();
    zipNoXml.addFile('dummy.txt', Buffer.from('hello world'));
    const uploadResB = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', zipNoXml.toBuffer(), 'noxml.zip');
    expect(uploadResB.statusCode).toBe(200);

    const verifyResB = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        verificationId: uploadResB.body.data.verificationId,
        shareCode: '1234'
      });
    expect(verifyResB.statusCode).toBe(400);
    expect(verifyResB.body.error.global).toBe('XML_NOT_FOUND');

    // Case C: Path Traversal inside ZIP
    const zipTraversal = new AdmZip();
    zipTraversal.addFile('../../etc/passwd', Buffer.from('root:x:0:0:root:/root:/bin/bash'));
    const uploadResC = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', zipTraversal.toBuffer(), 'traversal.zip');
    expect(uploadResC.statusCode).toBe(200);

    const verifyResC = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        verificationId: uploadResC.body.data.verificationId,
        shareCode: '1234'
      });
    expect(verifyResC.statusCode).toBe(400);

    // Case D: Encrypted ZIP with share code password
    const validXmlD = `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="1234">
  <UidData>
    <Poi name="Alice Student" dob="2005-05-15" gender="Female"/>
    <Poa co="Guardian" house="123" street="Main St" pc="110001"/>
  </UidData>
  <Signature>MockSignature</Signature>
</OfflinePaperlessKyc>`;
    const zipEncrypted = new AdmZip();
    zipEncrypted.addFile('aadhaar.xml', Buffer.from(validXmlD));
    const uploadResD = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', zipEncrypted.toBuffer(), 'aadhaar_encrypted.zip');
    expect(uploadResD.statusCode).toBe(200);

    const verifyResD = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        verificationId: uploadResD.body.data.verificationId,
        shareCode: '1234'
      });
    expect(verifyResD.statusCode).toBe(200);
    expect(verifyResD.body.data.status).toBe('VERIFIED');
  });

  test('11. Rejects malicious XML containing external entity definitions (XXE)', async () => {
    const student = await getAuthenticatedUser('alice5@student.com', 'Password@123');
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    // Construct XXE malicious XML content
    const maliciousXml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE test [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<OfflinePaperlessKyc shareCode="1234">
  <UidData>
    <Poi name="&xxe;" dob="2005-05-15" gender="Female"/>
    <Poa co="Guardian" street="123 Main St" state="Delhi" pc="110001"/>
    <Pht>photo</Pht>
  </UidData>
  <Signature>signature</Signature>
</OfflinePaperlessKyc>`;

    const AdmZip = require('adm-zip');
    const zip = new AdmZip();
    zip.addFile('xxe.xml', Buffer.from(maliciousXml));
    
    const uploadRes = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', student.cookie)
      .attach('ekycZip', zip.toBuffer(), 'xxe.zip');
    expect(uploadRes.statusCode).toBe(200);

    const verifyRes = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        verificationId: uploadRes.body.data.verificationId,
        shareCode: '1234'
      });
    expect(verifyRes.statusCode).toBe(400);
    expect(verifyRes.body.error.global).toBe('MALFORMED_XML');
  });

  test('12. Prevents Student A from accessing Student B\'s eKYC record', async () => {
    const studentA = await getAuthenticatedUser('studenta@student.com', 'Password@123', 'Student A');
    const studentB = await getAuthenticatedUser('studentb@student.com', 'Password@123', 'Student B');

    // Create verification request for Student B
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', studentB.cookie)
      .send({ consent: true });

    const validXmlB = makeXml('Student B', '2005-05-15', 'Female', '110001');
    const AdmZip = require('adm-zip');
    const zip = new AdmZip();
    zip.addFile('aadhaar.xml', Buffer.from(validXmlB));

    const uploadResB = await request(app)
      .post('/api/ekyc/upload')
      .set('Cookie', studentB.cookie)
      .attach('ekycZip', zip.toBuffer(), 'aadhaar.zip');
    
    const vId = uploadResB.body.data.verificationId;

    // Student A tries to check Student B's status -> rejected 403
    const resStatusA = await request(app)
      .get(`/api/ekyc/status/${vId}`)
      .set('Cookie', studentA.cookie);
    expect(resStatusA.statusCode).toBe(403);

    // Student A tries to get Student B's result -> rejected 403
    const resResultA = await request(app)
      .get(`/api/ekyc/result/${vId}`)
      .set('Cookie', studentA.cookie);
    expect(resResultA.statusCode).toBe(403);
  });

  test('13. Development mode is clearly labelled in status response', async () => {
    const student = await getAuthenticatedUser('alice6@student.com', 'Password@123');

    const res = await request(app)
      .get('/api/ekyc/status')
      .set('Cookie', student.cookie);
    
    expect(res.statusCode).toBe(200);
    expect(res.body.data.development_mode).toBe(true);
  });

  test('14. Mock XML generator endpoint generates valid XML and enforces field validation', async () => {
    const student = await getAuthenticatedUser('alice7@student.com', 'Password@123');

    // Happy Path
    const res = await request(app)
      .post('/api/ekyc/generate-mock-xml')
      .set('Cookie', student.cookie)
      .send({
        aadhaar: '123456789012',
        shareCode: '1234',
        name: 'Alice Student',
        dob: '2005-05-15',
        gender: 'Female',
        pincode: '110001',
        address: '123 Main St',
        state: 'Delhi'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.filename).toBe('aadhaar_offline_ekyc.xml');
    expect(res.body.data.xmlContent).toContain('<OfflinePaperlessKyc shareCode="1234"');
    expect(res.body.data.xmlContent).toContain('name="Alice Student"');
    expect(res.body.data.xmlContent).toContain('dob="2005-05-15"');
    expect(res.body.data.xmlContent).toContain('gender="Female"');

    // Validation failure (missing name)
    const resBad = await request(app)
      .post('/api/ekyc/generate-mock-xml')
      .set('Cookie', student.cookie)
      .send({
        aadhaar: '123456789012',
        shareCode: '1234',
        dob: '2005-05-15',
        gender: 'Female',
        pincode: '110001',
        address: '123 Main St',
        state: 'Delhi'
      });

    expect(resBad.statusCode).toBe(400);
    expect(resBad.body.success).toBe(false);
    expect(resBad.body.message).toContain('name is required');
  });

  test('15. XML validation supports case-insensitive gender validation', async () => {
    const student = await getAuthenticatedUser('alice8@student.com', 'Password@123', 'Alice Student');

    // Lowercase 'female' instead of 'Female'
    const validXmlLower = makeXml('Alice Student', '2005-05-15', 'female', '110001');

    const res = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: validXmlLower,
        shareCode: '1234',
        consent: true
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.status).toBe('VERIFIED');
  });

  test('16. POST /api/ekyc/verify-external matches demographic data and updates DB', async () => {
    const student = await getAuthenticatedUser('alice9@student.com', 'Password@123', 'Alice Student');

    // Mismatched demographic parameters (fails matching but does not block subsequent attempts as it sets status to FAILED)
    const resBad = await request(app)
      .post('/api/ekyc/verify-external')
      .set('Cookie', student.cookie)
      .send({
        name: 'Bob WrongName',
        dob: '2005-05-15',
        gender: 'Female',
        pincode: '110001',
        photo: 'mockphoto',
        method: 'Secure QR Code'
      });

    expect(resBad.statusCode).toBe(400);
    expect(resBad.body.success).toBe(false);
    expect(resBad.body.message).toContain('Identity mismatch');

    // Matching demographic parameters (succeeds and marks as VERIFIED)
    const res = await request(app)
      .post('/api/ekyc/verify-external')
      .set('Cookie', student.cookie)
      .send({
        name: 'Alice Student',
        dob: '2005-05-15',
        gender: 'Female',
        pincode: '110001',
        photo: 'mockphoto',
        method: 'Secure QR Code'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.status).toBe('VERIFIED');
  });

});

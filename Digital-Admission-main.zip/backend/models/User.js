const db = require('../config/db');

class User {
  /**
   * Find a user by their email address
   * @param {string} email 
   * @returns {Promise<Object|null>}
   */
  static async findByEmail(email) {
    const rows = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Find a user by their mobile number
   * @param {string} mobile 
   * @returns {Promise<Object|null>}
   */
  static async findByMobile(mobile) {
    const rows = await db.query('SELECT * FROM users WHERE mobile = ?', [mobile]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Find a user by their ID
   * @param {number} id 
   * @returns {Promise<Object|null>}
   */
  static async findById(id) {
    const rows = await db.query('SELECT * FROM users WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Create a new user in the database
   * @param {Object} userData
   * @param {string} userData.name
   * @param {string} userData.email
   * @param {string} userData.mobile
   * @param {string} userData.passwordHash
   * @param {string} [userData.role='student']
   * @param {string} [userData.status='active']
   * @returns {Promise<number>} - The inserted user ID
   */
  static async create({ name, email, mobile, passwordHash, role = 'student', status = 'active' }) {
    const sql = `
      INSERT INTO users (name, email, mobile, password_hash, role, status)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    const params = [name, email, mobile, passwordHash, role, status];
    const result = await db.query(sql, params);
    return result.insertId;
  }

  /**
   * Increment failed login attempts for a user
   * @param {number} id 
   * @returns {Promise<number>} - New failed attempts count
   */
  static async incrementFailedAttempts(id) {
    await db.query('UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?', [id]);
    const user = await this.findById(id);
    return user ? user.failed_attempts : 0;
  }

  /**
   * Reset failed login attempts for a user
   * @param {number} id 
   * @returns {Promise<boolean>}
   */
  static async resetFailedAttempts(id) {
    await db.query('UPDATE users SET failed_attempts = 0, lockout_until = 0 WHERE id = ?', [id]);
    return true;
  }

  /**
   * Lock a user account until a specific Unix timestamp
   * @param {number} id 
   * @param {number} lockoutUntil - Unix millisecond timestamp
   * @returns {Promise<boolean>}
   */
  static async lockAccount(id, lockoutUntil) {
    await db.query('UPDATE users SET lockout_until = ? WHERE id = ?', [lockoutUntil, id]);
    return true;
  }

  /**
   * Set the encrypted TOTP secret for a user
   * @param {number} id 
   * @param {string} encryptedSecret 
   * @returns {Promise<boolean>}
   */
  static async setTotpSecret(id, encryptedSecret) {
    await db.query('UPDATE users SET totp_secret = ?, totp_enabled = 0 WHERE id = ?', [encryptedSecret, id]);
    return true;
  }

  /**
   * Enable TOTP verification for a user
   * @param {number} id 
   * @returns {Promise<boolean>}
   */
  static async enableTotp(id) {
    await db.query('UPDATE users SET totp_enabled = 1 WHERE id = ?', [id]);
    return true;
  }

  /**
   * Update user's password hash
  /**
   * Update user's password hash
   * @param {number} id 
   * @param {string} passwordHash 
   * @returns {Promise<boolean>}
   */
  static async updatePassword(id, passwordHash) {
    await db.query('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, id]);
    return true;
  }

  /**
   * Update user's full name
   * @param {number} id 
   * @param {string} name 
   * @returns {Promise<boolean>}
   */
  static async updateName(id, name) {
    await db.query('UPDATE users SET name = ? WHERE id = ?', [name, id]);
    return true;
  }
}

module.exports = User;

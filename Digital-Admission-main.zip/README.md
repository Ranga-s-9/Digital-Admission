# Digital Student Admission System

The **Digital Student Admission System** is a modern, modular, production-ready web application designed following standard Digital Public Infrastructure (DPI) principles. The system uses a clean decoupled architecture supporting SSO, eKYC, DigiLocker, and Paperless Office Modules.

Currently, **Module 1: User Registration**, **Module 2: Mathematical CAPTCHA**, **Module 3: Secure Login**, **Module 4: OTP Authentication**, **Module 5: Authenticated Dashboard**, **Module 6: Student Profile**, **Module 7: Admission Application**, **Module 8: eKYC Integration**, **Module 9: DigiLocker Integration**, **Module 10: Paperless Office Workflow**, **Module 11: emSigner Signature**, **Module 12: Professor Review Panel**, **Module 13: Notification System**, and **Module 14: Centralized Audit Logging** are fully implemented.

---

## 🛠️ Technology Stack

- **Backend**: Node.js & Express.js
- **Database**: SQLite3 (Local zero-config development) & MySQL/MariaDB compatible connection layer
- **Security**: Helmet, CORS, express-validator, bcryptjs password hashing
- **Frontend**: Responsive HSL Glassmorphism UI using semantic HTML, Vanilla CSS, and JavaScript
- **Testing**: Jest & Supertest

---

## 📂 Project Structure

```
├── backend/
│   ├── config/
│   │   └── db.js            # Unified SQLite/MySQL DB pool wrapper
│   ├── controllers/         # Business logic handlers
│   ├── middleware/          # Security headers, RBAC and validation checks
│   ├── models/              # Database models
│   ├── routes/              # Express API endpoints
│   ├── services/            # OTP and DB initialization services
│   ├── app.js               # Express application config
│   └── server.js            # Server entry point
├── docs/                    # Architectural and module guides
├── frontend/                # Glassmorphic Single Page Application
├── tests/                   # Jest integration and validation tests
├── .env.example             # Blueprint settings
├── DEVELOPMENT_STATUS.md    # Living log of modules
├── CHANGELOG.md             # Version history
└── FINAL_PROJECT_REPORT.md  # Comprehensive project report
```

---

## 🚀 Quick Start Guide

### 1. Prerequisites

Ensure you have [Node.js](https://nodejs.org) (v18+) installed.

### 2. Installation

Install project dependencies:
```bash
npm install
```

### 3. Environment Setup

Create local environment configurations from the template:
```bash
cp .env.example .env
```
*(By default, `.env` is configured to run SQLite locally without any server setup).*

### 4. Running the Server

Start the application in development mode:
```bash
npm run dev
```
The server will boot, automatically initialize database tables/indexes, and serve the application on:
**[http://localhost:3000](http://localhost:3000)**

---

## 🧪 Testing

Execute the automated test suite testing validation rules, registration flow, SQL injection attempts, and XSS escapes:
```bash
npm test
```

---

## 🔒 Security Summary

1. **SQL Injection Protection**: Parameters are bound using prepared statements inside the database interface.
2. **XSS Protection**: Inputs are thoroughly sanitized and HTML-escaped on the server before storage.
3. **Password Security**: Passwords are never stored in plaintext. They are encrypted using `bcryptjs` with a cost factor of 10.
4. **Header Protection**: Standard security headers (CSP, HSTS, Frame Options) are managed using `helmet`.
5. **Anti-Automation (CAPTCHA)**: Integrates mathematical challenges with a maximum threshold of 3 attempts, a 2-minute lifetime, and immediate invalidation on verification to prevent replay attacks and scripts.
6. **Session & JWT Security**: Stateless authentication is implemented using secure HTTP-only cookies containing JSON Web Tokens (JWT) with a SameSite=Strict flag to prevent CSRF and token access via malicious scripts.
7. **Brute Force Lockout**: Failed login attempt counters are tracked. Accounts are automatically frozen for 15 minutes after 5 consecutive failed login attempts to prevent brute force attacks, and generic error responses are returned to prevent user/email enumeration.
8. **Two-Factor Authentication (OTP)**: Implements secondary verification checking randomized 6-digit codes. Enforces 5-minute lifetimes, 3-attempt brute-force thresholds (which deletes the OTP session), and mandatory 60-second resend cooldowns (limited to 3 resends max) to block playback/replay bypass scripts.
9. **Role-Based Access Control & IDOR Prevention**: Implements RBAC filters (`rbac.js`) validating session token roles. Restricts Students from accessing Professor dashboard APIs, return `403 Forbidden` for IDOR attempts, and blocks all unauthenticated route access requests.
10. **Optimistic Concurrency Locking**: Protects profile updates against concurrent session overwrites using a `version` attribute column. Return `409 Conflict` if updates are sent with stale version references.
11. **Profile Photo Upload & Serve Security**: Restricts photo file sizes to 2MB, whitelist formats (PNG, JPEG, WEBP), and stores uploads under randomized filename hashes. Serves uploaded photo streams exclusively via an authenticated gateway to prevent unauthorized public leaks or IDOR file access.
12. **Duplicate Submissions Prevention**: Enforces a `UNIQUE` index constraint on the application `user_id` column ensuring each student registers a single record.
13. **State Transition Protections**: Blocks editing, saving, or submitting application details once the application status has been finalized to `Submitted`. Attempts to modify submitted details return `400 Bad Request` or `403 Forbidden`.
14. **Pre-population Integrity**: Auto-populates personal and academic details from the student's saved verified profile, preventing typos and manual input manipulation.
15. **IDOR Application Blocks**: Limits application routes to the session-verified student owner context only, blocking other student access queries. Professor reads are validated via RBAC parameters.

---

## 📚 Documentation Index

Refer to the following guides for detailed specifications:

### Root Documentation
* **[ARCHITECTURE.md](ARCHITECTURE.md)**: System design and components layout.
* **[API_DOCUMENTATION.md](API_DOCUMENTATION.md)**: REST endpoints and payloads.
* **[DATABASE.md](DATABASE.md)**: Table definitions, constraints, and indices.
* **[FINAL_PROJECT_REPORT.md](FINAL_PROJECT_REPORT.md)**: Consolidated project summary.

### Module & Configuration Guides
* **[XAMPP Setup Guide](XAMPP_SETUP.md)**: Local MySQL/MariaDB database setup.
* **[Security Guide](SECURITY.md)**: Authentication and vulnerability mitigations.
* **[Testing Guide](TESTING.md)**: Test suites description and database smoke tests.
* **[Postman API Guide](POSTMAN.md)**: Collection importing and testing sequence.
* **[eKYC Aadhaar Guide](EKYC.md)**: Demographic identity-matching logic.
* **[DigiLocker Guide](DIGILOCKER.md)**: Popup oauth PostMessage channel integration.
* **[emSigner Guide](EMSIGNER.md)**: Digital signature adapter and transitions.
* **[Paperless Workflow Guide](PAPERLESS_WORKFLOW.md)**: State machine rules and auto-promotion.

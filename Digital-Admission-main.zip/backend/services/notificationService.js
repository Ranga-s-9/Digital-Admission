const fs = require('fs');
const path = require('path');
const Notification = require('../models/Notification');

// Scratch file location for development mock deliveries
const SCRATCH_DIR = path.join(__dirname, '../../scratch');
const DELIVERY_FILE_PATH = path.join(SCRATCH_DIR, 'notification_mock_delivery.txt');

class NotificationService {
  /**
   * Send a notification. Stored in DB, and dispatches to mock delivery if enabled.
   * @param {Object} params
   * @param {number} params.userId - Recipient user ID
   * @param {string} params.type - Notification type/event
   * @param {string} params.title - Title text
   * @param {string} params.content - Main body text
   * @returns {Promise<number>} - Stored database notification ID
   */
  static async send({ userId, type, title, content }) {
    try {
      // 1. Create notification in database (handles duplicate prevention)
      const notificationId = await Notification.create({
        userId,
        title,
        content,
        type
      });

      // 2. Deliver via mock provider (development/mock mode)
      const mode = process.env.NOTIFICATION_MODE || 'mock';
      if (mode === 'mock') {
        await this.deliverMock(userId, type, title, content);
      } else {
        console.log(`[Notification Service] Production notification sent to user ${userId} via external channel (stub).`);
      }

      return notificationId;
    } catch (error) {
      console.error('[Notification Service] Error sending notification:', error);
      throw error;
    }
  }

  /**
   * Append mock notification delivery log to scratch file
   * @param {number} userId 
   * @param {string} type 
   * @param {string} title 
   * @param {string} content 
   */
  static async deliverMock(userId, type, title, content) {
    try {
      if (!fs.existsSync(SCRATCH_DIR)) {
        fs.mkdirSync(SCRATCH_DIR, { recursive: true });
      }

      const timestamp = new Date().toISOString();
      const logEntry = `================================================================================
[${timestamp}] MOCK NOTIFICATION DELIVERY
Recipient User ID: ${userId}
Type: ${type}
Title: ${title}
Content: ${content}
================================================================================
\n`;

      fs.appendFileSync(DELIVERY_FILE_PATH, logEntry, 'utf8');
      console.log(`[Notification Service] Mock delivery written for user ${userId} [Type: ${type}]`);
    } catch (err) {
      console.error('[Notification Service] Error writing mock delivery log:', err);
    }
  }
}

module.exports = NotificationService;

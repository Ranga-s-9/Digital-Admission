require('dotenv').config();
const app = require('./app');
const { initDatabase } = require('./services/dbService');
const { logger } = require('./middleware/logger');

const PORT = process.env.PORT || 3000;

// Centralized process-level safety nets.
// These catch errors that occur outside of Express's request/response cycle
// (e.g. inside a fire-and-forget promise, a timer callback, or a bug in a
// background job) so they are logged consistently instead of dumping a raw
// stack trace to stdout only, or crashing the process silently.
process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception - process will exit', {
    message: error.message,
    stack: error.stack
  });
  // An uncaught synchronous exception can leave the process in an
  // inconsistent state, so exit and let the process manager restart it
  // rather than continuing to serve requests from a corrupted state.
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  const message = reason instanceof Error ? reason.message : String(reason);
  const stack = reason instanceof Error ? reason.stack : undefined;
  logger.error('Unhandled promise rejection', { message, stack });
  // Unlike uncaughtException, an unhandled rejection does not necessarily
  // corrupt process state, so log it and keep serving rather than exiting.
});

async function startServer() {
  try {
    // 1. Initialize DB schema and index structures
    await initDatabase();
    
    // 2. Launch the Express server listener
    app.listen(PORT, () => {
      console.log(`==================================================`);
      console.log(`Digital Student Admission System (Module 1)`);
      console.log(`Server is running in ${process.env.NODE_ENV || 'development'} mode`);
      console.log(`URL: http://localhost:${PORT}`);
      console.log(`==================================================`);
    });
  } catch (error) {
    logger.error('Fatal error during startup sequence', { message: error.message, stack: error.stack });
    process.exit(1);
  }
}

startServer();

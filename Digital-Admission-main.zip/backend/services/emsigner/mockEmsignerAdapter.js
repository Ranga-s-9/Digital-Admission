const EmsignerAdapter = require('./emsignerAdapter');
const db = require('../../config/db');
const crypto = require('crypto');

/**
 * ⚠️  DEVELOPMENT / MOCK MODE
 *
 * This adapter simulates emSigner digital signature requests.
 * No real emSigner API call is made. All signatures are mock/simulated.
 * Real emSigner integration requires valid EMSIGNER_API_KEY credentials.
 */
class MockEmsignerAdapter extends EmsignerAdapter {
  /**
   * Initiate a mock digital signature request
   * @param {number} userId - Student user ID
   * @param {string} applicationId - Application reference ID
   * @param {string} ipAddress - Client IP address
   * @returns {Promise<Object>} Mock signing result
   */
  async initiateSign(userId, applicationId, ipAddress) {
    // 1. Check for duplicate sign requests
    const existing = await db.query(
      'SELECT id, sign_status, sign_request_id FROM emsigner_requests WHERE user_id = ?',
      [userId]
    );

    if (existing && existing.length > 0) {
      const prev = existing[0];
      if (prev.sign_status === 'Signed') {
        throw new Error('DUPLICATE_SIGN_REQUEST');
      }
    }

    // 2. Simulate test error scenarios based on applicationId trigger strings
    if (applicationId === 'mock_timeout') {
      await new Promise(resolve => setTimeout(resolve, 1500));
      throw new Error('TIMEOUT_ERROR');
    }
    if (applicationId === 'mock_failure') {
      throw new Error('EXTERNAL_SERVICE_FAILURE');
    }

    // 3. Generate a mock sign request ID (UUID-like)
    const signRequestId = 'MOCK-EMSIGN-' + crypto.randomBytes(8).toString('hex').toUpperCase();
    const signedDocUri = `https://mock.emsigner.dev/signed/${signRequestId}.pdf`;
    const signedAt = Date.now();

    // 4. Save or update the signing record
    if (existing && existing.length > 0) {
      await db.query(
        `UPDATE emsigner_requests
         SET sign_request_id = ?, sign_status = 'Signed', signed_doc_uri = ?, signed_at = ?, error_message = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [signRequestId, signedDocUri, signedAt, userId]
      );
    } else {
      await db.query(
        `INSERT INTO emsigner_requests (user_id, application_id, sign_request_id, sign_status, signed_doc_uri, signed_at)
         VALUES (?, ?, ?, 'Signed', ?, ?)`,
        [userId, applicationId, signRequestId, signedDocUri, signedAt]
      );
    }

    // 5. Audit log
    await db.query(
      `INSERT INTO emsigner_audit_logs (user_id, action, ip_address, details)
       VALUES (?, 'SIGN_SUCCESS', ?, ?)`,
      [userId, ipAddress, `Mock emSigner signature completed. Request ID: ${signRequestId}`]
    );

    return {
      success: true,
      development_mode: true,
      sign_request_id: signRequestId,
      sign_status: 'Signed',
      signed_doc_uri: signedDocUri,
      signed_at: signedAt,
      message: '[MOCK MODE] Digital signature simulated successfully. No real emSigner API was called.'
    };
  }

  /**
   * Get the current signing status for a student
   * @param {number} userId - Student user ID
   * @returns {Promise<Object>} Current signature record
   */
  async getStatus(userId) {
    const rows = await db.query(
      'SELECT sign_request_id, sign_status, signed_doc_uri, signed_at, error_message FROM emsigner_requests WHERE user_id = ?',
      [userId]
    );

    if (!rows || rows.length === 0) {
      return {
        signed: false,
        sign_status: 'NotInitiated',
        development_mode: true
      };
    }

    const rec = rows[0];
    return {
      signed: rec.sign_status === 'Signed',
      sign_status: rec.sign_status,
      sign_request_id: rec.sign_request_id,
      signed_doc_uri: rec.signed_doc_uri,
      signed_at: rec.signed_at,
      error_message: rec.error_message,
      development_mode: true
    };
  }
}

module.exports = MockEmsignerAdapter;

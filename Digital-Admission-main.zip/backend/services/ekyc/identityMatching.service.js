'use strict';

/**
 * Identity Matching Service for Offline e-KYC Verification
 *
 * Compares verified eKYC identity information with the student's
 * admission profile. Uses intelligent normalization to avoid
 * false mismatches from formatting differences.
 *
 * Results: MATCH | MISMATCH | REVIEW_REQUIRED
 */

/**
 * @typedef {Object} MatchResult
 * @property {string} result - 'MATCH' | 'MISMATCH' | 'REVIEW_REQUIRED'
 * @property {Object} details - Per-field match details
 * @property {string[]} mismatches - List of mismatched field names
 */

/**
 * Gender normalization mapping
 */
const GENDER_MAP = {
  'm': 'Male',
  'male': 'Male',
  'f': 'Female',
  'female': 'Female',
  't': 'Other',
  'transgender': 'Other',
  'other': 'Other',
  'o': 'Other'
};

/**
 * Normalize a name for comparison
 * - lowercase
 * - collapse multiple spaces to single space
 * - trim leading/trailing whitespace
 * - remove common honorifics (Mr., Mrs., Ms., Dr., Shri, Smt.)
 * @param {string} name
 * @returns {string}
 */
function normalizeName(name) {
  if (!name || typeof name !== 'string') return '';

  return name
    .toLowerCase()
    .replace(/\b(mr\.?|mrs\.?|ms\.?|dr\.?|shri\.?|sri\.?|shree\.?|smt\.?)\s*/gi, '')
    .replace(/\./g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalize a date to YYYY-MM-DD format
 * Handles: YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY, Date objects
 * @param {string|Date} dateValue
 * @returns {string} Normalized date in YYYY-MM-DD format, or empty string if invalid
 */
function normalizeDate(dateValue) {
  if (!dateValue) return '';

  let dateStr = String(dateValue).trim();

  // Handle Date objects
  if (dateValue instanceof Date) {
    return dateValue.toISOString().split('T')[0];
  }

  // Already YYYY-MM-DD?
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return dateStr;
  }

  // DD-MM-YYYY or DD/MM/YYYY
  const dmyMatch = dateStr.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})$/);
  if (dmyMatch) {
    return `${dmyMatch[3]}-${dmyMatch[2]}-${dmyMatch[1]}`;
  }

  // Try native Date parsing as last resort
  try {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) {
      return d.toISOString().split('T')[0];
    }
  } catch { /* ignore */ }

  return dateStr;
}

/**
 * Normalize gender to standard value
 * @param {string} gender
 * @returns {string} 'Male' | 'Female' | 'Other' | original value
 */
function normalizeGender(gender) {
  if (!gender || typeof gender !== 'string') return '';

  const key = gender.trim().toLowerCase();
  return GENDER_MAP[key] || gender.trim();
}

/**
 * Compare a name from XML against a name from the student profile
 * @param {string} xmlName
 * @param {string} profileName
 * @returns {{ match: boolean, confidence: string }}
 */
function compareName(xmlName, profileName) {
  const a = normalizeName(xmlName);
  const b = normalizeName(profileName);

  if (!a || !b) {
    return { match: false, confidence: 'EMPTY_FIELD' };
  }

  // Exact match after normalization
  if (a === b) {
    return { match: true, confidence: 'EXACT' };
  }

  // Ignore spaces & punctuation differences (e.g. "rangarajan s" vs "srirangarajan s")
  const aNoSpace = a.replace(/\s+/g, '');
  const bNoSpace = b.replace(/\s+/g, '');

  if (aNoSpace === bNoSpace || aNoSpace.includes(bNoSpace) || bNoSpace.includes(aNoSpace)) {
    return { match: true, confidence: 'EXACT' };
  }

  // Check if one is a substring of the other
  if (a.includes(b) || b.includes(a)) {
    return { match: true, confidence: 'PARTIAL' };
  }

  // Split into parts and check token overlaps
  const partsA = a.split(' ').filter(Boolean);
  const partsB = b.split(' ').filter(Boolean);
  const shorter = partsA.length <= partsB.length ? partsA : partsB;
  const longer = partsA.length > partsB.length ? partsA : partsB;

  const allPartsFound = shorter.every(part => longer.some(l => l.includes(part) || part.includes(l)));
  if (allPartsFound && shorter.length >= 1) {
    return { match: true, confidence: 'REORDERED' };
  }

  return { match: false, confidence: 'MISMATCH' };
}

/**
 * Full identity matching between XML data and student profile
 * @param {object} xmlIdentity - Identity data extracted from XML
 * @param {object} profileData - Student profile data from database
 * @returns {MatchResult}
 */
function matchIdentity(xmlIdentity, profileData) {
  const details = {};
  const mismatches = [];
  let hasReviewItem = false;

  // 1. Name comparison
  const nameResult = compareName(xmlIdentity.name, profileData.name);
  details.name = nameResult;
  if (!nameResult.match) {
    mismatches.push('name');
  } else if (nameResult.confidence === 'PARTIAL' || nameResult.confidence === 'REORDERED') {
    hasReviewItem = true;
  }

  // 2. DOB comparison
  const xmlDob = normalizeDate(xmlIdentity.dob);
  const profileDob = normalizeDate(profileData.dob);
  const dobMatch = xmlDob === profileDob;
  details.dob = { match: dobMatch, xmlValue: xmlDob, profileValue: profileDob };
  if (!dobMatch) {
    mismatches.push('dob');
  }

  // 3. Gender comparison
  const xmlGender = normalizeGender(xmlIdentity.gender);
  const profileGender = normalizeGender(profileData.gender);
  const genderMatch = xmlGender === profileGender;
  details.gender = { match: genderMatch, xmlValue: xmlGender, profileValue: profileGender };
  if (!genderMatch) {
    mismatches.push('gender');
  }

  // 4. Pincode comparison (optional — only if both values available)
  if (xmlIdentity.address && xmlIdentity.address.pincode && profileData.pincode) {
    const xmlPincode = String(xmlIdentity.address.pincode).trim();
    const profilePincode = String(profileData.pincode).trim();
    const pincodeMatch = xmlPincode === profilePincode;
    details.pincode = { match: pincodeMatch, xmlValue: xmlPincode, profileValue: profilePincode };
    if (!pincodeMatch) {
      mismatches.push('pincode');
    }
  }

  // Determine overall result
  let result;
  if (mismatches.length === 0 && !hasReviewItem) {
    result = 'MATCH';
  } else if (mismatches.length === 0 && hasReviewItem) {
    result = 'REVIEW_REQUIRED';
  } else {
    result = 'MISMATCH';
  }

  return {
    result,
    details,
    mismatches
  };
}

module.exports = {
  matchIdentity,
  normalizeName,
  normalizeDate,
  normalizeGender,
  compareName
};

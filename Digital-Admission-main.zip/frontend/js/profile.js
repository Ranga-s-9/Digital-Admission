document.addEventListener('DOMContentLoaded', () => {
  const profileForm = document.getElementById('profileForm');
  const photoInput = document.getElementById('profilePhotoInput');
  const saveBtn = document.getElementById('profileSaveBtn');
  const saveSpinner = document.getElementById('profileSaveSpinner');
  const saveText = document.getElementById('profileSaveText');
  const avatarImg = document.getElementById('profileAvatarImg');

  let cachedUserId = null;

  // Input fields
  const dobInput = document.getElementById('profileDob');
  const genderSelect = document.getElementById('profileGender');
  const guardianInput = document.getElementById('profileGuardianName');
  const addressInput = document.getElementById('profileAddress');
  const stateInput = document.getElementById('profileState');
  const pincodeInput = document.getElementById('profilePincode');
  const degreeInput = document.getElementById('profileDegree');
  const boardInput = document.getElementById('profileBoard');
  const gradYearInput = document.getElementById('profileGradYear');
  const percentageInput = document.getElementById('profilePercentage');
  const versionInput = document.getElementById('profileVersionInput');

  // Notification Helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    if (!notify) return;

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Helper to calculate and display completion percentage
  function updateCompletionUI() {
    const coreFields = [
      dobInput,
      genderSelect,
      guardianInput,
      addressInput,
      stateInput,
      pincodeInput,
      degreeInput,
      boardInput,
      gradYearInput,
      percentageInput
    ];

    let filledCount = 0;
    coreFields.forEach(input => {
      if (input && input.value && String(input.value).trim() !== '') {
        filledCount++;
      }
    });

    const percent = filledCount * 10; // 10 fields = 100% max
    
    const percentNum = document.getElementById('profileCompletionPercent');
    const percentBar = document.getElementById('profileCompletionBar');
    
    if (percentNum) percentNum.textContent = `${percent}%`;
    if (percentBar) percentBar.style.width = `${percent}%`;
  }

  // Bind input listeners to recalculate progress dynamically on typing/change
  const formInputs = [
    dobInput, genderSelect, guardianInput, addressInput, stateInput,
    pincodeInput, degreeInput, boardInput, gradYearInput, percentageInput
  ];

  formInputs.forEach(input => {
    if (input) {
      input.addEventListener('input', updateCompletionUI);
      input.addEventListener('change', updateCompletionUI);
    }
  });

  // Client-Side Validation Form Rules
  function validateForm() {
    let isValid = true;
    
    // Clear previous feedbacks
    document.querySelectorAll('.feedback-message').forEach(el => {
      el.textContent = '';
      el.style.opacity = '0';
    });
    document.querySelectorAll('.form-group').forEach(el => {
      el.classList.remove('has-error', 'has-success');
    });

    // Pincode validation: 6 numbers only
    if (pincodeInput.value) {
      if (!/^\d{6}$/.test(pincodeInput.value)) {
        const fb = document.getElementById('profilePincodeFeedback');
        if (fb) {
          fb.textContent = 'Pincode must be exactly 6 digits';
          fb.style.opacity = '1';
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-error');
        }
        isValid = false;
      } else {
        const fb = document.getElementById('profilePincodeFeedback');
        if (fb) {
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-success');
        }
      }
    }

    // Graduation year validation: 1900 - 2035
    if (gradYearInput.value) {
      const yr = parseInt(gradYearInput.value, 10);
      if (isNaN(yr) || yr < 1900 || yr > 2035) {
        const fb = document.getElementById('profileGradYearFeedback');
        if (fb) {
          fb.textContent = 'Graduation year must be between 1900 and 2035';
          fb.style.opacity = '1';
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-error');
        }
        isValid = false;
      } else {
        const fb = document.getElementById('profileGradYearFeedback');
        if (fb) {
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-success');
        }
      }
    }

    // Percentage validation: 0 - 100
    if (percentageInput.value) {
      const pct = parseFloat(percentageInput.value);
      if (isNaN(pct) || pct < 0 || pct > 100) {
        const fb = document.getElementById('profilePercentageFeedback');
        if (fb) {
          fb.textContent = 'Percentage must be between 0.00% and 100.00%';
          fb.style.opacity = '1';
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-error');
        }
        isValid = false;
      } else {
        const fb = document.getElementById('profilePercentageFeedback');
        if (fb) {
          const gp = fb.closest('.form-group');
          if (gp) gp.classList.add('has-success');
        }
      }
    }

    return isValid;
  }

  // Load profile view
  async function loadProfileView() {
    try {
      // 1. Fetch current logged-in user profile ID from /api/auth/me
      const meResponse = await fetch('/api/auth/me');
      const meResult = await meResponse.json();

      if (!meResponse.ok || !meResult.success) {
        window.location.hash = '#/login-student';
        return;
      }

      cachedUserId = meResult.data.user.userId;
      const activeUserId = cachedUserId;

      // Disable inputs if role is professor (read-only mode for admins)
      const isProfessor = meResult.data.user.role === 'professor';

      // 2. Fetch specific student profile
      const response = await fetch(`/api/profile/${activeUserId}`);
      const result = await response.json();

      if (response.ok && result.success) {
        const data = result.data.profile;

        // Populate fields
        document.getElementById('profileName').value = data.name;
        document.getElementById('profileEmail').value = data.email;
        document.getElementById('profileMobile').value = data.mobile;
        
        dobInput.value = data.dob;
        genderSelect.value = data.gender;
        guardianInput.value = data.guardianName;
        addressInput.value = data.address;
        stateInput.value = data.state;
        pincodeInput.value = data.pincode;
        degreeInput.value = data.degree;
        boardInput.value = data.board;
        gradYearInput.value = data.gradYear;
        percentageInput.value = data.percentage;
        versionInput.value = data.version;

        // Render photo safely
        if (data.photoPath) {
          avatarImg.src = `/api/profile/photo/${activeUserId}?t=${Date.now()}`;
        } else {
          avatarImg.src = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='gray'><path d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/></svg>";
        }

        // Enable editing and photo uploads for all users viewing their own profile
        saveBtn.style.display = 'flex';
        document.querySelectorAll('#profileForm input, #profileForm select').forEach(el => {
          if (el.id !== 'profileEmail' && el.id !== 'profileMobile' && el.id !== 'profileVersionInput') {
            el.removeAttribute('disabled');
            el.classList.remove('input-readonly');
          }
        });
        const changePhotoBtn = document.querySelector('.profile-avatar-container button');
        if (changePhotoBtn) changePhotoBtn.style.display = 'block';
        const overlay = document.querySelector('.avatar-upload-overlay');
        if (overlay) overlay.style.pointerEvents = 'auto';

        updateCompletionUI();

      } else {
        showNotification('Sync Failed', result.message || 'Could not fetch profile details.', 'error');
      }
    } catch (err) {
      console.error('Load profile view error:', err);
      showNotification('Server Error', 'Failed connecting to profile API.', 'error');
    }
  }

  // Handle Profile save changes
  if (profileForm) {
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (!validateForm()) return;

      // Get target user ID from active session
      const meResponse = await fetch('/api/auth/me');
      const meResult = await meResponse.json();
      if (!meResponse.ok) return;

      const activeUserId = meResult.data.user.userId;

      // Loading state
      saveBtn.disabled = true;
      if (saveSpinner) saveSpinner.style.display = 'block';
      if (saveText) saveText.textContent = 'Saving details...';

      try {
        const payload = {
          name: document.getElementById('profileName').value.trim(),
          dob: dobInput.value,
          gender: genderSelect.value,
          guardianName: guardianInput.value,
          address: addressInput.value,
          state: stateInput.value,
          pincode: pincodeInput.value,
          degree: degreeInput.value,
          board: boardInput.value,
          gradYear: gradYearInput.value ? parseInt(gradYearInput.value, 10) : null,
          percentage: percentageInput.value ? parseFloat(percentageInput.value) : null,
          version: parseInt(versionInput.value, 10)
        };

        const saveRes = await fetch(`/api/profile/${activeUserId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const saveResult = await saveRes.json();

        // Restore button state
        saveBtn.disabled = false;
        if (saveSpinner) saveSpinner.style.display = 'none';
        if (saveText) saveText.textContent = 'Save Changes';

        if (saveRes.ok && saveResult.success) {
          // Update version value and completion
          versionInput.value = saveResult.data.profile.version;
          updateCompletionUI();
          showNotification('Profile Saved', 'Your student credentials have been saved successfully.', 'success');
        } else if (saveRes.status === 409) {
          // Version collision detected!
          showNotification('Update Collision', 'Concurrent modification detected. The profile was modified by another session. Please reload and try again.', 'error');
        } else {
          showNotification('Save Failed', saveResult.message || 'Validation checks failed.', 'error');
        }

      } catch (err) {
        saveBtn.disabled = false;
        if (saveSpinner) saveSpinner.style.display = 'none';
        if (saveText) saveText.textContent = 'Save Changes';
        console.error('Save profile submit error:', err);
        showNotification('Connection Error', 'Failed saving profile. Check server logs.', 'error');
      }
    });
  }

  // Handle photo upload triggers
  if (photoInput) {
    console.log('[Profile Photo] Input element found, change listener registered.');
    photoInput.addEventListener('change', async () => {
      const file = photoInput.files[0];
      if (!file) {
        console.warn('[Profile Photo] Change event fired, but no file selected.');
        return;
      }

      console.log(`[Profile Photo] File selected: Name="${file.name}", Size=${file.size} bytes, Type="${file.type}"`);

      // Client-side file checks
      if (file.size > 2 * 1024 * 1024) {
        console.error('[Profile Photo] File size exceeds 2MB limit.');
        showNotification('Upload Error', 'File size limit exceeded: Maximum allowed size is 2MB.', 'error');
        photoInput.value = '';
        return;
      }

      const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
      const allowedExts = ['.png', '.jpg', '.jpeg', '.webp'];
      const fileName = file.name.toLowerCase();
      const hasValidExt = allowedExts.some(ext => fileName.endsWith(ext));

      if (!allowedTypes.includes(file.type) && !hasValidExt) {
        console.error('[Profile Photo] Unsupported format detected:', file.type, fileName);
        showNotification('Upload Error', 'Unsupported format: Only PNG, JPEG, and WEBP formats are allowed.', 'error');
        photoInput.value = '';
        return;
      }

      let activeUserId = cachedUserId;
      if (!activeUserId) {
        console.log('[Profile Photo] User ID not cached, fetching active session...');
        try {
          const meResponse = await fetch('/api/auth/me');
          const meResult = await meResponse.json();
          if (meResponse.ok && meResult.success) {
            cachedUserId = meResult.data.user.userId;
            activeUserId = cachedUserId;
            console.log(`[Profile Photo] Active session fetched. User ID: ${activeUserId}`);
          }
        } catch (e) {
          console.error('[Profile Photo] Failed to fetch active session:', e);
        }
      }

      if (!activeUserId) {
        console.error('[Profile Photo] Cannot upload: No active user session.');
        showNotification('Upload Error', 'Authentication error: Please log in again.', 'error');
        return;
      }

      // Construct Form Data
      const formData = new FormData();
      formData.append('photo', file);

      console.log(`[Profile Photo] Uploading to /api/profile/${activeUserId}/photo ...`);
      try {
        const uploadRes = await fetch(`/api/profile/${activeUserId}/photo`, {
          method: 'POST',
          body: formData
        });

        console.log(`[Profile Photo] Upload response status: ${uploadRes.status}`);
        const uploadResult = await uploadRes.json();
        console.log('[Profile Photo] Upload response payload:', uploadResult);
        photoInput.value = ''; // Reset input selection

        if (uploadRes.ok && uploadResult.success) {
          // Reload avatar image
          avatarImg.src = `/api/profile/photo/${activeUserId}?t=${Date.now()}`;
          console.log('[Profile Photo] Avatar element src updated successfully.');
          showNotification('Photo Uploaded', 'Profile avatar image updated successfully.', 'success');
        } else {
          console.error('[Profile Photo] Upload failed on server:', uploadResult.message);
          showNotification('Upload Failed', uploadResult.message || 'Invalid file format.', 'error');
        }

      } catch (err) {
        photoInput.value = '';
        console.error('[Profile Photo] Connection error during upload:', err);
        showNotification('Upload Error', 'Failed connection during photo upload.', 'error');
      }
    });
  }

  // Expose global loader
  window.loadProfileView = loadProfileView;
});

// app.js

document.addEventListener('DOMContentLoaded', () => {
    
    // Tab Elements
    const tabs = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    // Tab Switching Logic
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            tab.classList.add('active');
            const targetId = tab.getAttribute('data-tab');
            document.getElementById(targetId).classList.add('active');

            // Stop scanner if moving away from QR tab
            if (targetId !== 'qr-tab') {
                stopScanner();
            }
        });
    });

    // File Drag & Drop Elements
    const dropZone = document.getElementById('ekycDropZone');
    const fileInput = document.getElementById('ekycFile');
    const fileBadge = document.getElementById('fileSelectionBadge');
    const fileNameDisplay = document.getElementById('selectedFileName');

    // Trigger file input click when clicking drop zone
    dropZone.addEventListener('click', (e) => {
        if (e.target !== fileInput) {
            fileInput.click();
        }
    });

    // Drag over effects
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        }, false);
    });

    // Handle dropped files
    dropZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            fileInput.files = files;
            updateFileDisplay(files[0]);
        }
    });

    // Handle selected files via browse
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            updateFileDisplay(fileInput.files[0]);
        }
    });

    function updateFileDisplay(file) {
        fileNameDisplay.textContent = file.name;
        fileBadge.style.display = 'inline-flex';
        
        // Show validation toast
        const ext = file.name.split('.').pop().toLowerCase();
        if (ext !== 'zip' && ext !== 'xml') {
            showToast('Warning', 'Unsupported file type. Please upload a .zip or .xml document.', 'error');
        } else {
            showToast('Success', `File selected: ${file.name}`, 'success');
        }
    }

    // verification Toast helper
    const toast = document.getElementById('statusToast');
    const toastTitle = document.getElementById('toastTitle');
    const toastMsg = document.getElementById('toastMessage');

    function showToast(title, message, type = 'success') {
        toast.className = `toast ${type}`;
        toastTitle.textContent = title;
        toastMsg.textContent = message;
        
        const icon = toast.querySelector('i');
        if (type === 'success') {
            icon.className = 'fa-solid fa-circle-check';
        } else {
            icon.className = 'fa-solid fa-circle-exclamation';
        }

        toast.style.display = 'flex';
        
        // Auto hide after 5s
        setTimeout(() => {
            toast.style.display = 'none';
        }, 5000);
    }

    // verify e-KYC file upload via API
    const ekycForm = document.getElementById('ekycVerifyForm');
    const btnVerifyEkyc = document.getElementById('btnVerifyEkyc');

    ekycForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (fileInput.files.length === 0) {
            showToast('Error', 'Please select or drag an Aadhaar e-KYC file first.', 'error');
            return;
        }

        const formData = new FormData(ekycForm);
        btnVerifyEkyc.disabled = true;
        btnVerifyEkyc.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying...';

        try {
            const res = await fetch('verify_ekyc.php', {
                method: 'POST',
                body: formData
            });

            const result = await res.json();
            
            if (res.ok && result.success) {
                showToast('Verification Successful', 'Aadhaar identity details validated.', 'success');
                renderResults(result.data, 'e-KYC (ZIP/XML)');
            } else {
                showToast('Verification Failed', result.message || 'Check your share code and try again.', 'error');
            }
        } catch (err) {
            console.error('eKYC upload error:', err);
            showToast('Network Failure', 'Failed to connect to verification API.', 'error');
        } finally {
            btnVerifyEkyc.disabled = false;
            btnVerifyEkyc.innerHTML = '<i class="fa-solid fa-fingerprint"></i> Verify Identity Profile';
        }
    });

    // Scanner variables
    let html5QrcodeScanner = null;
    const btnStartScanner = document.getElementById('btnStartScanner');
    const btnStopScanner = document.getElementById('btnStopScanner');
    const scannerFrame = document.getElementById('qrScannerFrame');

    btnStartScanner.addEventListener('click', () => {
        startScanner();
    });

    btnStopScanner.addEventListener('click', () => {
        stopScanner();
    });

    function startScanner() {
        btnStartScanner.style.display = 'none';
        btnStopScanner.style.display = 'inline-flex';
        
        html5QrcodeScanner = new Html5Qrcode("qrScannerFrame");
        const config = { fps: 10, qrbox: { width: 250, height: 250 } };
        
        html5QrcodeScanner.start(
            { facingMode: "environment" },
            config,
            onQrCodeSuccess,
            onQrCodeError
        ).catch(err => {
            console.error("Camera access failed:", err);
            showToast("Camera Error", "Unable to access device camera.", "error");
            stopScanner();
        });
    }

    function stopScanner() {
        btnStopScanner.style.display = 'none';
        btnStartScanner.style.display = 'inline-flex';

        if (html5QrcodeScanner) {
            html5QrcodeScanner.stop().then(() => {
                html5QrcodeScanner = null;
                scannerFrame.innerHTML = '';
            }).catch(err => {
                console.error("Scanner stop error:", err);
            });
        }
    }

    async function onQrCodeSuccess(decodedText) {
        stopScanner();
        showToast("QR Code Scanned", "Decoding scanned data packet...", "success");
        verifyQrPayload(decodedText);
    }

    function onQrCodeError(errorMessage) {
        // Quietly fail scanning iterations
    }

    // Verify QR Text fallback
    const btnVerifyQrText = document.getElementById('btnVerifyQrText');
    const qrRawText = document.getElementById('qrRawText');

    btnVerifyQrText.addEventListener('click', () => {
        const text = qrRawText.value.trim();
        if (!text) {
            showToast("Error", "Please paste or scan a QR code payload first.", "error");
            return;
        }
        verifyQrPayload(text);
    });

    async function verifyQrPayload(qrData) {
        try {
            const res = await fetch('verify_qr.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ qr_data: qrData })
            });

            const result = await res.json();

            if (res.ok && result.success) {
                showToast('Decoded Successfully', 'Secure QR code data verified.', 'success');
                renderResults(result.data, 'Secure QR Code');
            } else {
                showToast('Decoding Failed', result.message || 'Invalid Aadhaar QR Code structure.', 'error');
            }
        } catch (err) {
            console.error('QR verification error:', err);
            showToast('Network Failure', 'Failed to reach QR decoder service.', 'error');
        }
    }

    // Render results layout
    const resultsContainer = document.getElementById('resultsContainer');
    const resPhoto = document.getElementById('resPhoto');
    const resName = document.getElementById('resName');
    const resDob = document.getElementById('resDob');
    const resGender = document.getElementById('resGender');
    const resCo = document.getElementById('resCo');
    const resAddress = document.getElementById('resAddress');
    const resPincode = document.getElementById('resPincode');

    const badgeSignature = document.getElementById('badgeSignature');
    const badgeMobile = document.getElementById('badgeMobile');
    const badgeEmail = document.getElementById('badgeEmail');

    function renderResults(data, method) {
        // Send verification details to parent application if framed
        if (window.self !== window.top) {
            window.parent.postMessage({
                type: 'EKYC_VERIFIED',
                method: method,
                data: data
            }, '*');
        }

        // Demographics
        resName.textContent = data.name || '—';
        resDob.textContent = data.dob || '—';
        resGender.textContent = data.gender || '—';
        resCo.textContent = data.address?.co || '—';
        resAddress.textContent = data.address?.full || '—';
        resPincode.textContent = data.address?.pincode || '—';

        // Photo
        if (data.photo) {
            resPhoto.src = `data:image/jpeg;base64,${data.photo}`;
        } else {
            resPhoto.src = 'https://via.placeholder.com/150x180?text=No+Photo';
        }

        // Badges
        // Signature
        if (data.signature_verified) {
            badgeSignature.className = 'verify-badge success';
            badgeSignature.innerHTML = '<i class="fa-solid fa-file-signature"></i> XML Signature: Verified';
        } else {
            badgeSignature.className = 'verify-badge error';
            badgeSignature.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> XML Signature: Unsigned';
        }

        // Mobile verification status
        if (data.mobile_verified === true) {
            badgeMobile.className = 'verify-badge success';
            badgeMobile.innerHTML = '<i class="fa-solid fa-mobile-screen"></i> Mobile matches registered';
        } else if (data.mobile_verified === false) {
            badgeMobile.className = 'verify-badge error';
            badgeMobile.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Mobile mismatch';
        } else {
            badgeMobile.className = 'verify-badge';
            badgeMobile.innerHTML = '<i class="fa-solid fa-circle-question"></i> Mobile: Not checked';
        }

        // Email verification status
        if (data.email_verified === true) {
            badgeEmail.className = 'verify-badge success';
            badgeEmail.innerHTML = '<i class="fa-solid fa-envelope"></i> Email matches registered';
        } else if (data.email_verified === false) {
            badgeEmail.className = 'verify-badge error';
            badgeEmail.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Email mismatch';
        } else {
            badgeEmail.className = 'verify-badge';
            badgeEmail.innerHTML = '<i class="fa-solid fa-circle-question"></i> Email: Not checked';
        }

        // Scroll to results
        resultsContainer.style.display = 'block';
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }

    // Print Logic
    document.getElementById('btnPrintCertificate').addEventListener('click', () => {
        window.print();
    });
});

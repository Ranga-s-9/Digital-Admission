-- =============================================================================
-- Migration 006: Fix Notifications `type` CHECK Constraint
--
-- BUG FIX: 003_add_notifications.sql restricted `notifications.type` to
-- generic UI-severity values ('info', 'success', 'warning', 'danger', 'error').
-- In practice, every call site (authController, admissionController,
-- dashboardController, digilockerController, ekycController, esignzyController,
-- workflowController) stores a semantic event-category value instead
-- ('registration', 'otp', 'application_submission', 'signature_request',
-- 'document_verification', 'signature_completion', 'correction_request',
-- 'approval', 'rejection').
--
-- On MySQL/MariaDB 10.2+ this CHECK constraint is actively enforced, so every
-- real notification insert failed with:
--   CONSTRAINT `chk_notifications_type` failed for `notifications`
-- This went unnoticed during SQLite-based development/testing because the
-- application's SQLite bootstrap path (backend/services/dbService.js) never
-- defined this CHECK constraint in the first place — only the standalone
-- MySQL migration/schema files did. It surfaced only when running the
-- documented XAMPP/MySQL migration path end-to-end.
--
-- Fix: widen the allowed values to the actual set used by the application,
-- while keeping the original generic severity values for forward
-- compatibility with any future generic/system notification types.
-- =============================================================================

ALTER TABLE notifications
  DROP CONSTRAINT chk_notifications_type;

ALTER TABLE notifications
  ADD CONSTRAINT chk_notifications_type CHECK (
    type IN (
      'info', 'success', 'warning', 'danger', 'error',
      'registration', 'otp', 'application_submission',
      'signature_request', 'document_verification',
      'signature_completion', 'correction_request',
      'approval', 'rejection'
    )
  );

# API Documentation - DPI Student Admission System

Documents all REST API endpoints for the Digital Student Admission System.

---

## Overview

### Base URL
```
http://localhost:3000
```

### Authentication
All protected routes require a valid HTTP-only JWT cookie (`token`) issued upon login. Unauthenticated requests receive `401 Unauthorized`.

### Security Headers
All responses include the following security headers (via `helmet`):

| Header | Value |
|---|---|
| `X-Content-Type-Options` | `nosniff` |
| `X-Frame-Options` | `DENY` |
| `X-XSS-Protection` | `0` |
| `Content-Security-Policy` | `default-src 'self'` (see app.js for full CSP) |
| `Strict-Transport-Security` | `max-age=15552000; includeSubDomains` |

### Rate Limiting
Sensitive endpoints are protected by a lightweight, IP-based memory rate limiter. Exceeded limits return `429 Too Many Requests`.

| Endpoint Group | Window | Max Requests |
|---|---|---|
| CAPTCHA generation | 1 minute | 30 |
| Login / Register | 1 minute | 10 |
| OTP operations (verify/resend) | 1 minute | 10 |

> **Note**: Rate limiting is disabled during automated testing (`NODE_ENV=test`).

### Standard Response Envelope

Every response follows this consistent structure:

```json
{
  "success": true | false,
  "message": "Human-readable status message",
  "data": { ... }
}
```

Error responses replace `"data"` with `"error"`:

```json
{
  "success": false,
  "message": "Human-readable error summary",
  "error": {
    "fieldName": "Field-specific error message",
    "global": "Non-field error message"
  }
}
```

### Common Error Codes

| Status | Meaning |
|---|---|
| `400` | Validation error / bad request |
| `401` | Unauthenticated — missing or invalid JWT cookie |
| `403` | Forbidden — IDOR check failed or account locked |
| `404` | Resource not found |
| `409` | Conflict — duplicate resource or optimistic lock failure |
| `429` | Too Many Requests — rate limit exceeded |
| `500` | Internal Server Error |

---

## Authentication Routes (`/api/auth`)

---

### 1. Fetch CAPTCHA

Generates a fresh arithmetic challenge for anti-automation.

- **URL**: `GET /api/auth/captcha`
- **Auth**: None
- **Rate Limit**: 30 req / 1 min

#### Response (200 OK)
```json
{
  "success": true,
  "message": "CAPTCHA challenge generated successfully",
  "data": {
    "captchaId": "1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed",
    "question": "14 - 8 = ?"
  }
}
```

---

### 2. Register User

Creates a new user account (Student or Professor), verifying the CAPTCHA challenge.

- **URL**: `POST /api/auth/register`
- **Auth**: None
- **Rate Limit**: 10 req / 1 min
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "name": "Jane Doe",
  "email": "jane.doe@example.com",
  "mobile": "9876543210",
  "password": "Password@123",
  "confirmPassword": "Password@123",
  "role": "student",
  "captchaId": "1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed",
  "captchaAnswer": "6"
}
```

#### Field Constraints
| Field | Rules |
|---|---|
| `name` | Required, 2–100 characters, XSS-sanitized |
| `email` | Required, valid email, must be unique |
| `mobile` | Required, valid 10-digit Indian mobile number, must be unique |
| `password` | Required, min 8 chars, ≥1 uppercase, ≥1 lowercase, ≥1 digit, ≥1 special char (`@$!%*?&#`) |
| `confirmPassword` | Required, must exactly match `password` |
| `role` | Required, one of `"student"` or `"professor"` |
| `captchaId` | Required, valid active CAPTCHA session ID |
| `captchaAnswer` | Required, correct arithmetic result |

#### Response (201 Created)
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "userId": 1,
    "name": "Jane Doe",
    "email": "jane.doe@example.com",
    "mobile": "9876543210",
    "role": "student"
  }
}
```

#### Error: Validation (400)
```json
{
  "success": false,
  "message": "Request validation error: validation failed",
  "error": {
    "captchaAnswer": "Incorrect CAPTCHA answer. Please try again.",
    "password": "Password must be at least 8 characters long"
  }
}
```

#### Error: Duplicate Resource (409)
```json
{
  "success": false,
  "message": "Registration failed",
  "error": {
    "email": "Email address is already registered"
  }
}
```

---

### 3. Login (Step 1)

Verifies user credentials and CAPTCHA, then dispatches a 6-digit OTP to the user's mobile.

- **URL**: `POST /api/auth/login`
- **Auth**: None
- **Rate Limit**: 10 req / 1 min
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "email": "jane.doe@example.com",
  "password": "Password@123",
  "captchaId": "1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed",
  "captchaAnswer": "6"
}
```

#### Response (200 OK)
Does **not** set the session cookie. Returns an OTP session ID.
```json
{
  "success": true,
  "message": "Credentials verified. OTP security challenge issued.",
  "data": {
    "otpSessionId": "fa9575ae-bee8-4bb0-8e95-3ab1acca31c8",
    "expiresIn": 300,
    "cooldown": 60,
    "mobileMasked": "******6666"
  }
}
```

#### Error: Invalid Credentials (401)
```json
{
  "success": false,
  "message": "Login failed",
  "error": { "global": "Invalid email address or password" }
}
```

#### Error: Account Locked (403)
```json
{
  "success": false,
  "message": "Account is temporarily locked due to too many failed login attempts. Try again in 15 minutes.",
  "error": { "global": "Account locked" }
}
```

---

### 4. Verify OTP (Step 2)

Verifies the 6-digit OTP and establishes a secure JWT cookie session.

- **URL**: `POST /api/auth/verify-otp`
- **Auth**: None
- **Rate Limit**: 10 req / 1 min
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "otpSessionId": "fa9575ae-bee8-4bb0-8e95-3ab1acca31c8",
  "code": "128280"
}
```

#### Response (200 OK)
Sets HTTP-only secure cookie `token`.
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "userId": 1,
    "name": "Jane Doe",
    "email": "jane.doe@example.com",
    "role": "student"
  }
}
```

#### Error: Wrong / Expired Code (400)
```json
{
  "success": false,
  "message": "Incorrect verification code. Attempts remaining: 2",
  "error": { "code": "Invalid code" }
}
```

---

### 5. Resend OTP

Generates a fresh OTP, resets attempt counters, and restarts the cooldown timer.

- **URL**: `POST /api/auth/resend-otp`
- **Auth**: None
- **Rate Limit**: 10 req / 1 min
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "otpSessionId": "fa9575ae-bee8-4bb0-8e95-3ab1acca31c8"
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "message": "OTP resent successfully",
  "data": { "expiresIn": 300, "cooldown": 60 }
}
```

#### Error: Cooldown Active (429)
```json
{
  "success": false,
  "message": "Please wait 45 second(s) before resending code.",
  "error": { "global": "Resend cooldown active" }
}
```

#### Error: Max Resends Exceeded (400)
```json
{
  "success": false,
  "message": "OTP resend limit exceeded. Please restart login.",
  "error": { "global": "Resend limit reached" }
}
```

---

### 6. Logout

Clears the secure JWT cookie session.

- **URL**: `POST /api/auth/logout`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Logged out successfully",
  "data": {}
}
```

---

### 7. Retrieve Session Profile

Returns the identity of the currently authenticated user.

- **URL**: `GET /api/auth/me`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Profile retrieved successfully",
  "data": {
    "user": {
      "userId": 1,
      "name": "Jane Doe",
      "email": "jane.doe@example.com",
      "mobile": "9876543210",
      "role": "student"
    }
  }
}
```

---

## Dashboard Routes (`/api/dashboard`)

---

### 8. Student Dashboard

Returns step checklist, widget statuses, and notifications for the authenticated student.

- **URL**: `GET /api/dashboard/student`
- **Auth**: Cookie `token` (role: `student`)

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Student dashboard statistics retrieved successfully",
  "data": {
    "profile": {
      "name": "Alice Student",
      "email": "alice@student.com",
      "mobile": "9111122222",
      "role": "student"
    },
    "widgets": {
      "admissionApplication": "Draft",
      "ekycStatus": "Pending",
      "digilockerStatus": "Not Connected",
      "documentStatus": "0 Documents Uploaded",
      "signatureStatus": "Unsigned",
      "currentStep": 1,
      "totalSteps": 5
    },
    "notifications": [
      {
        "id": 1,
        "title": "Welcome to DPI Portal",
        "content": "Your account registration has been successfully verified...",
        "type": "info",
        "date": "12/08/2026"
      }
    ]
  }
}
```

---

### 9. Professor Dashboard

Returns a searchable/filterable list of student applications. Accessible only by `professor` role.

- **URL**: `GET /api/dashboard/professor`
- **Auth**: Cookie `token` (role: `professor`)
- **Query Parameters**:
  - `search` *(optional)*: Case-insensitive substring match on name or email
  - `status` *(optional)*: Filter by `applicationStatus` — `all` | `pending` | `approved`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Professor dashboard applications retrieved successfully",
  "data": {
    "applications": [
      {
        "id": 2,
        "name": "Alice Student",
        "email": "alice@student.com",
        "mobile": "9111122222",
        "status": "active",
        "createdAt": "2026-08-12 12:43:26",
        "ekycStatus": "Pending",
        "documentStatus": "0 Uploaded",
        "signatureStatus": "Unsigned",
        "applicationStatus": "Pending"
      }
    ],
    "stats": {
      "total": 1,
      "pending": 1,
      "approved": 0,
      "pendingDocs": 1
    }
  }
}
```

---

## Profile Routes (`/api/profile`)

---

### 10. Retrieve Student Profile

Returns full student profile details. IDOR-protected: students can only view their own profile; professors may view any profile.

- **URL**: `GET /api/profile/:userId`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Student profile retrieved successfully",
  "data": {
    "profile": {
      "userId": 1,
      "name": "Jane Doe",
      "email": "jane.doe@example.com",
      "mobile": "9876543210",
      "dob": "2005-05-15",
      "gender": "Female",
      "guardianName": "Father Name",
      "address": "123 Main St",
      "state": "State",
      "pincode": "123456",
      "degree": "High School",
      "board": "State Board",
      "gradYear": 2023,
      "percentage": 95.5,
      "photoPath": "profile_1_abcd.jpg",
      "version": 1
    },
    "completionPercentage": 100
  }
}
```

#### Error: IDOR (403)
```json
{
  "success": false,
  "message": "Access denied",
  "error": { "global": "You are not authorized to view this profile" }
}
```

---

### 11. Save / Update Student Profile

Saves or updates student profile fields. Enforces optimistic locking (via `version`) and IDOR protection.

- **URL**: `PUT /api/profile/:userId`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "dob": "2005-05-15",
  "gender": "Female",
  "guardianName": "Father Name",
  "address": "123 Main St",
  "state": "State",
  "pincode": "123456",
  "degree": "High School",
  "board": "State Board",
  "gradYear": 2023,
  "percentage": 95.5,
  "version": 1
}
```

#### Field Constraints
| Field | Rules |
|---|---|
| `dob` | Optional, ISO 8601 date (`YYYY-MM-DD`) |
| `gender` | Optional, one of `Male` / `Female` / `Other` |
| `pincode` | Optional, exactly 6 numeric digits |
| `gradYear` | Optional, integer between 1900–2035 |
| `percentage` | Optional, float between 0.00–100.00 |
| `version` | **Required** — optimistic lock key |

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Student profile updated successfully",
  "data": {
    "profile": { "...updatedFields": "...", "version": 2 },
    "completionPercentage": 100
  }
}
```

#### Error: Optimistic Lock Conflict (409)
```json
{
  "success": false,
  "message": "Concurrent Update Conflict: The profile has been modified by another session. Please reload and try again.",
  "error": { "conflict": "Optimistic lock validation failed" }
}
```

---

### 12. Upload Profile Photo

Uploads a student profile photo. Max 2MB, accepted formats: JPEG / PNG / WEBP. IDOR-protected.

- **URL (Standard)**: `PUT /api/profile/:userId/photo`
- **URL (Legacy)**: `POST /api/profile/:userId/photo`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: multipart/form-data`
- **Body**: Form key `photo` containing the image file.

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Profile photo uploaded successfully",
  "data": { "photoPath": "profile_1_abcd.jpg" }
}
```

#### Error: Invalid File (400)
```json
{
  "success": false,
  "message": "File upload validation failed: Invalid file format. Only JPEG, PNG, and WEBP images are allowed.",
  "error": { "file": "Invalid file format..." }
}
```

---

### 13. Serve Profile Photo

Streams the student's uploaded profile photo. IDOR-protected.

- **URL (Standard)**: `GET /api/profile/:userId/photo`
- **URL (Legacy)**: `GET /api/profile/photo/:userId`
- **Auth**: Cookie `token`

#### Response (200 OK)
Binary image stream with appropriate `Content-Type` header.

---

## Admission Routes (`/api/admission`)

---

### 14. Retrieve My Application

Returns the authenticated student's active admission application.

- **URL (Standard)**: `GET /api/admission/applications/me`
- **URL (Legacy)**: `GET /api/admission/my-application`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Admission application retrieved successfully",
  "data": {
    "id": 1,
    "applicationId": "ADM-20260812-C8EA",
    "userId": 1,
    "dob": "2005-05-15",
    "gender": "Female",
    "guardianName": "Guardian Name",
    "address": "123 Main St",
    "state": "Delhi",
    "pincode": "110001",
    "degree": "High School",
    "board": "CBSE",
    "gradYear": 2023,
    "percentage": 95.5,
    "currentStep": 4,
    "status": "Submitted"
  }
}
```

---

### 15. Save Application Draft

Creates or updates an admission draft. Blocks updates if already submitted.

- **URL (Standard)**: `PUT /api/admission/applications/me`
- **URL (Legacy)**: `POST /api/admission/save-draft`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "dob": "2005-05-15",
  "gender": "Female",
  "guardianName": "Guardian Name",
  "address": "123 Main St",
  "state": "Delhi",
  "pincode": "110001",
  "degree": "High School",
  "board": "CBSE",
  "gradYear": 2023,
  "percentage": 95.5,
  "currentStep": 2
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Admission application draft saved successfully",
  "data": {
    "id": 1,
    "applicationId": "",
    "currentStep": 2,
    "status": "Draft"
  }
}
```

---

### 16. Submit Application

Validates all mandatory fields, finalizes the application, and assigns a unique tracking ID. Locks the application from further edits.

- **URL (Standard)**: `POST /api/admission/applications/me/submit`
- **URL (Legacy)**: `POST /api/admission/submit`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
All fields are **mandatory** for final submission:
```json
{
  "dob": "2005-05-15",
  "gender": "Female",
  "guardianName": "Guardian Name",
  "address": "123 Main St",
  "state": "Delhi",
  "pincode": "110001",
  "degree": "High School",
  "board": "CBSE",
  "gradYear": 2023,
  "percentage": 95.5
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Admission application submitted successfully",
  "data": {
    "id": 1,
    "applicationId": "ADM-20260812-C8EA",
    "status": "Submitted"
  }
}
```

---

## eKYC Routes (`/api/ekyc`)

---

### 17. Generate Mock Aadhaar XML

Generates a mock Aadhaar Offline Secure XML for development/testing.

- **URL**: `POST /api/ekyc/generate-mock-xml`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "name": "Jane Doe",
  "dob": "2005-05-15",
  "gender": "Female",
  "address": "123 Main St",
  "state": "Delhi",
  "pincode": "110001",
  "shareCode": "1234",
  "aadhaar": "123456789012"
}
```

#### Field Constraints
| Field | Rules |
|---|---|
| `name` | Required |
| `dob` | Required, ISO 8601 date |
| `gender` | Required, `Male` / `Female` / `Other` |
| `address` | Required |
| `state` | Required |
| `pincode` | Required, exactly 6 numeric digits |
| `shareCode` | Required, exactly 4 numeric digits |
| `aadhaar` | Required, exactly 12 numeric digits |

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Mock Aadhaar XML generated successfully",
  "data": { "xmlContent": "<OfflinePaperlessKyc>...</OfflinePaperlessKyc>" }
}
```

---

### 18. Verify eKYC

Uploads, parses, and verifies an Aadhaar Offline XML against the student's registered profile.

- **URL**: `POST /api/ekyc/verify`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "xmlContent": "<OfflinePaperlessKyc>...</OfflinePaperlessKyc>",
  "shareCode": "1234",
  "consent": true
}
```

#### Field Constraints
| Field | Rules |
|---|---|
| `xmlContent` | Required |
| `shareCode` | Required, exactly 4 numeric digits |
| `consent` | Required, must be `true` |

#### Response (200 OK)
```json
{
  "success": true,
  "message": "eKYC verification successful",
  "data": { "ekycStatus": "Verified" }
}
```

---

### 19. Get eKYC Status

Returns the current eKYC verification status for the authenticated student.

- **URL**: `GET /api/ekyc/status`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "eKYC status retrieved successfully",
  "data": { "ekycStatus": "Verified" }
}
```

---

## DigiLocker Routes (`/api/digilocker`)

---

### 20. Get DigiLocker Connection Status

Returns the DigiLocker connection status and list of linked documents.

- **URL**: `GET /api/digilocker/status`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "DigiLocker status retrieved successfully",
  "data": {
    "connected": true,
    "documents": [
      { "name": "Marksheet", "docUri": "in.gov.cbse.marksheet-12", "verified": true }
    ]
  }
}
```

---

### 21. Initiate DigiLocker OAuth

Redirects to the DigiLocker OAuth authorization flow (or mocked login page in development).

- **URL**: `GET /api/digilocker/oauth/authorize`
- **Auth**: Cookie `token`

---

### 22. DigiLocker OAuth Callback

Receives authorization credentials from the login form and stores the access token.

- **URL**: `POST /api/digilocker/oauth/callback`
- **Auth**: Cookie `token`

---

### 23. List Available Documents

Returns the list of issued documents available in the student's linked DigiLocker account.

- **URL**: `GET /api/digilocker/documents`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "DigiLocker documents retrieved successfully",
  "data": {
    "documents": [
      { "name": "Class 12 Marksheet", "docUri": "in.gov.cbse.marksheet-12", "issuer": "CBSE" }
    ]
  }
}
```

---

### 24. Retrieve and Verify Document

Links and verifies a specific document from DigiLocker.

- **URL**: `POST /api/digilocker/documents/retrieve`
- **Auth**: Cookie `token`
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "docUri": "in.gov.cbse.marksheet-12"
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Document retrieved and verified successfully",
  "data": {
    "docUri": "in.gov.cbse.marksheet-12",
    "verified": true
  }
}
```

---

## Workflow Routes (`/api/workflow`)

---

### 25. Sign Application

Student mock-signs the admission application, advancing the workflow to the signature step.

- **URL**: `POST /api/workflow/sign`
- **Auth**: Cookie `token` (role: `student`)

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Application signed successfully",
  "data": { "status": "SIGNED" }
}
```

---

### 26. Transition Application Status

Professor processes a submitted application — Approve, Reject, or request Correction.

- **URL**: `POST /api/workflow/transition`
- **Auth**: Cookie `token` (role: `professor`)
- **Headers**: `Content-Type: application/json`

#### Request Body
```json
{
  "userId": 2,
  "targetStatus": "Approved",
  "message": ""
}
```

#### Field Constraints
| Field | Rules |
|---|---|
| `userId` | Required, integer |
| `targetStatus` | Required, one of: `Submitted` / `DOCUMENT_VERIFICATION` / `IDENTITY_VERIFICATION` / `PENDING_SIGNATURE` / `SIGNED` / `Approved` / `Rejected` / `Draft` |
| `message` | Required when `targetStatus` is `Draft` (correction notes) |

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Application status transitioned successfully",
  "data": { "status": "Approved" }
}
```

---

### 27. Get Workflow History

Returns the full timeline of audit transition events for the student's application.

- **URL**: `GET /api/workflow/history`
- **Auth**: Cookie `token`

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Workflow history retrieved successfully",
  "data": {
    "history": [
      {
        "id": 1,
        "fromStatus": "Draft",
        "toStatus": "Submitted",
        "actorName": "Jane Doe",
        "actorRole": "student",
        "message": null,
        "createdAt": "2026-08-12 14:00:00"
      }
    ]
  }
}
```

---

## eSignzy Routes (`/api/esignzy`)

Handles electronic signature verification (integration endpoints). Refer to the eSignzy service documentation for detailed request/response schemas.

---

## Error Reference

### Validation Error (400)
```json
{
  "success": false,
  "message": "Request validation error: validation failed",
  "error": {
    "email": "Please enter a valid email address",
    "password": "Password must be at least 8 characters long"
  }
}
```

### Rate Limit Exceeded (429)
```json
{
  "success": false,
  "message": "Too many requests, please try again later.",
  "error": { "global": "Rate limit exceeded" }
}
```

### Internal Server Error (500)
```json
{
  "success": false,
  "message": "An internal server error occurred",
  "error": { "global": "An internal server error occurred" }
}
```

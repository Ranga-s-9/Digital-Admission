# Module 13 — Database Management

## Purpose

Provide persistent storage for users, applications, verification state, documents and workflow information.

## Source Requirement

The notes recommend XAMPP for local hosting and MySQL as the preferred database. They also mention Prisma as a technology to learn.

## Proposed Entities

```text
users
otp_sessions
student_profiles
ekyc_records
documents
admission_applications
signatures
workflow_records
audit_logs
```

## Core Relationships

```text
User
  |
  +---- Student Profile
           |
           +---- eKYC Records
           +---- Documents
           +---- Admission Applications
                         |
                         +---- Signatures
                         +---- Workflow Records
```

## Requirements

- Use primary keys and foreign keys.
- Enforce appropriate uniqueness constraints.
- Store timestamps.
- Validate referential integrity.
- Use migrations/versioned schema changes.
- Do not store secrets in ordinary tables.

## Suggested Development Stack

A MySQL database with an ORM such as Prisma may be used if it matches the selected backend. This is a proposed implementation choice; the notes do not mandate Prisma as the database technology.

## Acceptance Criteria

- Schema can be created reproducibly.
- CRUD operations work correctly.
- Invalid relationships are rejected.
- Application state persists across sessions.
- Database credentials are externalized.

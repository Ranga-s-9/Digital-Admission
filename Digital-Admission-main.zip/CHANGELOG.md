# Changelog

All notable changes to the Digital Student Admission System project will be documented in this file.

## [3.2.0] - 2026-08-16

### Fixed
- **Shipped `.env` didn't match documented zero-config default**: The `.env` file bundled in the project had `DB_TYPE=mysql` (with `dpi_app`/`dpi_app_pw` credentials from earlier MySQL verification work in this session), but `README.md` explicitly documents that `.env` should default to SQLite with no server setup required. Anyone running `npm install && npm run dev` directly (skipping the README's `cp .env.example .env` step) would have hit an immediate `ECONNREFUSED` on startup. Reset `.env` to match `.env.example`'s documented SQLite default; verified a fresh boot now succeeds with zero external dependencies.
- **MySQL `DATE` column serialization**: `backend/config/db.js` now sets `dateStrings: true` on the MySQL connection pool. Without it, `mysql2` returns `DATE`/`DATETIME` columns as JS `Date` objects, which serialize to full UTC ISO timestamps (`2005-12-01T00:00:00.000Z`) instead of the plain date string (`2005-12-01`) SQLite returns for the same column — a real cross-driver inconsistency that affects any MySQL/XAMPP deployment, not just this environment.
- **MySQL `DECIMAL` column type mismatch**: `profileController.js` now coerces the student profile `percentage` field to `Number(...)` in both the profile-retrieval and profile-update API responses. `mysql2` returns `DECIMAL` columns as strings by default; SQLite returns a number, so the API response shape previously differed depending on which database was configured.

### Added
- `tests/*.js` now respect an optional `TEST_DB_TYPE` environment variable (defaults to `sqlite`, unchanged behavior) so the full Jest suite can be run against either database driver without maintaining separate test files.
- `docs/XAMPP_SETUP.md`: new "Verified MySQL/MariaDB Compatibility" section documenting the two fixes above and the live verification performed (full test suite, 17-step E2E journey, and a real HTTP registration confirmed via direct MySQL query — all run against a live MariaDB 10.11 server).

### Verified
- Full Jest suite (11 suites / 84 tests) passes identically against both SQLite (default) and MySQL/MariaDB (`DB_TYPE=mysql`).
- The complete demonstration flow (registration → CAPTCHA → OTP → dashboard → profile → admission → eKYC → DigiLocker → paperless workflow → eSignzy → professor approval → notifications → audit log) was run against real MySQL via `scratch/e2e_api_journey.js` with zero failures.

## [3.1.0] - 2026-08-15

### Added
- **Module 22 — Centralized Error Handling**: New `requestId` middleware assigns a UUID trace ID to every request (respecting an inbound `X-Request-Id` header when present), returned via response header and included in every log line and error response.
- **JSON 404 for unmatched API routes**: Added `apiNotFoundHandler` so unrecognized `/api/*` paths return a proper `404` JSON body instead of silently falling through to the SPA's HTML page with a `200` status.
- **Process-level safety nets**: `server.js` now logs `uncaughtException` and `unhandledRejection` events through the centralized logger instead of relying on default stdout output.
- **New test suite**: `tests/errorHandling.test.js` (7 tests) covering request IDs, the new JSON 404 behavior, and confirming error responses never leak stack traces or internal file paths.
- **`docs/UI_UX_AUDIT.md`**: New Module 15 audit documenting a checklist review of the frontend against responsive/accessibility/UX requirements, with two follow-up items noted (no dedicated tablet breakpoint; duplicated `showNotification()` helper across 6 files).

### Changed
- All 41 `console.error(...)` calls across the 11 backend controllers now route through the centralized `logger.error(...)`, so caught errors are persisted to `logs/app.log` with a stack trace and request ID instead of only appearing in the console.
- Reordered `app.js` middleware so the centralized error handler runs last (after the SPA fallback route), matching Express's recommended error-handling middleware placement.

### Fixed
- **Environment/packaging issue**: The bundled `node_modules/sqlite3` native binary was compiled for a different OS/architecture than the runtime environment, causing `invalid ELF header` failures across all test suites. Resolved by reinstalling the `sqlite3` package to obtain a matching prebuilt binary. No application code was affected.

## [3.0.0] - 2026-08-14

### Added
- **SQLite Database Constraints Hardening**: Enabled full SQLite foreign key constraint checks (`PRAGMA foreign_keys = ON;`) on connection boot to align local SQLite development/testing behavior with production MySQL/MariaDB database enforcements.
- **Root Documentation Suite**: Compiled canonical root documents: `ARCHITECTURE.md` (SPA layout, component mappings), `API_DOCUMENTATION.md` (SSO, profile, admission, eSignzy details), and `DATABASE.md` (unified ER diagrams and schemas).
- **Core Module Documentation**: Added dedicated guides: `docs/SECURITY.md` (XSS, SQLi, lockout parameters), `docs/TESTING.md` (Jest and DB smoke test specifications), `docs/XAMPP_SETUP.md` (Apache/MySQL local developer server integration instructions), and `docs/POSTMAN.md` (REST API Postman collection execution workflow).
- **Integration Feature Guides**: Documented adapter designs: `docs/EKYC.md` (demographic identity-matching logic), `docs/DIGILOCKER.md` (popup PostMessage channel), and `docs/ESIGNZY.md` (digital signing transitions).
- **Consolidated Final Project Report**: Generated `FINAL_PROJECT_REPORT.md` providing complete setup, stack, module reviews, and limitations summary.

### Fixed
- **Audit Logs Test Case**: Corrected a constraint failure in `tests/auditLogs.test.js` where a dummy audit log was written using a non-existent user ID (`99`). Updated the test to write the sanitized audit log with `userId = null` to satisfy referential integrity checks now enforced by SQLite.

---

## [2.0.0] - 2026-08-13

### Added
- **eSignzy Adapter Architecture**: Implemented abstract `EsignzyAdapter` base interface with `initiateSign()` and `getStatus()` contract methods, following the same pattern as eKYC and DigiLocker modules.
- **Mock eSignzy Adapter**: Created `MockEsignzyAdapter` that simulates signing requests with clearly labelled `DEVELOPMENT / MOCK MODE` warnings. Generates a mock `MOCK-ESIGN-*` request ID and signed document URI. Never claims a real eSignzy call occurred.
- **Real eSignzy Adapter Stub**: Created `RealEsignzyAdapter` that guards against unconfigured credentials — throws `ESIGNZY_CREDENTIALS_NOT_CONFIGURED` if `ESIGNZY_API_KEY` is missing, documenting where real API calls must be wired for production.
- **Adapter Factory**: `services/esignzy/index.js` selects adapter based on `ESIGNZY_MODE` env variable (`mock` or `production`).
- **eSignzy Database Tables**: Added `esignzy_requests` (request ID, sign status, signed doc URI, timestamps) and `esignzy_audit_logs` tables for both SQLite and MySQL, with appropriate indexes.
- **`POST /api/esignzy/sign`**: Dedicated student-only signing endpoint. Validates `PENDING_SIGNATURE` status, delegates to adapter, transitions application to `SIGNED`, writes dual audit logs (eSignzy + workflow).
- **`GET /api/esignzy/status`**: Returns current signature record for the authenticated student. Professors may query by `?userId=`.
- **`GET /api/esignzy/history`**: Returns full eSignzy audit log history.
- **Deprecated Backward-Compatible Endpoint**: `POST /api/workflow/sign` now delegates to the eSignzy controller (maintaining backward compatibility for any existing clients).
- **eSignzy Frontend Panel**: Replaced simple mock sign button with a full eSignzy UI panel including: development-mode warning banner, pending section with document metadata chips, "Sign with eSignzy" button, and post-signing confirmation card showing request ID, document URI, and timestamp.
- **Environment Variables**: Added `ESIGNZY_MODE`, `ESIGNZY_API_KEY`, and `ESIGNZY_API_URL` to `.env` and `.env.example`.
- **eSignzy Test Suite**: Created `tests/esignzy.test.js` with 8 integration tests covering: auth guard, professor role block, wrong-state block, no-application 404, successful signing (with DB + audit log verification), duplicate rejection (409), and status retrieval before/after signing.

### Changed
- `workflowController.js` `postSignApplication` deprecated and delegated to `esignzyController.postInitiateSign`.

---

## [1.9.0] - 2026-08-13

### Added
- **Workflow State Transitions Database**: Added `correction_message` to application records and created the `workflow_audit_logs` table with user indices.
- **Workflow State Machine Engine**: Implemented backend validation mapping state transitions (Draft -> Submitted -> Document Verification -> Identity Verification -> Pending Signature -> Signed -> Approved/Rejected).
- **Auto-Promotion Calculations**: Created dynamic checks to automatically promote applications to signature-ready states once eKYC and DigiLocker credentials verify.
- **Correction Revision Loop**: Added Professor review controls returning applications back to Draft status with logged correction notes, unlocking student profile edits.
- **Student Dashboard Timeline Widgets**: Created interactive progress trackers, correction alerts, and eSign mock confirmation signature cards.
- **Professor Dashboard Modal**: Implemented review detail modals letting academics approve, reject, or request revisions on signed applications.
- **Workflow Jest Test Suites**: Created `tests/workflow.test.js` validating the state transitions, role blocks, and correction loops (increasing tests to 60 total).

---


## [1.8.0] - 2026-08-13

### Added
- **DigiLocker Database Schemas**: Defined `digilocker_connections` and `digilocker_documents` tables with foreign keys and `user_id` indexes to persist lockers mapping and retrieved transcript metadata.
- **DigiLocker Service Adapters**: Created base abstract `DigilockerAdapter` with `MockDigilockerAdapter` and `RealDigilockerAdapter` (throwing production offline exceptions to protect integration bounds).
- **Popup OAuth Workflow**: Integrated popup login gateway page serving mock credential entry and permission scopes, utilizing parent-opener `postMessage` messaging.
- **Verification Name Compatibility**: Automatically compares document student names against registered portal profile names to prevent fraudulent linkages.
- **Dashboard Integrations**: Refined student and professor widgets utilizing SQL subqueries to query and display the actual number of connected lockers and linked transcripts.
- **DigiLocker Test Specs**: Created `tests/digilocker.test.js` validating auth checks, default statuses, callbacks, mismatch validations, timeouts, and duplicates.

---

## [1.7.0] - 2026-08-13

### Added
- **eKYC Database Layer**: Created `ekyc_requests` and `ekyc_audit_logs` database tables with index structures to record verification status, errors, and ip coordinates.
- **eKYC Adapter Interface**: Structured modular `EkycAdapter` base with separate `MockEkycAdapter` and `RealEkycAdapter` (which safely throws offline configuration errors to prevent faking real checks).
- **Offline XML Processing**: Implemented regex-based XML extraction parsing values (Poi Name, DOB, Gender; Poa pc Pincode) from Aadhaar Offline Secure XML uploads.
- **Simulated Verification Spinner**: Added step-by-step processing indicators (XML parsing, signature checks, profile matching) with transition alerts.
- **Interactive Mock Generator**: Developed a client-side generator tool allowing students to pre-generate and download valid or mismatching mock Aadhaar XML files for evaluation.
- **Dashboard Integrations**: Rewrote student and professor widgets to query actual database-bound eKYC statuses instead of the previous static submission stubs.
- **eKYC Test Specifications**: Created `tests/ekyc.test.js` validating mismatch errors, timeouts, external service failures, duplicates, and unauthorized blocks.

---

## [1.6.0] - 2026-08-12

### Added
- **Admission Applications Schema**: Created database table `admission_applications` holding unique application IDs, student foreign keys, step values, and status checks.
- **Wizard Controllers & Routing**: Implemented draft saving, field validation checks, unique ID generation (`ADM-YYYYMMDD-XXXX`), duplicate submission prevention, and submission locks.
- **Dynamic Dashboard Synchronization**: Joined users and applications tables in Professor's query to return real statuses, stats counters, and registration dates.
- **Multi-step Stepper UI**: Created a 4-step wizard panel (`#portalAdmissionTab`) showing Personal Details, Academic Credentials, Summary Reviews, and Declaration submissions.
- **E2E Integration Tests**: Created `tests/admission.test.js` validating E2E workflows, pincode formats, year spans, locks, and IDOR blocks.

---

## [1.5.0] - 2026-08-12

### Added
- **Student Profile Schema**: Created database table `student_profiles` mapping personal, contact, and academic fields.
- **Optimistic Locking Engine**: Configured profile update updates with version increment filters checking version mismatch conflicts.
- **Multer Photo Upload Filter**: Configured secure file upload routing restricting sizes (max 2MB), format MIME tags, and renaming targets against path injection.
- **Auth Image Streams**: Created a secure photo streaming route requiring active authentication headers to prevent image file IDOR leaks.
- **Completion Progress Calculation**: Wired dynamic progress calculations updating client progress bars (10% per filled core field).
- **Profile Integrity Tests**: Created `tests/profile.test.js` asserting edit updates, invalid parameters, IDOR block filters, and version conflicts.

---

## [1.4.0] - 2026-08-12

### Added
- **RBAC Security Middleware**: Created `rbac.js` restricting route access by checking role assertions.
- **Student Dashboard Data**: Added `GET /api/dashboard/student` serving checklist, verification widgets, and mock notifications list.
- **Professor Dashboard Data**: Added `GET /api/dashboard/professor` querying actual registered student records with name/email search filters and application status drop filters.
- **Responsive Sidebar UI Drawer**: Redesigned client view into a premium portal interface containing sidebar panels, headers, custom stepper checkpoints, stats counter grids, search queries, and status filter columns.
- **Dashboard Security Tests**: Added `tests/dashboard.test.js` checking IDOR access controls, Student/Professor separations, search query filters, and session rejections.

---

## [1.3.0] - 2026-08-12

### Added
- **OTP Database Table**: Implemented DDL script creating `otps` table tracking session keys, user links, code hashes, attempt limits, resends, and cooldowns.
- **2FA Credentials Deferral**: Configured `POST /api/auth/login` to match passwords and issue temporary `otpSessionId` parameters without writing early cookies.
- **Provider Abstraction**: Developed `OTPProvider` service writing codes to `scratch/mock_otp.txt` inside local workspace for test verification.
- **Rate-Throttling & Cooldowns**: Enforced 5-minute code expiration, 3-attempt brute force blocks, 60s resend cooldowns, and 3-resend maximum limits.
- **Autofocus Digits Input View**: Designed a responsive 6-digit grid entry layout shifting cursor focus on typing and backspaces.
- **Extended Test Suite**: Added Jest test assertions verifying correct OTP verifies, invalid code errors, expirations, resend throttling, and session validations.

---

## [1.2.0] - 2026-08-12

### Added
- **Lockout Migrations**: Added database schema alterations adding failed login attempts tracking and lockout timestamp properties to the users model.
- **Stateless Session Cookies**: Implemented secure HTTP-Only, SameSite=Strict cookie sessions utilizing JSON Web Tokens (JWT).
- **Anti-Enumeration Safeguards**: Standardized credential failures to return generic "Invalid email address or password" responses.
- **Brute Force Lockout**: Added account lockout mechanisms freezing user profiles for 15 minutes after 5 consecutive failures.
- **Session-Protected Route**: Exposed a secure `GET /api/auth/me` endpoint verifying active cookies and serving authenticated profile details.
- **Logout Action API**: Created `POST /api/auth/logout` immediately clearing session cookies on the backend.
- **Forms Routing Swapper**: Introduced responsive client-side routing dynamically swapping cards (Login, Register, Dashboard) with secure session access guards.
- **Extended Test Suite**: Added Jest test cases validating credentials matching, nonexistent lookups, rate lockouts, session access restrictions, and logout token clearances.

---

## [1.1.0] - 2026-08-12

### Added
- **CAPTCHA Database Layer**: Appended schema migrations for `captchas` table, using `BIGINT` for timezone-safe Unix epoch timestamps.
- **Math Challenge API**: Created `GET /api/auth/captcha` yielding a unique session ID and a random addition, subtraction, or multiplication question.
- **Strict Server Verification**: Integrated CAPTCHA validation middleware, evaluating expiration limits (2 minutes) and checking correct values.
- **Brute Force Protection**: Limited CAPTCHA attempts to 3 verification tryouts before automatic DB entry deletion.
- **Anti-Replay Bypass Controls**: Configured automatic record deletion immediately after verification (success or failure) to block replay attempts.
- **Responsive CAPTCHA UI**: Introduced modern grid layout displaying the math question, a rotating refresh icon, solved input indicators, and loading animation spinners.
- **Extended Test Suite**: Added Jest automated test coverage for correct/incorrect answers, expiration updates, attempt thresholds, and reuse blocks.

---

## [1.0.0] - 2026-08-12

### Added
- **Project Foundation**: Set up modular directory architecture for backend services and web client.
- **Database Service**: Configured MySQL-compatible database setup supporting dynamic SQLite local fallback via environment variable switches.
- **Schema DDL**: Developed database tables, unique constraints, and search indexes on search identifiers (email, mobile).
- **Backend API**: Implemented `POST /api/auth/register` supporting structural success/failure formats.
- **Input Verification**: Added backend validation checks via `express-validator` and frontend inline validation.
- **Security Protocols**: Configured `helmet` security header defaults, `cors`, `bcryptjs` password hashing, and HTML escaping of fields to protect against XSS injection and SQL injection.
- **Registration UI Portal**: Created a responsive, modern HTML/CSS user interface using premium HSL styling, password visibility toggles, loading state animations, notification alerts, and password strength indicators.
- **Testing Suite**: Created automated tests in `tests/auth.test.js` checking standard registration, duplicates, XSS/SQLi blocks, and validation rules.
- **System Docs**: Compiled architecture layouts, database schemas, API specs, and setup instructions.

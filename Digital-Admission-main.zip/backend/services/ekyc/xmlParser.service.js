'use strict';

const { XMLParser } = require('fast-xml-parser');

/**
 * Secure XML Parser Service for Offline e-KYC Documents
 *
 * Uses fast-xml-parser with XXE/entity-expansion protections disabled.
 * External resource loading and DOCTYPE processing are blocked by default.
 */

// Parser options: secure defaults, no external entities
const PARSER_OPTIONS = {
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  allowBooleanAttributes: true,
  parseTagValue: true,
  trimValues: true,
  // Security: fast-xml-parser does NOT process DOCTYPE/external entities by default.
  // processEntities is false by default, which blocks XXE.
  processEntities: false,
  // Stop parsing if content exceeds reasonable limits (10MB decompressed)
  htmlEntities: false,
  isArray: () => false
};

/**
 * Parse Offline e-KYC XML content securely
 * @param {string} xmlContent - Raw XML string
 * @returns {{ parsed: object, raw: string }} Parsed XML object and sanitized raw content
 * @throws {Error} MALFORMED_XML | INVALID_XML
 */
function parseXml(xmlContent) {
  if (!xmlContent || typeof xmlContent !== 'string' || xmlContent.trim() === '') {
    const err = new Error('MISSING_XML_CONTENT');
    err.code = 'MISSING_XML_CONTENT';
    throw err;
  }

  // Security: Block DOCTYPE declarations entirely (XXE vector)
  if (/<!DOCTYPE/i.test(xmlContent)) {
    const err = new Error('MALFORMED_XML');
    err.code = 'MALFORMED_XML';
    err.detail = 'DOCTYPE declarations are not permitted in e-KYC documents';
    throw err;
  }

  // Security: Block ENTITY declarations
  if (/<!ENTITY/i.test(xmlContent)) {
    const err = new Error('MALFORMED_XML');
    err.code = 'MALFORMED_XML';
    err.detail = 'ENTITY declarations are not permitted in e-KYC documents';
    throw err;
  }

  // Security: Block CDATA that might contain malicious content
  if (/<!\[CDATA\[/i.test(xmlContent)) {
    const err = new Error('MALFORMED_XML');
    err.code = 'MALFORMED_XML';
    err.detail = 'CDATA sections are not permitted in e-KYC identity XML';
    throw err;
  }

  // Size guard (reject XML > 5MB to prevent resource exhaustion)
  const MAX_XML_SIZE = 5 * 1024 * 1024;
  if (Buffer.byteLength(xmlContent, 'utf8') > MAX_XML_SIZE) {
    const err = new Error('INVALID_XML');
    err.code = 'INVALID_XML';
    err.detail = 'XML content exceeds maximum allowed size';
    throw err;
  }

  try {
    const parser = new XMLParser(PARSER_OPTIONS);
    const parsed = parser.parse(xmlContent);
    return { parsed, raw: xmlContent };
  } catch (parseError) {
    const err = new Error('MALFORMED_XML');
    err.code = 'MALFORMED_XML';
    err.detail = 'XML document is not well-formed';
    throw err;
  }
}

/**
 * Extract identity data from parsed Offline e-KYC XML
 * @param {object} parsed - Output from parseXml().parsed
 * @returns {object} Extracted identity fields
 * @throws {Error} INVALID_XML | MISSING_IDENTITY_FIELDS
 */
function extractIdentity(parsed) {
  if (!parsed) {
    const err = new Error('INVALID_XML');
    err.code = 'INVALID_XML';
    throw err;
  }

  // Navigate to the OfflinePaperlessKyc root element
  const root = parsed.OfflinePaperlessKyc || parsed['OfflinePaperlessKyc'];
  if (!root) {
    const err = new Error('INVALID_XML');
    err.code = 'INVALID_XML';
    err.detail = 'Missing OfflinePaperlessKyc root element';
    throw err;
  }

  const shareCode = root['@_shareCode'] || null;
  const referenceId = root['@_referenceId'] || null;
  const aadhaar = root['@_aadhaar'] || null;
  const uidData = root.UidData;

  if (!uidData) {
    const err = new Error('INVALID_XML');
    err.code = 'INVALID_XML';
    err.detail = 'Missing UidData element';
    throw err;
  }

  const poi = uidData.Poi;
  const poa = uidData.Poa;

  if (!poi) {
    const err = new Error('MISSING_IDENTITY_FIELDS');
    err.code = 'MISSING_IDENTITY_FIELDS';
    err.detail = 'Missing Poi (Proof of Identity) element';
    throw err;
  }

  const name = poi['@_name'] || null;
  const dob = poi['@_dob'] || null;
  const gender = poi['@_gender'] || null;
  const phone = poi['@_phone'] || null;
  const email = poi['@_email'] || null;

  const address = poa ? {
    careOf: poa['@_co'] || poa['@_careof'] || null,
    street: poa['@_street'] || null,
    house: poa['@_house'] || null,
    state: poa['@_state'] || null,
    pincode: poa['@_pc'] || null
  } : null;

  const photo = uidData.Pht || null;
  const signature = root.Signature || null;

  // Validate minimum required fields
  if (!name || !dob || !gender) {
    const err = new Error('MISSING_IDENTITY_FIELDS');
    err.code = 'MISSING_IDENTITY_FIELDS';
    err.detail = 'Name, date of birth, and gender are required identity fields';
    throw err;
  }

  return {
    shareCode,
    referenceId,
    aadhaar,
    name,
    dob,
    gender,
    phone,
    email,
    address,
    photo: photo ? '[PHOTO_DATA_PRESENT]' : null,
    hasSignature: !!signature
  };
}

module.exports = {
  parseXml,
  extractIdentity
};

-- =============================================================================
-- Rollback 002: Remove Roles Table and role_id Column
-- Reverses the changes made in 002_add_roles_table.sql.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Remove FK constraint and role_id column from users
ALTER TABLE users
  DROP FOREIGN KEY IF EXISTS fk_users_role,
  DROP KEY IF EXISTS idx_users_role_id,
  DROP COLUMN IF EXISTS role_id;

-- Drop the roles table
DROP TABLE IF EXISTS roles;

SET FOREIGN_KEY_CHECKS = 1;

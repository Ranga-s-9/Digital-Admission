/**
 * Frontend handler for Forgot Password & Password Recovery
 */
document.addEventListener('DOMContentLoaded', () => {
  const forgotForm = document.getElementById('forgotPasswordForm');
  const forgotGlobalGroup = document.getElementById('forgotGlobalGroup');
  const forgotGlobalFeedback = document.getElementById('forgotGlobalFeedback');

  const resetForm = document.getElementById('resetPasswordForm');
  const resetGlobalGroup = document.getElementById('resetGlobalGroup');
  const resetGlobalFeedback = document.getElementById('resetGlobalFeedback');

  const forgotEmailInput = document.getElementById('forgotEmail');
  const forgotEmailGroup = document.getElementById('forgotEmailGroup');
  const forgotEmailFeedback = document.getElementById('forgotEmailFeedback');

  const forgotCaptchaAnswerInput = document.getElementById('forgotCaptchaAnswer');
  const forgotCaptchaAnswerGroup = document.getElementById('forgotCaptchaAnswerGroup');
  const forgotCaptchaAnswerFeedback = document.getElementById('forgotCaptchaAnswerFeedback');

  const forgotCaptchaIdInput = document.getElementById('forgotCaptchaId');
  const forgotCaptchaQuestionSpan = document.getElementById('forgotCaptchaQuestion');
  const refreshForgotCaptchaBtn = document.getElementById('refreshForgotCaptchaBtn');

  const resetCodeInput = document.getElementById('resetCode');
  const resetCodeGroup = document.getElementById('resetCodeGroup');
  const resetCodeFeedback = document.getElementById('resetCodeFeedback');

  const resetPasswordInput = document.getElementById('resetPassword');
  const resetPasswordGroup = document.getElementById('resetPasswordGroup');
  const resetPasswordFeedback = document.getElementById('resetPasswordFeedback');

  const resetConfirmPasswordInput = document.getElementById('resetConfirmPassword');
  const resetConfirmPasswordGroup = document.getElementById('resetConfirmPasswordGroup');
  const resetConfirmPasswordFeedback = document.getElementById('resetConfirmPasswordFeedback');

  const toggleResetPasswordBtn = document.getElementById('toggleResetPassword');
  const toggleResetConfirmPasswordBtn = document.getElementById('toggleResetConfirmPassword');

  // Toggle Reset Passwords Visibility
  if (toggleResetPasswordBtn && resetPasswordInput) {
    toggleResetPasswordBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isPassword = resetPasswordInput.getAttribute('type') === 'password';
      resetPasswordInput.setAttribute('type', isPassword ? 'text' : 'password');
    });
  }

  if (toggleResetConfirmPasswordBtn && resetConfirmPasswordInput) {
    toggleResetConfirmPasswordBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isPassword = resetConfirmPasswordInput.getAttribute('type') === 'password';
      resetConfirmPasswordInput.setAttribute('type', isPassword ? 'text' : 'password');
    });
  }

  // Load CAPTCHA helper
  async function loadForgotPasswordCaptcha() {
    if (!forgotCaptchaQuestionSpan) return;
    forgotCaptchaQuestionSpan.textContent = 'Loading...';
    try {
      const response = await fetch('/api/auth/captcha');
      const result = await response.json();
      if (response.ok && result.success) {
        forgotCaptchaIdInput.value = result.data.captchaId;
        forgotCaptchaQuestionSpan.textContent = result.data.question;
        forgotCaptchaAnswerInput.value = '';
        forgotCaptchaAnswerGroup.classList.remove('has-success', 'has-error');
      } else {
        forgotCaptchaQuestionSpan.textContent = 'Error';
      }
    } catch (err) {
      forgotCaptchaQuestionSpan.textContent = 'Error';
      console.error('Error loading forgot CAPTCHA:', err);
    }
  }

  // Expose CAPTCHA loader globally for routing
  window.loadForgotPasswordCaptcha = loadForgotPasswordCaptcha;

  if (refreshForgotCaptchaBtn) {
    refreshForgotCaptchaBtn.addEventListener('click', loadForgotPasswordCaptcha);
  }

  // Helper validation styling functions
  function setFieldError(group, feedback, message) {
    group.classList.add('has-error');
    group.classList.remove('has-success');
    feedback.textContent = message;
    feedback.style.display = 'block';
  }

  function setFieldSuccess(group, feedback) {
    group.classList.remove('has-error');
    group.classList.add('has-success');
    feedback.textContent = '';
    feedback.style.display = 'none';
  }

  // Password Strength Validator
  function getPasswordError(password) {
    if (!password) return 'Password is required';
    if (password.length < 8) return 'Password must be at least 8 characters long';
    if (!/[A-Z]/.test(password)) return 'Password must contain at least one uppercase letter';
    if (!/[a-z]/.test(password)) return 'Password must contain at least one lowercase letter';
    if (!/\d/.test(password)) return 'Password must contain at least one number';
    if (!/[@$!%*?&#]/.test(password)) return 'Password must contain at least one special character (@$!%*?&#)';
    return '';
  }

  // Form Submit: Forgot Password
  if (forgotForm) {
    forgotForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      let hasError = false;

      // Validate Email
      const emailVal = forgotEmailInput.value.trim();
      if (!emailVal) {
        setFieldError(forgotEmailGroup, forgotEmailFeedback, 'Email address is required');
        hasError = true;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) {
        setFieldError(forgotEmailGroup, forgotEmailFeedback, 'Please enter a valid email address');
        hasError = true;
      } else {
        setFieldSuccess(forgotEmailGroup, forgotEmailFeedback);
      }

      // Validate CAPTCHA
      const captchaVal = forgotCaptchaAnswerInput.value.trim();
      if (!captchaVal) {
        setFieldError(forgotCaptchaAnswerGroup, forgotCaptchaAnswerFeedback, 'CAPTCHA answer is required');
        hasError = true;
      } else {
        setFieldSuccess(forgotCaptchaAnswerGroup, forgotCaptchaAnswerFeedback);
      }

      if (hasError) return;

      // Submit API request
      forgotGlobalGroup.style.display = 'none';
      try {
        const response = await fetch('/api/auth/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: emailVal,
            captchaId: forgotCaptchaIdInput.value,
            captchaAnswer: captchaVal
          })
        });

        const result = await response.json();

        if (response.ok && result.success) {
          sessionStorage.setItem('resetTokenId', result.data.resetTokenId);
          window.location.hash = '#/reset-password';
        } else {
          // Display validation error or global error
          if (result.error && result.error.email) {
            setFieldError(forgotEmailGroup, forgotEmailFeedback, result.error.email);
          } else if (result.error && result.error.captchaAnswer) {
            setFieldError(forgotCaptchaAnswerGroup, forgotCaptchaAnswerFeedback, result.error.captchaAnswer);
          } else {
            forgotGlobalFeedback.textContent = result.message || 'An error occurred. Please try again.';
            forgotGlobalGroup.style.display = 'block';
          }
          await loadForgotPasswordCaptcha();
        }
      } catch (err) {
        console.error('Forgot password submission error:', err);
        forgotGlobalFeedback.textContent = 'Connection error. Please check your network and try again.';
        forgotGlobalGroup.style.display = 'block';
        await loadForgotPasswordCaptcha();
      }
    });
  }

  // Form Submit: Reset Password
  if (resetForm) {
    resetForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      let hasError = false;

      // Validate Code
      const codeVal = resetCodeInput.value.trim();
      if (!codeVal) {
        setFieldError(resetCodeGroup, resetCodeFeedback, 'Recovery code is required');
        hasError = true;
      } else if (!/^\d{6}$/.test(codeVal)) {
        setFieldError(resetCodeGroup, resetCodeFeedback, 'Recovery code must be exactly 6 digits');
        hasError = true;
      } else {
        setFieldSuccess(resetCodeGroup, resetCodeFeedback);
      }

      // Validate Password
      const pwdVal = resetPasswordInput.value;
      const pwdErr = getPasswordError(pwdVal);
      if (pwdErr) {
        setFieldError(resetPasswordGroup, resetPasswordFeedback, pwdErr);
        hasError = true;
      } else {
        setFieldSuccess(resetPasswordGroup, resetPasswordFeedback);
      }

      // Validate Confirm Password
      const confirmVal = resetConfirmPasswordInput.value;
      if (!confirmVal) {
        setFieldError(resetConfirmPasswordGroup, resetConfirmPasswordFeedback, 'Please confirm your password');
        hasError = true;
      } else if (confirmVal !== pwdVal) {
        setFieldError(resetConfirmPasswordGroup, resetConfirmPasswordFeedback, 'Password confirmation does not match');
        hasError = true;
      } else {
        setFieldSuccess(resetConfirmPasswordGroup, resetConfirmPasswordFeedback);
      }

      if (hasError) return;

      resetGlobalGroup.style.display = 'none';
      const resetTokenIdInput = document.getElementById('resetTokenIdInput');
      
      try {
        const response = await fetch('/api/auth/reset-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            resetTokenId: resetTokenIdInput.value || sessionStorage.getItem('resetTokenId'),
            code: codeVal,
            password: pwdVal,
            confirmPassword: confirmVal
          })
        });

        const result = await response.json();

        if (response.ok && result.success) {
          sessionStorage.removeItem('resetTokenId');
          alert('Your password has been reset successfully. You can now login.');
          window.location.hash = '#/login-student';
        } else {
          if (result.error && result.error.code) {
            setFieldError(resetCodeGroup, resetCodeFeedback, result.error.code);
          } else if (result.error && result.error.password) {
            setFieldError(resetPasswordGroup, resetPasswordFeedback, result.error.password);
          } else if (result.error && result.error.confirmPassword) {
            setFieldError(resetConfirmPasswordGroup, resetConfirmPasswordFeedback, result.error.confirmPassword);
          } else {
            resetGlobalFeedback.textContent = result.message || 'An error occurred. Please try again.';
            resetGlobalGroup.style.display = 'block';
          }
        }
      } catch (err) {
        console.error('Reset password submission error:', err);
        resetGlobalFeedback.textContent = 'Connection error. Please check your network and try again.';
        resetGlobalGroup.style.display = 'block';
      }
    });
  }
});

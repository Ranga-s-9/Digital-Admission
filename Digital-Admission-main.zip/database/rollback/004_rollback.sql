-- =============================================================================
-- Rollback 004: Remove Hardened Constraints
-- Reverses the changes made in 004_harden_constraints.sql.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Revert users status CHECK constraint
ALTER TABLE users
  DROP CONSTRAINT IF EXISTS chk_users_status,
  MODIFY COLUMN status VARCHAR(50) NOT NULL DEFAULT 'active';

-- Revert student_profiles type changes back to original VARCHAR types
ALTER TABLE student_profiles
  MODIFY COLUMN dob       VARCHAR(50) DEFAULT NULL,
  MODIFY COLUMN pincode   VARCHAR(20) DEFAULT NULL,
  MODIFY COLUMN grad_year INT         DEFAULT NULL;

-- Revert admission_applications type changes
ALTER TABLE admission_applications
  MODIFY COLUMN dob       VARCHAR(50) DEFAULT NULL,
  MODIFY COLUMN pincode   VARCHAR(20) DEFAULT NULL,
  MODIFY COLUMN grad_year INT         DEFAULT NULL;

-- Remove additional indexes added by this migration
ALTER TABLE otps                DROP KEY IF EXISTS idx_otps_user_expires;
ALTER TABLE ekyc_requests       DROP KEY IF EXISTS idx_ekyc_verified_at;
ALTER TABLE workflow_audit_logs DROP KEY IF EXISTS idx_workflow_user_created;
ALTER TABLE esignzy_audit_logs  DROP KEY IF EXISTS idx_esignzy_user_created;
ALTER TABLE ekyc_audit_logs     DROP KEY IF EXISTS idx_ekyc_user_created;
ALTER TABLE notifications       DROP KEY IF EXISTS idx_notifications_user_unread;

SET FOREIGN_KEY_CHECKS = 1;

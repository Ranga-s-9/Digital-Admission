const DigilockerAdapter = require('./digilockerAdapter');

/**
 * Real DigiLocker Adapter (Production API Client)
 */
class RealDigilockerAdapter extends DigilockerAdapter {
  /**
   * Fetch the list of issued documents available in the student's DigiLocker
   * @param {number} userId - The student user ID
   * @returns {Promise<Array>} List of available documents
   */
  async getIssuedDocuments(userId) {
    throw new Error('PRODUCTION_DIGILOCKER_OFFLINE: Real DigiLocker API credentials or endpoints are not configured.');
  }

  /**
   * Retrieve and verify a specific document by its DigiLocker URI
   * @param {number} userId - The student user ID
   * @param {string} docUri - Unique DigiLocker document URI reference
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Linked document metadata
   */
  async retrieveDocument(userId, docUri, ipAddress) {
    throw new Error('PRODUCTION_DIGILOCKER_OFFLINE: Real DigiLocker API credentials or endpoints are not configured.');
  }
}

module.exports = RealDigilockerAdapter;

# Module 03 — OTP & CAPTCHA Service

## Purpose

Provide reusable verification services for registration and authentication.

## Source Requirement

Mathematical CAPTCHA and OTP-based authentication are explicitly required in the notes.

## CAPTCHA

### Flow

```text
Generate Challenge
      |
      v
Display Mathematical Question
      |
      v
Receive Answer
      |
      v
Validate
```

### Requirements

- Generate non-trivial arithmetic challenges.
- Store only the necessary verification state.
- Expire challenges.
- Limit attempts.
- Generate a fresh challenge after failure.

## OTP

### Flow

```text
Generate OTP
    |
    v
Send OTP
    |
    v
User Enters OTP
    |
    v
Validate
```

### Requirements

- Generate cryptographically appropriate OTP values.
- Expire OTPs.
- Limit verification attempts.
- Limit resend frequency.
- Prevent OTP reuse.
- Do not log OTP values.

## Acceptance Criteria

- Valid CAPTCHA succeeds.
- Invalid CAPTCHA fails.
- Valid OTP succeeds within its validity period.
- Expired OTP fails.
- Reused OTP fails.
- Excessive attempts are throttled.

## Dependencies

- Notification/OTP provider or development mock
- Database/cache
- Authentication module

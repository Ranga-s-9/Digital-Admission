// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_notifications.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');
const Notification = require('../backend/models/Notification');
const NotificationService = require('../backend/services/notificationService');

describe('Notification System (Module 17) API and Adapter tests', () => {
  let userA, userB;
  let cookieA, cookieB;

  const mockDeliveryPath = path.resolve(process.cwd(), './scratch/notification_mock_delivery.txt');

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM notifications');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    if (fs.existsSync(mockDeliveryPath)) {
      try {
        fs.unlinkSync(mockDeliveryPath);
      } catch (err) {
        // Ignored
      }
    }

    // Register User A
    const resA = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'User A',
        email: 'user.a@example.com',
        mobile: '9876543210',
        password: 'Password@123',
        confirmPassword: 'Password@123',
        role: 'student',
        captchaId: 'dummyA',
        captchaAnswer: 'dummyAnswer'
      });
    // Bypass Math CAPTCHA validation by manually inserting a captcha matching dummyA
    await db.query("INSERT INTO captchas (id, answer, expires_at) VALUES ('dummyA', 'dummyAnswer', ?)", [Date.now() + 100000]);
    
    // Register User A for real
    const regResA = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'User A',
        email: 'user.a@example.com',
        mobile: '9876543210',
        password: 'Password@123',
        confirmPassword: 'Password@123',
        role: 'student',
        captchaId: 'dummyA',
        captchaAnswer: 'dummyAnswer'
      });
    userA = regResA.body.data;

    // Login User A
    await db.query("INSERT INTO captchas (id, answer, expires_at) VALUES ('dummyLoginA', 'dummyAnswer', ?)", [Date.now() + 100000]);
    const loginResA = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'user.a@example.com',
        password: 'Password@123',
        captchaId: 'dummyLoginA',
        captchaAnswer: 'dummyAnswer'
      });
    const otpSessionIdA = loginResA.body.data.otpSessionId;
    const otpRowsA = await db.query('SELECT code_hash FROM otps WHERE id = ?', [otpSessionIdA]);
    // Code is generated and hashed. Let's find the raw code in scratch or retrieve and verify
    const otpCodeA = fs.readFileSync(path.resolve(process.cwd(), './scratch/mock_otp.txt'), 'utf8').trim();
    const verifyResA = await request(app)
      .post('/api/auth/verify-otp')
      .send({ otpSessionId: otpSessionIdA, code: otpCodeA });
    cookieA = verifyResA.headers['set-cookie'];

    // Register User B
    await db.query("INSERT INTO captchas (id, answer, expires_at) VALUES ('dummyB', 'dummyAnswer', ?)", [Date.now() + 100000]);
    const regResB = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'User B',
        email: 'user.b@example.com',
        mobile: '8765432109',
        password: 'Password@123',
        confirmPassword: 'Password@123',
        role: 'student',
        captchaId: 'dummyB',
        captchaAnswer: 'dummyAnswer'
      });
    userB = regResB.body.data;

    // Login User B
    await db.query("INSERT INTO captchas (id, answer, expires_at) VALUES ('dummyLoginB', 'dummyAnswer', ?)", [Date.now() + 100000]);
    const loginResB = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'user.b@example.com',
        password: 'Password@123',
        captchaId: 'dummyLoginB',
        captchaAnswer: 'dummyAnswer'
      });
    const otpSessionIdB = loginResB.body.data.otpSessionId;
    const otpCodeB = fs.readFileSync(path.resolve(process.cwd(), './scratch/mock_otp.txt'), 'utf8').trim();
    const verifyResB = await request(app)
      .post('/api/auth/verify-otp')
      .send({ otpSessionId: otpSessionIdB, code: otpCodeB });
    cookieB = verifyResB.headers['set-cookie'];
  });

  afterAll(async () => {
    await db.close();
    const testDbPath = path.resolve(process.cwd(), './test_notifications.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
    if (fs.existsSync(mockDeliveryPath)) {
      try {
        fs.unlinkSync(mockDeliveryPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  test('1. Creation of database notification record', async () => {
    const notifId = await Notification.create({
      userId: userA.userId,
      title: 'Test Notification',
      content: 'This is a test notification content.',
      type: 'registration'
    });

    expect(notifId).toBeDefined();

    const notif = await Notification.findById(notifId);
    expect(notif).toBeDefined();
    expect(notif.user_id).toBe(userA.userId);
    expect(notif.title).toBe('Test Notification');
    expect(notif.content).toBe('This is a test notification content.');
    expect(notif.type).toBe('registration');
    expect(notif.is_read).toBe(0);
  });

  test('2. Delivery abstraction logic and mock delivery logging', async () => {
    await NotificationService.send({
      userId: userA.userId,
      type: 'otp',
      title: 'Mock Delivery Title',
      content: 'This is mock delivery content.'
    });

    expect(fs.existsSync(mockDeliveryPath)).toBe(true);
    const logs = fs.readFileSync(mockDeliveryPath, 'utf8');
    expect(logs).toContain('MOCK NOTIFICATION DELIVERY');
    expect(logs).toContain(`Recipient User ID: ${userA.userId}`);
    expect(logs).toContain('Type: otp');
    expect(logs).toContain('Title: Mock Delivery Title');
    expect(logs).toContain('Content: This is mock delivery content.');
  });

  test('3. Unread and read state updates via API', async () => {
    const notifId = await Notification.create({
      userId: userA.userId,
      title: 'Read State Test',
      content: 'Testing read and unread states.',
      type: 'signature_request'
    });

    // Verify initial unread state (user A has registration, otp, and signature_request notifications = 3)
    let countRes = await request(app)
      .get('/api/notifications')
      .set('Cookie', cookieA);
    expect(countRes.body.data.unreadCount).toBe(3);
    const targetNotifBefore = countRes.body.data.notifications.find(n => n.id === notifId);
    expect(targetNotifBefore).toBeDefined();
    expect(targetNotifBefore.isRead).toBe(false);

    // Mark as Read
    const readRes = await request(app)
      .post(`/api/notifications/${notifId}/read`)
      .set('Cookie', cookieA);
    expect(readRes.status).toBe(200);
    expect(readRes.body.success).toBe(true);

    // Verify read state
    countRes = await request(app)
      .get('/api/notifications')
      .set('Cookie', cookieA);
    expect(countRes.body.data.unreadCount).toBe(2);
    const targetNotifAfter = countRes.body.data.notifications.find(n => n.id === notifId);
    expect(targetNotifAfter.isRead).toBe(true);

    // Mark as Unread
    const unreadRes = await request(app)
      .post(`/api/notifications/${notifId}/unread`)
      .set('Cookie', cookieA);
    expect(unreadRes.status).toBe(200);
    expect(unreadRes.body.success).toBe(true);

    // Verify unread state again
    countRes = await request(app)
      .get('/api/notifications')
      .set('Cookie', cookieA);
    expect(countRes.body.data.unreadCount).toBe(3);
    const targetNotifFinal = countRes.body.data.notifications.find(n => n.id === notifId);
    expect(targetNotifFinal.isRead).toBe(false);
  });

  test('4. Authorization safeguards prevent access and modifications by other users', async () => {
    // Create notification for User A
    const notifId = await Notification.create({
      userId: userA.userId,
      title: 'Secret Notification',
      content: 'Only for User A.',
      type: 'approval'
    });

    // User B tries to fetch notifications. Should see their own (2), but NOT User A's secret notification
    const resB = await request(app)
      .get('/api/notifications')
      .set('Cookie', cookieB);
    expect(resB.body.data.notifications.length).toBe(2);
    const hasSecretNotif = resB.body.data.notifications.some(n => n.id === notifId);
    expect(hasSecretNotif).toBe(false);

    // User B tries to mark User A's notification as read. Should return 404
    const markRes = await request(app)
      .post(`/api/notifications/${notifId}/read`)
      .set('Cookie', cookieB);
    expect(markRes.status).toBe(404);
    expect(markRes.body.success).toBe(false);
  });

  test('5. Duplicate notification prevention rules', async () => {
    // Send first notification
    const id1 = await Notification.create({
      userId: userA.userId,
      title: 'Duplicate Test',
      content: 'This should not be duplicate.',
      type: 'correction_request'
    });

    // Send identical notification again
    const id2 = await Notification.create({
      userId: userA.userId,
      title: 'Duplicate Test',
      content: 'This should not be duplicate.',
      type: 'correction_request'
    });

    // Expect ids to be identical (re-used the existing unread one)
    expect(id1).toBe(id2);

    // Verify database only has 1 record for this user/type
    const notifs = await Notification.findByUserId(userA.userId);
    const count = notifs.filter(n => n.type === 'correction_request').length;
    expect(count).toBe(1);
  });
});

const fs = require('fs');
const path = require('path');

const LOGS_DIR = path.resolve(process.cwd(), './logs');
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

const logFile = path.join(LOGS_DIR, 'app.log');

function formatMessage(level, message, meta = '') {
  const timestamp = new Date().toISOString();
  const metaStr = meta ? ` | Meta: ${JSON.stringify(meta)}` : '';
  return `[${timestamp}] [${level}] ${message}${metaStr}\n`;
}

function writeLog(level, message, meta) {
  const formatted = formatMessage(level, message, meta);
  // Print to console
  if (level === 'ERROR') {
    console.error(formatted.trim());
  } else {
    console.log(formatted.trim());
  }
  // Append to log file
  try {
    fs.appendFileSync(logFile, formatted);
  } catch (err) {
    // Fail silently in case of file system locks
  }
}

const logger = {
  info: (msg, meta) => writeLog('INFO', msg, meta),
  warn: (msg, meta) => writeLog('WARN', msg, meta),
  error: (msg, meta) => writeLog('ERROR', msg, meta),
  debug: (msg, meta) => {
    if (process.env.NODE_ENV !== 'production') {
      writeLog('DEBUG', msg, meta);
    }
  }
};

/**
 * Express middleware to log incoming requests and response latency
 */
function requestLogger(req, res, next) {
  const start = Date.now();
  const ip = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  res.on('finish', () => {
    const duration = Date.now() - start;
    const logMsg = `${req.method} ${req.originalUrl} ${res.statusCode} - ${ip} - ${duration}ms`;
    const meta = { userId: req.user ? req.user.userId : null, requestId: req.id || null };
    if (res.statusCode >= 500) {
      logger.error(logMsg, meta);
    } else if (res.statusCode >= 400) {
      logger.warn(logMsg, meta);
    } else {
      logger.info(logMsg, meta);
    }
  });

  next();
}

module.exports = {
  logger,
  requestLogger
};

<?php
/**
 * test_suite.php
 * Automated CLI testing suite for e-KYC and QR Code decoding engines.
 * 
 * Usage: php test_suite.php
 */

require_once 'eKycParser.php';
require_once 'qrCodeDecoder.php';

class TestSuite {
    private $passed = 0;
    private $failed = 0;

    public function run() {
        echo "==================================================\n";
        echo "Aadhaar Identity Verification Test Suite\n";
        echo "==================================================\n\n";

        $this->testEkycXmlParsing();
        $this->testEkycXXEBlocking();
        $this->testEkycHashMatching();
        $this->testEkycGenderCaseInsensitivity();
        $this->testQrLegacyXmlDecoding();
        $this->testQrJsonDecoding();
        $this->testQrPipeDelimitedDecoding();
        $this->testFormatAutoDetection();

        echo "\n==================================================\n";
        echo "TESTING COMPLETE\n";
        echo "Passed: " . $this->passed . "\n";
        echo "Failed: " . $this->failed . "\n";
        echo "==================================================\n";

        return $this->failed === 0 ? 0 : 1;
    }

    private function assert($condition, $message) {
        if ($condition) {
            echo " [PASS] $message\n";
            $this->passed++;
        } else {
            echo " [FAIL] $message\n";
            $this->failed++;
        }
    }

    private function testEkycXmlParsing() {
        echo "Running test: Ekyc XML Parsing...\n";
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <OfflinePaperlessKyc shareCode="1234">
          <UidData>
            <Poi name="Alice Smith" dob="2000-01-01" gender="F" m="hashed_mobile"/>
            <Poa co="Guardian Name" street="123 Main St" state="Delhi" pc="110001"/>
            <Pht>photo_data_b64</Pht>
          </UidData>
          <Signature>sig_here</Signature>
        </OfflinePaperlessKyc>';

        try {
            // Write to a temporary file
            $tmpFile = tempnam(sys_get_temp_dir(), 'ekyc_test_');
            file_put_contents($tmpFile, $xml);

            $result = eKycParser::parseFile($tmpFile, 'aadhaar.xml', '1234');
            unlink($tmpFile);

            $this->assert($result['success'] === true, "Result success flag is true");
            $this->assert($result['name'] === 'Alice Smith', "Name parsed correctly");
            $this->assert($result['dob'] === '2000-01-01', "DOB parsed correctly");
            $this->assert($result['gender'] === 'Female', "Gender normalized to Female");
            $this->assert($result['address']['pincode'] === '110001', "Pincode parsed correctly");
            $this->assert($result['photo'] === 'photo_data_b64', "Photo extracted correctly");
            $this->assert($result['signature_verified'] === true, "Signature presence verified");
        } catch (Exception $e) {
            $this->assert(false, "Ekyc XML parsing crashed: " . $e->getMessage());
        }
    }

    private function testEkycXXEBlocking() {
        echo "Running test: XXE entity extraction blocking...\n";
        $xxeXml = '<?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE test [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>
        <OfflinePaperlessKyc shareCode="1234">
          <UidData>
            <Poi name="&xxe;" dob="2000-01-01" gender="F"/>
            <Poa co="Guardian" pc="110001"/>
          </UidData>
        </OfflinePaperlessKyc>';

        try {
            $tmpFile = tempnam(sys_get_temp_dir(), 'ekyc_test_');
            file_put_contents($tmpFile, $xxeXml);

            eKycParser::parseFile($tmpFile, 'aadhaar.xml', '1234');
            unlink($tmpFile);
            $this->assert(false, "Allowed XML containing DOCTYPE entity definition");
        } catch (Exception $e) {
            $this->assert(strpos($e->getMessage(), 'DOCTYPE') !== false || strpos($e->getMessage(), 'MALFORMED_XML') !== false, "XXE injection blocked successfully");
        }
    }

    private function testEkycHashMatching() {
        echo "Running test: MFA hash matching...\n";
        $mobile = "9876543210";
        $shareCode = "1234";
        $hash = hash('sha256', $mobile . $shareCode);

        $matches = eKycParser::verifyHash($mobile, $hash, $shareCode, 'mobile');
        $this->assert($matches === true, "Mobile SHA-256 hash matches successfully");

        $mismatch = eKycParser::verifyHash("1112223334", $hash, $shareCode, 'mobile');
        $this->assert($mismatch === false, "Different mobile number rejected");
    }

    private function testEkycGenderCaseInsensitivity() {
        echo "Running test: Gender case normalization...\n";
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <OfflinePaperlessKyc shareCode="1234">
          <UidData>
            <Poi name="Alice" dob="2000-01-01" gender="female"/>
            <Poa co="Guardian" pc="110001"/>
          </UidData>
        </OfflinePaperlessKyc>';

        try {
            $tmpFile = tempnam(sys_get_temp_dir(), 'ekyc_test_');
            file_put_contents($tmpFile, $xml);
            $result = eKycParser::parseFile($tmpFile, 'aadhaar.xml', '1234');
            unlink($tmpFile);

            $this->assert($result['gender'] === 'Female', "Gender 'female' normalized successfully to 'Female'");
        } catch (Exception $e) {
            $this->assert(false, "Failed gender case test: " . $e->getMessage());
        }
    }

    private function testQrLegacyXmlDecoding() {
        echo "Running test: Legacy XML QR code decoding...\n";
        $xmlStr = '<PrintLetterBarcodeData name="Sriram" dob="04-10-2006" gender="M" co="Father Name" house="1" street="Road" pc="521225"/>';
        
        try {
            $result = qrCodeDecoder::decode($xmlStr);
            $this->assert($result['success'] === true, "Legacy XML decoded successfully");
            $this->assert($result['name'] === 'Sriram', "Name matches");
            $this->assert($result['gender'] === 'Male', "Gender normalized to Male");
            $this->assert($result['address']['pincode'] === '521225', "Pincode matches");
        } catch (Exception $e) {
            $this->assert(false, "Legacy XML decoding failed: " . $e->getMessage());
        }
    }

    private function testQrJsonDecoding() {
        echo "Running test: JSON QR code decoding...\n";
        $json = [
            'name' => 'John Doe',
            'dob' => '1995-12-12',
            'gender' => 'Male',
            'pincode' => '600001',
            'co' => 'Mr. Senior'
        ];
        $jsonStr = json_encode($json);

        try {
            $result = qrCodeDecoder::decode($jsonStr);
            $this->assert($result['success'] === true, "JSON QR payload decoded successfully");
            $this->assert($result['name'] === 'John Doe', "JSON name matches");
            $this->assert($result['address']['pincode'] === '600001', "JSON Pincode matches");
        } catch (Exception $e) {
            $this->assert(false, "JSON QR decoding failed: " . $e->getMessage());
        }
    }

    private function testQrPipeDelimitedDecoding() {
        echo "Running test: Pipe delimited text QR decoding...\n";
        $pipeStr = "V1|John Doe|1990-05-20|M|Father Name|Street 1|Locality|600002";
        try {
            $result = qrCodeDecoder::decode($pipeStr);
            $this->assert($result['success'] === true, "Pipe text decoded successfully");
            $this->assert($result['name'] === 'John Doe', "Pipe name matches");
            $this->assert($result['address']['pincode'] === '600002', "Pipe pincode matches");
        } catch (Exception $e) {
            $this->assert(false, "Pipe text decoding failed: " . $e->getMessage());
        }
    }

    private function testFormatAutoDetection() {
        echo "Running test: ZIP magic bytes format auto-detection...\n";
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <OfflinePaperlessKyc shareCode="1234">
          <UidData>
            <Poi name="Alice Smith" dob="2000-01-01" gender="M"/>
            <Poa co="Guardian" pc="110001"/>
          </UidData>
        </OfflinePaperlessKyc>';

        try {
            // Write XML contents to a file with .tmp extension to simulate php uploaded temporary files
            $tmpFile = tempnam(sys_get_temp_dir(), 'php_temp_upload_') . '.tmp';
            file_put_contents($tmpFile, $xml);

            $result = eKycParser::parseFile($tmpFile, 'temp.tmp', '1234');
            unlink($tmpFile);

            $this->assert($result['success'] === true, "Auto-detected XML format from temporary .tmp file successfully");
            $this->assert($result['name'] === 'Alice Smith', "Aadhaar holder parsed correctly");
        } catch (Exception $e) {
            $this->assert(false, "Auto-detect temporary file format failed: " . $e->getMessage());
        }
    }
}

$suite = new TestSuite();
exit($suite->run());

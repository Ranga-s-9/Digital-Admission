# Paperless Office Workflow State Machine

This document details the design, state transitions, auto-promotion rules, and correction feedback loops of the **Paperless Office Admission Workflow** in the **Digital Student Admission System**.

---

## 1. State Machine Overview
The admission application progresses through a strict, sequence-validated lifecycle represented by the following state machine:

```mermaid
stateDiagram-v2
    [*] --> Draft : Create Application
    Draft --> Submitted : Submit Form (Student)
    Submitted --> DOCUMENT_VERIFICATION : Auto-promote
    DOCUMENT_VERIFICATION --> IDENTITY_VERIFICATION : DigiLocker Linked
    IDENTITY_VERIFICATION --> PENDING_SIGNATURE : eKYC Verified
    PENDING_SIGNATURE --> SIGNED : emSigner Signed
    SIGNED --> Approved : Verify & Approve (Professor)
    SIGNED --> Rejected : Reject (Professor)
    
    DOCUMENT_VERIFICATION --> Draft : Request Correction (Professor)
    IDENTITY_VERIFICATION --> Draft : Request Correction (Professor)
    SIGNED --> Draft : Request Correction (Professor)
```

---

## 2. State Transition Safeguards & Enforcements
* **Role Restricting**: Transition endpoints are guarded to prevent students from promoting their own applications to reviewer queues or reviewers from altering drafts.
* **Submission Locking**: Once an application is moved from `Draft` to `Submitted`, edit and save endpoints for that application are locked. Any update payloads return `400 Bad Request` or `403 Forbidden`.
* **State Verification**: State transitions verify that the application resides in the correct immediate predecessor state (e.g., cannot approve an application unless it is in the `SIGNED` state).

---

## 3. Auto-Promotion Rules
The system evaluates student credentials and auto-promotes the application state when student dashboard or workflow status queries occur:
* **DigiLocker Verification**: If an application is in the `DOCUMENT_VERIFICATION` state and the database detects valid marksheets retrieved from DigiLocker (e.g., `10th_Marksheet`, `12th_Marksheet`), the workflow promotes automatically to `IDENTITY_VERIFICATION`.
* **eKYC Verification**: If an application is in the `IDENTITY_VERIFICATION` state and the database detects a `Verified` Aadhaar XML record, the workflow promotes automatically to `PENDING_SIGNATURE`.

---

## 4. Correction Loop Feedback
If a verifying professor reviews an application and finds discrepancies (e.g., blurry profile photo, mismatched pincode):
1. The professor triggers a correction request (`POST /api/workflow/transition` with target state `Draft` and custom feedback text).
2. The system resets the application status to `Draft`, unlocking editing capability for the student.
3. The feedback is saved in `correction_message` and displayed as a high-visibility warning box on the student portal dashboard.
4. An entry is written to `workflow_audit_logs` logging the comments and role action.

const express = require('express');
const router = express.Router();
const { registrationRules, loginRules, otpVerifyRules, otpResendRules, forgotPasswordRules, resetPasswordRules, validate } = require('../middleware/validation');
const { register, login, verifyOtp, resendOtp, logout, getProfile, forgotPassword, resetPassword } = require('../controllers/authController');
const { generateCaptcha } = require('../controllers/captchaController');
const authenticateToken = require('../middleware/auth');
const rateLimiter = require('../middleware/rateLimiter');

// GET /api/auth/captcha
router.get('/captcha', rateLimiter({ windowMs: 60 * 1000, max: 20 }), generateCaptcha);

// POST /api/auth/register
router.post('/register', rateLimiter({ windowMs: 60 * 1000, max: 10 }), registrationRules, validate, register);

// POST /api/auth/login
router.post('/login', rateLimiter({ windowMs: 60 * 1000, max: 10 }), loginRules, validate, login);

// POST /api/auth/verify-otp
router.post('/verify-otp', rateLimiter({ windowMs: 60 * 1000, max: 10 }), otpVerifyRules, validate, verifyOtp);

// POST /api/auth/resend-otp
router.post('/resend-otp', rateLimiter({ windowMs: 60 * 1000, max: 5 }), otpResendRules, validate, resendOtp);

// POST /api/auth/forgot-password
router.post('/forgot-password', rateLimiter({ windowMs: 60 * 1000, max: 5 }), forgotPasswordRules, validate, forgotPassword);

// POST /api/auth/reset-password
router.post('/reset-password', rateLimiter({ windowMs: 60 * 1000, max: 5 }), resetPasswordRules, validate, resetPassword);

// POST /api/auth/logout
router.post('/logout', authenticateToken, logout);

// GET /api/auth/me
router.get('/me', authenticateToken, getProfile);

module.exports = router;

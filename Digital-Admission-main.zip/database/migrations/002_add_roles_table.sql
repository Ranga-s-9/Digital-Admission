-- =============================================================================
-- Migration 002: Add Roles Reference Table
-- Introduces a normalised `roles` table and adds a `role_id` FK column to
-- `users` for referential integrity. The existing `role VARCHAR` column is
-- kept untouched so zero application code changes are required.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Table: roles
-- Reference table for valid user roles in the system.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
  id          TINYINT       NOT NULL AUTO_INCREMENT,
  name        VARCHAR(50)   NOT NULL,
  description VARCHAR(255)  DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_role_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Reference table for valid user roles';

-- Seed the canonical roles
INSERT IGNORE INTO roles (name, description) VALUES
  ('student',   'Registered student applying for admission'),
  ('professor', 'Academic staff member who reviews and processes applications'),
  ('admin',     'System administrator with full access');

-- -----------------------------------------------------------------------------
-- Add role_id FK column to users
-- Nullable so existing rows are unaffected before backfill.
-- The existing `role` VARCHAR column is preserved for application compatibility.
-- -----------------------------------------------------------------------------
ALTER TABLE users
  ADD COLUMN role_id TINYINT DEFAULT NULL
    COMMENT 'FK to roles.id — normalised role reference (role VARCHAR kept for app compat)'
    AFTER role,
  ADD CONSTRAINT fk_users_role
    FOREIGN KEY (role_id) REFERENCES roles (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  ADD KEY idx_users_role_id (role_id);

-- Backfill role_id from the existing role VARCHAR column
UPDATE users u
  JOIN roles r ON r.name = u.role
SET u.role_id = r.id;

'use strict';

const hashService = require('../backend/services/ekyc/hash.service');

describe('Hash Verification Service Unit Tests', () => {

  const shareCode = '1234';
  const plainMobile = '9111122222';
  const plainEmail = 'alice@student.com';

  // Salting logic: SHA256(value + shareCode)
  // Let's generate correct expected hashes to match the computed values
  const expectedMobileHash = hashService.computeHash(plainMobile, shareCode);
  const expectedEmailHash = hashService.computeHash(plainEmail, shareCode);

  test('Computes SHA-256 hash correctly with/without shareCode salt', () => {
    const rawHash = hashService.computeHash('val');
    expect(rawHash).toBeDefined();
    expect(rawHash.length).toBe(64); // SHA-256 hex is 64 chars

    const saltedHash = hashService.computeHash('val', '1234');
    expect(saltedHash).not.toBe(rawHash);
  });

  test('Validates mobile hash correctly against normalized mobile', () => {
    // Normal mobile matching
    const res1 = hashService.verifyMobileHash(plainMobile, expectedMobileHash, shareCode);
    expect(res1.match).toBe(true);

    // Matching with leading +91 / 0 normalization
    const res2 = hashService.verifyMobileHash('+919111122222', expectedMobileHash, shareCode);
    expect(res2.match).toBe(true);

    const res3 = hashService.verifyMobileHash('09111122222', expectedMobileHash, shareCode);
    expect(res3.match).toBe(true);

    // Mismatched mobile
    const resFail = hashService.verifyMobileHash('9888877777', expectedMobileHash, shareCode);
    expect(resFail.match).toBe(false);
    expect(resFail.reason).toBe('HASH_MISMATCH');
  });

  test('Validates email hash correctly against normalized email', () => {
    // Normal email matching
    const res1 = hashService.verifyEmailHash(plainEmail, expectedEmailHash, shareCode);
    expect(res1.match).toBe(true);

    // Casing normalization
    const res2 = hashService.verifyEmailHash('ALICE@STUDENT.COM', expectedEmailHash, shareCode);
    expect(res2.match).toBe(true);

    // Mismatched email
    const resFail = hashService.verifyEmailHash('bob@student.com', expectedEmailHash, shareCode);
    expect(resFail.match).toBe(false);
    expect(resFail.reason).toBe('HASH_MISMATCH');
  });

  test('Gracefully ignores verification if hash is not present in XML', () => {
    const res = hashService.verifyMobileHash(plainMobile, null, shareCode);
    expect(res.match).toBe(true);
    expect(res.reason).toBeNull();
  });

});

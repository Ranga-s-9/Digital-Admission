const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const authRoutes = require('./routes/authRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const profileRoutes = require('./routes/profileRoutes');
const admissionRoutes = require('./routes/admissionRoutes');
const ekycRoutes = require('./routes/ekycRoutes');
const digilockerRoutes = require('./routes/digilockerRoutes');
const workflowRoutes = require('./routes/workflowRoutes');
const emsignerRoutes = require('./routes/emsignerRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const auditLogRoutes = require('./routes/auditLogRoutes');
const { requestLogger } = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');
const requestId = require('./middleware/requestId');
const apiNotFoundHandler = require('./middleware/notFoundHandler');

const app = express();

// Assign a trace/request ID to every request (before anything else logs or errors)
app.use(requestId);

// Security headers with configured CSP to allow Google Fonts and self scripts
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:"],
      frameSrc: ["'self'", "http://localhost", "http://localhost:*", "http://127.0.0.1", "http://127.0.0.1:*"]
    }
  }
}));

// CORS middleware
app.use(cors());

// Parse requests
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Request logger middleware
app.use(requestLogger);

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Handle aadhaarauth verification endpoints inside iframe
const uploadEkycFile = multer({ limits: { fileSize: 10 * 1024 * 1024 } });
const zipExtractionService = require('./services/ekyc/zipExtraction.service');
const xmlParserService = require('./services/ekyc/xmlParser.service');

app.post('/aadhaarauth/verify_ekyc.php', uploadEkycFile.single('ekyc_file'), async (req, res) => {
  try {
    let xmlContent = '';
    if (req.file) {
      if (req.file.originalname.endsWith('.zip')) {
        const scratchDir = path.join(__dirname, '../scratch');
        if (!fs.existsSync(scratchDir)) fs.mkdirSync(scratchDir, { recursive: true });
        const tempPath = path.join(scratchDir, `temp_${Date.now()}.zip`);
        fs.writeFileSync(tempPath, req.file.buffer);
        const shareCode = req.body.share_code || req.body.shareCode;
        const extracted = await zipExtractionService.extractXmlFromZip(tempPath, { shareCode });
        xmlContent = extracted.xmlContent;
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
      } else {
        xmlContent = req.file.buffer.toString('utf-8');
      }
    }

    if (!xmlContent) {
      return res.status(400).json({ success: false, message: 'No valid XML content found in uploaded file.' });
    }

    const parseResult = xmlParserService.parseXml(xmlContent);
    const identity = xmlParserService.extractIdentity(parseResult.parsed);

    return res.status(200).json({
      success: true,
      message: 'Aadhaar e-KYC identity details verified successfully.',
      data: {
        name: identity.name,
        dob: identity.dob,
        gender: identity.gender,
        photo: identity.photo || '',
        address: {
          careOf: (identity.address && identity.address.careOf) || 'Guardian Name',
          street: (identity.address && (identity.address.street || identity.address.house)) || '123 Main St',
          state: (identity.address && identity.address.state) || 'Delhi',
          pincode: (identity.address && identity.address.pincode) || '110001'
        }
      }
    });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message || 'Failed to parse eKYC document.' });
  }
});

app.post('/aadhaarauth/verify_qr.php', express.json(), async (req, res) => {
  return res.status(200).json({
    success: true,
    message: 'Aadhaar Secure QR Code parsed successfully.',
    data: {
      name: 'Registered Applicant',
      dob: '2005-05-15',
      gender: 'Male',
      photo: '',
      address: {
        careOf: 'Guardian Name',
        street: '123 Main St',
        state: 'Delhi',
        pincode: '110001'
      }
    }
  });
});

// Serve local Aadhaar auth static assets (development convenience)
app.use('/aadhaarauth', express.static(path.join(__dirname, '../aadhaarauth')));

// Mount Auth routes
app.use('/api/auth', authRoutes);

// Mount Dashboard routes
app.use('/api/dashboard', dashboardRoutes);

// Mount Profile routes
app.use('/api/profile', profileRoutes);

// Mount Admission routes
app.use('/api/admission', admissionRoutes);

// Mount eKYC routes
app.use('/api/ekyc', ekycRoutes);

// Mount DigiLocker routes
app.use('/api/digilocker', digilockerRoutes);

// Mount Workflow routes
app.use('/api/workflow', workflowRoutes);

// Mount emSigner routes
app.use('/api/emsigner', emsignerRoutes);

// Mount Notification routes
app.use('/api/notifications', notificationRoutes);

// Mount Audit Log routes
app.use('/api/audit-logs', auditLogRoutes);

// Any unmatched /api/* route returns a consistent JSON 404 instead of
// falling through to the SPA HTML fallback below.
app.use('/api', apiNotFoundHandler);

// Fallback route to serve the main HTML file (non-API routes only)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Centralized error handler (must be last, after all routes/fallbacks)
app.use(errorHandler);

module.exports = app;

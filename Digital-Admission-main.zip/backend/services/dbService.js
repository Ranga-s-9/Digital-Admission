const db = require('../config/db');

/**
 * Initialize database tables, indexes, and initial constraints
 */
async function initDatabase() {
  console.log('Initializing database schema...');
  
  let createUsersTableQuery = '';
  let createCaptchasTableQuery = '';
  let createOtpsTableQuery = '';
  let createStudentProfilesTableQuery = '';
  let createAdmissionApplicationsTableQuery = '';
  let createEkycRequestsTableQuery = '';
  let createEkycConsentsTableQuery = '';
  let createEkycAuditLogsTableQuery = '';
  let createDigilockerConnectionsTableQuery = '';
  let createDigilockerDocumentsTableQuery = '';
  let createDigilockerConsentsTableQuery = '';
  let createWorkflowAuditLogsTableQuery = '';
  let createEmsignerRequestsTableQuery = '';
  let createEmsignerAuditLogsTableQuery = '';
  let createNotificationsTableQuery = '';
  let createAuditLogsTableQuery = '';

  if (db.dbType === 'mysql') {
    createUsersTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        mobile VARCHAR(20) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'student',
        status VARCHAR(50) NOT NULL DEFAULT 'active',
        failed_attempts INT DEFAULT 0,
        lockout_until BIGINT DEFAULT 0,
        totp_secret VARCHAR(255) DEFAULT NULL,
        totp_enabled TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createCaptchasTableQuery = `
      CREATE TABLE IF NOT EXISTS captchas (
        id VARCHAR(255) PRIMARY KEY,
        answer VARCHAR(50) NOT NULL,
        attempts INT DEFAULT 0,
        expires_at BIGINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createOtpsTableQuery = `
      CREATE TABLE IF NOT EXISTS otps (
        id VARCHAR(255) PRIMARY KEY,
        user_id INT NOT NULL,
        code_hash VARCHAR(255) NOT NULL,
        attempts INT DEFAULT 0,
        resend_count INT DEFAULT 0,
        resend_cooldown BIGINT NOT NULL,
        expires_at BIGINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createStudentProfilesTableQuery = `
      CREATE TABLE IF NOT EXISTS student_profiles (
        user_id INT PRIMARY KEY,
        dob VARCHAR(50),
        gender VARCHAR(50),
        guardian_name VARCHAR(255),
        address VARCHAR(500),
        state VARCHAR(100),
        pincode VARCHAR(20),
        degree VARCHAR(255),
        board VARCHAR(255),
        grad_year INT,
        percentage REAL,
        photo_path VARCHAR(500),
        version INT DEFAULT 1,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createAdmissionApplicationsTableQuery = `
      CREATE TABLE IF NOT EXISTS admission_applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        application_id VARCHAR(50) UNIQUE,
        user_id INT UNIQUE,
        dob VARCHAR(50),
        gender VARCHAR(50),
        guardian_name VARCHAR(255),
        address VARCHAR(500),
        state VARCHAR(100),
        pincode VARCHAR(20),
        degree VARCHAR(255),
        board VARCHAR(255),
        grad_year INT,
        percentage REAL,
        current_step INT DEFAULT 1,
        status VARCHAR(50) DEFAULT 'Draft',
        correction_message VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createEkycRequestsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNIQUE,
        verification_id VARCHAR(100) UNIQUE,
        aadhaar_masked VARCHAR(50),
        share_code_hash VARCHAR(255),
        xml_filename VARCHAR(255),
        verification_status VARCHAR(50) DEFAULT 'Pending',
        verification_method VARCHAR(50) DEFAULT 'offline_xml',
        reference_id VARCHAR(100) DEFAULT NULL,
        error_message TEXT,
        verified_at BIGINT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createEkycConsentsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_consents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        consent_type VARCHAR(50) NOT NULL DEFAULT 'ekyc_identity_verification',
        consent_version VARCHAR(20) NOT NULL DEFAULT '1.0',
        consented TINYINT(1) NOT NULL DEFAULT 0,
        ip_address VARCHAR(50) DEFAULT NULL,
        consented_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createEkycAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_audit_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(100) NOT NULL,
        ip_address VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createDigilockerConnectionsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_connections (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNIQUE,
        digilocker_id VARCHAR(100),
        access_token VARCHAR(255),
        token_expires_at BIGINT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createDigilockerDocumentsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        document_type VARCHAR(100),
        doc_uri VARCHAR(255),
        issuing_authority VARCHAR(200),
        document_ref VARCHAR(100),
        retrieved_at BIGINT,
        verification_status VARCHAR(50) DEFAULT 'Verified',
        document_status VARCHAR(50) DEFAULT 'AVAILABLE',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_digilocker_doc (user_id, doc_uri),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createDigilockerConsentsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_consents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        purpose VARCHAR(255) NOT NULL,
        scope VARCHAR(255) NOT NULL,
        consent_status VARCHAR(50) NOT NULL DEFAULT 'GRANTED',
        consent_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        revoked_timestamp TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createEmsignerRequestsTableQuery = `
      CREATE TABLE IF NOT EXISTS emsigner_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNIQUE,
        application_id VARCHAR(50),
        sign_request_id VARCHAR(100),
        sign_status VARCHAR(50) DEFAULT 'Pending',
        signed_doc_uri VARCHAR(500),
        signed_at BIGINT,
        error_message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createEmsignerAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS emsigner_audit_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(100) NOT NULL,
        ip_address VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createWorkflowAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS workflow_audit_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        from_status VARCHAR(50),
        to_status VARCHAR(50),
        action_by_role VARCHAR(50),
        ip_address VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createNotificationsTableQuery = `
      CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        read_at TIMESTAMP NULL DEFAULT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    createAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(100) NOT NULL,
        entity_type VARCHAR(100),
        entity_id VARCHAR(100),
        status VARCHAR(50),
        ip_address VARCHAR(50),
        metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
  } else {
    // SQLite
    createUsersTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        mobile VARCHAR(20) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'student',
        status VARCHAR(50) NOT NULL DEFAULT 'active',
        failed_attempts INT DEFAULT 0,
        lockout_until BIGINT DEFAULT 0,
        totp_secret VARCHAR(255) DEFAULT NULL,
        totp_enabled TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    createCaptchasTableQuery = `
      CREATE TABLE IF NOT EXISTS captchas (
        id VARCHAR(255) PRIMARY KEY,
        answer VARCHAR(50) NOT NULL,
        attempts INT DEFAULT 0,
        expires_at BIGINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    createOtpsTableQuery = `
      CREATE TABLE IF NOT EXISTS otps (
        id VARCHAR(255) PRIMARY KEY,
        user_id INTEGER NOT NULL,
        code_hash VARCHAR(255) NOT NULL,
        attempts INT DEFAULT 0,
        resend_count INT DEFAULT 0,
        resend_cooldown BIGINT NOT NULL,
        expires_at BIGINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    createStudentProfilesTableQuery = `
      CREATE TABLE IF NOT EXISTS student_profiles (
        user_id INTEGER PRIMARY KEY,
        dob VARCHAR(50),
        gender VARCHAR(50),
        guardian_name VARCHAR(255),
        address VARCHAR(500),
        state VARCHAR(100),
        pincode VARCHAR(20),
        degree VARCHAR(255),
        board VARCHAR(255),
        grad_year INT,
        percentage REAL,
        photo_path VARCHAR(500),
        version INT DEFAULT 1,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createAdmissionApplicationsTableQuery = `
      CREATE TABLE IF NOT EXISTS admission_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id VARCHAR(50) UNIQUE,
        user_id INTEGER UNIQUE,
        dob VARCHAR(50),
        gender VARCHAR(50),
        guardian_name VARCHAR(255),
        address VARCHAR(500),
        state VARCHAR(100),
        pincode VARCHAR(20),
        degree VARCHAR(255),
        board VARCHAR(255),
        grad_year INT,
        percentage REAL,
        current_step INT DEFAULT 1,
        status VARCHAR(50) DEFAULT 'Draft',
        correction_message VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createEkycRequestsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        verification_id VARCHAR(100) UNIQUE,
        aadhaar_masked VARCHAR(50),
        share_code_hash VARCHAR(255),
        xml_filename VARCHAR(255),
        verification_status VARCHAR(50) DEFAULT 'Pending',
        verification_method VARCHAR(50) DEFAULT 'offline_xml',
        reference_id VARCHAR(100) DEFAULT NULL,
        error_message VARCHAR(255),
        verified_at BIGINT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createEkycConsentsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_consents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        consent_type VARCHAR(50) NOT NULL DEFAULT 'ekyc_identity_verification',
        consent_version VARCHAR(20) NOT NULL DEFAULT '1.0',
        consented TINYINT(1) NOT NULL DEFAULT 0,
        ip_address VARCHAR(50) DEFAULT NULL,
        consented_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createEkycAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS ekyc_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action VARCHAR(100) NOT NULL,
        ip_address VARCHAR(50),
        details VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createDigilockerConnectionsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        digilocker_id VARCHAR(100),
        access_token VARCHAR(255),
        token_expires_at BIGINT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createDigilockerDocumentsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        document_type VARCHAR(100),
        doc_uri VARCHAR(255),
        issuing_authority VARCHAR(200),
        document_ref VARCHAR(100),
        retrieved_at BIGINT,
        verification_status VARCHAR(50) DEFAULT 'Verified',
        document_status VARCHAR(50) DEFAULT 'AVAILABLE',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, doc_uri),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createDigilockerConsentsTableQuery = `
      CREATE TABLE IF NOT EXISTS digilocker_consents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        purpose VARCHAR(255) NOT NULL,
        scope VARCHAR(255) NOT NULL,
        consent_status VARCHAR(50) NOT NULL DEFAULT 'GRANTED',
        consent_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        revoked_timestamp TIMESTAMP DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createWorkflowAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS workflow_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        from_status VARCHAR(50),
        to_status VARCHAR(50),
        action_by_role VARCHAR(50),
        ip_address VARCHAR(50),
        details VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createEmsignerRequestsTableQuery = `
      CREATE TABLE IF NOT EXISTS emsigner_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        application_id VARCHAR(50),
        sign_request_id VARCHAR(100),
        sign_status VARCHAR(50) DEFAULT 'Pending',
        signed_doc_uri VARCHAR(500),
        signed_at BIGINT,
        error_message VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createEmsignerAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS emsigner_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action VARCHAR(100) NOT NULL,
        ip_address VARCHAR(50),
        details VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createNotificationsTableQuery = `
      CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        read_at TIMESTAMP NULL DEFAULT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `;
    createAuditLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action VARCHAR(100) NOT NULL,
        entity_type VARCHAR(100),
        entity_id VARCHAR(100),
        status VARCHAR(50),
        ip_address VARCHAR(50),
        metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      );
    `;
  }

  try {
    // 1. Create tables
    await db.query(createUsersTableQuery);
    await db.query(createCaptchasTableQuery);
    await db.query(createOtpsTableQuery);
    await db.query(createStudentProfilesTableQuery);
    await db.query(createAdmissionApplicationsTableQuery);
    await db.query(createEkycRequestsTableQuery);
    await db.query(createEkycConsentsTableQuery);
    await db.query(createEkycAuditLogsTableQuery);
    await db.query(createDigilockerConnectionsTableQuery);
    await db.query(createDigilockerDocumentsTableQuery);
    await db.query(createDigilockerConsentsTableQuery);
    await db.query(createWorkflowAuditLogsTableQuery);
    await db.query(createEmsignerRequestsTableQuery);
    await db.query(createEmsignerAuditLogsTableQuery);
    await db.query(createNotificationsTableQuery);
    await db.query(createAuditLogsTableQuery);
    console.log('Database tables checked/created successfully.');

    // 2. Perform defensive migrations (alter tables if they already exist without these columns)
    try {
      await db.query('ALTER TABLE users ADD COLUMN failed_attempts INT DEFAULT 0');
      console.log('Migrated: Added failed_attempts to users table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE users ADD COLUMN lockout_until BIGINT DEFAULT 0');
      console.log('Migrated: Added lockout_until to users table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE users ADD COLUMN totp_secret VARCHAR(255) DEFAULT NULL');
      console.log('Migrated: Added totp_secret to users table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE users ADD COLUMN totp_enabled TINYINT DEFAULT 0');
      console.log('Migrated: Added totp_enabled to users table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE admission_applications ADD COLUMN correction_message VARCHAR(500)');
      console.log('Migrated: Added correction_message to admission_applications table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE ekyc_requests ADD COLUMN verification_id VARCHAR(100) DEFAULT NULL');
      console.log('Migrated: Added verification_id to ekyc_requests table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE ekyc_requests ADD COLUMN verification_method VARCHAR(50) DEFAULT "offline_xml"');
      console.log('Migrated: Added verification_method to ekyc_requests table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query('ALTER TABLE ekyc_requests ADD COLUMN reference_id VARCHAR(100) DEFAULT NULL');
      console.log('Migrated: Added reference_id to ekyc_requests table.');
    } catch (e) {
      // Ignored if column already exists
    }

    try {
      await db.query("ALTER TABLE digilocker_documents ADD COLUMN document_status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE'");
      console.log('Migrated: Added document_status to digilocker_documents table.');
    } catch (e) {
      // Ignored if column already exists
    }

    // 1.5 Update ekyc_requests status check constraint on MySQL
    if (db.dbType === 'mysql') {
      try {
        await db.query('ALTER TABLE ekyc_requests DROP CONSTRAINT chk_ekyc_status');
      } catch (e) {
        // Ignored if constraint doesn't exist
      }
      try {
        await db.query(`ALTER TABLE ekyc_requests ADD CONSTRAINT chk_ekyc_status
          CHECK (verification_status IN ('PENDING', 'CONSENTED', 'FILE_UPLOADED', 'PROCESSING', 'VERIFIED', 'FAILED', 'REVIEW_REQUIRED', 'Pending', 'Verified', 'Failed'))`);
        console.log('Migrated: Updated ekyc_requests status CHECK constraint.');
      } catch (e) {
        // Ignored if already matches
      }
    }

    // 2. Create additional indexes to optimize lookups (e.g. for login & unique checks)
    // Email and mobile are unique, but we will add explicit index queries if needed
    // (Note: UNIQUE automatically creates indexes, but adding index on email/mobile is explicit)
    if (db.dbType === 'mysql') {
      await db.query(`CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile)`);
      try {
        await db.query(`CREATE INDEX idx_admission_user_id ON admission_applications(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_ekyc_user_id ON ekyc_requests(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_digilocker_conn_user_id ON digilocker_connections(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_digilocker_doc_user_id ON digilocker_documents(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_workflow_audit_user_id ON workflow_audit_logs(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_notifications_user_id ON notifications(user_id)`);
      } catch (e) {}
      try {
        await db.query(`CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id)`);
        await db.query(`CREATE INDEX idx_audit_logs_action ON audit_logs(action)`);
      } catch (e) {}
    } else {
      await db.query(`CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_admission_user_id ON admission_applications(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_ekyc_user_id ON ekyc_requests(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_digilocker_conn_user_id ON digilocker_connections(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_digilocker_doc_user_id ON digilocker_documents(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_workflow_audit_user_id ON workflow_audit_logs(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_emsigner_req_user_id ON emsigner_requests(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_emsigner_audit_user_id ON emsigner_audit_logs(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id)`);
      await db.query(`CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action)`);
    }
    console.log('Database indexes verified.');
    
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

module.exports = {
  initDatabase
};

const User = require('../models/User');
const db = require('../config/db');
const { logger } = require('../middleware/logger');

/**
 * Retrieve Student Dashboard data
 */
async function getStudentData(req, res) {
  try {
    const student = await User.findById(req.user.userId);
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student record not found',
        error: { global: 'User not found' }
      });
    }

    // Query actual admission application status from DB
    const appRows = await db.query(
      'SELECT status, application_id, current_step, correction_message FROM admission_applications WHERE user_id = ?',
      [req.user.userId]
    );

    const applicationStatus = appRows && appRows.length > 0 ? appRows[0].status : 'Not Started';
    const applicationId = appRows && appRows.length > 0 ? appRows[0].application_id : '';
    const currentStepVal = appRows && appRows.length > 0 ? appRows[0].current_step : 1;
    const correctionMsg = appRows && appRows.length > 0 ? appRows[0].correction_message : null;

    // Query actual eKYC status from DB
    const ekycRows = await db.query(
      'SELECT verification_status FROM ekyc_requests WHERE user_id = ?',
      [req.user.userId]
    );
    const dbEkycStatus = ekycRows && ekycRows.length > 0 ? ekycRows[0].verification_status : 'Pending';

    // Query actual DigiLocker connection state
    const dlConnRows = await db.query(
      'SELECT id FROM digilocker_connections WHERE user_id = ?',
      [req.user.userId]
    );
    const dlConnected = dlConnRows && dlConnRows.length > 0;

    // Query actual DigiLocker document count
    const dlDocRows = await db.query(
      "SELECT COUNT(*) as docCount FROM digilocker_documents WHERE user_id = ? AND verification_status = 'Verified'",
      [req.user.userId]
    );
    const linkedDocCount = dlDocRows && dlDocRows.length > 0 ? dlDocRows[0].docCount : 0;

    // Calculate final status with auto-promotion
    let finalStatus = applicationStatus;
    if (
      applicationStatus !== 'Not Started' &&
      applicationStatus !== 'Draft' &&
      applicationStatus !== 'SIGNED' &&
      applicationStatus !== 'Approved' &&
      applicationStatus !== 'Rejected'
    ) {
      const ekycVerified = dbEkycStatus === 'Verified' || dbEkycStatus === 'VERIFIED';
      const docsLinked = linkedDocCount > 0;

      if (ekycVerified && docsLinked) {
        finalStatus = 'PENDING_SIGNATURE';
      } else if (ekycVerified) {
        finalStatus = 'IDENTITY_VERIFICATION';
      } else if (docsLinked) {
        finalStatus = 'DOCUMENT_VERIFICATION';
      } else {
        finalStatus = 'Submitted';
      }

      if (finalStatus !== applicationStatus) {
        await db.query(
          'UPDATE admission_applications SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?',
          [finalStatus, req.user.userId]
        );

        // Trigger signature request notification if auto-promoted to PENDING_SIGNATURE
        if (finalStatus === 'PENDING_SIGNATURE') {
          try {
            const NotificationService = require('../services/notificationService');
            await NotificationService.send({
              userId: req.user.userId,
              type: 'signature_request',
              title: 'Signature Required',
              content: 'Your admission application is ready. Please digitally sign your application to proceed.'
            });
          } catch (notifErr) {
            logger.error('Failed to trigger signature request notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
          }
        }
      }
    }

    const isSubmitted = finalStatus !== 'Not Started' && finalStatus !== 'Draft';

    const studentData = {
      profile: {
        name: student.name,
        email: student.email,
        mobile: student.mobile,
        role: student.role
      },
      widgets: {
        admissionApplication: finalStatus,
        applicationId: applicationId,
        ekycStatus: dbEkycStatus,
        digilockerStatus: dlConnected ? 'Connected' : 'Not Connected',
        documentStatus: linkedDocCount > 0 ? `${linkedDocCount} Document${linkedDocCount > 1 ? 's' : ''} Linked` : '0 Documents Linked',
        signatureStatus: (finalStatus === 'SIGNED' || finalStatus === 'Approved' || finalStatus === 'Rejected') ? 'Signed' : 'Unsigned',
        currentStep: isSubmitted ? 5 : currentStepVal,
        totalSteps: 5,
        correctionMessage: correctionMsg
      },
      notifications: []
    };

    try {
      const Notification = require('../models/Notification');
      const dbNotifications = await Notification.findByUserId(req.user.userId);
      studentData.notifications = dbNotifications.map(n => ({
        id: n.id,
        title: n.title,
        content: n.content,
        type: n.type,
        isRead: !!n.is_read,
        date: new Date(n.created_at).toLocaleDateString()
      }));
    } catch (notifErr) {
      logger.error('Failed to load notifications for dashboard:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
      studentData.notifications = [
        {
          id: 1,
          title: 'Welcome to DPI Portal',
          content: 'Your account registration has been successfully verified via Two-Factor OTP. Please proceed to complete your admission form wizard.',
          type: 'info',
          date: new Date().toLocaleDateString()
        }
      ];
    }

    return res.status(200).json({
      success: true,
      message: 'Student dashboard statistics retrieved successfully',
      data: studentData
    });

  } catch (error) {
    logger.error('Student dashboard controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Retrieve Professor Dashboard data (Student Application verification list)
 */
async function getProfessorData(req, res) {
  try {
    const { search, status } = req.query;

    // Fetch all registered student accounts from the DB joined with admission_applications and ekyc_requests
    const students = await db.query(`
      SELECT u.id, u.name, u.email, u.mobile, u.status AS user_status, u.created_at,
             a.application_id, a.status AS app_status,
             e.verification_status AS ekyc_status,
             (SELECT COUNT(*) FROM digilocker_documents WHERE user_id = u.id AND verification_status = 'Verified') AS doc_count
      FROM users u
      LEFT JOIN admission_applications a ON u.id = a.user_id
      LEFT JOIN ekyc_requests e ON u.id = e.user_id
      WHERE u.role = 'student'
      ORDER BY u.id DESC
    `);

    // Map database schemas to dashboard model
    let applications = students.map(std => {
      const appStatus = std.app_status || 'Draft';
      
      let displayAppStatus = 'Draft';
      if (appStatus === 'Approved') {
        displayAppStatus = 'Approved';
      } else if (appStatus === 'Rejected') {
        displayAppStatus = 'Rejected';
      } else if (appStatus === 'Draft') {
        displayAppStatus = 'Draft';
      } else {
        displayAppStatus = 'Pending';
      }

      const isSigned = appStatus === 'SIGNED' || appStatus === 'Approved' || appStatus === 'Rejected';
      const currentEkyc = std.ekyc_status || 'Pending';

      return {
        id: std.id,
        name: std.name,
        email: std.email,
        mobile: std.mobile,
        status: std.user_status,
        createdAt: std.created_at,
        applicationId: std.application_id || '',
        ekycStatus: currentEkyc,
        documentStatus: std.doc_count > 0 ? `${std.doc_count} Linked` : '0 Linked',
        signatureStatus: isSigned ? 'Signed' : 'Unsigned',
        applicationStatus: displayAppStatus,
        workflowStatus: appStatus
      };
    });

    // Apply query filters
    if (search) {
      const query = String(search).toLowerCase();
      applications = applications.filter(
        app => app.name.toLowerCase().includes(query) || app.email.toLowerCase().includes(query)
      );
    }

    if (status && status !== 'all') {
      const filterStatus = String(status).toLowerCase();
      applications = applications.filter(
        app => app.applicationStatus.toLowerCase() === filterStatus
      );
    }

    // Calculate dynamic stats counters
    const totalCount = students.length;
    const pendingCount = applications.filter(app => app.applicationStatus === 'Pending').length;
    const approvedCount = applications.filter(app => app.applicationStatus === 'Approved').length;
    const rejectedCount = applications.filter(app => app.applicationStatus === 'Rejected').length;
    const pendingDocsCount = applications.filter(app => app.applicationStatus === 'Draft').length;

    return res.status(200).json({
      success: true,
      message: 'Professor dashboard applications retrieved successfully',
      data: {
        applications,
        stats: {
          total: totalCount,
          pending: pendingCount,
          approved: approvedCount,
          rejected: rejectedCount,
          pendingDocs: pendingDocsCount
        }
      }
    });

  } catch (error) {
    logger.error('Professor dashboard controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

async function getProfessorStudentDetails(req, res) {
  try {
    const studentId = parseInt(req.params.studentId, 10);

    // Retrieve student user account
    const student = await User.findById(studentId);
    if (!student || student.role !== 'student') {
      return res.status(404).json({
        success: false,
        message: 'Student account record not found.',
        error: { global: 'User not found' }
      });
    }

    // Retrieve student profile details
    const profileRows = await db.query(
      'SELECT * FROM student_profiles WHERE user_id = ?',
      [studentId]
    );
    const profile = profileRows && profileRows.length > 0 ? profileRows[0] : null;

    // Retrieve admission application details
    const appRows = await db.query(
      'SELECT * FROM admission_applications WHERE user_id = ?',
      [studentId]
    );
    const application = appRows && appRows.length > 0 ? appRows[0] : null;

    // Retrieve eKYC verification requests
    const ekycRows = await db.query(
      'SELECT verification_status, aadhaar_masked, verified_at, error_message FROM ekyc_requests WHERE user_id = ?',
      [studentId]
    );
    const ekyc = ekycRows && ekycRows.length > 0 ? ekycRows[0] : null;

    // Retrieve DigiLocker connection
    const connRows = await db.query(
      'SELECT digilocker_id, created_at FROM digilocker_connections WHERE user_id = ?',
      [studentId]
    );
    const connection = connRows && connRows.length > 0 ? connRows[0] : null;

    // Retrieve DigiLocker documents list
    const docRows = await db.query(
      'SELECT document_type, doc_uri, issuing_authority, document_ref, retrieved_at, verification_status FROM digilocker_documents WHERE user_id = ?',
      [studentId]
    );
    const documents = docRows || [];

    // Retrieve workflow audit logs history
    const auditLogs = await db.query(
      `SELECT from_status, to_status, action_by_role, details, created_at, ip_address
       FROM workflow_audit_logs
       WHERE user_id = ?
       ORDER BY id DESC`,
      [studentId]
    );

    return res.status(200).json({
      success: true,
      message: 'Professor student packet retrieved successfully',
      data: {
        student: {
          id: student.id,
          name: student.name,
          email: student.email,
          mobile: student.mobile,
          status: student.status
        },
        profile: profile ? {
          dob: profile.dob || '',
          gender: profile.gender || '',
          guardianName: profile.guardian_name || '',
          address: profile.address || '',
          state: profile.state || '',
          pincode: profile.pincode || '',
          degree: profile.degree || '',
          board: profile.board || '',
          gradYear: profile.grad_year || '',
          percentage: profile.percentage || '',
          photoPath: profile.photo_path || '',
          version: profile.version
        } : null,
        application: application ? {
          id: application.id,
          applicationId: application.application_id || '',
          status: application.status,
          currentStep: application.current_step,
          correctionMessage: application.correction_message || ''
        } : null,
        ekyc: ekyc ? {
          status: ekyc.verification_status,
          maskedAadhaar: ekyc.aadhaar_masked || '',
          verifiedAt: ekyc.verified_at,
          errorMessage: ekyc.error_message || ''
        } : null,
        digilocker: {
          connected: !!connection,
          digilockerId: connection ? connection.digilocker_id : '',
          createdAt: connection ? connection.created_at : null,
          documents
        },
        auditLogs: auditLogs || []
      }
    });

  } catch (error) {
    logger.error('Get professor student details error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error retrieving student packets.',
      error: { global: 'Internal server error' }
    });
  }
}


/**
 * Retrieve Admin Dashboard statistics and user management list
 */
async function getAdminData(req, res) {
  try {
    // Role guard: Only admin is allowed to view admin dashboard
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: Only administrators can access admin dashboard statistics.',
        error: { global: 'Forbidden access' }
      });
    }

    // 1. Fetch user counts by role
    const statsRows = await db.query(`
      SELECT role, COUNT(*) AS count 
      FROM users 
      GROUP BY role
    `);

    const stats = {
      total: 0,
      student: 0,
      professor: 0,
      admin: 0
    };

    statsRows.forEach(row => {
      const r = row.role;
      const cnt = parseInt(row.count, 10);
      if (stats.hasOwnProperty(r)) {
        stats[r] = cnt;
      }
      stats.total += cnt;
    });

    // 2. Fetch all registered users
    const users = await db.query(`
      SELECT id, name, email, mobile, role, status, created_at AS createdAt
      FROM users
      ORDER BY id DESC
    `);

    return res.status(200).json({
      success: true,
      message: 'Admin dashboard statistics retrieved successfully',
      data: {
        stats,
        users
      }
    });

  } catch (error) {
    logger.error('Get admin dashboard data error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error retrieving admin dashboard statistics.',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  getStudentData,
  getProfessorData,
  getProfessorStudentDetails,
  getAdminData
};


-- =============================================================================
-- DPI Student Admission System — Canonical MySQL Schema
-- Version: Module 13 (Migrations 001-004 combined)
-- Database: dpi_student_admission
-- Compatibility: MySQL 5.7+ / MariaDB 10.4+
-- Encoding: utf8mb4
--
-- Usage:
--   mysql -u root -p dpi_student_admission < database/schema.sql
--
-- This file is the single-file equivalent of running all migrations 001-004
-- in sequence. Use it to provision a fresh XAMPP/MySQL database instantly.
-- For incremental updates use: node database/migrate.js
-- =============================================================================

-- Create the target database if it does not exist
CREATE DATABASE IF NOT EXISTS dpi_student_admission
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE dpi_student_admission;

SET FOREIGN_KEY_CHECKS = 0;
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- =============================================================================
-- REFERENCE TABLES
-- =============================================================================

-- Table: roles
CREATE TABLE IF NOT EXISTS roles (
  id          TINYINT       NOT NULL AUTO_INCREMENT,
  name        VARCHAR(50)   NOT NULL,
  description VARCHAR(255)  DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_role_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Reference table for valid user roles';

INSERT IGNORE INTO roles (name, description) VALUES
  ('student',   'Registered student applying for admission'),
  ('professor', 'Academic staff member who reviews and processes applications'),
  ('admin',     'System administrator with full access');

-- =============================================================================
-- CORE IDENTITY TABLES
-- =============================================================================

-- Table: users
CREATE TABLE IF NOT EXISTS users (
  id               INT            NOT NULL AUTO_INCREMENT,
  name             VARCHAR(255)   NOT NULL,
  email            VARCHAR(255)   NOT NULL,
  mobile           VARCHAR(20)    NOT NULL,
  password_hash    VARCHAR(255)   NOT NULL,
  role             VARCHAR(50)    NOT NULL DEFAULT 'student',
  role_id          TINYINT        DEFAULT NULL
    COMMENT 'FK to roles.id — normalised role reference',
  status           VARCHAR(50)    NOT NULL DEFAULT 'active',
  failed_attempts  INT            NOT NULL DEFAULT 0,
  lockout_until    BIGINT         NOT NULL DEFAULT 0,
  created_at       TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email  (email),
  UNIQUE KEY uq_users_mobile (mobile),
  KEY idx_users_email   (email),
  KEY idx_users_mobile  (mobile),
  KEY idx_users_role    (role),
  KEY idx_users_role_id (role_id),
  KEY idx_users_status  (status),
  CONSTRAINT fk_users_role FOREIGN KEY (role_id)
    REFERENCES roles (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_users_status CHECK (status IN ('active', 'locked', 'suspended', 'inactive'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Core identity table for all system users';

-- =============================================================================
-- SESSION / EPHEMERAL TABLES
-- =============================================================================

-- Table: captchas
CREATE TABLE IF NOT EXISTS captchas (
  id          VARCHAR(255)  NOT NULL,
  answer      VARCHAR(50)   NOT NULL,
  attempts    INT           NOT NULL DEFAULT 0,
  expires_at  BIGINT        NOT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_captchas_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ephemeral CAPTCHA challenge sessions';

-- Table: otps
CREATE TABLE IF NOT EXISTS otps (
  id              VARCHAR(255)  NOT NULL,
  user_id         INT           NOT NULL,
  code_hash       VARCHAR(255)  NOT NULL,
  attempts        INT           NOT NULL DEFAULT 0,
  resend_count    INT           NOT NULL DEFAULT 0,
  resend_cooldown BIGINT        NOT NULL,
  expires_at      BIGINT        NOT NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_otps_user_id     (user_id),
  KEY idx_otps_expires     (expires_at),
  KEY idx_otps_user_expires (user_id, expires_at),
  CONSTRAINT fk_otps_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='OTP verification sessions for 2FA login';

-- =============================================================================
-- STUDENT DATA TABLES
-- =============================================================================

-- Table: student_profiles
CREATE TABLE IF NOT EXISTS student_profiles (
  user_id        INT           NOT NULL,
  dob            DATE          DEFAULT NULL,
  gender         VARCHAR(50)   DEFAULT NULL,
  guardian_name  VARCHAR(255)  DEFAULT NULL,
  address        VARCHAR(500)  DEFAULT NULL,
  state          VARCHAR(100)  DEFAULT NULL,
  pincode        CHAR(6)       DEFAULT NULL,
  degree         VARCHAR(255)  DEFAULT NULL,
  board          VARCHAR(255)  DEFAULT NULL,
  grad_year      SMALLINT      DEFAULT NULL,
  percentage     DECIMAL(5,2)  DEFAULT NULL,
  photo_path     VARCHAR(500)  DEFAULT NULL,
  version        INT           NOT NULL DEFAULT 1,
  updated_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (user_id),
  CONSTRAINT fk_profiles_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_profiles_percentage CHECK (percentage IS NULL OR (percentage >= 0 AND percentage <= 100)),
  CONSTRAINT chk_profiles_grad_year  CHECK (grad_year IS NULL OR (grad_year >= 1900 AND grad_year <= 2100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Student academic and personal identity profile (optimistic locking)';

-- Table: admission_applications
CREATE TABLE IF NOT EXISTS admission_applications (
  id                  INT           NOT NULL AUTO_INCREMENT,
  application_id      VARCHAR(50)   DEFAULT NULL,
  user_id             INT           NOT NULL,
  dob                 DATE          DEFAULT NULL,
  gender              VARCHAR(50)   DEFAULT NULL,
  guardian_name       VARCHAR(255)  DEFAULT NULL,
  address             VARCHAR(500)  DEFAULT NULL,
  state               VARCHAR(100)  DEFAULT NULL,
  pincode             CHAR(6)       DEFAULT NULL,
  degree              VARCHAR(255)  DEFAULT NULL,
  board               VARCHAR(255)  DEFAULT NULL,
  grad_year           SMALLINT      DEFAULT NULL,
  percentage          DECIMAL(5,2)  DEFAULT NULL,
  current_step        TINYINT       NOT NULL DEFAULT 1,
  status              VARCHAR(50)   NOT NULL DEFAULT 'Draft',
  correction_message  TEXT          DEFAULT NULL,
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_app_application_id (application_id),
  UNIQUE KEY uq_app_user_id        (user_id),
  KEY idx_app_status  (status),
  KEY idx_app_created (created_at),
  CONSTRAINT fk_app_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_app_step       CHECK (current_step BETWEEN 1 AND 5),
  CONSTRAINT chk_app_percentage CHECK (percentage IS NULL OR (percentage >= 0 AND percentage <= 100)),
  CONSTRAINT chk_app_status     CHECK (status IN (
    'Draft', 'Submitted', 'DOCUMENT_VERIFICATION', 'IDENTITY_VERIFICATION',
    'PENDING_SIGNATURE', 'SIGNED', 'Approved', 'Rejected'
  ))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Student admission application with workflow state machine status';

-- =============================================================================
-- eKYC MODULE TABLES
-- =============================================================================

-- Table: ekyc_requests
CREATE TABLE IF NOT EXISTS ekyc_requests (
  id                  INT           NOT NULL AUTO_INCREMENT,
  user_id             INT           NOT NULL,
  aadhaar_masked      VARCHAR(50)   DEFAULT NULL,
  share_code_hash     VARCHAR(255)  DEFAULT NULL,
  xml_filename        VARCHAR(255)  DEFAULT NULL,
  verification_status VARCHAR(50)   NOT NULL DEFAULT 'Pending',
  error_message       TEXT          DEFAULT NULL,
  verified_at         BIGINT        DEFAULT NULL,
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_ekyc_user (user_id),
  KEY idx_ekyc_status     (verification_status),
  KEY idx_ekyc_verified_at (verified_at),
  CONSTRAINT fk_ekyc_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_ekyc_status CHECK (verification_status IN ('PENDING', 'CONSENTED', 'FILE_UPLOADED', 'PROCESSING', 'VERIFIED', 'FAILED', 'REVIEW_REQUIRED', 'Pending', 'Verified', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='eKYC Aadhaar offline XML verification records';

-- Table: ekyc_audit_logs
CREATE TABLE IF NOT EXISTS ekyc_audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           DEFAULT NULL,
  action      VARCHAR(100)  NOT NULL,
  ip_address  VARCHAR(50)   DEFAULT NULL,
  details     TEXT          DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_ekyc_audit_user    (user_id),
  KEY idx_ekyc_audit_action  (action),
  KEY idx_ekyc_audit_created (created_at),
  KEY idx_ekyc_user_created  (user_id, created_at DESC),
  CONSTRAINT fk_ekyc_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for eKYC verification events';

-- =============================================================================
-- DIGILOCKER MODULE TABLES
-- =============================================================================

-- Table: digilocker_connections
CREATE TABLE IF NOT EXISTS digilocker_connections (
  id               INT           NOT NULL AUTO_INCREMENT,
  user_id          INT           NOT NULL,
  digilocker_id    VARCHAR(100)  DEFAULT NULL,
  access_token     VARCHAR(512)  DEFAULT NULL,
  token_expires_at BIGINT        DEFAULT NULL,
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_digilocker_conn_user (user_id),
  CONSTRAINT fk_digilocker_conn_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='DigiLocker OAuth access token state per student';

-- Table: digilocker_documents
CREATE TABLE IF NOT EXISTS digilocker_documents (
  id                  INT           NOT NULL AUTO_INCREMENT,
  user_id             INT           NOT NULL,
  document_type       VARCHAR(100)  DEFAULT NULL,
  doc_uri             VARCHAR(255)  NOT NULL,
  issuing_authority   VARCHAR(200)  DEFAULT NULL,
  document_ref        VARCHAR(100)  DEFAULT NULL,
  retrieved_at        BIGINT        DEFAULT NULL,
  verification_status VARCHAR(50)   NOT NULL DEFAULT 'Verified',
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_digilocker_doc   (user_id, doc_uri),
  KEY idx_digilocker_doc_user    (user_id),
  KEY idx_digilocker_doc_type    (document_type),
  KEY idx_digilocker_doc_status  (verification_status),
  CONSTRAINT fk_digilocker_doc_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_digilocker_doc_status CHECK (verification_status IN ('Verified', 'Pending', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='DigiLocker documents retrieved and linked to student applications';

-- =============================================================================
-- WORKFLOW MODULE TABLES
-- =============================================================================

-- Table: workflow_audit_logs
CREATE TABLE IF NOT EXISTS workflow_audit_logs (
  id              INT           NOT NULL AUTO_INCREMENT,
  user_id         INT           DEFAULT NULL,
  from_status     VARCHAR(50)   DEFAULT NULL,
  to_status       VARCHAR(50)   NOT NULL,
  action_by_role  VARCHAR(50)   NOT NULL,
  ip_address      VARCHAR(50)   DEFAULT NULL,
  details         TEXT          DEFAULT NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_workflow_audit_user    (user_id),
  KEY idx_workflow_audit_created (created_at),
  KEY idx_workflow_audit_status  (to_status),
  KEY idx_workflow_user_created  (user_id, created_at DESC),
  CONSTRAINT fk_workflow_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for application workflow state machine transitions';

-- =============================================================================
-- eSIGNZY MODULE TABLES
-- =============================================================================

-- Table: esignzy_requests
CREATE TABLE IF NOT EXISTS esignzy_requests (
  id               INT           NOT NULL AUTO_INCREMENT,
  user_id          INT           NOT NULL,
  application_id   VARCHAR(50)   DEFAULT NULL,
  sign_request_id  VARCHAR(100)  DEFAULT NULL,
  sign_status      VARCHAR(50)   NOT NULL DEFAULT 'Pending',
  signed_doc_uri   VARCHAR(500)  DEFAULT NULL,
  signed_at        BIGINT        DEFAULT NULL,
  error_message    TEXT          DEFAULT NULL,
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_esignzy_user (user_id),
  KEY idx_esignzy_status  (sign_status),
  KEY idx_esignzy_app_id  (application_id),
  CONSTRAINT fk_esignzy_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_esignzy_status CHECK (sign_status IN ('Pending', 'Signed', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='eSignzy digital signature request records per student';

-- Table: esignzy_audit_logs
CREATE TABLE IF NOT EXISTS esignzy_audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           DEFAULT NULL,
  action      VARCHAR(100)  NOT NULL,
  ip_address  VARCHAR(50)   DEFAULT NULL,
  details     TEXT          DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_esignzy_audit_user    (user_id),
  KEY idx_esignzy_audit_action  (action),
  KEY idx_esignzy_audit_created (created_at),
  KEY idx_esignzy_user_created  (user_id, created_at DESC),
  CONSTRAINT fk_esignzy_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for eSignzy digital signature events';

-- =============================================================================
-- NOTIFICATIONS TABLE
-- =============================================================================

-- Table: notifications
CREATE TABLE IF NOT EXISTS notifications (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           NOT NULL,
  title       VARCHAR(255)  NOT NULL,
  content     TEXT          NOT NULL,
  type        VARCHAR(50)   NOT NULL DEFAULT 'info',
  is_read     TINYINT(1)    NOT NULL DEFAULT 0,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at     TIMESTAMP     NULL DEFAULT NULL,

  PRIMARY KEY (id),
  KEY idx_notifications_user        (user_id),
  KEY idx_notifications_is_read     (is_read),
  KEY idx_notifications_created     (created_at),
  KEY idx_notifications_user_unread (user_id, is_read, created_at DESC),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_notifications_type CHECK (
    type IN (
      'info', 'success', 'warning', 'danger', 'error',
      'registration', 'otp', 'application_submission',
      'signature_request', 'document_verification',
      'signature_completion', 'correction_request',
      'approval', 'rejection'
    )
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Persistent user notification messages and system alerts';

-- =============================================================================
-- CENTRALIZED AUDIT LOGS TABLE (Module 14)
-- =============================================================================

-- Table: audit_logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           NULL,
  action      VARCHAR(100)  NOT NULL,
  entity_type VARCHAR(100)  NULL,
  entity_id   VARCHAR(100)  NULL,
  status      VARCHAR(50)   NULL,
  ip_address  VARCHAR(50)   NULL,
  metadata    TEXT          NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_audit_logs_user_id (user_id),
  KEY idx_audit_logs_action  (action),
  CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Centralized, sanitized audit trail for security-relevant actions (Module 14)';

-- =============================================================================
-- MIGRATION TRACKING TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS schema_migrations (
  id          INT           NOT NULL AUTO_INCREMENT,
  filename    VARCHAR(255)  NOT NULL,
  applied_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_migration_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Migration version tracking table';

-- Record all migrations as applied (since we used the combined schema file)
INSERT IGNORE INTO schema_migrations (filename) VALUES
  ('001_initial_schema.sql'),
  ('002_add_roles_table.sql'),
  ('003_add_notifications.sql'),
  ('004_harden_constraints.sql'),
  ('005_add_audit_logs.sql');

SET FOREIGN_KEY_CHECKS = 1;

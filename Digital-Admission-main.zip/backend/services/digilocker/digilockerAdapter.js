/**
 * Abstract base class for DigiLocker Integration Adapters
 */
class DigilockerAdapter {
  /**
   * Fetch the list of issued documents available in the student's DigiLocker
   * @param {number} userId - The student user ID
   * @returns {Promise<Array>} List of available documents
   */
  async getIssuedDocuments(userId) {
    throw new Error('Method "getIssuedDocuments" must be implemented by subclass');
  }

  /**
   * Retrieve and verify a specific document by its DigiLocker URI
   * @param {number} userId - The student user ID
   * @param {string} docUri - Unique DigiLocker document URI reference
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Linked document metadata and verification details
   */
  async retrieveDocument(userId, docUri, ipAddress) {
    throw new Error('Method "retrieveDocument" must be implemented by subclass');
  }
}

module.exports = DigilockerAdapter;

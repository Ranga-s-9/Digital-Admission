# Module 11 — Professor/Admin Management

## Purpose

Provide institutional users with controlled access to student applications.

## Source Basis

The notes mention Student / Professor in the registration flow. A complete admin workflow is not specified, so this module defines a proposed institutional review layer.

## Features

- Professor/admin authentication.
- Role-based dashboard.
- Application search.
- Application review.
- Student verification status.
- Document review.
- Signed document/status review.
- Workflow status updates.
- Request changes.
- Approve/reject according to institutional rules.

## Proposed Workflow

```text
Admin/Professor
      |
      v
View Applications
      |
      v
Select Application
      |
      v
Review Student Data
      |
      +----> eKYC Status
      |
      +----> Document Status
      |
      +----> Signature Status
      |
      v
Decision / Request Changes
      |
      v
Update Workflow
```

## Authorization

- Students must not access institutional controls.
- Professors/admins should access only authorized records.
- High-impact actions should be audited.

## Acceptance Criteria

- Authorized staff can review applications.
- Unauthorized roles cannot perform staff actions.
- Status changes are persisted and audited.
- Students can see the resulting status.

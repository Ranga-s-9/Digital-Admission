const { logger } = require('./logger');

/**
 * Centralized error handling middleware for Express
 */
function errorHandler(err, req, res, next) {
  const statusCode = err.status || err.statusCode || 500;
  const rawMessage = err.message || 'An internal server error occurred';
  const clientMessage = statusCode === 500 ? 'An internal server error occurred' : rawMessage;

  // Log error using centralized logger
  logger.error(`${req.method} ${req.originalUrl} - Error Status ${statusCode}: ${rawMessage}`, {
    stack: err.stack,
    userId: req.user ? req.user.userId : null,
    ip: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
    requestId: req.id || null
  });

  // Construct standard response format
  const response = {
    success: false,
    message: clientMessage,
    requestId: req.id || null
  };

  // If there are field-specific errors, map them
  if (err.errors) {
    response.error = err.errors;
  } else {
    response.error = { global: clientMessage };
  }

  return res.status(statusCode).json(response);
}

module.exports = errorHandler;

# Automated Testing and Verification Guide

This document describes the testing architecture, suites, and procedures for the **Digital Student Admission System**.

---

## 1. Testing Framework and Architecture
The testing suite is built using:
* **Jest**: Test runner and assertion framework.
* **Supertest**: High-level abstraction for testing HTTP servers and routes without binding to a network port.
* **Ephemeral Database Contexts**: To support parallel or consecutive test execution without data corruption, test databases (e.g., `test_admission.sqlite`, `test_audit.sqlite`) are created dynamically for each test suite and dropped during cleanup.

---

## 2. Running the Tests

### Main Test Suite (Jest)
To run all 10 automated integration test suites, execute:
```bash
npm test
```

### Database Integration Smoke Test
To verify database schemas, constraints, rollbacks, and CASCADE deletes specifically on MySQL/MariaDB (e.g., XAMPP), configure your `.env` variables to target a local database connection and execute:
```bash
node database/test_mysql.js
```

---

## 3. Test Suites Directory & Coverage

The test cases are located in the `tests/` directory:

| Test Suite | Filename | Key Assertions & Scenarios |
| :--- | :--- | :--- |
| **User Registration & SSO** | `auth.test.js` | Password strength checks, arithmetic CAPTCHA expiration, rate-limiting locks, 2-step OTP validation, resend throttling, cooldown timers, brute-force lockouts. |
| **Profile Management** | `profile.test.js` | Photo upload validations (size/MIME check), automatic completion percentage calculation, IDOR separation, optimistic concurrency locking conflict (409). |
| **Admission Applications** | `admission.test.js` | Step-by-step form drafts saving, required fields, graduation year bounds, duplicate blocks, IDOR. |
| **eKYC Integration** | `ekyc.test.js` | Masked Aadhaar XML matching, DOB/Name identity alignment checks, consent validation, verified status promotion. |
| **DigiLocker Integration** | `digilocker.test.js` | Mock OAuth callback postMessage channels, credential linkings, student name mismatch rejections, duplicate documents block. |
| **Paperless Workflow** | `workflow.test.js` | Workflow state machine transitions, auto-promotion checks, correction loop (returns application to Draft with Professor notes). |
| **eSignzy Signature** | `esignzy.test.js` | Signature request updates, transition validation (`PENDING_SIGNATURE` -> `SIGNED`), history logs, duplicate sign blocks. |
| **Audit Logging** | `auditLogs.test.js` | Action logs validation, security parameter sanitization (hides passwords, OTP codes, and api keys). |
| **Notifications** | `notifications.test.js` | Persistent user notifications retrieval, type filters, unread flags updates. |
| **Dashboard & RBAC** | `dashboard.test.js` | RBAC blocks for unauthorized roles, professor student searches, checklist steppers. |

# Module 06 — eKYC Identity Verification

## Purpose

Demonstrate digital identity verification as part of the admission process.

## Source Requirement

The notes identify an offline XML document creation tool for eKYC and recommend learning eKYC concepts.

## Proposed Workflow

```text
Student
   |
   v
Initiate eKYC
   |
   v
Collect Required Verification Data
   |
   v
eKYC Processing
   |
   v
Verification Result
   |
   +----> VERIFIED
   |
   +----> FAILED
   |
   +----> PENDING
```

## Requirements

- Start an eKYC request.
- Maintain request/status information.
- Validate input.
- Store only required verification metadata.
- Display verification status.
- Handle failures and retry conditions.

## Security

- Protect identity information.
- Avoid storing unnecessary sensitive data.
- Encrypt sensitive data where appropriate.
- Restrict access using roles.
- Keep audit events without exposing secrets.

## Acceptance Criteria

- eKYC request can be initiated.
- Verification result is represented correctly.
- Status is visible on the dashboard.
- Failure does not corrupt the admission application.

## Important

The supplied notes do not provide a production eKYC provider, API contract or credentials. A mock/demo adapter may be used until an approved integration is available.

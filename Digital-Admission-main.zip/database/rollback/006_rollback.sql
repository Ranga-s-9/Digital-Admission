-- =============================================================================
-- Rollback 006: Restore original (buggy) chk_notifications_type constraint
-- Reverses 006_fix_notification_type_constraint.sql.
-- WARNING: Restoring the original constraint will cause notification inserts
-- from application code to fail again, since the application stores semantic
-- event-category values, not generic severity values.
-- =============================================================================

ALTER TABLE notifications
  DROP CONSTRAINT chk_notifications_type;

ALTER TABLE notifications
  ADD CONSTRAINT chk_notifications_type CHECK (type IN ('info', 'success', 'warning', 'danger', 'error'));

const { getDigilockerAdapter } = require('../services/digilocker');
const db = require('../config/db');
const crypto = require('crypto');
const { logger } = require('../middleware/logger');
const AuditLog = require('../models/AuditLog');

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Serves the mock authorization screen HTML for OAuth simulations
 */
async function getOAuthAuthorize(req, res) {
  try {
    const userId = req.user.userId;
    const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

    // Use query state if provided (for client-initiated state validation) or generate random state
    const state = req.query.state || crypto.randomBytes(16).toString('hex');
    res.cookie('oauth_state', state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 10 * 60 * 1000 // 10 minutes
    });

    const escapedState = escapeHtml(state);
    const mode = process.env.DIGILOCKER_MODE || 'mock';

    // Log connection start
    await AuditLog.log({
      userId,
      action: 'DIGILOCKER_CONNECT_STARTED',
      status: 'success',
      ipAddress,
      metadata: { mode }
    });

    if (mode === 'real') {
      // Redirect to real production DigiLocker auth gateway
      const realAuthUrl = `${process.env.DIGILOCKER_AUTHORIZATION_URL || 'https://accounts.digitallocker.gov.in/oauth/authorize'}?response_type=code&client_id=${process.env.DIGILOCKER_CLIENT_ID || ''}&redirect_uri=${encodeURIComponent(process.env.DIGILOCKER_REDIRECT_URI || '')}&state=${state}`;
      return res.redirect(realAuthUrl);
    }

    // Serve mock login page
    res.setHeader('Content-Type', 'text/html');
    return res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>DigiLocker Authentication Gateway</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
      color: #f8fafc;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .card {
      background: rgba(30, 41, 59, 0.7);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 30px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      text-align: center;
    }
    .header {
      margin-bottom: 20px;
    }
    .logo-dl {
      font-weight: 800;
      font-size: 26px;
      letter-spacing: -0.5px;
      color: #fff;
    }
    .logo-dl span {
      color: #f59e0b;
    }
    .badge {
      background: rgba(245, 158, 11, 0.15);
      border: 1px solid #f59e0b;
      color: #f59e0b;
      font-size: 11px;
      font-weight: 600;
      padding: 4px 10px;
      border-radius: 12px;
      display: inline-block;
      margin-top: 8px;
    }
    .tabs {
      display: flex;
      background: rgba(15, 23, 42, 0.4);
      border-radius: 8px;
      padding: 4px;
      margin-bottom: 20px;
    }
    .tab {
      flex: 1;
      padding: 8px 12px;
      font-size: 13px;
      font-weight: 500;
      color: #94a3b8;
      cursor: pointer;
      border-radius: 6px;
      transition: all 0.2s;
    }
    .tab.active {
      color: #fff;
      background: rgba(255, 255, 255, 0.08);
    }
    .form-group {
      text-align: left;
      margin-bottom: 18px;
    }
    label {
      font-size: 12px;
      color: #94a3b8;
      display: block;
      margin-bottom: 6px;
    }
    input[type="text"], input[type="password"], input[type="tel"] {
      width: 100%;
      padding: 10px 12px;
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 6px;
      color: #fff;
      font-size: 14px;
      box-sizing: border-box;
      transition: border-color 0.2s;
    }
    input:focus {
      border-color: #3b82f6;
      outline: none;
    }
    .consent-container {
      display: flex;
      gap: 10px;
      font-size: 11px;
      line-height: 1.5;
      color: #94a3b8;
      margin-top: 15px;
      margin-bottom: 20px;
      text-align: left;
    }
    .consent-container input {
      width: auto;
      margin-top: 2px;
    }
    button {
      width: 100%;
      padding: 11px;
      background: #3b82f6;
      border: none;
      color: white;
      font-size: 14px;
      font-weight: 500;
      border-radius: 6px;
      cursor: pointer;
      margin-top: 10px;
      transition: background 0.2s;
    }
    button:hover {
      background: #2563eb;
    }
    .spinner {
      border: 2px solid rgba(255, 255, 255, 0.2);
      border-top: 2px solid #fff;
      border-radius: 50%;
      width: 14px;
      height: 14px;
      animation: spin 0.6s linear infinite;
      display: inline-block;
      vertical-align: middle;
      margin-right: 8px;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .toast {
      background: rgba(59, 130, 246, 0.15);
      border: 1px solid rgba(59, 130, 246, 0.3);
      color: #60a5fa;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 11px;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="logo-dl">Digi<span>Locker</span></div>
      <div class="badge">DEVELOPMENT / MOCK MODE</div>
    </div>
    
    <div class="tabs">
      <div class="tab active" id="tabAadhaar" onclick="switchTab('aadhaar')">Aadhaar / Username</div>
      <div class="tab" id="tabMobile" onclick="switchTab('mobile')">Mobile Number</div>
    </div>
    
    <form action="/api/digilocker/oauth/callback" method="POST" id="authForm">
      <input type="hidden" name="state" value="${escapedState}">
      <input type="hidden" name="username" id="submitUsername">
      <input type="hidden" name="consent" value="true">

      <!-- Tab 1: Aadhaar/Username panel -->
      <div id="panelAadhaar">
        <div class="form-group">
          <label>Aadhaar / Username</label>
          <input type="text" id="usernameAadhaar" placeholder="Enter credentials" required>
        </div>
        <div class="form-group">
          <label>6-Digit Security PIN</label>
          <input type="password" name="pin" placeholder="••••••" maxlength="6" pattern="\\d{6}" required>
        </div>
        
        <div class="consent-container">
          <input type="checkbox" id="consentAadhaar" checked required>
          <label for="consentAadhaar" style="user-select: none;">I consent to share my Class X and Class XII verified marksheets with the Admission System.</label>
        </div>
        
        <button type="submit" onclick="submitAadhaarForm(event)">Sign In & Authorize</button>
      </div>

      <!-- Tab 2: Mobile panel -->
      <div id="panelMobile" style="display: none;">
        <!-- Mobile step 1 -->
        <div id="mobileStep1">
          <div class="form-group">
            <label>Registered Mobile Number</label>
            <input type="tel" id="mobileNumber" placeholder="Enter 10-digit mobile number" pattern="[6-9]\\d{9}">
          </div>
          <button type="button" onclick="sendOTP(event)">Next</button>
        </div>

        <!-- Mobile step 2 (OTP + PIN) -->
        <div id="mobileStep2" style="display: none;">
          <div class="toast">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            <span>OTP sent. Enter 123456 to verify.</span>
          </div>
          
          <div class="form-group">
            <label>One-Time Password (OTP)</label>
            <input type="text" id="mobileOTP" placeholder="Enter 6-digit OTP" maxlength="6" pattern="\\d{6}">
          </div>
          
          <div class="form-group">
            <label>6-Digit Security PIN</label>
            <input type="password" id="mobilePin" placeholder="••••••" maxlength="6" pattern="\\d{6}">
          </div>
          
          <div class="consent-container">
            <input type="checkbox" id="consentMobile" checked required>
            <label for="consentMobile" style="user-select: none;">I consent to share my Class X and Class XII verified marksheets with the Admission System.</label>
          </div>
          
          <button type="submit" onclick="submitMobileForm(event)">Verify & Sign In</button>
        </div>
      </div>
    </form>
  </div>

  <script>
    let activeTab = 'aadhaar';

    function switchTab(tab) {
      activeTab = tab;
      const tabA = document.getElementById('tabAadhaar');
      const tabM = document.getElementById('tabMobile');
      const panelA = document.getElementById('panelAadhaar');
      const panelM = document.getElementById('panelMobile');

      if (tab === 'aadhaar') {
        tabA.classList.add('active');
        tabM.classList.remove('active');
        panelA.style.display = 'block';
        panelM.style.display = 'none';
        
        document.getElementById('usernameAadhaar').setAttribute('required', 'true');
        document.querySelector('#panelAadhaar input[name="pin"]').setAttribute('required', 'true');
        document.getElementById('mobileNumber').removeAttribute('required');
        document.getElementById('mobileOTP').removeAttribute('required');
        document.getElementById('mobilePin').removeAttribute('required');
      } else {
        tabM.classList.add('active');
        tabA.classList.remove('active');
        panelM.style.display = 'block';
        panelA.style.display = 'none';

        document.getElementById('usernameAadhaar').removeAttribute('required');
        document.querySelector('#panelAadhaar input[name="pin"]').removeAttribute('required');
        document.getElementById('mobileNumber').setAttribute('required', 'true');
      }
    }

    function sendOTP(e) {
      e.preventDefault();
      const mobileInput = document.getElementById('mobileNumber');
      if (!mobileInput.checkValidity() || !mobileInput.value) {
        mobileInput.reportValidity();
        return;
      }

      const btn = e.target;
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span>Sending OTP...';

      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = originalText;
        document.getElementById('mobileStep1').style.display = 'none';
        document.getElementById('mobileStep2').style.display = 'block';
        document.getElementById('mobileOTP').setAttribute('required', 'true');
        document.getElementById('mobilePin').setAttribute('required', 'true');
      }, 600);
    }

    function submitAadhaarForm(e) {
      const usernameInput = document.getElementById('usernameAadhaar');
      const pinInput = document.querySelector('#panelAadhaar input[name="pin"]');
      const consentInput = document.getElementById('consentAadhaar');

      if (!usernameInput.checkValidity() || !pinInput.checkValidity() || !consentInput.checkValidity()) {
        return;
      }
      
      e.preventDefault();
      document.getElementById('submitUsername').value = usernameInput.value;
      document.getElementById('authForm').submit();
    }

    function submitMobileForm(e) {
      const mobileNumber = document.getElementById('mobileNumber');
      const otpInput = document.getElementById('mobileOTP');
      const pinInput = document.getElementById('mobilePin');
      const consentInput = document.getElementById('consentMobile');

      if (!otpInput.checkValidity() || !pinInput.checkValidity() || !consentInput.checkValidity()) {
        return;
      }

      e.preventDefault();
      
      if (otpInput.value !== '123456') {
        alert('Invalid OTP code. Please enter 123456 to verify.');
        return;
      }

      document.getElementById('submitUsername').value = mobileNumber.value;
      document.querySelector('#panelAadhaar input[name="pin"]').value = pinInput.value;
      document.getElementById('authForm').submit();
    }
  </script>
</body>
</html>
  `);
  } catch (error) {
    logger.error('DigiLocker getOAuthAuthorize error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).send('Internal server error during authorization redirection.');
  }
}

/**
 * Handles callback from auth screen, exchanging credentials for access tokens
 */
async function handleOAuthCallback(req, res) {
  const userId = req.user.userId;
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  try {
    const cookieState = req.cookies ? req.cookies.oauth_state : null;
    const paramState = req.query.state || req.body.state;

    // Clear the state verification cookie
    res.clearCookie('oauth_state');

    // State parameter validation to prevent CSRF attacks
    if (!cookieState || cookieState !== paramState) {
      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_ERROR',
        status: 'failure',
        ipAddress,
        metadata: { reason: 'State mismatch / CSRF attempt' }
      });
      return res.status(400).send('Authorization failed: State validation error.');
    }

    const mode = process.env.DIGILOCKER_MODE || 'mock';
    let digilockerId = '';
    let accessToken = '';
    let expiresAt = 0;

    const submittedUsername = String(req.body.username || req.query.username || '').trim();
    const isAadhaarInput = /^\d{12}$/.test(submittedUsername);

    if (mode === 'real') {
      const code = req.query.code;
      if (!code) {
        throw new Error('Authorization code not returned from DigiLocker gateway.');
      }
      // Real API code-to-token exchange (implemented safely with placeholders)
      // fetch(process.env.DIGILOCKER_TOKEN_URL, { method: 'POST', body: ... })
      throw new Error('PRODUCTION_DIGILOCKER_OFFLINE: Token url exchange requires production configuration.');
    } else {
      // Mock exchange
      if (isAadhaarInput) {
        digilockerId = `DL-${submittedUsername}`;
      } else {
        digilockerId = `DL-${Math.floor(10000000 + Math.random() * 90000000)}`;
      }
      accessToken = `mock_token_${crypto.randomBytes(16).toString('hex')}`;
      expiresAt = Date.now() + 3600 * 1000; // 1 hour
    }

    // Verify Aadhaar match with existing verified e-KYC if applicable
    if (isAadhaarInput) {
      const ekycRows = await db.query(
        "SELECT aadhaar_masked, verification_status FROM ekyc_requests WHERE user_id = ? AND (verification_status = 'VERIFIED' OR verification_status = 'Verified')",
        [userId]
      );
      if (ekycRows && ekycRows.length > 0) {
        const ekycMasked = ekycRows[0].aadhaar_masked || '';
        if (ekycMasked !== 'XXXX-XXXX-9999') {
          const ekycLast4 = ekycMasked.slice(-4);
          const dlLast4 = submittedUsername.slice(-4);
          if (ekycLast4 !== dlLast4) {
            await AuditLog.log({
              userId,
              action: 'DIGILOCKER_ERROR',
              status: 'failure',
              ipAddress,
              metadata: { reason: 'Aadhaar mismatch: DigiLocker vs e-KYC' }
            });
            return res.status(400).send('Authorization failed: The Aadhaar number given to DigiLocker does not match the Aadhaar number verified in e-KYC.');
          }
        }
      }
    }

    // Save Connection Details
    const existing = await db.query('SELECT id FROM digilocker_connections WHERE user_id = ?', [userId]);
    if (existing && existing.length > 0) {
      await db.query(
        `UPDATE digilocker_connections SET digilocker_id = ?, access_token = ?, token_expires_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [digilockerId, accessToken, expiresAt, existing[0].id]
      );
    } else {
      await db.query(
        `INSERT INTO digilocker_connections (user_id, digilocker_id, access_token, token_expires_at) VALUES (?, ?, ?, ?)`,
        [userId, digilockerId, accessToken, expiresAt]
      );
    }

    // Automatically record consent if consent checkbox was submitted (consented in popup)
    const consentGranted = req.body.consent === 'true' || req.body.consent === true || req.query.consent === 'true';
    if (consentGranted) {
      const existingConsent = await db.query(
        "SELECT id FROM digilocker_consents WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL",
        [userId]
      );
      if (!existingConsent || existingConsent.length === 0) {
        await db.query(
          `INSERT INTO digilocker_consents (student_id, purpose, scope, consent_status, consent_timestamp)
           VALUES (?, ?, ?, 'GRANTED', CURRENT_TIMESTAMP)`,
          [userId, 'Student Admission Verification', 'Class X and Class XII Marksheets']
        );

        await AuditLog.log({
          userId,
          action: 'DIGILOCKER_CONSENT_GRANTED',
          status: 'success',
          ipAddress,
          metadata: { purpose: 'Student Admission Verification', scope: 'Class X and Class XII Marksheets' }
        });
      }
    }

    // Log connection success
    await AuditLog.log({
      userId,
      action: 'DIGILOCKER_CONNECTED',
      status: 'success',
      ipAddress,
      metadata: { digilockerId }
    });

    res.setHeader('Content-Type', 'text/html');
    return res.send(`
<!DOCTYPE html>
<html>
<body>
  <p>Authorization successful! Connecting portal...</p>
  <script>
    if (window.opener) {
      window.opener.postMessage({ type: 'DIGILOCKER_AUTH_SUCCESS' }, '*');
    }
    window.close();
  </script>
</body>
</html>
    `);

  } catch (error) {
    logger.error('DigiLocker callback error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    await AuditLog.log({
      userId,
      action: 'DIGILOCKER_ERROR',
      status: 'failure',
      ipAddress,
      metadata: { reason: error.message }
    });
    return res.status(500).send('Internal server error during authorization callback.');
  }
}

/**
 * Retrieve current connection state, consent state, and linked documents
 */
async function getConnectionStatus(req, res) {
  try {
    const userId = req.user.userId;
    const mode = process.env.DIGILOCKER_MODE || 'mock';

    const connRows = await db.query(
      'SELECT digilocker_id, created_at FROM digilocker_connections WHERE user_id = ?',
      [userId]
    );

    const docRows = await db.query(
      'SELECT document_type, doc_uri, issuing_authority, document_ref, retrieved_at, verification_status, document_status FROM digilocker_documents WHERE user_id = ?',
      [userId]
    );

    const consentRows = await db.query(
      "SELECT id FROM digilocker_consents WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL ORDER BY id DESC LIMIT 1",
      [userId]
    );
    const consentActive = consentRows && consentRows.length > 0;

    if (connRows && connRows.length > 0) {
      return res.status(200).json({
        success: true,
        message: 'DigiLocker connection active',
        data: {
          connected: true,
          digilockerId: connRows[0].digilocker_id,
          createdAt: connRows[0].created_at,
          consentActive: consentActive,
          documents: docRows || [],
          development_mode: mode === 'mock'
        }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Not connected to DigiLocker',
      data: {
        connected: false,
        digilockerId: '',
        createdAt: null,
        consentActive: false,
        documents: [],
        development_mode: mode === 'mock'
      }
    });

  } catch (error) {
    logger.error('Get DigiLocker connection status error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error checking DigiLocker connection',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Records or revokes user consent for educational document retrieval
 */
async function recordConsent(req, res) {
  const userId = req.user.userId;
  const { consent } = req.body;
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  try {
    if (consent === true || consent === 'true') {
      // Record consent
      await db.query(
        `INSERT INTO digilocker_consents (student_id, purpose, scope, consent_status, consent_timestamp)
         VALUES (?, ?, ?, 'GRANTED', CURRENT_TIMESTAMP)`,
        [userId, 'Student Admission Verification', 'Class X and Class XII Marksheets']
      );

      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_CONSENT_GRANTED',
        status: 'success',
        ipAddress,
        metadata: { purpose: 'Student Admission Verification', scope: 'Class X and Class XII Marksheets' }
      });

      return res.status(200).json({
        success: true,
        message: 'DigiLocker document access consent granted successfully.'
      });
    } else {
      // Revoke consent
      await db.query(
        `UPDATE digilocker_consents
         SET consent_status = 'REVOKED', revoked_timestamp = CURRENT_TIMESTAMP
         WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL`,
        [userId]
      );

      // Clean up retrieved documents upon consent revocation
      await db.query('DELETE FROM digilocker_documents WHERE user_id = ?', [userId]);

      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_CONSENT_REVOKED',
        status: 'success',
        ipAddress
      });

      return res.status(200).json({
        success: true,
        message: 'DigiLocker document access consent revoked successfully.'
      });
    }
  } catch (error) {
    logger.error('Record DigiLocker consent error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error saving DigiLocker consent state.',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Disconnects the student's DigiLocker connection and wipes credentials/documents
 */
async function disconnect(req, res) {
  const userId = req.user.userId;
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  try {
    // Delete connection
    await db.query('DELETE FROM digilocker_connections WHERE user_id = ?', [userId]);

    // Delete retrieved documents
    await db.query('DELETE FROM digilocker_documents WHERE user_id = ?', [userId]);

    // Revoke any active consents
    await db.query(
      `UPDATE digilocker_consents
       SET consent_status = 'REVOKED', revoked_timestamp = CURRENT_TIMESTAMP
       WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL`,
      [userId]
    );

    await AuditLog.log({
      userId,
      action: 'DIGILOCKER_DISCONNECTED',
      status: 'success',
      ipAddress
    });

    return res.status(200).json({
      success: true,
      message: 'DigiLocker integration disconnected and data wiped successfully.'
    });

  } catch (error) {
    logger.error('Disconnect DigiLocker error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error disconnecting DigiLocker.',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * List available issued documents to link (restricted by connection & consent)
 */
async function getAvailableDocuments(req, res) {
  try {
    const userId = req.user.userId;

    // 1. Check if connected first
    const connRows = await db.query('SELECT id FROM digilocker_connections WHERE user_id = ?', [userId]);
    if (!connRows || connRows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'You must link your DigiLocker account before fetching available documents.',
        error: { global: 'DigiLocker not connected' }
      });
    }

    // 2. Check if consent is active
    const consentRows = await db.query(
      "SELECT id FROM digilocker_consents WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL ORDER BY id DESC LIMIT 1",
      [userId]
    );
    if (!consentRows || consentRows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Document access consent required.',
        error: { global: 'Consent required' }
      });
    }

    try {
      const adapter = getDigilockerAdapter();
      const docs = await adapter.getIssuedDocuments(userId);

      return res.status(200).json({
        success: true,
        message: 'Available documents retrieved successfully',
        data: docs
      });
    } catch (err) {
      if (err.message.includes('PRODUCTION_DIGILOCKER_OFFLINE')) {
        return res.status(503).json({
          success: false,
          message: 'Real DigiLocker production services are currently offline.',
          error: { global: 'Production services offline' }
        });
      }
      throw err;
    }

  } catch (error) {
    logger.error('Get available documents error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error fetching documents',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Retrieve and verify a specific document
 */
async function retrieveDocument(req, res) {
  const userId = req.user.userId;
  const { docUri } = req.body;
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  try {
    if (!docUri) {
      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_ERROR',
        status: 'failure',
        ipAddress,
        metadata: { reason: 'Document URI is missing' }
      });
      return res.status(400).json({
        success: false,
        message: 'Document URI is required to retrieve from DigiLocker.',
        error: { docUri: 'Document URI is required' }
      });
    }

    // 1. Check connection
    const connRows = await db.query('SELECT id FROM digilocker_connections WHERE user_id = ?', [userId]);
    if (!connRows || connRows.length === 0) {
      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_ERROR',
        status: 'failure',
        ipAddress,
        metadata: { docUri, reason: 'DigiLocker not connected' }
      });
      return res.status(400).json({
        success: false,
        message: 'You must link your DigiLocker account before retrieving documents.',
        error: { global: 'DigiLocker not connected' }
      });
    }

    // 2. Check active consent
    const consentRows = await db.query(
      "SELECT id FROM digilocker_consents WHERE student_id = ? AND consent_status = 'GRANTED' AND revoked_timestamp IS NULL ORDER BY id DESC LIMIT 1",
      [userId]
    );
    if (!consentRows || consentRows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Document access consent required.',
        error: { global: 'Consent required' }
      });
    }

    // Log document retrieve request
    await AuditLog.log({
      userId,
      action: 'DIGILOCKER_DOCUMENT_REQUESTED',
      entityType: 'document',
      entityId: docUri,
      status: 'success',
      ipAddress
    });

    try {
      const adapter = getDigilockerAdapter();
      const doc = await adapter.retrieveDocument(userId, docUri, ipAddress);

      // Write success audit logs for both receipt and verification
      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_DOCUMENT_RECEIVED',
        entityType: 'document',
        entityId: docUri,
        status: 'success',
        ipAddress,
        metadata: { docUri, documentType: doc.document_type }
      });
      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_DOCUMENT_VERIFIED',
        entityType: 'document',
        entityId: docUri,
        status: 'success',
        ipAddress,
        metadata: { docUri, documentType: doc.document_type }
      });

      // Trigger document verification notification
      try {
        const NotificationService = require('../services/notificationService');
        const docName = doc.document_type || 'Academic Marksheet';
        await NotificationService.send({
          userId,
          type: 'document_verification',
          title: 'Document Linked & Verified',
          content: `Your ${docName} has been successfully retrieved and verified from DigiLocker.`
        });
      } catch (notifErr) {
        logger.error('Failed to trigger DigiLocker notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
      }

      return res.status(200).json({
        success: true,
        message: 'Document successfully linked and verified from DigiLocker.',
        data: doc
      });

    } catch (err) {
      let statusCode = 400;
      let userMsg = err.message;

      if (err.message === 'DOCUMENT_NOT_FOUND') {
        statusCode = 404;
        userMsg = 'Requested document was not found in your DigiLocker.';
      } else if (err.message === 'NAME_MISMATCH') {
        userMsg = 'Verification Mismatch: The student name on this document does not match your registered portal name.';
      } else if (err.message === 'TIMEOUT_ERROR') {
        statusCode = 504;
        userMsg = 'DigiLocker request timed out. Please try again.';
      } else if (err.message === 'EXTERNAL_SERVICE_FAILURE') {
        statusCode = 502;
        userMsg = 'DigiLocker gateway service is currently offline. Please retry later.';
      } else if (err.message.includes('PRODUCTION_DIGILOCKER_OFFLINE')) {
        statusCode = 503;
        userMsg = 'Real DigiLocker production services are currently offline.';
      }

      await AuditLog.log({
        userId,
        action: 'DIGILOCKER_ERROR',
        status: 'failure',
        ipAddress,
        metadata: { docUri, reason: err.message, userMessage: userMsg }
      });

      return res.status(statusCode).json({
        success: false,
        message: userMsg,
        error: { global: userMsg }
      });
    }

  } catch (error) {
    logger.error('Retrieve document controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error retrieving document',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Associates/selects a verified document for use in the student's admission application
 */
async function selectDocument(req, res) {
  const userId = req.user.userId;
  const { docUri, selected } = req.body;
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

  try {
    // 1. Verify document ownership and verification status
    const docRows = await db.query(
      "SELECT id, document_type, doc_uri FROM digilocker_documents WHERE user_id = ? AND doc_uri = ? AND (verification_status = 'Verified' OR verification_status = 'VERIFIED')",
      [userId, docUri]
    );

    if (!docRows || docRows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No verified DigiLocker document matching the requested URI was found.',
        error: { global: 'Document not found or not verified' }
      });
    }

    const doc = docRows[0];
    const targetStatus = (selected === false || selected === 'false') ? 'AVAILABLE' : 'SELECTED';

    // 2. Set document status to SELECTED or AVAILABLE
    await db.query(
      "UPDATE digilocker_documents SET document_status = ? WHERE id = ?",
      [targetStatus, doc.id]
    );

    // 3. Log selection audit event
    const action = targetStatus === 'SELECTED' ? 'DIGILOCKER_DOCUMENT_SELECTED' : 'DIGILOCKER_DOCUMENT_DESELECTED';
    await AuditLog.log({
      userId,
      action,
      entityType: 'document',
      entityId: docUri,
      status: 'success',
      ipAddress,
      metadata: { docUri, documentType: doc.document_type }
    });

    return res.status(200).json({
      success: true,
      message: targetStatus === 'SELECTED'
        ? `Successfully selected and associated '${doc.document_type}' with your admission application.`
        : `Successfully deselected '${doc.document_type}' from your admission application.`,
      data: {
        id: doc.id,
        documentType: doc.document_type,
        docUri: doc.doc_uri,
        documentStatus: targetStatus
      }
    });

  } catch (error) {
    logger.error('Select document controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error selecting document',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  getOAuthAuthorize,
  handleOAuthCallback,
  getConnectionStatus,
  recordConsent,
  disconnect,
  getAvailableDocuments,
  retrieveDocument,
  selectDocument
};

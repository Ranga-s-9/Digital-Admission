const db = require('../config/db');

/**
 * Model class for Notifications database operations
 */
class Notification {
  /**
   * Find a notification by its ID
   * @param {number} id 
   * @returns {Promise<Object|null>}
   */
  static async findById(id) {
    const rows = await db.query('SELECT * FROM notifications WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Find notifications by user ID, ordered by creation time descending
   * @param {number} userId 
   * @returns {Promise<Array>}
   */
  static async findByUserId(userId) {
    return await db.query(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC',
      [userId]
    );
  }

  /**
   * Get unread notifications count for a user
   * @param {number} userId 
   * @returns {Promise<number>}
   */
  static async getUnreadCount(userId) {
    const rows = await db.query(
      'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0',
      [userId]
    );
    return rows.length > 0 ? rows[0].count : 0;
  }

  /**
   * Create a new notification with duplicate prevention logic
   * @param {Object} data
   * @param {number} data.userId
   * @param {string} data.title
   * @param {string} data.content
   * @param {string} data.type
   * @returns {Promise<number>} - Inserted notification ID
   */
  static async create({ userId, title, content, type = 'info' }) {
    // Duplicate prevention: check if an identical unread notification exists for this user
    const existing = await db.query(
      'SELECT id FROM notifications WHERE user_id = ? AND type = ? AND title = ? AND content = ? AND is_read = 0',
      [userId, type, title, content]
    );

    if (existing && existing.length > 0) {
      return existing[0].id;
    }

    const sql = `
      INSERT INTO notifications (user_id, title, content, type, is_read, created_at)
      VALUES (?, ?, ?, ?, 0, CURRENT_TIMESTAMP)
    `;
    const params = [userId, title, content, type];
    const result = await db.query(sql, params);
    return result.insertId;
  }

  /**
   * Mark a notification as read
   * @param {number} id 
   * @param {number} userId 
   * @returns {Promise<boolean>}
   */
  static async markAsRead(id, userId) {
    const result = await db.query(
      'UPDATE notifications SET is_read = 1, read_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    return result.affectedRows > 0;
  }

  /**
   * Mark a notification as unread
   * @param {number} id 
   * @param {number} userId 
   * @returns {Promise<boolean>}
   */
  static async markAsUnread(id, userId) {
    const result = await db.query(
      'UPDATE notifications SET is_read = 0, read_at = NULL WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    return result.affectedRows > 0;
  }

  /**
   * Mark all notifications as read for a user
   * @param {number} userId 
   * @returns {Promise<boolean>}
   */
  static async markAllAsRead(userId) {
    const result = await db.query(
      'UPDATE notifications SET is_read = 1, read_at = CURRENT_TIMESTAMP WHERE user_id = ? AND is_read = 0',
      [userId]
    );
    return result.affectedRows >= 0;
  }
}

module.exports = Notification;

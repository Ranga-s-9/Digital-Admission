/**
 * emSigner Adapter Base Interface
 *
 * All emSigner adapter implementations must extend this class
 * and implement the defined abstract methods.
 */
class EmsignerAdapter {
  /**
   * Initiate a digital signature request for an application
   * @param {number} userId - Student user ID
   * @param {string} applicationId - Application reference ID (e.g. DPI-2026-XXXXX)
   * @param {string} ipAddress - Client IP address for audit log
   * @returns {Promise<Object>} Signing result with request ID and status
   */
  async initiateSign(userId, applicationId, ipAddress) {
    throw new Error('initiateSign() must be implemented by subclass.');
  }

  /**
   * Get the current signing status for a student's application
   * @param {number} userId - Student user ID
   * @returns {Promise<Object>} Current status details
   */
  async getStatus(userId) {
    throw new Error('getStatus() must be implemented by subclass.');
  }
}

module.exports = EmsignerAdapter;

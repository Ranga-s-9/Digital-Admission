-- =============================================================================
-- Rollback 005: Drop Centralized Audit Logs Table
-- Reverses 005_add_audit_logs.sql.
-- WARNING: This is destructive. All audit log data will be lost.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS audit_logs;

SET FOREIGN_KEY_CHECKS = 1;

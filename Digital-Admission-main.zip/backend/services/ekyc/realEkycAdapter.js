const EkycAdapter = require('./ekycAdapter');
const db = require('../../config/db');
const crypto = require('crypto');
const xmlParserService = require('./xmlParser.service');
const xmlValidationService = require('./xmlValidation.service');
const signatureService = require('./signature.service');
const identityMatchingService = require('./identityMatching.service');
const hashService = require('./hash.service');

/**
 * Real eKYC Verification Adapter (Production Service Connection)
 *
 * Implements the official Offline XML eKYC verification pipeline:
 * 1. Safe XML Parsing
 * 2. Structure & Field Validation
 * 3. Cryptographic Signature Validation against trusted UIDAI certificates
 * 4. SHA-256 mobile/email hash matching
 * 5. Demographic data matching
 */
class RealEkycAdapter extends EkycAdapter {
  /**
   * Verify eKYC via Offline XML
   * @param {number} userId - The student user ID
   * @param {string} xmlContent - The uploaded XML document content
   * @param {string} shareCode - The 4-digit share code
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Verification results
   */
  async verify(userId, xmlContent, shareCode, ipAddress) {
    // 1. Validate inputs exist
    if (!xmlContent || String(xmlContent).trim() === '') {
      throw new Error('MISSING_XML_CONTENT');
    }
    if (!shareCode || String(shareCode).trim() === '') {
      throw new Error('MISSING_SHARE_CODE');
    }

    // 2. Parse XML securely
    let parsed, identity;
    try {
      const parseResult = xmlParserService.parseXml(xmlContent);
      parsed = parseResult.parsed;
      identity = xmlParserService.extractIdentity(parsed);
    } catch (err) {
      throw new Error(err.code || 'MALFORMED_XML');
    }

    // 3. Validate XML structure
    const structureResult = xmlValidationService.validateStructure(parsed);
    if (!structureResult.valid) {
      throw new Error('INVALID_XML');
    }

    // 4. Validate identity fields
    const fieldResult = xmlValidationService.validateIdentityFields(identity);
    if (!fieldResult.valid) {
      throw new Error('MISSING_IDENTITY_FIELDS');
    }

    // 5. Check share code match (if present in XML root; real UIDAI XML uses shareCode for ZIP encryption)
    if (identity.shareCode && identity.shareCode !== shareCode) {
      throw new Error('INVALID_SHARE_CODE');
    }

    // 6. Verify digital signature using UIDAI public key/certificate
    const sigResult = await signatureService.verifySignature(xmlContent);
    if (!sigResult.valid) {
      throw new Error(sigResult.reason || 'SIGNATURE_INVALID');
    }
    
    // Safety check: if signatureService returned mock signature verification because the cert was missing,
    // we should NOT accept it as valid production eKYC. Fail safely.
    if (sigResult.isMock) {
      throw new Error('PRODUCTION_EKYC_OFFLINE: Real eKYC UIDAI certificate is not configured or is offline.');
    }

    // 7. Get user & student profile
    const users = await db.query('SELECT name, email, mobile FROM users WHERE id = ?', [userId]);
    if (!users || users.length === 0) {
      throw new Error('UNAUTHORIZED_ACCESS');
    }

    const profiles = await db.query('SELECT dob, gender, pincode FROM student_profiles WHERE user_id = ?', [userId]);
    const profile = profiles && profiles.length > 0 ? profiles[0] : null;

    if (!profile) {
      throw new Error('PROFILE_NOT_INITIALIZED');
    }

    // 8. Check Duplicate Verification
    const existingRequests = await db.query('SELECT verification_status FROM ekyc_requests WHERE user_id = ?', [userId]);
    if (existingRequests && existingRequests.length > 0) {
      const existing = existingRequests[0];
      if (existing.verification_status === 'VERIFIED') {
        throw new Error('DUPLICATE_VERIFICATION');
      }
    }

    // 9. Verify Hashed values (Mobile and Email) if present in XML
    if (identity.phone) {
      const mobileHashRes = hashService.verifyMobileHash(users[0].mobile, identity.phone, shareCode);
      if (!mobileHashRes.match) {
        throw new Error('HASH_MISMATCH');
      }
    }
    if (identity.email) {
      const emailHashRes = hashService.verifyEmailHash(users[0].email, identity.email, shareCode);
      if (!emailHashRes.match) {
        throw new Error('HASH_MISMATCH');
      }
    }

    // 10. Identity demographic fields matching
    const matchResult = identityMatchingService.matchIdentity(identity, {
      name: users[0].name,
      dob: profile.dob,
      gender: profile.gender,
      pincode: profile.pincode
    });

    const isMatch = matchResult.result === 'MATCH' || matchResult.result === 'REVIEW_REQUIRED';

    // Mask Aadhaar number
    const aadhaarMasked = identity.aadhaar && /^\d{12}$/.test(identity.aadhaar)
      ? 'XXXX-XXXX-' + identity.aadhaar.slice(-4)
      : 'XXXX-XXXX-9999';

    // Verify perfect matching with linked DigiLocker account if present
    const digilockerRows = await db.query(
      'SELECT digilocker_id FROM digilocker_connections WHERE user_id = ?',
      [userId]
    );
    if (digilockerRows && digilockerRows.length > 0) {
      const digilockerId = digilockerRows[0].digilocker_id || '';
      if (digilockerId.startsWith('DL-')) {
        const dlAadhaar = digilockerId.replace('DL-', '');
        if (/^\d{12}$/.test(dlAadhaar) && identity.aadhaar && /^\d{12}$/.test(identity.aadhaar)) {
          if (dlAadhaar !== identity.aadhaar) {
            throw new Error('AADHAAR_MISMATCH');
          }
        }
      }
    }
    const shareCodeHash = crypto.createHash('sha256').update(shareCode).digest('hex');
    const verifiedStatus = isMatch ? 'VERIFIED' : 'FAILED';
    const errorMessage = isMatch ? null : `Identity mismatch: ${matchResult.mismatches.join(', ')} did not match profile`;
    const verifiedAt = isMatch ? Date.now() : null;

    if (existingRequests && existingRequests.length > 0) {
      await db.query(
        `UPDATE ekyc_requests 
         SET aadhaar_masked = ?, share_code_hash = ?, xml_filename = ?, verification_status = ?, error_message = ?, verified_at = ?, verification_method = 'offline_xml', updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [aadhaarMasked, shareCodeHash, 'aadhaar_offline_ekyc.xml', verifiedStatus, errorMessage, verifiedAt, userId]
      );
    } else {
      await db.query(
        `INSERT INTO ekyc_requests (user_id, aadhaar_masked, share_code_hash, xml_filename, verification_status, error_message, verified_at, verification_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'offline_xml')`,
        [userId, aadhaarMasked, shareCodeHash, 'aadhaar_offline_ekyc.xml', verifiedStatus, errorMessage, verifiedAt]
      );
    }

    // Log audit entry
    const action = isMatch ? 'VERIFY_SUCCESS' : 'VERIFY_FAILED';
    const logDetails = isMatch
      ? 'Identity details verified successfully via Production Aadhaar Offline XML.'
      : `Verification failed: ${errorMessage}`;

    await db.query(
      `INSERT INTO ekyc_audit_logs (user_id, action, ip_address, details)
       VALUES (?, ?, ?, ?)`,
      [userId, action, ipAddress, logDetails]
    );

    return {
      success: isMatch,
      status: verifiedStatus,
      development_mode: false,
      data: isMatch ? {
        name: identity.name,
        dob: identity.dob,
        gender: identity.gender,
        pincode: identity.address ? identity.address.pincode : null,
        verifiedAt,
        signatureVerification: sigResult.detail
      } : null,
      error: isMatch ? null : errorMessage
    };
  }
}

module.exports = RealEkycAdapter;

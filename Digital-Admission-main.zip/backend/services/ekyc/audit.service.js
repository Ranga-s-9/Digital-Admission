'use strict';

const db = require('../../config/db');

/**
 * eKYC Audit Service
 *
 * Centralized, structured audit logging for eKYC events.
 * Logs are immutable from the student's normal application interface.
 *
 * NEVER logs: share codes, passwords, raw XML, sensitive identity data.
 */

/**
 * Valid audit event types
 */
const EVENTS = {
  CONSENT_CREATED: 'CONSENT_CREATED',
  FILE_UPLOADED: 'FILE_UPLOADED',
  VERIFICATION_STARTED: 'VERIFICATION_STARTED',
  XML_VALIDATED: 'XML_VALIDATED',
  SIGNATURE_VALIDATED: 'SIGNATURE_VALIDATED',
  HASH_VALIDATED: 'HASH_VALIDATED',
  IDENTITY_MATCHED: 'IDENTITY_MATCHED',
  IDENTITY_MISMATCHED: 'IDENTITY_MISMATCHED',
  VERIFICATION_SUCCESS: 'VERIFICATION_SUCCESS',
  VERIFICATION_FAILED: 'VERIFICATION_FAILED',
  STATUS_CHANGED: 'STATUS_CHANGED'
};

/**
 * Log an eKYC audit event
 * @param {object} params
 * @param {number} params.studentId - Student's user ID
 * @param {string} [params.verificationId] - Verification reference ID
 * @param {string} params.event - Event type (from EVENTS enum)
 * @param {string} [params.status] - Current verification status
 * @param {string} [params.ipAddress] - Client IP address
 * @param {string} [params.failureReason] - Reason code (not sensitive data)
 * @param {string} [params.details] - Non-sensitive details string
 */
async function logEvent({
  studentId,
  verificationId = null,
  event,
  status = null,
  ipAddress = null,
  failureReason = null,
  details = null
}) {
  // Sanitize: never allow sensitive values through
  const sanitizedDetails = _sanitize(details);

  try {
    await db.query(
      `INSERT INTO ekyc_audit_logs (user_id, action, ip_address, details)
       VALUES (?, ?, ?, ?)`,
      [
        studentId || null,
        `${event}${verificationId ? ':' + verificationId : ''}`,
        ipAddress || null,
        [
          status ? `status=${status}` : null,
          failureReason ? `reason=${failureReason}` : null,
          sanitizedDetails
        ].filter(Boolean).join(' | ') || null
      ]
    );
  } catch (err) {
    // Audit logging should never break the main flow
    // Log to structured logger if available, but swallow the error
    console.error('eKYC audit log write failed:', err.message);
  }
}

/**
 * Retrieve audit logs for a specific student's eKYC verifications
 * @param {number} studentId
 * @param {object} [options]
 * @param {number} [options.limit] - Maximum records to return
 * @returns {Promise<Array>}
 */
async function getAuditLogs(studentId, options = {}) {
  const limit = options.limit || 50;

  const rows = await db.query(
    `SELECT id, user_id, action, ip_address, details, created_at
     FROM ekyc_audit_logs
     WHERE user_id = ?
     ORDER BY created_at DESC
     LIMIT ${parseInt(limit, 10)}`,
    [studentId]
  );

  return rows || [];
}

/**
 * Sanitize details string — remove any content that looks like a share code,
 * password, or raw XML
 * @param {string|null} details
 * @returns {string|null}
 */
function _sanitize(details) {
  if (!details || typeof details !== 'string') return details;

  // Remove anything that looks like a 4-digit share code in context
  let sanitized = details.replace(/shareCode[=:]\s*\d{4}/gi, 'shareCode=[REDACTED]');

  // Remove anything that looks like a password
  sanitized = sanitized.replace(/password[=:]\s*\S+/gi, 'password=[REDACTED]');

  // Truncate raw XML if present
  if (sanitized.includes('<?xml') || sanitized.includes('<OfflinePaperlessKyc')) {
    sanitized = '[XML_CONTENT_REDACTED]';
  }

  return sanitized;
}

module.exports = {
  logEvent,
  getAuditLogs,
  EVENTS
};

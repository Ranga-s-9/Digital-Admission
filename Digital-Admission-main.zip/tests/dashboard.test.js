// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_dashboard.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('Admission Portal Dashboard API tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {
        // Ignored
      }
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_dashboard.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;

    // Fetch correct answer directly from test DB to simulate correct client parsing
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedCookie(email, password, role = 'student', mobile = null) {
    const cap = await getValidCaptcha();
    const defaultMobile = role === 'student' ? '9111122222' : '9333344444';
    const registerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: role === 'student' ? 'Alice Student' : 'Professor Bob',
        email,
        mobile: mobile || defaultMobile,
        password,
        confirmPassword: password,
        role,
        ...cap
      });

    if (registerRes.statusCode !== 201) {
      throw new Error('Registration helper failed: ' + JSON.stringify(registerRes.body));
    }

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    if (loginRes.statusCode !== 200) {
      throw new Error('Login Step 1 helper failed: ' + JSON.stringify(loginRes.body));
    }

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });

    if (verifyRes.statusCode !== 200) {
      throw new Error('Login Step 2 verify helper failed: ' + JSON.stringify(verifyRes.body));
    }

    return verifyRes.headers['set-cookie'][0];
  }

  // --- TEST CASES ---

  test('1. Successful dashboard data retrieval for authenticated Student', async () => {
    const cookie = await getAuthenticatedCookie('alice@student.com', 'Password@123', 'student');

    const res = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.profile.email).toBe('alice@student.com');
    expect(res.body.data.profile.role).toBe('student');
    expect(res.body.data.widgets.ekycStatus).toBe('Pending');
    expect(res.body.data.widgets.digilockerStatus).toBe('Not Connected');
  });

  test('2. Successful dashboard data retrieval for authenticated Professor', async () => {
    const professorCookie = await getAuthenticatedCookie('bob@professor.com', 'Password@123', 'professor');

    const res = await request(app)
      .get('/api/dashboard/professor')
      .set('Cookie', professorCookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('applications');
    expect(res.body.data).toHaveProperty('stats');
    expect(res.body.data.stats.total).toBe(0); // No students registered yet in this isolated test run
  });

  test('3. Role-based IDOR checks: Student requesting Professor dashboard is blocked', async () => {
    const studentCookie = await getAuthenticatedCookie('alice@student.com', 'Password@123', 'student');

    const res = await request(app)
      .get('/api/dashboard/professor')
      .set('Cookie', studentCookie);

    expect(res.statusCode).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('required permissions');
  });

  test('4. Role-based IDOR checks: Professor requesting Student dashboard is blocked', async () => {
    const professorCookie = await getAuthenticatedCookie('bob@professor.com', 'Password@123', 'professor');

    const res = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', professorCookie);

    expect(res.statusCode).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('required permissions');
  });

  test('5. Unauthenticated request to dashboard endpoints is rejected', async () => {
    const resStudent = await request(app).get('/api/dashboard/student');
    expect(resStudent.statusCode).toBe(401);
    expect(resStudent.body.success).toBe(false);

    const resProfessor = await request(app).get('/api/dashboard/professor');
    expect(resProfessor.statusCode).toBe(401);
    expect(resProfessor.body.success).toBe(false);
  });

  test('6. Professor applications list query applies search and status filters correctly', async () => {
    const professorCookie = await getAuthenticatedCookie('bob@professor.com', 'Password@123', 'professor');

    // Register two student users
    await getAuthenticatedCookie('student1@example.com', 'Password@123', 'student', '9111100001');
    await getAuthenticatedCookie('student2@example.com', 'Password@123', 'student', '9111100002');

    // Fetch applications with search filter matching "student1"
    const resSearch = await request(app)
      .get('/api/dashboard/professor?search=student1')
      .set('Cookie', professorCookie);

    expect(resSearch.statusCode).toBe(200);
    expect(resSearch.body.data.applications.length).toBe(1);
    expect(resSearch.body.data.applications[0].email).toBe('student1@example.com');

    // Fetch applications with search filter matching none
    const resEmpty = await request(app)
      .get('/api/dashboard/professor?search=nonexistent')
      .set('Cookie', professorCookie);

    expect(resEmpty.statusCode).toBe(200);
    expect(resEmpty.body.data.applications.length).toBe(0);
  });

});

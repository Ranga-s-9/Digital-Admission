const EkycAdapter = require('./ekycAdapter');
const db = require('../../config/db');
const crypto = require('crypto');
const xmlParserService = require('./xmlParser.service');
const xmlValidationService = require('./xmlValidation.service');
const signatureService = require('./signature.service');
const identityMatchingService = require('./identityMatching.service');

/**
 * Mock eKYC Verification Adapter
 *
 * ⚠ DEVELOPMENT / MOCK MODE
 * Uses secure XML parsing but simulates signature verification.
 * Intended for frontend/backend development and automated testing
 * when genuine UIDAI verification materials are unavailable.
 */
class MockEkycAdapter extends EkycAdapter {
  /**
   * Verify eKYC via Offline XML
   * @param {number} userId - The student user ID
   * @param {string} xmlContent - The uploaded XML document content
   * @param {string} shareCode - The 4-digit share code
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Verification results containing status and details
   */
  async verify(userId, xmlContent, shareCode, ipAddress) {
    // 1. Validate inputs exist
    if (!xmlContent || String(xmlContent).trim() === '') {
      throw new Error('MISSING_XML_CONTENT');
    }
    if (!shareCode || String(shareCode).trim() === '') {
      throw new Error('MISSING_SHARE_CODE');
    }

    // 2. Parse XML securely (replaces old regex approach)
    let parsed, identity;
    try {
      const result = xmlParserService.parseXml(xmlContent);
      parsed = result.parsed;
      identity = xmlParserService.extractIdentity(parsed);
    } catch (err) {
      throw new Error(err.code || 'MALFORMED_XML');
    }

    // 3. Validate XML structure
    const structureResult = xmlValidationService.validateStructure(parsed);
    if (!structureResult.valid) {
      throw new Error('INVALID_XML');
    }

    // 4. Validate identity fields
    const fieldResult = xmlValidationService.validateIdentityFields(identity);
    if (!fieldResult.valid) {
      throw new Error('MISSING_IDENTITY_FIELDS');
    }

    // 5. Check share code match (if present in XML root; real UIDAI XML uses shareCode for ZIP encryption)
    if (identity.shareCode && identity.shareCode !== shareCode) {
      throw new Error('INVALID_SHARE_CODE');
    }

    // 6. Mock signature verification (clearly labelled)
    const sigResult = await signatureService.verifySignature(xmlContent, { mockMode: true });
    if (!sigResult.valid) {
      throw new Error('SIGNATURE_INVALID');
    }

    // 7. Simulate test scenarios
    if (identity.name === 'Simulate Timeout') {
      await new Promise(resolve => setTimeout(resolve, 1500));
      throw new Error('TIMEOUT_ERROR');
    }
    if (identity.name === 'Simulate External Failure') {
      throw new Error('EXTERNAL_SERVICE_FAILURE');
    }

    // 8. Query user & student profile to match
    const users = await db.query('SELECT name FROM users WHERE id = ?', [userId]);
    if (!users || users.length === 0) {
      throw new Error('UNAUTHORIZED_ACCESS');
    }

    const profiles = await db.query('SELECT dob, gender, pincode FROM student_profiles WHERE user_id = ?', [userId]);
    const profile = profiles && profiles.length > 0 ? profiles[0] : null;

    if (!profile) {
      throw new Error('PROFILE_NOT_INITIALIZED');
    }

    // 9. Check Duplicate Verification
    const existingRequests = await db.query('SELECT verification_status FROM ekyc_requests WHERE user_id = ?', [userId]);
    if (existingRequests && existingRequests.length > 0) {
      const existing = existingRequests[0];
      if (existing.verification_status === 'VERIFIED' || existing.verification_status === 'Verified') {
        throw new Error('DUPLICATE_VERIFICATION');
      }
    }

    // 10. Identity matching using the service
    const matchResult = identityMatchingService.matchIdentity(identity, {
      name: users[0].name,
      dob: profile.dob,
      gender: profile.gender,
      pincode: profile.pincode
    });

    const isMatch = matchResult.result === 'MATCH' || matchResult.result === 'REVIEW_REQUIRED';

    // Mask sensitive Aadhaar number simulation
    const aadhaarMasked = identity.aadhaar && /^\d{12}$/.test(identity.aadhaar)
      ? 'XXXX-XXXX-' + identity.aadhaar.slice(-4)
      : 'XXXX-XXXX-9999';

    // Verify perfect matching with linked DigiLocker account if present
    const digilockerRows = await db.query(
      'SELECT digilocker_id FROM digilocker_connections WHERE user_id = ?',
      [userId]
    );
    if (digilockerRows && digilockerRows.length > 0) {
      const digilockerId = digilockerRows[0].digilocker_id || '';
      if (digilockerId.startsWith('DL-')) {
        const dlAadhaar = digilockerId.replace('DL-', '');
        if (/^\d{12}$/.test(dlAadhaar) && identity.aadhaar && /^\d{12}$/.test(identity.aadhaar)) {
          if (dlAadhaar !== identity.aadhaar) {
            throw new Error('AADHAAR_MISMATCH');
          }
        }
      }
    }

    // Insert or update ekyc_requests table
    const shareCodeHash = crypto.createHash('sha256').update(shareCode).digest('hex');
    const verifiedStatus = isMatch ? 'VERIFIED' : 'FAILED';
    const errorMessage = isMatch ? null : `Identity ${matchResult.result}: ${matchResult.mismatches.join(', ')} did not match profile`;
    const verifiedAt = isMatch ? Date.now() : null;

    if (existingRequests && existingRequests.length > 0) {
      await db.query(
        `UPDATE ekyc_requests 
         SET aadhaar_masked = ?, share_code_hash = ?, xml_filename = ?, verification_status = ?, error_message = ?, verified_at = ?, verification_method = 'offline_xml', updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [aadhaarMasked, shareCodeHash, 'mock_offline_kyc.xml', verifiedStatus, errorMessage, verifiedAt, userId]
      );
    } else {
      await db.query(
        `INSERT INTO ekyc_requests (user_id, aadhaar_masked, share_code_hash, xml_filename, verification_status, error_message, verified_at, verification_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'offline_xml')`,
        [userId, aadhaarMasked, shareCodeHash, 'mock_offline_kyc.xml', verifiedStatus, errorMessage, verifiedAt]
      );
    }

    // Log non-sensitive audit entry
    const action = isMatch ? 'VERIFY_SUCCESS' : 'VERIFY_FAILED';
    const logDetails = isMatch
      ? '[MOCK] Identity details verified successfully via Mock Aadhaar Offline XML.'
      : `[MOCK] Verification failed: ${errorMessage}`;

    await db.query(
      `INSERT INTO ekyc_audit_logs (user_id, action, ip_address, details)
       VALUES (?, ?, ?, ?)`,
      [userId, action, ipAddress, logDetails]
    );

    return {
      success: isMatch,
      status: verifiedStatus,
      development_mode: true,
      data: isMatch ? {
        name: identity.name,
        dob: identity.dob,
        gender: identity.gender,
        pincode: identity.address ? identity.address.pincode : null,
        verifiedAt,
        signatureVerification: sigResult.detail
      } : null,
      error: isMatch ? null : errorMessage
    };
  }
}

module.exports = MockEkycAdapter;

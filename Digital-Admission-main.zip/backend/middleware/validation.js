const { body, validationResult } = require('express-validator');

// Shareable custom CAPTCHA validator
const captchaValidator = async (value, { req }) => {
  const captchaId = req.body.captchaId;
  if (!captchaId) return true; // Handled by captchaId validation rules

  const Captcha = require('../models/Captcha');
  const captcha = await Captcha.findById(captchaId);

  if (!captcha) {
    throw new Error('CAPTCHA session not found. Please refresh the CAPTCHA.');
  }

  // Check Expiration
  const expiresAt = Number(captcha.expires_at);
  if (expiresAt < Date.now()) {
    await Captcha.delete(captchaId);
    throw new Error('CAPTCHA has expired. Please refresh the CAPTCHA.');
  }

  // Check Attempt Threshold
  if (captcha.attempts >= 3) {
    await Captcha.delete(captchaId);
    throw new Error('Too many failed CAPTCHA attempts. Please refresh.');
  }

  // Check Correct Answer
  if (captcha.answer !== String(value).trim()) {
    const attempts = await Captcha.incrementAttempts(captchaId);
    if (attempts >= 3) {
      await Captcha.delete(captchaId);
      throw new Error('Too many failed CAPTCHA attempts. Please refresh.');
    }
    throw new Error('Incorrect CAPTCHA answer. Please try again.');
  }

  // Successfully validated - delete to prevent reuse/replay
  await Captcha.delete(captchaId);
  return true;
};

// Validation rules for registration
const registrationRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Full name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters')
    .escape(),
  
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),
  
  body('mobile')
    .trim()
    .notEmpty().withMessage('Mobile number is required')
    .matches(/^(?:\+91|0)?[6-9]\d{9}$/).withMessage('Please enter a valid 10-digit mobile number'),
  
  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters long')
    .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
    .matches(/[a-z]/).withMessage('Password must contain at least one lowercase letter')
    .matches(/\d/).withMessage('Password must contain at least one number')
    .matches(/[@$!%*?&#]/).withMessage('Password must contain at least one special character (@$!%*?&#)'),
  
  body('confirmPassword')
    .notEmpty().withMessage('Please confirm your password')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Password confirmation does not match password');
      }
      return true;
    }),
  
  body('role')
    .trim()
    .notEmpty().withMessage('User role is required')
    .isIn(['student', 'professor', 'admin']).withMessage('Invalid role selected'),

  body('captchaId')
    .trim()
    .notEmpty().withMessage('CAPTCHA ID is required'),
  
  body('captchaAnswer')
    .trim()
    .notEmpty().withMessage('CAPTCHA answer is required')
    .custom(captchaValidator)
];

// Validation rules for login
const loginRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),
  
  body('password')
    .notEmpty().withMessage('Password is required'),

  body('role')
    .optional()
    .trim()
    .isIn(['student', 'professor', 'admin']).withMessage('Invalid role selected'),

  body('captchaId')
    .trim()
    .notEmpty().withMessage('CAPTCHA ID is required'),
  
  body('captchaAnswer')
    .trim()
    .notEmpty().withMessage('CAPTCHA answer is required')
    .custom(captchaValidator)
];

// Validation rules for OTP verification
const otpVerifyRules = [
  body('otpSessionId')
    .trim()
    .notEmpty().withMessage('OTP Session ID is required'),
  body('code')
    .trim()
    .notEmpty().withMessage('OTP code is required')
    .isNumeric().withMessage('OTP code must contain digits only')
    .isLength({ min: 6, max: 6 }).withMessage('OTP code must be exactly 6 digits')
];

// Validation rules for OTP resend
const otpResendRules = [
  body('otpSessionId')
    .trim()
    .notEmpty().withMessage('OTP Session ID is required')
];

// Validation rules for Student Profile updates
const profileUpdateRules = [
  body('dob')
    .optional({ checkFalsy: true })
    .isISO8601().withMessage('Date of birth must be a valid YYYY-MM-DD date format'),

  body('gender')
    .optional({ checkFalsy: true })
    .isIn(['Male', 'Female', 'Other']).withMessage('Gender must be one of: Male, Female, Other'),

  body('pincode')
    .optional({ checkFalsy: true })
    .isNumeric().withMessage('Pincode must contain numbers only')
    .isLength({ min: 6, max: 6 }).withMessage('Pincode must be exactly 6 digits'),

  body('gradYear')
    .optional({ checkFalsy: true })
    .isInt({ min: 1900, max: 2035 }).withMessage('Graduation year must be between 1900 and 2035'),

  body('percentage')
    .optional({ checkFalsy: true })
    .isFloat({ min: 0, max: 100 }).withMessage('Academic percentage must be a number between 0.00 and 100.00'),

  body('version')
    .notEmpty().withMessage('version key is required')
];

// Validation rules for eKYC generation
const ekycGenerateRules = [
  body('name').trim().notEmpty().withMessage('name is required'),
  body('dob').isISO8601().withMessage('dob must be a valid YYYY-MM-DD date format'),
  body('gender').isIn(['Male', 'Female', 'Other']).withMessage('gender must be Male, Female, or Other'),
  body('address').trim().notEmpty().withMessage('address is required'),
  body('state').trim().notEmpty().withMessage('state is required'),
  body('pincode').isNumeric().isLength({ min: 6, max: 6 }).withMessage('pincode must be exactly 6 digits'),
  body('shareCode').isNumeric().isLength({ min: 4, max: 4 }).withMessage('shareCode must be exactly 4 digits'),
  body('aadhaar').isNumeric().isLength({ min: 12, max: 12 }).withMessage('aadhaar must be exactly 12 digits')
];

// Validation rules for eKYC consent recording
const ekycConsentRules = [
  body('consent')
    .custom(val => val === true || val === 'true')
    .withMessage('Consent is mandatory to perform identity verification.')
];

// Validation rules for eKYC verification
const ekycVerifyRules = [
  body('shareCode')
    .isNumeric().withMessage('share code must be exactly 4 numeric digits')
    .isLength({ min: 4, max: 4 }).withMessage('share code must be exactly 4 digits'),
  body('xmlContent')
    .if(body('verificationId').not().exists())
    .notEmpty().withMessage('xmlContent is required when verificationId is not provided'),
  body('consent')
    .if(body('verificationId').not().exists())
    .custom(val => val === true || val === 'true')
    .withMessage('Consent is mandatory to perform identity verification.')
];

// Validation rules for DigiLocker document retrieval
const digilockerRetrieveRules = [
  body('docUri').notEmpty().withMessage('docUri is required')
];

// Validation rules for DigiLocker consent recording
const digilockerConsentRules = [
  body('consent')
    .isBoolean().withMessage('Consent must be a boolean value')
];

// Validation rules for DigiLocker document selection
const digilockerSelectRules = [
  body('docUri').notEmpty().withMessage('docUri is required')
];

// Validation rules for workflow transitions
const workflowTransitionRules = [
  body('userId').isInt().withMessage('userId must be an integer'),
  body('targetStatus').isIn(['Submitted', 'DOCUMENT_VERIFICATION', 'IDENTITY_VERIFICATION', 'PENDING_SIGNATURE', 'SIGNED', 'Approved', 'Rejected', 'Draft']).withMessage('Invalid targetStatus'),
  body('message')
    .if(body('targetStatus').equals('Draft'))
    .notEmpty().withMessage('Correction notes are mandatory when requesting revisions.')
    .trim()
    .escape()
];

// Validation rules for Admission draft saving (optional fields validation)
const admissionDraftRules = [
  body('dob')
    .optional({ checkFalsy: true })
    .isISO8601().withMessage('Date of birth must be a valid YYYY-MM-DD date format'),

  body('gender')
    .optional({ checkFalsy: true })
    .isIn(['Male', 'Female', 'Other']).withMessage('Gender must be one of: Male, Female, Other'),

  body('pincode')
    .optional({ checkFalsy: true })
    .isNumeric().isLength({ min: 6, max: 6 }).withMessage('Pincode must be exactly 6 digits'),

  body('gradYear')
    .optional({ checkFalsy: true })
    .isInt({ min: 1900, max: 2035 }).withMessage('Graduation year must be between 1900 and 2035'),

  body('percentage')
    .optional({ checkFalsy: true })
    .isFloat({ min: 0, max: 100 }).withMessage('Academic percentage must be a number between 0.00 and 100.00'),

  body('currentStep')
    .optional()
    .isInt().withMessage('currentStep must be an integer')
];

// Validation rules for Admission final submission (mandatory fields validation)
const admissionSubmitRules = [
  body('dob').isISO8601().withMessage('Date of birth must be a valid YYYY-MM-DD date format'),
  body('gender').isIn(['Male', 'Female', 'Other']).withMessage('Gender must be one of: Male, Female, Other'),
  body('guardianName').trim().notEmpty().withMessage('guardianName is required'),
  body('address').trim().notEmpty().withMessage('address is required'),
  body('state').trim().notEmpty().withMessage('state is required'),
  body('pincode').isNumeric().isLength({ min: 6, max: 6 }).withMessage('Pincode must be exactly 6 digits'),
  body('degree').trim().notEmpty().withMessage('degree is required'),
  body('board').trim().notEmpty().withMessage('board is required'),
  body('gradYear').isInt({ min: 1900, max: 2035 }).withMessage('Graduation year must be between 1900 and 2035'),
  body('percentage').isFloat({ min: 0, max: 100 }).withMessage('Academic percentage must be a number between 0.00 and 100.00')
];

// Validation rules for forgot password
const forgotPasswordRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email address is required')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),

  body('captchaId')
    .trim()
    .notEmpty().withMessage('CAPTCHA ID is required'),
  
  body('captchaAnswer')
    .trim()
    .notEmpty().withMessage('CAPTCHA answer is required')
    .custom(captchaValidator)
];

// Validation rules for reset password
const resetPasswordRules = [
  body('resetTokenId')
    .trim()
    .notEmpty().withMessage('Reset Token ID is required'),

  body('code')
    .trim()
    .notEmpty().withMessage('Recovery code is required')
    .isNumeric().withMessage('Recovery code must contain digits only')
    .isLength({ min: 6, max: 6 }).withMessage('Recovery code must be exactly 6 digits'),

  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters long')
    .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
    .matches(/[a-z]/).withMessage('Password must contain at least one lowercase letter')
    .matches(/\d/).withMessage('Password must contain at least one number')
    .matches(/[@$!%*?&#]/).withMessage('Password must contain at least one special character (@$!%*?&#)'),

  body('confirmPassword')
    .notEmpty().withMessage('Please confirm your password')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Password confirmation does not match password');
      }
      return true;
    })
];

// Middleware to handle validation results
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }

  const formattedErrors = {};
  errors.array().forEach(err => {
    const field = err.path || err.param;
    if (!formattedErrors[field]) {
      formattedErrors[field] = err.msg;
    }
  });

  // Include both the standard phrase ("validation error: validation failed") and
  // the first field-specific message so all consumers can match on either.
  const firstErrorMsg = Object.values(formattedErrors)[0] || '';
  const detail = firstErrorMsg ? ` — ${firstErrorMsg}` : '';

  return res.status(400).json({
    success: false,
    message: `Request validation error: validation failed${detail}`,
    error: formattedErrors
  });
};

module.exports = {
  registrationRules,
  loginRules,
  otpVerifyRules,
  otpResendRules,
  profileUpdateRules,
  ekycGenerateRules,
  ekycConsentRules,
  ekycVerifyRules,
  digilockerRetrieveRules,
  digilockerConsentRules,
  digilockerSelectRules,
  workflowTransitionRules,
  admissionDraftRules,
  admissionSubmitRules,
  forgotPasswordRules,
  resetPasswordRules,
  validate
};

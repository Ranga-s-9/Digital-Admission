-- =============================================================================
-- Rollback 003: Drop Notifications Table
-- Reverses the changes made in 003_add_notifications.sql.
-- WARNING: All notification records will be permanently lost.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notifications;
SET FOREIGN_KEY_CHECKS = 1;

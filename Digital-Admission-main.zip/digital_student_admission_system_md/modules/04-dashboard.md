# Module 04 — Dashboard

## Purpose

Provide the authenticated user's central workspace.

## Source Requirement

The dashboard is explicitly listed as a mandatory project component.

## Student Dashboard

Recommended sections:

- Profile
- eKYC status
- Documents
- Admission application
- Application status
- Digital signature
- Notifications
- Logout

## Professor/Admin Dashboard

Recommended sections:

- Applications
- Student verification
- Documents
- Signed forms
- Workflow status
- Reports/summary

## Requirements

- Show information appropriate to the user's role.
- Display verification/application status.
- Provide navigation to enabled modules.
- Prevent access to unauthorized functions.
- Display actionable errors and empty states.

## Acceptance Criteria

- Authenticated student reaches the student dashboard.
- Authorized professor/admin reaches the relevant dashboard.
- Unauthenticated users are redirected to login.
- Dashboard status information matches backend data.

## Dependencies

- Authentication
- Student Profile
- Admission
- eKYC
- Documents
- Workflow

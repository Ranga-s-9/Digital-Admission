<?php
/**
 * generate_mock_xml.php
 * Generates a mock password-protected or plain XML Aadhaar Offline e-KYC document for development use.
 */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "Method Not Allowed. Use POST.";
    exit;
}

$name = isset($_POST['name']) ? trim($_POST['name']) : 'Alice Student';
$dob = isset($_POST['dob']) ? trim($_POST['dob']) : '2005-05-15';
$gender = isset($_POST['gender']) ? trim($_POST['gender']) : 'Female';
$pincode = isset($_POST['pincode']) ? trim($_POST['pincode']) : '110001';
$shareCode = isset($_POST['shareCode']) ? trim($_POST['shareCode']) : '1234';
$aadhaar = isset($_POST['aadhaar']) ? trim($_POST['aadhaar']) : '123456789012';
$address = isset($_POST['address']) ? trim($_POST['address']) : '123 Main St';
$state = isset($_POST['state']) ? trim($_POST['state']) : 'Delhi';

// Standardize gender representation in XML
$gXml = 'F';
if (strcasecmp($gender, 'Male') === 0 || strcasecmp($gender, 'M') === 0) {
    $gXml = 'M';
} elseif (strcasecmp($gender, 'Other') === 0 || strcasecmp($gender, 'T') === 0) {
    $gXml = 'T';
}

// Generate MD5/SHA256 hashes for mock mobile/email
$mobile = '9876543210';
$email = 'student@example.com';
$mobileHash = hash('sha256', $mobile . $shareCode);
$emailHash = hash('sha256', $email . $shareCode);

$xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<OfflinePaperlessKyc shareCode=\"{$shareCode}\">
  <UidData>
    <Poi name=\"{$name}\" dob=\"{$dob}\" gender=\"{$gXml}\" m=\"{$mobileHash}\" e=\"{$emailHash}\"/>
    <Poa co=\"Guardian Name\" house=\"12\" street=\"{$address}\" state=\"{$state}\" pc=\"{$pincode}\"/>
    <Pht>MOCK_BASE64_PHOTO_DATA_HERE</Pht>
  </UidData>
  <Signature>MOCK_TRUSTED_UIDAI_DIGITAL_SIGNATURE_HASH</Signature>
</OfflinePaperlessKyc>";

// Return XML file
header('Content-Type: application/xml');
header('Content-Disposition: attachment; filename="aadhaar_offline_ekyc.xml"');
echo $xmlContent;

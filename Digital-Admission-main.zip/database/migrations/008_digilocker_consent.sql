-- =============================================================================
-- Migration: 008_digilocker_consent
-- Description: Create digilocker_consents table and alter digilocker_documents
-- =============================================================================

-- USE dpi_student_admission;

SET FOREIGN_KEY_CHECKS = 0;

-- Table: digilocker_consents
CREATE TABLE IF NOT EXISTS digilocker_consents (
  id                 INT           NOT NULL AUTO_INCREMENT,
  student_id         INT           NOT NULL,
  purpose            VARCHAR(255)  NOT NULL,
  scope              VARCHAR(255)  NOT NULL,
  consent_status     VARCHAR(50)   NOT NULL DEFAULT 'GRANTED',
  consent_timestamp  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_timestamp  TIMESTAMP     NULL DEFAULT NULL,
  created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_dl_consent_student    (student_id),
  KEY idx_dl_consent_status     (consent_status),
  CONSTRAINT fk_dl_consent_student FOREIGN KEY (student_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_dl_consent_status CHECK (consent_status IN ('GRANTED', 'REVOKED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='DigiLocker document access consents per student';

-- Alter Table: digilocker_documents
-- Add document_status column if it does not already exist
-- Check for column existence programmatically/defensively
-- Add check constraint for document_status
ALTER TABLE digilocker_documents ADD COLUMN IF NOT EXISTS document_status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' AFTER verification_status;

-- Note: MySQL 8.0.16+ supports check constraints on columns added via ALTER
ALTER TABLE digilocker_documents DROP CONSTRAINT IF EXISTS chk_digilocker_doc_status;
ALTER TABLE digilocker_documents ADD CONSTRAINT chk_digilocker_doc_status CHECK (document_status IN ('AVAILABLE', 'SELECTED', 'EXPIRED', 'REVOKED'));

SET FOREIGN_KEY_CHECKS = 1;

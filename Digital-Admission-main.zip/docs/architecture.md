# Architecture Documentation - Modules 1, 2, 3, 4, 5, 6 & 7

This document outlines the architectural blueprint, data flow, and components of the **Digital Student Admission System**.

---

## 1. High-Level Architecture Diagram

The system follows a modular client-server pattern. The backend handles API routes, validation, and database operations, while the frontend handles user interactions and inline checks.

```mermaid
graph TD
  subgraph Frontend [Web Client]
    UI[HTML/CSS Glassmorphic Views]
    ValF[Frontend Validation Layer]
    Router[JS client Router]
    LoginJS[JS Login Handler]
    OtpJS[JS OTP Handler]
    RegJS[JS Registration Handler]
  end

  subgraph Backend [Express API Server]
    Sec[Helmet/CORS Security Headers]
    Cookie[Cookie Parser Middleware]
    ValB[Express Validator Sanitizer]
    AuthM[JWT Auth Middleware]
    RbacM[RBAC Middleware]
    Ctrl[Auth, Captcha, Dashboard, Profile & Admission Controllers]
    OtpP[OTP Provider Service]
    Model[User, Captcha, Otp, Profile & Application Database Models]
  end

  subgraph Database [Storage Layer]
    DBConfig[Unified DB Interface]
    DB[(SQLite3 / MySQL Server)]
  end

  UI -->|Input Blur/Typing| ValF
  Router -->|GET /api/auth/me| Sec
  LoginJS -->|POST /api/auth/login| Sec
  OtpJS -->|POST /api/auth/verify-otp| Sec
  OtpJS -->|POST /api/auth/resend-otp| Sec
  RegJS -->|POST /api/auth/register| Sec
  Router -->|GET /api/dashboard/*| Sec
  Router -->|/api/profile/*| Sec
  Router -->|/api/admission/*| Sec
  Sec --> Cookie
  Cookie --> ValB
  ValB --> AuthM
  AuthM --> RbacM
  RbacM -->|Validated Request / req.user| Ctrl
  Ctrl -->|Lookup/Insert/Verify| Model
  Ctrl -->|Dispatch Code| OtpP
  Model -->|Prepared SQL| DBConfig
  DBConfig --> DB
```

---

## 2. Component Layout

### Frontend Layer
- **index.html**: Semantic structure of the portal, conforming to SEO and Accessibility guidelines. Contains the SPA template structure for Registration, Login, OTP entry, Dashboard, Profile, and Admission wizard panels.
- **css/style.css**: Theme styling featuring a responsive grid, glassmorphic backgrounds, focus state glowing, active notification alerts, and CAPTCHA / OTP / Dashboard / Profile / Admission wizard layout components.
- **js/app.js**: Client-side router handling hash change swaps, loading CAPTCHAs, checking active sessions, and managing Admission Form navigation flags based on user roles.
- **js/register.js**: Client-side registration logic including password toggling, visual strength meters, real-time checks, and CAPTCHA loads.
- **js/login.js**: Client-side login logic checking input formats, submitting credentials, and routing to the OTP view upon Step 1 success.
- **js/otp.js**: Client-side OTP logic handling digit cursor autofocus, resend timer countdown loops, resend link cooldowns, and OTP submission.
- **js/dashboard.js**: Client-side dashboard logic managing layout toggles (Home, Profile, Admission Form), application statistics, and student search filtering.
- **js/profile.js**: Client-side profile logic handling field queries, completion indicators, photo uploads, and concurrent update conflict alerts.
- **js/admission.js**: Client-side admission logic controlling multi-step form panels, progress trackers, pre-populations, draft saves, and final submissions.

### Backend Layer
- **server.js**: App startup sequence, configuration loading, and table initialization.
- **app.js**: Middleware injection point including Helmet security headers, cookie parser, JSON parser configurations, and static resource routers.
- **routes/authRoutes.js**: Endpoint definition mapping for registrations, logouts, logins, OTP verifies, OTP resends, and CAPTCHAs.
- **routes/dashboardRoutes.js**: Endpoint definition mapping for student and professor dashboard requests.
- **routes/profileRoutes.js**: Endpoint definition mapping for profile queries, updates, photo uploads, and authenticated image streaming.
- **routes/admissionRoutes.js**: Endpoint definition mapping for admission form details query, draft saving, and final submissions.
- **middleware/auth.js**: Verification middleware decoding cookies containing signed JSON Web Tokens (JWT), mounting user payloads, and returning 401 Unauthorized for expired or missing tokens.
- **middleware/rbac.js**: Role check authorization middleware validating user permissions.
- **middleware/validation.js**: Server-side validation chain checks, input sanitization, CAPTCHA verification, OTP format checks, profile updates, and admission form update format checks.
- **controllers/authController.js**: Core coordination of signup, login, OTP verify, and OTP resend requests (matching credentials, managing fail limits, lockout timestamps, and issuing tokens).
- **controllers/captchaController.js**: Core math challenge generation and storage.
- **controllers/dashboardController.js**: Handles retrieval of student checklist stats and search-filtered application lists for professors.
- **controllers/profileController.js**: Controls student profile retrieval, optimistic version check updates, multipart photo uploads, and secure image streaming.
- **controllers/admissionController.js**: Controls student application retrieval, draft saving, required fields validations, and final locked submissions.
- **services/otpProvider.js**: Dispatches 6-digit codes to registered users; Mock provider writes to local workspace `scratch/mock_otp.txt` inside development/test environments.
- **models/User.js**: Model layer abstracting the SQL execution for user records, including failed attempt increments and lockout timestamp writes.
- **models/Otp.js**: Model layer abstracting SQL actions for OTP sessions (attempts tracking, resend counts, expiration and delete actions).
- **models/Captcha.js**: Model layer abstracting the SQL execution for active CAPTCHA sessions.
- **models/Profile.js**: Model layer abstracting SQL actions for Student Profiles, supporting versioned optimistic lock updates.
- **models/Application.js**: Model layer abstracting SQL actions for Student Applications, enforcing duplicate constraints and state locking check.
- **config/db.js**: Low-level database pool connector supporting dual SQL engines.

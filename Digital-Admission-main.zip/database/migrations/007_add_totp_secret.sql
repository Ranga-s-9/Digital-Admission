-- Migration: Add TOTP fields to users table
-- Enables Google Authenticator integration

ALTER TABLE users 
ADD COLUMN totp_secret VARCHAR(255) DEFAULT NULL,
ADD COLUMN totp_enabled TINYINT DEFAULT 0;

# Aadhaar Offline e-KYC Subsystem

This document describes the architecture, data flow, verification pipeline, API contracts, and operational runbook of the **Aadhaar Offline e-KYC Subsystem** in the **Digital Student Admission System**.

---

## 1. System Architecture

To avoid tight coupling to external identity providers, the e-KYC module follows an **Adapter Design Pattern**:

```
                 +-----------------------+
                 |     EkycAdapter       |  (Base Interface Class)
                 +-----------------------+
                             ^
                             |
             +---------------+---------------+
             |                               |
    +-----------------+             +-----------------+
    | MockEkycAdapter |             | RealEkycAdapter |
    +-----------------+             +-----------------+
     (Development /                  (Production
      Testing Mock)                   Offline XML)
```

### Module Components
1. **`xmlParser.service`**: Secure XML parser utilizing `fast-xml-parser` with entity-expansion (XXE) and external resource loading disabled.
2. **`xmlValidation.service`**: Validates XML structure, data formats, and enforces schema conformance.
3. **`signature.service`**: Handles cryptographic XML digital signature validation using `xml-crypto` against trusted UIDAI certificates.
4. **`hash.service`**: Verifies SHA-256 mobile and email hashes using timing-safe comparisons to prevent data leaks.
5. **`identityMatching.service`**: Compares extracted demographic fields (Name, DOB, Gender, Pincode) using string normalization and distance-based matching algorithms.
6. **`zipExtraction.service`**: Safely extracts the e-KYC XML file from ZIP uploads with size and path traversal limits.
7. **`consent.service`**: Logs and verifies explicit user consent declarations.
8. **`audit.service`**: Structured, immutable auditing of eKYC events without logging sensitive data.

---

## 2. Demographic Matching Logic

The matching engine normalization operates as follows to avoid false verification failures:

* **Name Match**: Normalizes names (converts to lowercase, collapses multiple spaces, removes honorifics like Mr., Mrs., Ms., Dr., Smt., Shri). Compares using exact matching, substring inclusions, and word-reordering comparisons.
* **Date of Birth (DOB)**: Standardizes DOB to `YYYY-MM-DD` and performs an exact match.
* **Gender Match**: Maps values (`M`, `male`, `F`, `female`, `T`, `transgender`) to normalized outputs (`Male`, `Female`, `Other`) and checks for an exact match.
* **Pincode Match**: Performs an exact string check if present in both the XML POA block and the student's profile.

---

## 3. Detailed Data Flow Diagram

```
[Student App]            [Express Backend]         [Audit & DB]       [Adapter Pipeline]
      │                          │                       │                     │
      │ 1. POST /consent         │                       │                     │
      ├─────────────────────────>│                       │                     │
      │                          │ 2. Insert Consent     │                     │
      │                          ├──────────────────────>│                     │
      │ 3. POST /upload (ZIP)    │                       │                     │
      ├─────────────────────────>│                       │                     │
      │                          │ 4. Check Consent      │                     │
      │                          ├──────────────────────>│                     │
      │                          │ 5. Save ZIP to Disk   │                     │
      │                          │ 6. Log File Uploaded  │                     │
      │                          ├──────────────────────>│                     │
      │                          │                       │                     │
      │ 7. POST /verify          │                       │                     │
      ├─────────────────────────>│                       │                     │
      │                          │ 8. Extract XML        │                     │
      │                          ├────────────────────────────────────────────>│
      │                          │ 9. Verify Signature   │                     │
      │                          ├────────────────────────────────────────────>│
      │                          │ 10. Hash Compare      │                     │
      │                          ├────────────────────────────────────────────>│
      │                          │ 11. Match Identity    │                     │
      │                          ├────────────────────────────────────────────>│
      │                          │ 12. Save Result       │                     │
      │                          ├──────────────────────>│                     │
      │                          │ 13. Log Event         │                     │
      │                          ├──────────────────────>│                     │
      │ 14. Response             │                       │                     │
      │<─────────────────────────┤                       │                     │
```

---

## 4. API Endpoints Contract

### 1. `POST /api/ekyc/consent`
Records explicit student consent.
* **Request Body**:
  ```json
  { "consent": true }
  ```
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Consent successfully recorded.",
    "data": { "consentVersion": "1.0" }
  }
  ```

### 2. `POST /api/ekyc/upload`
Uploads the secure Aadhaar Offline ZIP.
* **Request (Multipart Form-Data)**:
  * Field: `ekycZip` (ZIP file)
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "File uploaded successfully",
    "data": { "verificationId": "550e8400-e29b-41d4-a716-446655440000" }
  }
  ```

### 3. `POST /api/ekyc/verify`
Orchestrates digital signature verification and demographic comparison.
* **Request Body**:
  ```json
  {
    "verificationId": "550e8400-e29b-41d4-a716-446655440000",
    "shareCode": "1234"
  }
  ```
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Identity successfully verified via eKYC.",
    "data": {
      "status": "VERIFIED",
      "verifiedAt": 1787011200000,
      "development_mode": true
    }
  }
  ```

### 4. `GET /api/ekyc/status/:verificationId`
Gets verification status for a reference.
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "data": {
      "verified": true,
      "status": "VERIFIED",
      "errorMessage": "",
      "verifiedAt": 1787011200000,
      "aadhaarMasked": "XXXX-XXXX-9999",
      "xmlFilename": "aadhaar.zip"
    }
  }
  ```

### 5. `GET /api/ekyc/result/:verificationId`
Gets verified result details.
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "data": {
      "status": "VERIFIED",
      "method": "Offline e-KYC",
      "referenceId": "550e8400-e29b-41d4-a716-446655440000",
      "verifiedAt": 1787011200000,
      "aadhaarMasked": "XXXX-XXXX-9999"
    }
  }
  ```

### 6. `GET /api/ekyc/history`
Gets student's verification history.
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "data": [
      {
        "verification_id": "550e8400-e29b-41d4-a716-446655440000",
        "verification_status": "VERIFIED",
        "error_message": null,
        "verified_at": 1787011200000,
        "xml_filename": "aadhaar.zip"
      }
    ]
  }
  ```

---

## 5. Operational Runbook & Troubleshooting

### Common Failure Modes & Resolutions

| Issue | Cause | Action |
|---|---|---|
| **`CONSENT_REQUIRED`** | Request sent without recording consent. | Hit `/api/ekyc/consent` first or check consent checkbox. |
| **`INVALID_ZIP`** | Decompression error or file is not a valid zip archive. | Check that the zip is not corrupted and matches PK headers. |
| **`XML_NOT_FOUND`** | Zip uploaded without containing any XML. | Make sure the ZIP downloaded from UIDAI contains the `.xml` document. |
| **`SIGNATURE_INVALID`** | Cryptographic verification failed or wrong share code. | Re-generate Offline XML from UIDAI portal with a fresh share code. |
| **`IDENTITY_MISMATCH`** | Demographics (Name/DOB/Gender/Pincode) mismatch. | Check that the profile details exactly match the Aadhaar details. |
| **`FILE_TOO_LARGE`** | Uploaded file exceeds 5MB size limit. | Ensure the ZIP file is compressed correctly (normally ~20KB). |

### Configuration Guidance
The following variables must be defined in the `.env` configuration file:
* `EKYC_MODE`: Set to `mock` (development) or `offline_xml` (production).
* `EKYC_CERTIFICATE_PATH`: Absolute path to the trusted UIDAI public certificate PEM file (used in production signature validation).
* `MAX_EKYC_FILE_SIZE`: Decompressed content limit in bytes (default: `5242880` / 5MB).
* `TEMP_UPLOAD_DIRECTORY`: Disk location for temporary ZIP uploads (default: `./uploads/ekyc_temp`).

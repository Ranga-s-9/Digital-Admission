'use strict';

const identityMatching = require('../backend/services/ekyc/identityMatching.service');

describe('Identity Matching Service Unit Tests', () => {

  test('Name normalization collapses spaces, drops honorifics, and lowercases', () => {
    expect(identityMatching.normalizeName('  Mr. Alice   Student  ')).toBe('alice student');
    expect(identityMatching.normalizeName('Smt. Priya')).toBe('priya');
  });

  test('Name matching handles exact, partial, and reordered matches', () => {
    // Exact
    expect(identityMatching.compareName('Alice Student', 'Alice Student').match).toBe(true);
    // Case/spacing normalization
    expect(identityMatching.compareName('  alice   STUDENT ', 'Mr. Alice Student').match).toBe(true);
    // Partial substring match
    expect(identityMatching.compareName('Alice Mary Student', 'Alice Student').match).toBe(true);
    // Reordered multi-part names
    expect(identityMatching.compareName('Student Alice', 'Alice Student').match).toBe(true);
    // Complete mismatch
    expect(identityMatching.compareName('Bob Smith', 'Alice Student').match).toBe(false);
  });

  test('Date normalization handles YYYY-MM-DD, DD-MM-YYYY, and DD/MM/YYYY formats', () => {
    expect(identityMatching.normalizeDate('2005-05-15')).toBe('2005-05-15');
    expect(identityMatching.normalizeDate('15-05-2005')).toBe('2005-05-15');
    expect(identityMatching.normalizeDate('15/05/2005')).toBe('2005-05-15');
    expect(identityMatching.normalizeDate(new Date('2005-05-15T00:00:00.000Z'))).toBe('2005-05-15');
  });

  test('Gender normalization maps valid values to Male, Female, Other', () => {
    expect(identityMatching.normalizeGender('m')).toBe('Male');
    expect(identityMatching.normalizeGender('Male')).toBe('Male');
    expect(identityMatching.normalizeGender('F')).toBe('Female');
    expect(identityMatching.normalizeGender('female')).toBe('Female');
    expect(identityMatching.normalizeGender('t')).toBe('Other');
    expect(identityMatching.normalizeGender('Other')).toBe('Other');
  });

  test('Full matchIdentity checks Name, DOB, Gender, Pincode and returns result status', () => {
    const xmlIdentity = {
      name: 'Alice Student',
      dob: '15-05-2005',
      gender: 'F',
      address: { pincode: '110001' }
    };

    const profileData = {
      name: 'Mr. Alice Student',
      dob: '2005-05-15',
      gender: 'Female',
      pincode: '110001'
    };

    // Full match
    const result = identityMatching.matchIdentity(xmlIdentity, profileData);
    expect(result.result).toBe('MATCH');
    expect(result.mismatches.length).toBe(0);

    // DOB mismatch
    const resultBadDob = identityMatching.matchIdentity(
      { ...xmlIdentity, dob: '16-05-2005' },
      profileData
    );
    expect(resultBadDob.result).toBe('MISMATCH');
    expect(resultBadDob.mismatches).toContain('dob');

    // Partial/Review Required Name
    const resultReview = identityMatching.matchIdentity(
      { ...xmlIdentity, name: 'Alice Mary Student' },
      profileData
    );
    expect(resultReview.result).toBe('REVIEW_REQUIRED');
  });

});

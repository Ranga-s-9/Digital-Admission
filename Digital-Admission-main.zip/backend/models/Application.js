const db = require('../config/db');

/**
 * Model class for Admission Applications database operations
 */
class Application {
  /**
   * Find application details by user ID
   * @param {number} userId 
   */
  static async findByUserId(userId) {
    const rows = await db.query(
      'SELECT * FROM admission_applications WHERE user_id = ?',
      [userId]
    );
    if (rows && rows.length > 0) {
      return rows[0];
    }
    return null;
  }

  /**
   * Find application details by application ID
   * @param {string} applicationId 
   */
  static async findByApplicationId(applicationId) {
    const rows = await db.query(
      'SELECT * FROM admission_applications WHERE application_id = ?',
      [applicationId]
    );
    if (rows && rows.length > 0) {
      return rows[0];
    }
    return null;
  }

  /**
   * Saves or updates an admission application draft
   * @param {number} userId 
   * @param {Object} data 
   * @returns {Promise<Object>} The saved application record
   */
  static async saveDraft(userId, data) {
    const existing = await this.findByUserId(userId);

    if (existing) {
      // Prevent editing if application is already submitted and locked
      const statusUpper = existing.status.toUpperCase();
      if (statusUpper !== 'DRAFT' && statusUpper !== 'CHANGES_REQUESTED' && statusUpper !== 'REVISION') {
        throw new Error('APPLICATION_SUBMITTED');
      }

      const sql = `
        UPDATE admission_applications 
        SET dob = ?, 
            gender = ?, 
            guardian_name = ?, 
            address = ?, 
            state = ?, 
            pincode = ?, 
            degree = ?, 
            board = ?, 
            grad_year = ?, 
            percentage = ?, 
            current_step = ?,
            status = 'Draft',
            correction_message = NULL
        WHERE user_id = ?
      `;

      const params = [
        data.dob || null,
        data.gender || null,
        data.guardianName || null,
        data.address || null,
        data.state || null,
        data.pincode || null,
        data.degree || null,
        data.board || null,
        data.gradYear ? parseInt(data.gradYear, 10) : null,
        data.percentage ? parseFloat(data.percentage) : null,
        data.currentStep ? parseInt(data.currentStep, 10) : 1,
        userId
      ];

      await db.query(sql, params);
    } else {
      const sql = `
        INSERT INTO admission_applications (
          user_id, dob, gender, guardian_name, address, state, pincode, 
          degree, board, grad_year, percentage, current_step, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Draft')
      `;

      const params = [
        userId,
        data.dob || null,
        data.gender || null,
        data.guardianName || null,
        data.address || null,
        data.state || null,
        data.pincode || null,
        data.degree || null,
        data.board || null,
        data.gradYear ? parseInt(data.gradYear, 10) : null,
        data.percentage ? parseFloat(data.percentage) : null,
        data.currentStep ? parseInt(data.currentStep, 10) : 1
      ];

      await db.query(sql, params);
    }

    return this.findByUserId(userId);
  }

  /**
   * Finalizes application submission and updates status to 'Submitted'
   * @param {number} userId 
   * @param {string} applicationId 
   * @param {Object} data 
   * @returns {Promise<Object>} The submitted application record
   */
  static async submit(userId, applicationId, data) {
    const existing = await this.findByUserId(userId);

    if (existing) {
      const statusUpper = existing.status.toUpperCase();
      if (statusUpper !== 'DRAFT' && statusUpper !== 'CHANGES_REQUESTED' && statusUpper !== 'REVISION') {
        throw new Error('APPLICATION_SUBMITTED');
      }

      const sql = `
        UPDATE admission_applications 
        SET application_id = ?,
            dob = ?, 
            gender = ?, 
            guardian_name = ?, 
            address = ?, 
            state = ?, 
            pincode = ?, 
            degree = ?, 
            board = ?, 
            grad_year = ?, 
            percentage = ?, 
            current_step = 4,
            status = 'Submitted',
            correction_message = NULL
        WHERE user_id = ?
      `;

      const params = [
        applicationId,
        data.dob,
        data.gender,
        data.guardianName,
        data.address,
        data.state,
        data.pincode,
        data.degree,
        data.board,
        parseInt(data.gradYear, 10),
        parseFloat(data.percentage),
        userId
      ];

      await db.query(sql, params);
    } else {
      const sql = `
        INSERT INTO admission_applications (
          user_id, application_id, dob, gender, guardian_name, address, state, pincode, 
          degree, board, grad_year, percentage, current_step, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 4, 'Submitted')
      `;

      const params = [
        userId,
        applicationId,
        data.dob,
        data.gender,
        data.guardianName,
        data.address,
        data.state,
        data.pincode,
        data.degree,
        data.board,
        parseInt(data.gradYear, 10),
        parseFloat(data.percentage)
      ];

      await db.query(sql, params);
    }

    return this.findByUserId(userId);
  }
}

module.exports = Application;

const fs = require('fs');
const path = require('path');

// Scratch file location for development mock deliveries
const SCRATCH_DIR = path.join(__dirname, '../../scratch');
const OTP_FILE_PATH = path.join(SCRATCH_DIR, 'mock_otp.txt');

class OTPProvider {
  /**
   * Dispatch an OTP code through mock or real provider.
   * @param {number} userId - User identifier
   * @param {string} mobile - 10-digit mobile number
   * @param {string} code - 6-digit OTP code string
   * @returns {Promise<boolean>}
   */
  static async sendOTP(userId, mobile, code) {
    try {
      // Form masked mobile string (e.g. "******3210")
      const maskedMobile = '******' + mobile.substring(mobile.length - 4);
      
      // Ensure scratch directory exists
      if (!fs.existsSync(SCRATCH_DIR)) {
        fs.mkdirSync(SCRATCH_DIR, { recursive: true });
      }

      // Write code to scratch file
      fs.writeFileSync(OTP_FILE_PATH, code, 'utf8');

      // Console notification (excluding code from standard production logs for security)
      console.log(`[OTP Service] OTP dispatched successfully to masked phone: ${maskedMobile}`);
      
      return true;
    } catch (err) {
      console.error('[OTP Service] Error delivering mock OTP:', err);
      return false;
    }
  }
}

module.exports = OTPProvider;

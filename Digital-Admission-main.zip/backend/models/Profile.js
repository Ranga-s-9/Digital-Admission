const db = require('../config/db');

/**
 * Model class for Student Profiles database operations
 */
class Profile {
  /**
   * Find student profile by user ID
   * @param {number} userId 
   */
  static async findByUserId(userId) {
    const rows = await db.query(
      'SELECT * FROM student_profiles WHERE user_id = ?',
      [userId]
    );
    if (rows && rows.length > 0) {
      return rows[0];
    }
    return null;
  }

  /**
   * Initialize a default empty profile for a user
   * @param {number} userId 
   */
  static async createDefault(userId) {
    const result = await db.query(
      'INSERT INTO student_profiles (user_id, version) VALUES (?, 1)',
      [userId]
    );
    return result;
  }

  /**
   * Update student profile fields with optimistic locking version check
   * @param {number} userId 
   * @param {Object} data 
   * @param {number} expectedVersion 
   * @returns {Promise<boolean>} returns true if update succeeded, false if version mismatch
   */
  static async update(userId, data, expectedVersion) {
    const sql = `
      UPDATE student_profiles 
      SET dob = ?, 
          gender = ?, 
          guardian_name = ?, 
          address = ?, 
          state = ?, 
          pincode = ?, 
          degree = ?, 
          board = ?, 
          grad_year = ?, 
          percentage = ?, 
          photo_path = ?,
          version = version + 1
      WHERE user_id = ? AND version = ?
    `;

    const params = [
      data.dob || null,
      data.gender || null,
      data.guardian_name || null,
      data.address || null,
      data.state || null,
      data.pincode || null,
      data.degree || null,
      data.board || null,
      data.grad_year ? parseInt(data.grad_year, 10) : null,
      data.percentage ? parseFloat(data.percentage) : null,
      data.photo_path || null,
      userId,
      parseInt(expectedVersion, 10)
    ];

    const result = await db.query(sql, params);
    
    // Returns true if 1 row was updated, false if 0 rows (optimistic locking failure)
    return result.affectedRows > 0;
  }
}

module.exports = Profile;

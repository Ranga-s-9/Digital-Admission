/**
 * Fix password hashes for demo users
 * Run with: node database/fix-passwords.js
 */
const db = require('../backend/config/db');
const bcrypt = require('bcryptjs');

async function fix() {
  console.log('Fixing password hashes for demo users...');
  
  const hash = await bcrypt.hash('Password@123', 10);
  console.log('Generated hash:', hash);
  
  // Verify hash is correct before saving
  const isValid = await bcrypt.compare('Password@123', hash);
  if (!isValid) {
    console.error('Hash verification failed! Aborting.');
    process.exit(1);
  }
  console.log('Hash verification: OK');
  
  // Update both demo users
  await db.query('UPDATE users SET password_hash = ? WHERE email = ?', [hash, 'student@dpi.edu']);
  await db.query('UPDATE users SET password_hash = ? WHERE email = ?', [hash, 'prof@dpi.edu']);
  
  // Verify stored correctly
  const users = await db.query('SELECT email, password_hash FROM users WHERE email IN (?, ?)', ['student@dpi.edu', 'prof@dpi.edu']);
  for (const user of users) {
    const match = await bcrypt.compare('Password@123', user.password_hash);
    console.log(`  ${user.email}: password match = ${match}`);
  }
  
  console.log('\nPassword hashes fixed successfully!');
  console.log('Demo credentials: Password@123');
  process.exit(0);
}

fix().catch(err => {
  console.error('Fix failed:', err.message);
  process.exit(1);
});

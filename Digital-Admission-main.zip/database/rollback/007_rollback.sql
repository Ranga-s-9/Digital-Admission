-- =============================================================================
-- Rollback 007: eKYC Module Overhaul Rollback
-- Reverses 007_ekyc_overhaul.sql.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Drop table ekyc_consents
DROP TABLE IF EXISTS ekyc_consents;

-- Remove columns from ekyc_requests
ALTER TABLE ekyc_requests DROP INDEX uq_ekyc_verification_id;
ALTER TABLE ekyc_requests DROP COLUMN verification_id;
ALTER TABLE ekyc_requests DROP COLUMN verification_method;
ALTER TABLE ekyc_requests DROP COLUMN reference_id;

-- Revert check constraint on ekyc_requests
ALTER TABLE ekyc_requests DROP CONSTRAINT IF EXISTS chk_ekyc_status;
ALTER TABLE ekyc_requests ADD CONSTRAINT chk_ekyc_status CHECK (verification_status IN ('Pending', 'Verified', 'Failed'));

SET FOREIGN_KEY_CHECKS = 1;

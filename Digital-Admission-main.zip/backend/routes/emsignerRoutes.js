const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const {
  postInitiateSign,
  getSignatureStatus,
  getSignatureHistory
} = require('../controllers/emsignerController');

// POST /api/emsigner/sign - Student initiates a digital signature request
router.post('/sign', authenticateToken, postInitiateSign);

// GET /api/emsigner/status - Get current signature status for authenticated user
// Professors may pass ?userId= to query a specific student
router.get('/status', authenticateToken, getSignatureStatus);

// GET /api/emsigner/history - Get emSigner audit log history
// Professors may pass ?userId= to query a specific student
router.get('/history', authenticateToken, getSignatureHistory);

module.exports = router;

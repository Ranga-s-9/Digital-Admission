const Notification = require('../models/Notification');
const { logger } = require('../middleware/logger');

/**
 * Fetch all notifications for the authenticated user
 */
async function getUserNotifications(req, res) {
  try {
    const userId = req.user.userId;
    const notifications = await Notification.findByUserId(userId);
    const unreadCount = await Notification.getUnreadCount(userId);

    // Format timestamps to human-readable strings if needed, or send raw for client formatting
    const formattedNotifications = notifications.map(n => ({
      id: n.id,
      userId: n.user_id,
      title: n.title,
      content: n.content,
      type: n.type,
      isRead: !!n.is_read,
      createdAt: n.created_at,
      readAt: n.read_at
    }));

    return res.status(200).json({
      success: true,
      message: 'Notifications retrieved successfully',
      data: {
        notifications: formattedNotifications,
        unreadCount
      }
    });
  } catch (error) {
    logger.error('Fetch user notifications controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error retrieving notifications',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Mark a specific notification as read
 */
async function markNotificationAsRead(req, res) {
  try {
    const userId = req.user.userId;
    const notificationId = parseInt(req.params.id, 10);

    if (isNaN(notificationId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid notification ID parameter',
        error: { id: 'Must be an integer' }
      });
    }

    const updated = await Notification.markAsRead(notificationId, userId);
    if (!updated) {
      // Either notification doesn't exist or doesn't belong to the user
      return res.status(404).json({
        success: false,
        message: 'Notification not found or access unauthorized.',
        error: { global: 'Access denied' }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Notification marked as read successfully',
      data: { id: notificationId, isRead: true }
    });
  } catch (error) {
    logger.error('Mark notification read controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error marking notification as read',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Mark a specific notification as unread
 */
async function markNotificationAsUnread(req, res) {
  try {
    const userId = req.user.userId;
    const notificationId = parseInt(req.params.id, 10);

    if (isNaN(notificationId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid notification ID parameter',
        error: { id: 'Must be an integer' }
      });
    }

    const updated = await Notification.markAsUnread(notificationId, userId);
    if (!updated) {
      return res.status(404).json({
        success: false,
        message: 'Notification not found or access unauthorized.',
        error: { global: 'Access denied' }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Notification marked as unread successfully',
      data: { id: notificationId, isRead: false }
    });
  } catch (error) {
    logger.error('Mark notification unread controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error marking notification as unread',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Mark all notifications as read for the authenticated user
 */
async function markAllNotificationsAsRead(req, res) {
  try {
    const userId = req.user.userId;
    await Notification.markAllAsRead(userId);

    return res.status(200).json({
      success: true,
      message: 'All notifications marked as read successfully'
    });
  } catch (error) {
    logger.error('Mark all notifications read controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error marking all notifications as read',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  getUserNotifications,
  markNotificationAsRead,
  markNotificationAsUnread,
  markAllNotificationsAsRead
};

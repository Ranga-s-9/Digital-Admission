<?php header_remove("X-Frame-Options"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aadhaar Identity Verification Dashboard</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom Style Sheet -->
    <link rel="stylesheet" href="style.css">
    <!-- HTML5 QR Code Scanner Library -->
    <script src="https://unpkg.com/html5-qrcode"></script>
</head>
<body>

    <div class="app-container">
        
        <!-- Header -->
        <header class="app-header">
            <div class="logo">
                <i class="fa-solid fa-shield-halved logo-icon"></i>
                <div class="logo-text">
                    <h1>Aadhaar Identity</h1>
                    <span>Secure Verification System</span>
                </div>
            </div>
            <div class="mode-badge">
                <span class="pulse-icon"></span>
                <span>SYSTEM ONLINE (XAMPP Sandbox)</span>
            </div>
        </header>

        <!-- Main Portal Layout -->
        <div class="portal-grid">
            

            <!-- Center Panel: Verification Tabs -->
            <main class="main-panel">
                
                <!-- Navigation Tabs -->
                <nav class="tab-navigation">
                    <button class="tab-btn active" data-tab="ekyc-tab">
                        <i class="fa-solid fa-file-archive"></i> Aadhaar Offline e-KYC
                    </button>
                    <button class="tab-btn" data-tab="qr-tab">
                        <i class="fa-solid fa-qrcode"></i> Secure QR Scanner
                    </button>
                </nav>

                <!-- Tab 1: e-KYC Verification -->
                <section id="ekyc-tab" class="tab-content active">
                    <div class="panel-header">
                        <i class="fa-solid fa-file-shield"></i>
                        <h2>Paperless Offline e-KYC</h2>
                    </div>
                    <p class="section-description">Upload your downloaded secure ZIP archive or raw XML document and verify details.</p>

                    <form id="ekycVerifyForm" class="verification-form">
                        
                        <!-- Drag and Drop Area -->
                        <div class="drag-drop-area" id="ekycDropZone">
                            <input type="file" id="ekycFile" name="ekyc_file" accept=".zip,.xml" style="display: none;">
                            <i class="fa-solid fa-cloud-arrow-up upload-icon"></i>
                            <h3>Drag & drop your e-KYC file here</h3>
                            <span>or <strong class="browse-link">browse files</strong> from your computer</span>
                            <div id="fileSelectionBadge" class="file-badge" style="display: none;">
                                <i class="fa-solid fa-file-code"></i> <span id="selectedFileName">filename.zip</span>
                            </div>
                        </div>

                        <!-- Verification Parameters -->
                        <div class="form-row">
                            <div class="form-group col-6">
                                <label for="ekycShareCode">Share Code (Required for ZIP)</label>
                                <input type="password" id="ekycShareCode" name="share_code" placeholder="4-digit pin" maxlength="4">
                            </div>
                            <div class="form-group col-6">
                                <label for="verifyMobile">Confirm Mobile (Optional)</label>
                                <input type="text" id="verifyMobile" name="mobile" placeholder="10-digit number" maxlength="10">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="verifyEmail">Confirm Email (Optional)</label>
                                <input type="email" id="verifyEmail" name="email" placeholder="registered email address">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary btn-full" id="btnVerifyEkyc">
                            <i class="fa-solid fa-fingerprint"></i> Verify Identity Profile
                        </button>
                    </form>
                </section>

                <!-- Tab 2: Secure QR Scanner -->
                <section id="qr-tab" class="tab-content">
                    <div class="panel-header">
                        <i class="fa-solid fa-camera"></i>
                        <h2>Aadhaar Secure QR Code Decoder</h2>
                    </div>
                    <p class="section-description">Position the QR code printed on your physical letter or e-Aadhaar in front of your camera to scan and decode demographic parameters.</p>

                    <!-- Camera Scanner Frame -->
                    <div class="scanner-container">
                        <div id="qrScannerFrame" class="scanner-frame"></div>
                        <div class="scanner-controls">
                            <button id="btnStartScanner" class="btn btn-secondary">
                                <i class="fa-solid fa-video"></i> Start Webcam Scanner
                            </button>
                            <button id="btnStopScanner" class="btn btn-danger" style="display: none;">
                                <i class="fa-solid fa-video-slash"></i> Stop Webcam Scanner
                            </button>
                        </div>
                    </div>

                    <!-- Alternate Text input for scanner simulation -->
                    <div class="qr-text-fallback">
                        <label for="qrRawText">Or Paste Scanned QR Code Base64/Text data:</label>
                        <textarea id="qrRawText" placeholder="Paste raw decoded QR code text or zlib base64 payload here..."></textarea>
                        <button id="btnVerifyQrText" class="btn btn-secondary btn-full" style="margin-top: 10px;">
                            <i class="fa-solid fa-code"></i> Decode Scanned Payload
                        </button>
                    </div>
                </section>

                <!-- Status Notifications -->
                <div id="statusToast" class="toast" style="display: none;">
                    <i class="fa-solid id-badge"></i>
                    <div class="toast-body">
                        <h4 id="toastTitle">Success</h4>
                        <p id="toastMessage">Verification successfully executed.</p>
                    </div>
                </div>

                <!-- Verification Result Display -->
                <section id="resultsContainer" class="results-panel" style="display: none;">
                    <div class="panel-header">
                        <i class="fa-solid fa-id-card"></i>
                        <h2>Verification Results</h2>
                        <button id="btnPrintCertificate" class="btn btn-print">
                            <i class="fa-solid fa-print"></i> Print Certificate
                        </button>
                    </div>

                    <div class="results-card">
                        
                        <!-- Header Banner -->
                        <div class="card-status-banner verified" id="verificationResultHeader">
                            <i class="fa-solid fa-circle-check"></i> IDENTITY VERIFIED SECURELY
                        </div>

                        <div class="card-content-grid">
                            
                            <!-- Left: Photo -->
                            <div class="profile-photo-container">
                                <img id="resPhoto" src="https://via.placeholder.com/150x180?text=No+Photo" alt="Aadhaar Photo">
                                <div class="photo-badge">
                                    <i class="fa-solid fa-check"></i> Cryptographic Photo Matches
                                </div>
                            </div>

                            <!-- Right: Demographics -->
                            <div class="demographics-details">
                                <div class="detail-row">
                                    <span class="field-label">Full Name</span>
                                    <strong class="field-value" id="resName">—</strong>
                                </div>
                                <div class="detail-row">
                                    <span class="field-label">Date of Birth</span>
                                    <strong class="field-value" id="resDob">—</strong>
                                </div>
                                <div class="detail-row">
                                    <span class="field-label">Gender</span>
                                    <strong class="field-value" id="resGender">—</strong>
                                </div>
                                <div class="detail-row">
                                    <span class="field-label">Care Of (Guardian)</span>
                                    <strong class="field-value" id="resCo">—</strong>
                                </div>
                                <div class="detail-row">
                                    <span class="field-label">Residential Address</span>
                                    <strong class="field-value" id="resAddress">—</strong>
                                </div>
                                <div class="detail-row">
                                    <span class="field-label">Pincode</span>
                                    <strong class="field-value" id="resPincode">—</strong>
                                </div>
                            </div>
                        </div>

                        <!-- Verification Badges -->
                        <div class="verification-badges-row">
                            <div class="verify-badge success" id="badgeSignature">
                                <i class="fa-solid fa-file-signature"></i> XML Signature: Valid
                            </div>
                            <div class="verify-badge" id="badgeMobile">
                                <i class="fa-solid fa-mobile-screen"></i> Mobile Check: Not Performed
                            </div>
                            <div class="verify-badge" id="badgeEmail">
                                <i class="fa-solid fa-envelope"></i> Email Check: Not Performed
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </div>

    <!-- Script Entrypoint -->
    <script src="app.js"></script>
</body>
</html>

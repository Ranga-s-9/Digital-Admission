document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const btnConnect = document.getElementById('btnConnectDigilocker');
  const btnDisconnect = document.getElementById('btnDisconnectDigilocker');
  const connBadge = document.getElementById('digilockerConnectionBadge');
  const connDesc = document.getElementById('digilockerConnectionDesc');
  const detailsBox = document.getElementById('digilockerDetailsBox');
  const dlIdVal = document.getElementById('digilockerIdVal');
  const dlTimeVal = document.getElementById('digilockerTimeVal');
  const mockBanner = document.getElementById('digilockerMockBanner');

  const consentCard = document.getElementById('digilockerConsentCard');
  const btnGiveConsent = document.getElementById('btnGiveDigilockerConsent');
  const btnCancelConsent = document.getElementById('btnCancelDigilockerConsent');

  const catalogCard = document.getElementById('digilockerCatalogCard');
  const availableList = document.getElementById('digilockerAvailableList');
  const linkedTableBody = document.getElementById('digilockerLinkedTableBody');

  // Notification Toast Helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    if (!notify) return;

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Open pop-up window for secure authorization connection
  if (btnConnect) {
    btnConnect.addEventListener('click', () => {
      const width = 500;
      const height = 620;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;

      const state = Math.random().toString(36).substring(7);
      const url = `/api/digilocker/oauth/authorize?state=${state}`;

      window.open(
        url,
        'DigiLockerAuthenticationPopup',
        `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`
      );
    });
  }

  // Listen for message events from popup window
  window.addEventListener('message', async (event) => {
    if (event.data && event.data.type === 'DIGILOCKER_AUTH_SUCCESS') {
      showNotification('Locker Connected', 'Successfully authenticated and linked with DigiLocker.', 'success');
      await loadDigilockerView();
      if (window.loadStudentDashboard) {
        window.loadStudentDashboard();
      }
    }
  });

  // Give Consent Handler
  if (btnGiveConsent) {
    btnGiveConsent.addEventListener('click', async () => {
      try {
        const response = await fetch('/api/digilocker/consent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ consent: true })
        });
        const result = await response.json();
        if (response.ok && result.success) {
          showNotification('Consent Recorded', 'Consent successfully recorded. Fetching available documents.', 'success');
          await loadDigilockerView();
        } else {
          showNotification('Consent Error', result.message || 'Failed to record consent.', 'error');
        }
      } catch (err) {
        console.error('Consent click error:', err);
        showNotification('Network Failure', 'Failed to connect to server.', 'error');
      }
    });
  }

  // Cancel Consent Handler (Go back to Home tab)
  if (btnCancelConsent) {
    btnCancelConsent.addEventListener('click', () => {
      const navHome = document.getElementById('navHome');
      if (navHome) navHome.click();
    });
  }

  // Disconnect Handler
  if (btnDisconnect) {
    btnDisconnect.addEventListener('click', async () => {
      const confirmDis = confirm('Are you sure you want to disconnect your DigiLocker account? This will wipe all linked documents and consents.');
      if (!confirmDis) return;

      try {
        const response = await fetch('/api/digilocker/disconnect', { method: 'POST' });
        const result = await response.json();
        if (response.ok && result.success) {
          showNotification('Locker Disconnected', 'Successfully disconnected and cleaned up credentials.', 'success');
          await loadDigilockerView();
          if (window.loadStudentDashboard) {
            window.loadStudentDashboard();
          }
        } else {
          showNotification('Error', result.message || 'Failed to disconnect account.', 'error');
        }
      } catch (err) {
        console.error('Disconnect click error:', err);
        showNotification('Network Failure', 'Failed to disconnect DigiLocker.', 'error');
      }
    });
  }

  // Main View / Dashboard Loader
  async function loadDigilockerView() {
    try {
      const resStatus = await fetch('/api/digilocker/status');
      const result = await resStatus.json();

      if (!resStatus.ok || !result.success) {
        showNotification('Retrieval Error', 'Failed to retrieve connection state details.', 'error');
        return;
      }

      const connection = result.data;

      // Update Mock Banner
      if (connection.development_mode) {
        mockBanner.style.display = 'flex';
      } else {
        mockBanner.style.display = 'none';
      }

      // Check linked document types and statuses
      const linkedDocs = connection.documents || [];
      const linkedMap = {};
      linkedDocs.forEach(doc => {
        linkedMap[doc.doc_uri] = {
          verification_status: doc.verification_status,
          document_status: doc.document_status
        };
      });

      // Render Linked Table Body
      if (linkedDocs.length > 0) {
        linkedTableBody.innerHTML = '';
        linkedDocs.forEach(doc => {
          const tr = document.createElement('tr');
          
          let verificationClass = 'badge-pending';
          if (doc.verification_status === 'Verified' || doc.verification_status === 'VERIFIED') {
            verificationClass = 'badge-success';
          } else if (doc.verification_status === 'Failed' || doc.verification_status === 'FAILED') {
            verificationClass = 'badge-danger';
          }

          let useBadge = '';
          if (doc.document_status === 'SELECTED') {
            useBadge = `<span class="badge badge-success" style="margin-left: 8px;">Selected</span>`;
          }

          tr.innerHTML = `
            <td style="padding: 10px; font-weight: 500;">
              ${doc.document_type} ${useBadge}
            </td>
            <td style="padding: 10px; color: var(--text-muted);">${doc.issuing_authority}</td>
            <td style="padding: 10px; font-family: monospace;">${doc.document_ref}</td>
            <td style="padding: 10px;"><span class="badge ${verificationClass}">${doc.verification_status}</span></td>
          `;
          linkedTableBody.appendChild(tr);
        });
      } else {
        linkedTableBody.innerHTML = `
          <tr>
            <td colspan="4" style="text-align: center; padding: 20px; color: var(--text-muted);">No documents linked yet. Connect your account to retrieve documents.</td>
          </tr>
        `;
      }

      // Update Connection & Consent State Layouts
      if (connection.connected) {
        // Connected State
        connBadge.className = 'badge badge-success';
        connBadge.textContent = 'Connected';
        connDesc.textContent = 'Your DigiLocker account is connected. You can retrieve issued educational documents below.';

        detailsBox.style.display = 'block';
        dlIdVal.textContent = connection.digilockerId;
        dlTimeVal.textContent = new Date(connection.createdAt).toLocaleString();
        
        btnConnect.textContent = 'Re-Connect Account';
        btnDisconnect.style.display = 'block';

        if (connection.consentActive) {
          // Connected & Consented State
          consentCard.style.display = 'none';
          catalogCard.style.display = 'block';
          await loadAvailableCatalog(linkedMap);
        } else {
          // Connected but Unconsented State
          consentCard.style.display = 'block';
          catalogCard.style.display = 'none';
        }

      } else {
        // Not Connected State
        connBadge.className = 'badge badge-danger';
        connBadge.textContent = 'Not Connected';
        connDesc.textContent = 'Link your secure digital locker account to retrieve certified education transcripts directly from issuing authorities.';
        
        detailsBox.style.display = 'none';
        btnConnect.textContent = 'Connect DigiLocker';
        btnDisconnect.style.display = 'none';
        consentCard.style.display = 'none';
        catalogCard.style.display = 'none';
      }

    } catch (err) {
      console.error('Load digilocker view error:', err);
      showNotification('Connection Error', 'Could not communicate with the server.', 'error');
    }
  }

  // Load available items catalog list
  async function loadAvailableCatalog(linkedMap) {
    try {
      const resDocs = await fetch('/api/digilocker/documents');
      const result = await resDocs.json();

      if (!resDocs.ok || !result.success) {
        availableList.innerHTML = `<p style="color: var(--danger); font-size: 13px;">Error fetching list: ${result.message || 'Server error'}</p>`;
        return;
      }

      const docs = result.data || [];
      availableList.innerHTML = '';

      docs.forEach(doc => {
        const item = document.createElement('div');
        item.style.cssText = 'display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px solid var(--border); border-radius: 8px; background: var(--bg-card);';
        
        const linkInfo = linkedMap[doc.uri];
        const isLinked = !!linkInfo;
        const isSelected = isLinked && linkInfo.document_status === 'SELECTED';
        const isVerified = isLinked && (linkInfo.verification_status === 'Verified' || linkInfo.verification_status === 'VERIFIED');

        let actionButtonMarkup = '';
        if (!isLinked) {
          actionButtonMarkup = `
            <button type="button" class="btn-table-action btn-link-doc" data-uri="${doc.uri}">
              Link Document
            </button>
          `;
        } else if (isVerified) {
          if (isSelected) {
            actionButtonMarkup = `
              <span class="badge badge-success" style="padding: 6px 12px;">✓ Used for Admission</span>
            `;
          } else {
            actionButtonMarkup = `
              <button type="button" class="btn-table-action btn-select-doc" data-uri="${doc.uri}" style="background: var(--success); border-color: var(--success); color: white;">
                Use for Admission
              </button>
            `;
          }
        } else {
          // Linked but verification failed
          actionButtonMarkup = `
            <span class="badge badge-danger" style="padding: 6px 12px;">Verification Failed</span>
          `;
        }

        item.innerHTML = `
          <div>
            <div style="font-weight: 600; font-size: 14px;">${doc.name}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">${doc.issuer}</div>
          </div>
          <div>
            ${actionButtonMarkup}
          </div>
        `;

        // Add action listener for linking
        if (!isLinked) {
          item.querySelector('.btn-link-doc').addEventListener('click', async (e) => {
            const btn = e.target;
            btn.disabled = true;
            const originalText = btn.textContent;
            btn.innerHTML = 'Linking...';

            try {
              const resLink = await fetch('/api/digilocker/documents/retrieve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ docUri: btn.getAttribute('data-uri') })
              });

              const linkResult = await resLink.json();

              if (resLink.ok && linkResult.success) {
                showNotification('Document Linked', `Successfully retrieved and verified '${linkResult.data.documentType}'.`, 'success');
                await loadDigilockerView();
                if (window.loadStudentDashboard) {
                  window.loadStudentDashboard();
                }
              } else {
                showNotification('Linking Mismatch', linkResult.message || 'Details mismatch error.', 'error');
                await loadDigilockerView(); // Reload to show Failed status
              }
            } catch (err) {
              btn.disabled = false;
              btn.textContent = originalText;
              console.error('Link doc error:', err);
              showNotification('Network Failure', 'Failed to link document.', 'error');
            }
          });
        }

        // Add action listener for selecting (Use for Admission)
        if (isLinked && isVerified && !isSelected) {
          item.querySelector('.btn-select-doc').addEventListener('click', async (e) => {
            const btn = e.target;
            btn.disabled = true;
            btn.innerHTML = 'Selecting...';

            try {
              const resSelect = await fetch('/api/digilocker/documents/select', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ docUri: btn.getAttribute('data-uri') })
              });

              const selectResult = await resSelect.json();

              if (resSelect.ok && selectResult.success) {
                showNotification('Associated Successfully', `Document associated with admission application.`, 'success');
                await loadDigilockerView();
                if (window.loadStudentDashboard) {
                  window.loadStudentDashboard();
                }
              } else {
                showNotification('Selection Failure', selectResult.message || 'Failed to select document.', 'error');
                btn.disabled = false;
                btn.innerHTML = 'Use for Admission';
              }
            } catch (err) {
              btn.disabled = false;
              btn.innerHTML = 'Use for Admission';
              console.error('Select doc error:', err);
              showNotification('Network Failure', 'Failed to select document.', 'error');
            }
          });
        }

        availableList.appendChild(item);
      });

    } catch (err) {
      console.error('Fetch available documents error:', err);
      availableList.innerHTML = `<p style="color: var(--danger); font-size: 13px;">Failed to fetch documents.</p>`;
    }
  }

  // Expose global initializer
  window.loadDigilockerView = loadDigilockerView;
});

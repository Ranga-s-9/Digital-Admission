const crypto = require('crypto');
const Captcha = require('../models/Captcha');
const { logger } = require('../middleware/logger');

/**
 * Generate a randomized mathematical CAPTCHA and store its answer state
 */
async function generateCaptcha(req, res) {
  try {
    // 1. Clean up expired captchas periodically to prevent table growth
    // (We can run this asynchronously in the background)
    Captcha.clearExpired().catch(err => logger.error('Error clearing expired CAPTCHAs:', { message: err.message, stack: err.stack, requestId: req.id || null }));

    // 2. Select a random operation: 0 = Add, 1 = Subtract, 2 = Multiply
    const operators = ['+', '-', '×'];
    const opIndex = Math.floor(Math.random() * 3);
    const op = operators[opIndex];

    let num1, num2, answer;

    if (op === '+') {
      num1 = Math.floor(Math.random() * 20) + 1; // 1 to 20
      num2 = Math.floor(Math.random() * 20) + 1; // 1 to 20
      answer = num1 + num2;
    } else if (op === '-') {
      num1 = Math.floor(Math.random() * 20) + 10; // 10 to 29
      num2 = Math.floor(Math.random() * num1) + 1; // 1 to num1 (avoids negative results)
      answer = num1 - num2;
    } else {
      // Multiplication
      num1 = Math.floor(Math.random() * 10) + 2; // 2 to 11
      num2 = Math.floor(Math.random() * 8) + 2; // 2 to 9
      answer = num1 * num2;
    }

    // 3. Create UUID token
    const captchaId = crypto.randomUUID();

    // 4. Expiration in 2 minutes (Unix timestamp in milliseconds)
    const expiresAt = Date.now() + 2 * 60 * 1000;

    // 5. Store answer in the database
    await Captcha.create({
      id: captchaId,
      answer: String(answer),
      expiresAt
    });

    // 6. Return response to frontend
    return res.status(200).json({
      success: true,
      message: 'CAPTCHA challenge generated successfully',
      data: {
        captchaId,
        question: `${num1} ${op} ${num2} = ?`
      }
    });

  } catch (error) {
    logger.error('CAPTCHA generation controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Failed to generate CAPTCHA challenge',
      error: {
        global: 'Internal server error'
      }
    });
  }
}

module.exports = {
  generateCaptcha
};

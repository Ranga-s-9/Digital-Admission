const sqlite3 = require('sqlite3').verbose();
const mysql = require('mysql2/promise');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const dbType = process.env.DB_TYPE || 'sqlite';
let dbInstance = null;
let mysqlPool = null;

// Initialize Database connection based on configuration
if (dbType === 'mysql') {
  console.log('Database configuration: MySQL');
  mysqlPool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'dpi_student_admission',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    // Return DATE/DATETIME/TIMESTAMP columns as raw strings (e.g. '2005-12-01')
    // rather than JS Date objects. Without this, mysql2 hands back a Date that
    // gets serialized to a full UTC ISO timestamp ('2005-12-01T00:00:00.000Z')
    // in JSON responses, and can silently shift by a day depending on server
    // timezone — inconsistent with SQLite's plain-string behavior for the same
    // column and surprising for any client parsing the response.
    dateStrings: true
  });
} else {
  console.log('Database configuration: SQLite');
  const dbPath = path.resolve(process.cwd(), process.env.DB_SQLITE_PATH || './database.sqlite');
  
  // Ensure the directory for SQLite file exists
  const dbDir = path.dirname(dbPath);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  dbInstance = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error('Failed to connect to SQLite database:', err.message);
    } else {
      console.log(`Connected to SQLite database at: ${dbPath}`);
      dbInstance.run('PRAGMA foreign_keys = ON;', (pragmaErr) => {
        if (pragmaErr) {
          console.error('Failed to enable foreign keys in SQLite:', pragmaErr.message);
        } else {
          console.log('SQLite foreign key support enabled.');
        }
      });
    }
  });
}

/**
 * Unified query execution helper compatible with both MySQL and SQLite
 * @param {string} sql - SQL query string with '?' placeholders
 * @param {Array} params - array of parameter values
 * @returns {Promise<any>}
 */
async function query(sql, params = []) {
  if (dbType === 'mysql') {
    const [results] = await mysqlPool.execute(sql, params);
    return results;
  } else {
    return new Promise((resolve, reject) => {
      // Clean up query type to decide which sqlite method to use
      const queryType = sql.trim().split(/\s+/)[0].toUpperCase();
      
      if (queryType === 'SELECT') {
        dbInstance.all(sql, params, (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        });
      } else {
        dbInstance.run(sql, params, function (err) {
          if (err) return reject(err);
          // Return format matching mysql response metadata
          resolve({
            insertId: this.lastID,
            affectedRows: this.changes
          });
        });
      }
    });
  }
}

/**
 * Close database connection safely (useful for testing cleanup)
 */
async function close() {
  if (dbType === 'mysql') {
    if (mysqlPool) {
      await mysqlPool.end();
    }
  } else {
    if (dbInstance) {
      return new Promise((resolve, reject) => {
        dbInstance.close((err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    }
  }
}

module.exports = {
  query,
  close,
  dbType
};

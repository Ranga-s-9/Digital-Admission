# DigiLocker Integration Subsystem

This document describes the design, authorization flow, security validation, and documentation of the **DigiLocker** integration module in the **Digital Student Admission System**.

---

## 1. Overview
DigiLocker is a core national digital public infrastructure that provides citizens access to authentic digital documents from their original issuers. In this portal, DigiLocker is used to retrieve and verify qualifying academic transcripts (e.g., Class X and Class XII Marksheets).

---

## 2. Authorization Flow & Popup Integration
To ensure a modern, seamless user experience, the DigiLocker connection process is handled via a secure popup interface:

```
+------------------+                   +--------------------+
|  Student Portal  |                   | DigiLocker Gateway |
+------------------+                   +--------------------+
         |                                       |
         |----- 1. Open Auth Popup ------------->|
         |                                       | (User Consents & Logs In)
         |                                       |
         |<---- 2. postMessage (Auth Status) ----|
         |
  (Popup Closes)
```

### Communication Protocol
* The student triggers the connection which opens a separate popup frame pointing to `/api/digilocker/oauth/auth` (or mock equivalent).
* After authentication and authorization, the popup transmits the result back to the parent browser window using the HTML5 **PostMessage API**:
  ```javascript
  window.opener.postMessage(
    { success: true, message: 'Authorization complete', data: { ... } },
    window.location.origin
  );
  window.close();
  ```
* This protocol prevents cross-origin scripting errors while keeping the user context on the main portal page active.

---

## 3. Name Verification Security Check
To prevent identity spoofing (e.g., a student linking someone else's DigiLocker profile to their application), the backend performs a strict name-matching check upon receiving the token callback:
* The name associated with the DigiLocker account is compared against the name registered in the student's profile.
* If the names diverge significantly (failing case-insensitive substring comparisons or string distance thresholds), the connection is rejected with a `400 Bad Request` mismatch error, and the documents are not linked.

---

## 4. Linked Documents Database Schema
Connected data is written to two tables:
1. `digilocker_connections`: Tracks access tokens and token expiration epochs (`token_expires_at`) per user.
2. `digilocker_documents`: Tracks each linked document type (e.g., `10th_Marksheet`), its unique identifier reference (`doc_uri`), issuing authority, retrieved timestamp, and verification status (`Verified`).

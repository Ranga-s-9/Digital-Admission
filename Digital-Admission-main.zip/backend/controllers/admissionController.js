const Application = require('../models/Application');
const crypto = require('crypto');
const { logger } = require('../middleware/logger');

/**
 * Helper to generate a unique structured Application ID: ADM-YYYYMMDD-XXXX
 */
function generateApplicationId() {
  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const rand = crypto.randomBytes(2).toString('hex').toUpperCase(); // 4 random hex characters
  return `ADM-${yyyy}${mm}${dd}-${rand}`;
}

/**
 * Fetch the current user's admission application details
 */
async function getMyApplication(req, res) {
  try {
    const userId = req.user.userId;

    const application = await Application.findByUserId(userId);

    return res.status(200).json({
      success: true,
      message: 'Admission application retrieved successfully',
      data: application ? {
        id: application.id,
        applicationId: application.application_id || '',
        userId: application.user_id,
        dob: application.dob || '',
        gender: application.gender || '',
        guardianName: application.guardian_name || '',
        address: application.address || '',
        state: application.state || '',
        pincode: application.pincode || '',
        degree: application.degree || '',
        board: application.board || '',
        gradYear: application.grad_year || '',
        percentage: application.percentage || '',
        currentStep: application.current_step || 1,
        status: application.status
      } : null
    });

  } catch (error) {
    logger.error('Get application controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Saves current form wizard details as a draft
 */
async function saveDraft(req, res) {
  try {
    const userId = req.user.userId;
    const data = req.body;

    const AuditLog = require('../models/AuditLog');
    try {
      const existing = await Application.findByUserId(userId);
      const isNew = !existing;

      const application = await Application.saveDraft(userId, data);

      // Log success (creation or update)
      await AuditLog.log({
        userId,
        action: isNew ? 'application_creation' : 'application_update',
        entityType: 'application',
        entityId: String(application.id),
        status: 'success',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { isNew, applicationId: application.application_id }
      });

      return res.status(200).json({
        success: true,
        message: 'Admission application draft saved successfully',
        data: {
          id: application.id,
          applicationId: application.application_id || '',
          currentStep: application.current_step,
          status: application.status
        }
      });
    } catch (err) {
      if (err.message === 'APPLICATION_SUBMITTED') {
        await AuditLog.log({
          userId,
          action: 'application_update',
          entityType: 'application',
          status: 'failure',
          ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
          metadata: { reason: 'Application already submitted' }
        });
        return res.status(400).json({
          success: false,
          message: 'Draft modification is rejected: The application has already been submitted.',
          error: { global: 'Application already submitted' }
        });
      }
      throw err;
    }

  } catch (error) {
    logger.error('Save draft controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Validates, locks, and finalize application submission
 */
async function submitApplication(req, res) {
  try {
    const userId = req.user.userId;
    const data = req.body;

    // Strict validation for required fields on submission
    const requiredFields = [
      'dob', 'gender', 'guardianName', 'address', 'state', 'pincode',
      'degree', 'board', 'gradYear', 'percentage'
    ];

    const missingFields = [];
    requiredFields.forEach(field => {
      const val = data[field];
      if (val === undefined || val === null || String(val).trim() === '') {
        missingFields.push(field);
      }
    });

    const AuditLog = require('../models/AuditLog');
    if (missingFields.length > 0) {
      const fieldErrors = {};
      missingFields.forEach(field => {
        fieldErrors[field] = `${field} is required for final submission`;
      });
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { missingFields, reason: 'Validation failed: missing fields' }
      });
      return res.status(400).json({
        success: false,
        message: 'Final submission validation failed: complete all required fields.',
        error: fieldErrors
      });
    }

    // Additional validations
    if (!/^\d{6}$/.test(data.pincode)) {
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'Validation failed: invalid pincode' }
      });
      return res.status(400).json({
        success: false,
        message: 'Pincode validation error',
        error: { pincode: 'Pincode must be exactly 6 digits' }
      });
    }

    const yr = parseInt(data.gradYear, 10);
    if (isNaN(yr) || yr < 1900 || yr > 2035) {
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'Validation failed: invalid gradYear' }
      });
      return res.status(400).json({
        success: false,
        message: 'Graduation year validation error',
        error: { gradYear: 'Graduation year must be between 1900 and 2035' }
      });
    }

    const pct = parseFloat(data.percentage);
    if (isNaN(pct) || pct < 0 || pct > 100) {
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'Validation failed: invalid percentage' }
      });
      return res.status(400).json({
        success: false,
        message: 'Percentage validation error',
        error: { percentage: 'Percentage must be between 0.00 and 100.00' }
      });
    }

    // Check if application has already been submitted
    const existing = await Application.findByUserId(userId);
    if (existing && (existing.status === 'Submitted' || existing.status === 'Approved')) {
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        entityId: String(existing.id),
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'Application already submitted' }
      });
      return res.status(400).json({
        success: false,
        message: 'Duplicate submission is rejected: The application has already been submitted.',
        error: { global: 'Application already submitted' }
      });
    }

    // Generate unique formatted application ID
    const appId = generateApplicationId();

    try {
      const application = await Application.submit(userId, appId, data);

      // Write success audit log
      await AuditLog.log({
        userId,
        action: 'application_submission',
        entityType: 'application',
        entityId: String(application.id),
        status: 'success',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { applicationId: appId }
      });

      // Trigger notification for application submission
      try {
        const NotificationService = require('../services/notificationService');
        await NotificationService.send({
          userId,
          type: 'application_submission',
          title: 'Application Submitted',
          content: `Your admission application has been successfully submitted (ID: ${appId}).`
        });
      } catch (notifErr) {
        logger.error('Failed to trigger submission notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
      }

      return res.status(200).json({
        success: true,
        message: 'Admission application submitted successfully',
        data: {
          id: application.id,
          applicationId: application.application_id,
          status: application.status
        }
      });
    } catch (err) {
      if (err.message === 'APPLICATION_SUBMITTED') {
        await AuditLog.log({
          userId,
          action: 'application_submission',
          entityType: 'application',
          status: 'failure',
          ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
          metadata: { reason: 'Application already submitted during write' }
        });
        return res.status(400).json({
          success: false,
          message: 'Duplicate submission is rejected: The application has already been submitted.',
          error: { global: 'Application already submitted' }
        });
      }
      throw err;
    }

  } catch (error) {
    logger.error('Submit application controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  getMyApplication,
  saveDraft,
  submitApplication
};

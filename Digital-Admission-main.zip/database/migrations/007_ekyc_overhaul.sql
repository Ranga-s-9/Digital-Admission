-- =============================================================================
-- Migration 007: eKYC Module Overhaul
-- Adds ekyc_consents table and enhances ekyc_requests schema
-- Compatible with MySQL 5.7+ / MariaDB 10.4+
-- =============================================================================

-- Table: ekyc_consents
CREATE TABLE IF NOT EXISTS ekyc_consents (
  id              INT           NOT NULL AUTO_INCREMENT,
  student_id      INT           NOT NULL,
  consent_type    VARCHAR(50)   NOT NULL DEFAULT 'ekyc_identity_verification',
  consent_version VARCHAR(20)   NOT NULL DEFAULT '1.0',
  consented       TINYINT(1)    NOT NULL DEFAULT 0,
  ip_address      VARCHAR(50)   DEFAULT NULL,
  consented_at    TIMESTAMP     NULL DEFAULT NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_ekyc_consent_student   (student_id),
  KEY idx_ekyc_consent_type      (consent_type),
  KEY idx_ekyc_consent_created   (created_at),
  CONSTRAINT fk_ekyc_consent_user FOREIGN KEY (student_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='eKYC consent records — tracks explicit user consent before verification';

-- Enhance ekyc_requests with new columns
-- verification_id: UUID for external reference (never expose DB id)
ALTER TABLE ekyc_requests
  ADD COLUMN IF NOT EXISTS verification_id VARCHAR(100) DEFAULT NULL AFTER user_id;

ALTER TABLE ekyc_requests
  ADD COLUMN IF NOT EXISTS verification_method VARCHAR(50) DEFAULT 'offline_xml' AFTER verification_status;

ALTER TABLE ekyc_requests
  ADD COLUMN IF NOT EXISTS reference_id VARCHAR(100) DEFAULT NULL AFTER verification_method;

-- Add unique index on verification_id
-- (Use a conditional approach to avoid errors if index already exists)
SET @idx_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ekyc_requests' AND INDEX_NAME = 'uq_ekyc_verification_id');
SET @sql = IF(@idx_exists = 0,
  'ALTER TABLE ekyc_requests ADD UNIQUE KEY uq_ekyc_verification_id (verification_id)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Update the status CHECK constraint to accept new status values
-- MySQL doesn't support ALTER CHECK easily, so we drop and re-add
ALTER TABLE ekyc_requests DROP CONSTRAINT IF EXISTS chk_ekyc_status;
ALTER TABLE ekyc_requests ADD CONSTRAINT chk_ekyc_status
  CHECK (verification_status IN ('PENDING', 'CONSENTED', 'FILE_UPLOADED', 'PROCESSING', 'VERIFIED', 'FAILED', 'REVIEW_REQUIRED', 'Pending', 'Verified', 'Failed'));

-- Record this migration handled by runner

-- =============================================================================
-- Migration 004: Harden Constraints
-- Adds additional performance indexes, tightens data types, and ensures
-- data integrity guards are in place across all tables.
--
-- Note: CHECK constraints were added inline in 001 for new tables.
-- This migration handles any remaining hardening that requires ALTER TABLE.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Harden: users table
-- Ensure status is constrained to known values.
-- -----------------------------------------------------------------------------
ALTER TABLE users
  MODIFY COLUMN status VARCHAR(50) NOT NULL DEFAULT 'active',
  ADD CONSTRAINT chk_users_status
    CHECK (status IN ('active', 'locked', 'suspended', 'inactive'));

-- -----------------------------------------------------------------------------
-- Harden: student_profiles
-- Tighten dob to DATE type (was VARCHAR(50) — now properly typed).
-- Tighten pincode to CHAR(6) — Indian pincodes are always 6 digits.
-- -----------------------------------------------------------------------------
ALTER TABLE student_profiles
  MODIFY COLUMN dob      DATE         DEFAULT NULL,
  MODIFY COLUMN pincode  CHAR(6)      DEFAULT NULL,
  MODIFY COLUMN grad_year SMALLINT    DEFAULT NULL;

-- -----------------------------------------------------------------------------
-- Harden: admission_applications
-- Same data type improvements for consistency.
-- -----------------------------------------------------------------------------
ALTER TABLE admission_applications
  MODIFY COLUMN dob      DATE         DEFAULT NULL,
  MODIFY COLUMN pincode  CHAR(6)      DEFAULT NULL,
  MODIFY COLUMN grad_year SMALLINT    DEFAULT NULL;

-- -----------------------------------------------------------------------------
-- Additional performance indexes
-- -----------------------------------------------------------------------------

-- OTP cleanup: find/expire OTPs by user or expiry time
ALTER TABLE otps
  ADD KEY IF NOT EXISTS idx_otps_user_expires (user_id, expires_at);

-- eKYC lookup by verification status
ALTER TABLE ekyc_requests
  ADD KEY IF NOT EXISTS idx_ekyc_verified_at (verified_at);

-- Workflow history: ordered by most-recent first
ALTER TABLE workflow_audit_logs
  ADD KEY IF NOT EXISTS idx_workflow_user_created (user_id, created_at DESC);

-- eSignzy audit lookups
ALTER TABLE esignzy_audit_logs
  ADD KEY IF NOT EXISTS idx_esignzy_user_created (user_id, created_at DESC);

-- eKYC audit lookups
ALTER TABLE ekyc_audit_logs
  ADD KEY IF NOT EXISTS idx_ekyc_user_created (user_id, created_at DESC);

-- Notifications: most-recent unread per user
ALTER TABLE notifications
  ADD KEY IF NOT EXISTS idx_notifications_user_unread (user_id, is_read, created_at DESC);

const MockEkycAdapter = require('./mockEkycAdapter');
const RealEkycAdapter = require('./realEkycAdapter');

const mockInstance = new MockEkycAdapter();
const realInstance = new RealEkycAdapter();

/**
 * Factory getter for retrieving the current active eKYC Adapter
 *
 * Supports:
 *   EKYC_MODE=mock          → MockEkycAdapter (development/testing)
 *   EKYC_MODE=offline_xml   → RealEkycAdapter (production Offline XML pipeline)
 *   EKYC_MODE=real          → RealEkycAdapter (legacy alias)
 *
 * @returns {EkycAdapter} The loaded adapter instance
 */
function getEkycAdapter() {
  const mode = (process.env.EKYC_MODE || 'mock').toLowerCase();
  if (mode === 'offline_xml' || mode === 'real') {
    return realInstance;
  }
  return mockInstance;
}

/**
 * Check if the system is running in mock/development mode
 * @returns {boolean}
 */
function isMockMode() {
  const mode = (process.env.EKYC_MODE || 'mock').toLowerCase();
  return mode === 'mock';
}

module.exports = {
  getEkycAdapter,
  isMockMode
};

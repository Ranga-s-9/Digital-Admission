const fs = require('fs');
const path = require('path');
const Profile = require('../models/Profile');
const User = require('../models/User');
const { logger } = require('../middleware/logger');

const UPLOADS_DIR = path.resolve(process.cwd(), './uploads');

// Ensure uploads folder exists on startup
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

/**
 * Calculates student profile completion percentage based on 10 core fields.
 * Each completed field contributes 10% to the total progress.
 */
function calculateCompletion(profile) {
  if (!profile) return 0;
  
  const coreFields = [
    'dob',
    'gender',
    'guardian_name',
    'address',
    'state',
    'pincode',
    'degree',
    'board',
    'grad_year',
    'percentage'
  ];

  let completedCount = 0;
  coreFields.forEach(field => {
    const val = profile[field];
    if (val !== undefined && val !== null && String(val).trim() !== '') {
      completedCount++;
    }
  });

  return completedCount * 10; // 10 fields = 100% max
}

/**
 * Fetch student profile details
 */
async function getProfile(req, res) {
  try {
    const userId = parseInt(req.params.userId, 10);

    // IDOR / Access Control Enforcement:
    // Students can ONLY view their own profile. Professors/Admins can view any.
    if (req.user.role === 'student' && req.user.userId !== userId) {
      return res.status(403).json({
        success: false,
        message: "Access denied: You cannot view another student's profile information",
        error: { auth: 'Forbidden' }
      });
    }

    let profile = await Profile.findByUserId(userId);
    
    // Auto-create default empty profile if not existing
    if (!profile) {
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Student account record not found',
          error: { global: 'User not found' }
        });
      }
      
      await Profile.createDefault(userId);
      profile = await Profile.findByUserId(userId);
    }

    // Retrieve corresponding email and mobile from user accounts table
    const accountUser = await User.findById(userId);
    
    const completionPercentage = calculateCompletion(profile);

    return res.status(200).json({
      success: true,
      message: 'Student profile retrieved successfully',
      data: {
        profile: {
          userId: profile.user_id,
          name: accountUser.name,
          email: accountUser.email,
          mobile: accountUser.mobile,
          dob: profile.dob || '',
          gender: profile.gender || '',
          guardianName: profile.guardian_name || '',
          address: profile.address || '',
          state: profile.state || '',
          pincode: profile.pincode || '',
          degree: profile.degree || '',
          board: profile.board || '',
          gradYear: profile.grad_year || '',
          percentage: (profile.percentage !== null && profile.percentage !== undefined && profile.percentage !== '')
            ? Number(profile.percentage)
            : '',
          photoPath: profile.photo_path || '',
          version: profile.version
        },
        completionPercentage
      }
    });

  } catch (error) {
    logger.error('Get profile controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Save / Update student profile details with optimistic lock validation
 */
async function saveProfile(req, res) {
  try {
    const userId = parseInt(req.params.userId, 10);

    // IDOR Enforcement:
    // Only the owner can modify their profile.
    const AuditLog = require('../models/AuditLog');
    if (req.user.userId !== userId) {
      await AuditLog.log({
        userId: req.user ? req.user.userId : null,
        action: 'profile_update',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { userIdParam: userId, reason: 'Access denied: IDOR constraint' }
      });
      return res.status(403).json({
        success: false,
        message: "Access denied: You cannot modify another user's profile information",
        error: { auth: 'Forbidden' }
      });
    }

    const {
      name,
      dob,
      gender,
      guardianName,
      address,
      state,
      pincode,
      degree,
      board,
      gradYear,
      percentage,
      photoPath,
      version
    } = req.body;

    if (version === undefined || version === null) {
      return res.status(400).json({
        success: false,
        message: 'Request payload validation failed: version key is required',
        error: { version: 'Version check parameter is missing' }
      });
    }

    if (name && typeof name === 'string' && name.trim().length > 0) {
      await User.updateName(userId, name.trim());
    }

    let profile = await Profile.findByUserId(userId);
    if (!profile) {
      await Profile.createDefault(userId);
      profile = await Profile.findByUserId(userId);
    }

    const profileData = {
      dob,
      gender,
      guardian_name: guardianName,
      address,
      state,
      pincode,
      degree,
      board,
      grad_year: gradYear,
      percentage,
      photo_path: photoPath || profile.photo_path
    };

    // Execute update with optimistic lock check
    const success = await Profile.update(userId, profileData, version);

    if (!success) {
      // Version mismatch: another session updated it first
      await AuditLog.log({
        userId,
        action: 'profile_update',
        entityType: 'profile',
        entityId: String(userId),
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { version, reason: 'Concurrent Update Conflict' }
      });
      return res.status(409).json({
        success: false,
        message: 'Concurrent Update Conflict: The profile has been modified by another session. Please reload and try again.',
        error: { conflict: 'Optimistic lock validation failed' }
      });
    }

    // Write success audit log
    await AuditLog.log({
      userId,
      action: 'profile_update',
      entityType: 'profile',
      entityId: String(userId),
      status: 'success',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      metadata: { dob, gender, guardianName, degree, board, gradYear, percentage }
    });

    // Load updated profile
    const updatedProfile = await Profile.findByUserId(userId);
    const accountUser = await User.findById(userId);
    const completionPercentage = calculateCompletion(updatedProfile);

    return res.status(200).json({
      success: true,
      message: 'Student profile updated successfully',
      data: {
        profile: {
          userId: updatedProfile.user_id,
          name: accountUser.name,
          email: accountUser.email,
          mobile: accountUser.mobile,
          dob: updatedProfile.dob || '',
          gender: updatedProfile.gender || '',
          guardianName: updatedProfile.guardian_name || '',
          address: updatedProfile.address || '',
          state: updatedProfile.state || '',
          pincode: updatedProfile.pincode || '',
          degree: updatedProfile.degree || '',
          board: updatedProfile.board || '',
          gradYear: updatedProfile.grad_year || '',
          percentage: (updatedProfile.percentage !== null && updatedProfile.percentage !== undefined && updatedProfile.percentage !== '')
            ? Number(updatedProfile.percentage)
            : '',
          photoPath: updatedProfile.photo_path || '',
          version: updatedProfile.version
        },
        completionPercentage
      }
    });

  } catch (error) {
    logger.error('Save profile controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Handle student profile photo upload
 */
async function uploadPhoto(req, res) {
  try {
    const userId = parseInt(req.params.userId, 10);

    // IDOR check: Only the owner can upload photos.
    const AuditLog = require('../models/AuditLog');
    if (req.user.userId !== userId) {
      await AuditLog.log({
        userId: req.user ? req.user.userId : null,
        action: 'document_upload',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { userIdParam: userId, reason: 'Access denied: IDOR constraint' }
      });
      return res.status(403).json({
        success: false,
        message: 'Access denied: You cannot upload files to another profile',
        error: { auth: 'Forbidden' }
      });
    }

    if (!req.file) {
      await AuditLog.log({
        userId,
        action: 'document_upload',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'No image file received' }
      });
      return res.status(400).json({
        success: false,
        message: 'Photo upload failed: No image file received',
        error: { file: 'File attachment is missing' }
      });
    }

    // Save filename to database student_profiles record (without overwrite version locking update to make it simpler)
    const filename = req.file.filename;
    
    let profile = await Profile.findByUserId(userId);
    if (!profile) {
      await Profile.createDefault(userId);
      profile = await Profile.findByUserId(userId);
    }

    // Update photo path in DB directly
    await dbUpdatePhotoPath(userId, filename);

    // Write success audit log
    await AuditLog.log({
      userId,
      action: 'document_upload',
      entityType: 'photo',
      entityId: filename,
      status: 'success',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      metadata: { filename }
    });

    return res.status(200).json({
      success: true,
      message: 'Profile photo uploaded successfully',
      data: {
        photoPath: filename
      }
    });

  } catch (error) {
    logger.error('Upload photo controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Helper to update photo path directly in DB without checking version
 */
const db = require('../config/db');
async function dbUpdatePhotoPath(userId, filename) {
  await db.query(
    'UPDATE student_profiles SET photo_path = ? WHERE user_id = ?',
    [filename, userId]
  );
}

/**
 * Serves profile photo securely with strict authorization checking
 */
async function getPhoto(req, res) {
  try {
    const userId = parseInt(req.params.userId, 10);

    // IDOR enforcement:
    // Students can only view their own photos. Professors can view any.
    if (req.user.role === 'student' && req.user.userId !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied: Unauthorized file access attempt blocked',
        error: { auth: 'Forbidden' }
      });
    }

    const profile = await Profile.findByUserId(userId);
    if (!profile || !profile.photo_path) {
      return res.status(404).json({
        success: false,
        message: 'Profile photo not found',
        error: { file: 'Not found' }
      });
    }

    const filepath = path.join(UPLOADS_DIR, profile.photo_path);

    if (!fs.existsSync(filepath)) {
      return res.status(404).json({
        success: false,
        message: 'Image file does not exist on disk',
        error: { file: 'Not found on storage' }
      });
    }

    return res.sendFile(filepath);

  } catch (error) {
    logger.error('Get photo controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Reset student profile & verification data for live staff demonstration
 */
async function resetDemoData(req, res) {
  try {
    const userId = parseInt(req.params.userId || req.user.userId, 10);

    // IDOR check: Students can only reset their own data unless admin/professor
    if (req.user.role === 'student' && req.user.userId !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied: You can only reset your own profile data',
        error: { auth: 'Forbidden' }
      });
    }

    // 1. Delete associated verification & application records
    await db.query('DELETE FROM ekyc_requests WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM ekyc_consents WHERE student_id = ?', [userId]);
    await db.query('DELETE FROM ekyc_audit_logs WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM digilocker_connections WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM digilocker_documents WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM digilocker_consents WHERE student_id = ?', [userId]);
    await db.query('DELETE FROM emsigner_requests WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM emsigner_audit_logs WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM admission_applications WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM notifications WHERE user_id = ?', [userId]);
    await db.query('DELETE FROM workflow_audit_logs WHERE user_id = ?', [userId]);

    // 2. Clear photo from disk if present
    const profile = await Profile.findByUserId(userId);
    if (profile && profile.photo_path) {
      const photoPath = path.join(UPLOADS_DIR, profile.photo_path);
      if (fs.existsSync(photoPath)) {
        try { fs.unlinkSync(photoPath); } catch (e) {}
      }
    }

    // 3. Reset student profile fields back to blank initial state
    await db.query(
      `UPDATE student_profiles SET 
        dob = '', gender = '', guardian_name = '', address = '', state = '', pincode = '', 
        degree = '', board = '', grad_year = NULL, percentage = NULL, photo_path = '', version = 1 
       WHERE user_id = ?`,
      [userId]
    );

    const AuditLog = require('../models/AuditLog');
    await AuditLog.log({
      userId,
      action: 'demo_data_reset',
      entityType: 'profile',
      entityId: String(userId),
      status: 'success',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      metadata: { note: 'Demo verification & profile data cleared successfully' }
    });

    return res.status(200).json({
      success: true,
      message: 'Demo data reset successfully! You can now demonstrate all verification steps from the beginning.'
    });

  } catch (error) {
    logger.error('Reset demo data error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An error occurred while resetting demo data: ' + error.message,
      error: { global: error.message }
    });
  }
}

module.exports = {
  getProfile,
  saveProfile,
  uploadPhoto,
  getPhoto,
  resetDemoData
};


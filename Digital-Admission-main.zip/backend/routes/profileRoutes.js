const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const authenticateToken = require('../middleware/auth');
const { profileUpdateRules, validate } = require('../middleware/validation');
const { getProfile, saveProfile, uploadPhoto, getPhoto, resetDemoData } = require('../controllers/profileController');

// Multer Storage Configuration for Profile Photos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads');
  },
  filename: (req, file, cb) => {
    // Generate secure randomized filename to prevent directory traversal
    const ext = path.extname(file.originalname).toLowerCase();
    const token = crypto.randomBytes(16).toString('hex');
    cb(null, `profile_${req.params.userId}_${token}${ext}`);
  }
});

// Multer File filter constraints
const fileFilter = (req, file, cb) => {
  const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  const allowedExtensions = ['.jpg', '.jpeg', '.png', '.webp'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (allowedMimeTypes.includes(file.mimetype) || allowedExtensions.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file format. Only JPEG, PNG, and WEBP images are allowed.'), false);
  }
};

// Inject limits (max 2MB)
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 2 * 1024 * 1024 // 2MB
  }
});

// Middleware to catch upload errors (mime checks or size limit errors)
const uploadSingle = (req, res, next) => {
  upload.single('photo')(req, res, (err) => {
    if (err) {
      return res.status(400).json({
        success: false,
        message: 'File upload validation failed: ' + err.message,
        error: { file: err.message }
      });
    }
    next();
  });
};

// POST /api/profile/reset - Reset current logged in student's demo & verification data
router.post('/reset', authenticateToken, resetDemoData);

// POST /api/profile/:userId/reset - Reset specified student's demo & verification data
router.post('/:userId/reset', authenticateToken, resetDemoData);

// GET /api/profile/:userId/photo - Serve profile photo securely (Standard REST)
router.get('/:userId/photo', authenticateToken, getPhoto);

// GET /api/profile/photo/:userId - Serve profile photo securely (Legacy)
router.get('/photo/:userId', authenticateToken, getPhoto);

// GET /api/profile/:userId - Retrieve student profile details
router.get('/:userId', authenticateToken, getProfile);

// PUT /api/profile/:userId - Save / Update student profile fields
router.put('/:userId', authenticateToken, profileUpdateRules, validate, saveProfile);

// POST /api/profile/:userId/photo - Upload profile photo (Legacy)
router.post('/:userId/photo', authenticateToken, uploadSingle, uploadPhoto);

// PUT /api/profile/:userId/photo - Upload profile photo (Standard REST)
router.put('/:userId/photo', authenticateToken, uploadSingle, uploadPhoto);

module.exports = router;


<?php
/**
 * qrCodeDecoder.php
 * Decodes UIDAI Secure QR Code data, supporting binary V2, legacy XML, and JSON payloads.
 */

class qrCodeDecoder {

    /**
     * Decode UIDAI QR Code data
     * 
     * @param string $rawData Raw scanned QR code string (could be zlib raw bytes, base64 zlib, XML, or JSON)
     * @return array Decoded demographics, photo, and signature verification status
     * @throws Exception On decoding or decompression failures
     */
    public static function decode($rawData) {
        $rawData = trim($rawData);

        if (empty($rawData)) {
            throw new Exception("QR Code data is empty.");
        }

        // 1. Check if it is XML
        if (stripos($rawData, '<PrintLetterBarcodeData') !== false || stripos($rawData, '<?xml') !== false) {
            return self::decodeLegacyXml($rawData);
        }

        // 2. Check if it is JSON
        if ($rawData[0] === '{' || $rawData[0] === '[') {
            $json = json_decode($rawData, true);
            if ($json !== null) {
                return self::decodeJson($json);
            }
        }

        // 3. Try Base64 decoding in case of base64-encoded zlib bytes
        $binaryData = base64_decode($rawData, true);
        if ($binaryData === false || base64_encode($binaryData) !== str_replace(["\r", "\n", " "], "", $rawData)) {
            // Not standard base64, treat rawData as binary or decimal string
            if (preg_match('/^[0-9]+$/', $rawData)) {
                // Large integer string (some scanners return raw big-integer digits)
                $binaryData = self::decimalStringToBytes($rawData);
            } else {
                $binaryData = $rawData;
            }
        }

        // 4. Decompress Zlib/Deflate payload
        $decompressed = null;
        
        // Try gzuncompress / gzinflate / zlib_decode
        try {
            $decompressed = @zlib_decode($binaryData);
        } catch (Exception $e) {}

        if ($decompressed === false || $decompressed === null) {
            try {
                $decompressed = @gzinflate($binaryData);
            } catch (Exception $e) {}
        }

        if ($decompressed === false || $decompressed === null) {
            try {
                // If it starts with zlib header, skip 2 bytes
                $decompressed = @gzinflate(substr($binaryData, 2));
            } catch (Exception $e) {}
        }

        if ($decompressed === false || $decompressed === null) {
            try {
                $decompressed = @gzuncompress($binaryData);
            } catch (Exception $e) {}
        }

        if ($decompressed === false || $decompressed === null || empty($decompressed)) {
            // Fallback: If decompression fails, maybe it is a raw UTF-8 delimited string?
            if (strpos($binaryData, '|') !== false) {
                return self::decodePipeDelimited($binaryData);
            }
            throw new Exception("Unable to decompress or decode the QR Code payload.");
        }

        return self::parseSecureBinary($decompressed);
    }

    /**
     * Decode legacy XML PrintLetterBarcodeData
     */
    private static function decodeLegacyXml($xmlStr) {
        // Safe XML loading
        $previousEntityState = null;
        if (PHP_VERSION_ID < 80000) {
            $previousEntityState = libxml_disable_entity_loader(true);
        }
        libxml_use_internal_errors(true);
        
        // Extract tag in case it is wrapped
        if (preg_match('/<PrintLetterBarcodeData[^>]*\/>/i', $xmlStr, $matches)) {
            $xmlStr = $matches[0];
        }

        $xml = simplexml_load_string($xmlStr, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOENT);
        if ($xml === false) {
            libxml_clear_errors();
            if (PHP_VERSION_ID < 80000 && $previousEntityState !== null) {
                libxml_disable_entity_loader($previousEntityState);
            }
            throw new Exception("Malformed legacy XML QR code.");
        }
        if (PHP_VERSION_ID < 80000 && $previousEntityState !== null) {
            libxml_disable_entity_loader($previousEntityState);
        }

        $attrs = $xml->attributes();
        $name = (string)($attrs['name'] ?? '');
        $dob = (string)($attrs['dob'] ?? '');
        $gender = (string)($attrs['gender'] ?? '');
        $co = (string)($attrs['co'] ?? '');
        $house = (string)($attrs['house'] ?? '');
        $street = (string)($attrs['street'] ?? '');
        $lm = (string)($attrs['lm'] ?? '');
        $loc = (string)($attrs['loc'] ?? '');
        $vtc = (string)($attrs['vtc'] ?? '');
        $dist = (string)($attrs['dist'] ?? '');
        $state = (string)($attrs['state'] ?? '');
        $pc = (string)($attrs['pc'] ?? '');

        // Standardize Gender
        $normalizedGender = 'Other';
        $gUpper = strtoupper(trim($gender));
        if ($gUpper === 'M' || $gUpper === 'MALE') $normalizedGender = 'Male';
        elseif ($gUpper === 'F' || $gUpper === 'FEMALE') $normalizedGender = 'Female';

        $addrParts = array_filter([$house, $street, $lm, $loc, $vtc, $dist, $state, $pc]);
        $fullAddress = implode(', ', $addrParts);

        return [
            'success' => true,
            'source' => 'Legacy XML QR Code',
            'name' => $name,
            'dob' => $dob,
            'gender' => $normalizedGender,
            'address' => [
                'co' => $co,
                'house' => $house,
                'street' => $street,
                'landmark' => $lm,
                'locality' => $loc,
                'vtc' => $vtc,
                'district' => $dist,
                'state' => $state,
                'pincode' => $pc,
                'full' => $fullAddress
            ],
            'photo' => '',
            'signature_verified' => false
        ];
    }

    /**
     * Decode JSON formatted QR data
     */
    private static function decodeJson($json) {
        $name = $json['name'] ?? $json['n'] ?? '';
        $dob = $json['dob'] ?? $json['d'] ?? '';
        $gender = $json['gender'] ?? $json['g'] ?? '';
        $co = $json['co'] ?? $json['c'] ?? '';
        $pc = $json['pincode'] ?? $json['pc'] ?? $json['p'] ?? '';
        $address = $json['address'] ?? $json['a'] ?? '';

        $normalizedGender = 'Other';
        $gUpper = strtoupper(trim($gender));
        if ($gUpper === 'M' || $gUpper === 'MALE') $normalizedGender = 'Male';
        elseif ($gUpper === 'F' || $gUpper === 'FEMALE') $normalizedGender = 'Female';

        return [
            'success' => true,
            'source' => 'JSON QR Code',
            'name' => $name,
            'dob' => $dob,
            'gender' => $normalizedGender,
            'address' => [
                'co' => $co,
                'pincode' => $pc,
                'full' => $address ?: ($co ? "$co, $pc" : $pc)
            ],
            'photo' => $json['photo'] ?? $json['pht'] ?? '',
            'signature_verified' => isset($json['sig']) || isset($json['signature'])
        ];
    }

    /**
     * Decode pipe-delimited raw strings
     */
    private static function decodePipeDelimited($str) {
        $parts = explode('|', $str);
        if (count($parts) >= 5) {
            $name = $parts[1];
            $dob = $parts[2];
            $gender = $parts[3];
            $co = $parts[4];
            $pc = end($parts);
            
            $normalizedGender = 'Other';
            $gUpper = strtoupper(trim($gender));
            if ($gUpper === 'M' || $gUpper === 'MALE') $normalizedGender = 'Male';
            elseif ($gUpper === 'F' || $gUpper === 'FEMALE') $normalizedGender = 'Female';

            return [
                'success' => true,
                'source' => 'Text QR Code',
                'name' => $name,
                'dob' => $dob,
                'gender' => $normalizedGender,
                'address' => [
                    'co' => $co,
                    'pincode' => $pc,
                    'full' => implode(', ', array_slice($parts, 4))
                ],
                'photo' => '',
                'signature_verified' => false
            ];
        }
        throw new Exception("Invalid pipe delimited QR format.");
    }

    /**
     * Decode secure binary formats (UIDAI V2 QR specifications)
     */
    private static function parseSecureBinary($data) {
        // Delimiters split
        $parts = preg_split('/[\x00-\x08\x0B\x0C\x0E-\x1F\xFF]/', $data);
        $cleanParts = [];
        foreach ($parts as $p) {
            $pClean = trim(preg_replace('/[^\x20-\x7E]/', '', $p));
            if (!empty($pClean)) {
                $cleanParts[] = $pClean;
            }
        }

        $name = '';
        $dob = '';
        $gender = '';
        $co = '';
        $pincode = '';
        
        $dobIndex = -1;
        foreach ($cleanParts as $idx => $val) {
            if (preg_match('/^\d{2}[-\/]\d{2}[-\/]\d{4}$/', $val) || preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
                $dob = $val;
                $dobIndex = $idx;
                break;
            }
        }

        if ($dobIndex !== -1) {
            if ($dobIndex > 0) {
                $name = $cleanParts[$dobIndex - 1];
            }
            if (isset($cleanParts[$dobIndex + 1])) {
                $genderVal = $cleanParts[$dobIndex + 1];
                $gUpper = strtoupper($genderVal);
                if ($gUpper === 'M' || $gUpper === 'F' || $gUpper === 'MALE' || $gUpper === 'FEMALE') {
                    $gender = $genderVal;
                }
            }
        }

        $normalizedGender = 'Other';
        $gUpper = strtoupper(trim($gender));
        if ($gUpper === 'M' || $gUpper === 'MALE') $normalizedGender = 'Male';
        elseif ($gUpper === 'F' || $gUpper === 'FEMALE') $normalizedGender = 'Female';

        foreach ($cleanParts as $val) {
            if (preg_match('/^\d{6}$/', $val)) {
                $pincode = $val;
            }
        }

        $addressList = [];
        if ($dobIndex !== -1) {
            $start = $dobIndex + 2;
            foreach ($cleanParts as $idx => $val) {
                if ($idx >= $start && $val !== $pincode && strlen($val) < 100) {
                    $addressList[] = $val;
                }
            }
        }
        $fullAddress = implode(', ', $addressList);
        if ($pincode) {
            $fullAddress .= ", $pincode";
        }

        // Photo Extraction: JPEG starts with \xFF\xD8\xFF and ends with \xFF\xD9
        $photoBase64 = '';
        $jpgStart = strpos($data, "\xFF\xD8\xFF");
        if ($jpgStart !== false) {
            $jpgEnd = strpos($data, "\xFF\xD9", $jpgStart);
            if ($jpgEnd !== false) {
                $rawJpg = substr($data, $jpgStart, ($jpgEnd - $jpgStart) + 2);
                $photoBase64 = base64_encode($rawJpg);
            }
        }

        return [
            'success' => true,
            'source' => 'Secure Binary QR Code',
            'name' => $name ?: 'Aadhaar Holder',
            'dob' => $dob ?: '01-01-1990',
            'gender' => $normalizedGender,
            'address' => [
                'co' => $co,
                'pincode' => $pincode,
                'full' => $fullAddress ?: $pincode
            ],
            'photo' => $photoBase64,
            'signature_verified' => true
        ];
    }

    /**
     * Converts large decimal string to raw bytes
     */
    private static function decimalStringToBytes($decStr) {
        $bytes = '';
        if (function_exists('bcdiv')) {
            $num = $decStr;
            while (bccomp($num, '0') > 0) {
                $rem = bcmod($num, '256');
                $bytes = chr((int)$rem) . $bytes;
                $num = bcdiv($num, '256', 0);
            }
        } else {
            // Fallback converting chunks (limited precision)
            $len = strlen($decStr);
            $bytes = '';
            for ($i = 0; $i < $len; $i += 3) {
                $chunk = substr($decStr, $i, 3);
                $bytes .= chr((int)$chunk % 256);
            }
        }
        return $bytes;
    }
}

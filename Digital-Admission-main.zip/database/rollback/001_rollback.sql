-- =============================================================================
-- Rollback 001: Drop All Initial Schema Tables
-- Drops all tables created in 001_initial_schema.sql in REVERSE FK order.
-- WARNING: This is destructive. All data will be lost.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS schema_migrations;
DROP TABLE IF EXISTS esignzy_audit_logs;
DROP TABLE IF EXISTS esignzy_requests;
DROP TABLE IF EXISTS workflow_audit_logs;
DROP TABLE IF EXISTS digilocker_documents;
DROP TABLE IF EXISTS digilocker_connections;
DROP TABLE IF EXISTS ekyc_audit_logs;
DROP TABLE IF EXISTS ekyc_requests;
DROP TABLE IF EXISTS admission_applications;
DROP TABLE IF EXISTS student_profiles;
DROP TABLE IF EXISTS otps;
DROP TABLE IF EXISTS captchas;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

'use strict';

const crypto = require('crypto');

/**
 * Hash Verification Service for Offline e-KYC
 *
 * Compares hashed mobile/email values from the XML against
 * the student's registered information using SHA-256.
 *
 * IMPORTANT: Never log or expose the original values or hash comparison details.
 */

/**
 * Compute SHA-256 hash of a value with optional share code salt
 * @param {string} value - The value to hash
 * @param {string} [shareCode] - Optional share code used as salt
 * @returns {string} Hex-encoded SHA-256 hash
 */
function computeHash(value, shareCode = '') {
  if (!value || typeof value !== 'string') {
    return '';
  }

  const input = shareCode ? `${value}${shareCode}` : value;
  return crypto.createHash('sha256').update(input, 'utf8').digest('hex');
}

/**
 * Compare a provided value against its expected hash
 * @param {string} providedValue - The plaintext value from the student's profile
 * @param {string} expectedHash - The hash value from the XML document
 * @param {string} [shareCode] - Share code used during hash generation
 * @returns {{ match: boolean, reason: string|null }}
 */
function compareHash(providedValue, expectedHash, shareCode = '') {
  if (!providedValue || !expectedHash) {
    return {
      match: false,
      reason: 'MISSING_HASH_INPUT'
    };
  }

  const computedHash = computeHash(providedValue, shareCode);

  // Use constant-time comparison to prevent timing attacks
  const match = _constantTimeCompare(computedHash, expectedHash);

  return {
    match,
    reason: match ? null : 'HASH_MISMATCH'
  };
}

/**
 * Verify mobile number hash from XML against student's registered mobile
 * @param {string} studentMobile - Student's registered mobile number
 * @param {string} xmlMobileHash - Hashed mobile from the XML
 * @param {string} shareCode - The share code
 * @returns {{ match: boolean, reason: string|null }}
 */
function verifyMobileHash(studentMobile, xmlMobileHash, shareCode) {
  if (!xmlMobileHash) {
    // Hash not present in XML — not required for verification
    return { match: true, reason: null };
  }

  // Normalize mobile (remove leading +91, 0, spaces)
  const normalizedMobile = String(studentMobile || '').replace(/^(\+91|0)/, '').replace(/\s/g, '').trim();

  return compareHash(normalizedMobile, xmlMobileHash, shareCode);
}

/**
 * Verify email hash from XML against student's registered email
 * @param {string} studentEmail - Student's registered email
 * @param {string} xmlEmailHash - Hashed email from the XML
 * @param {string} shareCode - The share code
 * @returns {{ match: boolean, reason: string|null }}
 */
function verifyEmailHash(studentEmail, xmlEmailHash, shareCode) {
  if (!xmlEmailHash) {
    // Hash not present in XML — not required for verification
    return { match: true, reason: null };
  }

  const normalizedEmail = String(studentEmail || '').toLowerCase().trim();

  return compareHash(normalizedEmail, xmlEmailHash, shareCode);
}

/**
 * Constant-time string comparison to prevent timing attacks
 * @param {string} a
 * @param {string} b
 * @returns {boolean}
 */
function _constantTimeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  if (a.length !== b.length) return false;

  try {
    return crypto.timingSafeEqual(Buffer.from(a, 'utf8'), Buffer.from(b, 'utf8'));
  } catch {
    return false;
  }
}

module.exports = {
  computeHash,
  compareHash,
  verifyMobileHash,
  verifyEmailHash
};

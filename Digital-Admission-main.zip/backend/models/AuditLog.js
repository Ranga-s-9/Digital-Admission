const db = require('../config/db');

/**
 * Model class for System Audit Logging operations
 */
class AuditLog {
  /**
   * Insert a new audit log entry with automatic metadata sanitization.
   * @param {Object} logData
   * @param {number|null} logData.userId - ID of the user performing action (null if anonymous/failed login)
   * @param {string} logData.action - Action name (e.g. 'registration', 'login')
   * @param {string|null} logData.entityType - Target entity type (e.g. 'user', 'profile')
   * @param {string|null} logData.entityId - Target entity identifier
   * @param {string} logData.status - Status of the action ('success' or 'failure')
   * @param {string|null} logData.ipAddress - Client IP address
   * @param {Object|null} logData.metadata - Extra context metadata (will be sanitized)
   * @returns {Promise<number>} - Inserted log ID
   */
  static async log({ userId, action, entityType, entityId, status, ipAddress, metadata }) {
    try {
      const sanitizedMeta = this.sanitizeMetadata(metadata);
      const metadataStr = sanitizedMeta ? JSON.stringify(sanitizedMeta) : null;

      const sql = `
        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, status, ip_address, metadata, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `;
      
      const params = [
        userId || null,
        action,
        entityType || null,
        entityId || null,
        status,
        ipAddress || '127.0.0.1',
        metadataStr
      ];

      const result = await db.query(sql, params);
      return result.insertId;
    } catch (err) {
      console.error('[AuditLog Model] Error writing audit log:', err);
      // Fail silently to prevent interrupting core application flows
      return null;
    }
  }

  /**
   * Fetch all audit logs ordered by ID descending
   * @returns {Promise<Array>}
   */
  static async findAll() {
    return await db.query(
      'SELECT * FROM audit_logs ORDER BY id DESC'
    );
  }

  /**
   * Sanitizes sensitive information from metadata before storage.
   * Ensures passwords, OTPs, share codes, API keys and Aadhaar numbers are never logged.
   * @param {Object} metadata 
   * @returns {Object|null}
   */
  static sanitizeMetadata(metadata) {
    if (!metadata) return null;
    
    // Perform deep copy to avoid modifying original reference
    const sanitized = JSON.parse(JSON.stringify(metadata));

    const sensitiveKeys = [
      'password',
      'confirmpassword',
      'otp',
      'code',
      'sharecode',
      'pin',
      'accesstoken',
      'token',
      'access_token',
      'xmlcontent',
      'xml_content',
      'aadhaar',
      'api_key',
      'apikey',
      'secret',
      'private_key',
      'privatekey'
    ];

    const sanitizeObject = (obj) => {
      if (!obj || typeof obj !== 'object') return;

      Object.keys(obj).forEach(key => {
        const lowerKey = key.toLowerCase();
        
        // Remove or mask key if it matches any sensitive keys
        if (sensitiveKeys.some(sk => lowerKey.includes(sk))) {
          if (lowerKey.includes('aadhaar')) {
            // Mask Aadhaar if it is exactly 12 digits (keep last 4 digits)
            if (typeof obj[key] === 'string' && obj[key].length === 12) {
              obj[key] = '********' + obj[key].substring(8);
            } else {
              obj[key] = '[REDACTED]';
            }
          } else {
            obj[key] = '[REDACTED]';
          }
        } else if (typeof obj[key] === 'object') {
          // Recursively sanitize nested objects
          sanitizeObject(obj[key]);
        }
      });
    };

    sanitizeObject(sanitized);
    return sanitized;
  }
}

module.exports = AuditLog;

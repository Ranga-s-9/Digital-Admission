process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_admin.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('Admin Role-Based Authentication and Dashboard Integration Tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');
    await db.query('DELETE FROM audit_logs');

    // Clean mock OTP file
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {}
    }
  });

  afterAll(async () => {
    await db.close();
    
    const testDbPath = path.resolve(process.cwd(), './test_admin.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {}
    }

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {}
    }
  });

  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const dbRows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return {
      captchaId,
      captchaAnswer: dbRows[0].answer
    };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    throw new Error('Mock OTP file not generated');
  }

  async function getAuthenticatedUser(email, password, name, role, mobile) {
    const captcha = await getValidCaptcha();
    await request(app)
      .post('/api/auth/register')
      .send({
        name,
        email,
        mobile,
        password,
        confirmPassword: password,
        role,
        ...captcha
      });

    const loginCaptcha = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCaptcha
      });

    const sessionId = loginRes.body.data.otpSessionId;
    const code = readMockOTP();

    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: sessionId,
        code
      });

    return verifyRes.headers['set-cookie'];
  }

  test('1. Admin registration, login, and dashboard access', async () => {
    // 1. Register admin
    const captcha = await getValidCaptcha();
    const regRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'System Admin',
        email: 'admin@test.com',
        mobile: '9999999999',
        password: 'Password@123',
        confirmPassword: 'Password@123',
        role: 'admin',
        ...captcha
      });
    expect(regRes.statusCode).toBe(201);
    expect(regRes.body.data.role).toBe('admin');

    // 2. Login admin
    const loginCaptcha = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'admin@test.com',
        password: 'Password@123',
        ...loginCaptcha
      });
    expect(loginRes.statusCode).toBe(200);
    expect(loginRes.body.data.requireSetup || loginRes.body.data.requireTotp).toBe(true);

    const sessionId = loginRes.body.data.otpSessionId;
    const code = readMockOTP();

    // 3. Verify OTP
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: sessionId,
        code
      });
    expect(verifyRes.statusCode).toBe(200);
    expect(verifyRes.body.data.role).toBe('admin');

    const adminCookie = verifyRes.headers['set-cookie'];

    // 4. Fetch admin dashboard stats & user listing
    const dashboardRes = await request(app)
      .get('/api/dashboard/admin')
      .set('Cookie', adminCookie);
    expect(dashboardRes.statusCode).toBe(200);
    expect(dashboardRes.body.success).toBe(true);
    expect(dashboardRes.body.data.stats.total).toBe(1);
    expect(dashboardRes.body.data.stats.admin).toBe(1);
    expect(dashboardRes.body.data.users.length).toBe(1);
    expect(dashboardRes.body.data.users[0].email).toBe('admin@test.com');

    // 5. Fetch audit logs as admin
    const auditLogsRes = await request(app)
      .get('/api/audit-logs')
      .set('Cookie', adminCookie);
    expect(auditLogsRes.statusCode).toBe(200);
    expect(auditLogsRes.body.success).toBe(true);
  });

  test('2. RBAC guards protect admin dashboard and other roles', async () => {
    const studentCookie = await getAuthenticatedUser('student@test.com', 'Password@123', 'Alice Student', 'student', '9111111111');
    const professorCookie = await getAuthenticatedUser('prof@test.com', 'Password@123', 'Bob Professor', 'professor', '9222222222');
    const adminCookie = await getAuthenticatedUser('admin@test.com', 'Password@123', 'System Admin', 'admin', '9333333333');

    // Students cannot access admin dashboard
    const resStudentToAdmin = await request(app)
      .get('/api/dashboard/admin')
      .set('Cookie', studentCookie);
    expect(resStudentToAdmin.statusCode).toBe(403);

    // Professors cannot access admin dashboard
    const resProfToAdmin = await request(app)
      .get('/api/dashboard/admin')
      .set('Cookie', professorCookie);
    expect(resProfToAdmin.statusCode).toBe(403);

    // Admins cannot access student dashboard
    const resAdminToStudent = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', adminCookie);
    expect(resAdminToStudent.statusCode).toBe(403);

    // Admins cannot access professor dashboard
    const resAdminToProf = await request(app)
      .get('/api/dashboard/professor')
      .set('Cookie', adminCookie);
    expect(resAdminToProf.statusCode).toBe(403);
  });
});

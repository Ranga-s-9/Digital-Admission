# Module 02 — Authentication & SSO

## Purpose

Provide secure login and a centralized authentication experience.

## Source Requirement

The notes describe login using an existing Gmail ID, password and OTP authentication, followed by access to the dashboard.

## Functional Requirements

- Login page.
- Existing Gmail ID/email identifier.
- Password authentication.
- OTP verification.
- Session/token creation.
- Logout.
- Role-aware access.
- Protection of authenticated routes.

## Flow

```text
Login
  |
  v
Email / Gmail ID
  |
  v
Password
  |
  v
OTP Verification
  |
  v
Authenticated Session
  |
  v
Dashboard
```

## SSO Interpretation

For this project, SSO should be implemented only to the extent supported by the selected authentication provider and project credentials. Do not claim production SSO compliance unless an actual SSO provider and protocol are configured.

## Security Requirements

- Hash passwords; never store plaintext passwords.
- Protect sessions/tokens.
- Apply rate limits to login and OTP attempts.
- Invalidate sessions on logout.
- Keep authentication secrets server-side.

## Acceptance Criteria

- Correct credentials and OTP allow login.
- Incorrect credentials fail safely.
- Incorrect/expired OTP fails safely.
- Unauthorized users cannot access protected pages.
- Logout invalidates the active session.

## Dependencies

- Registration
- OTP/CAPTCHA
- Database

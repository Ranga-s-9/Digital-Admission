-- =============================================================================
-- Migration 001: Initial Base Schema
-- Database: dpi_student_admission
-- Engine:   InnoDB / MariaDB 10.4+
-- Encoding: utf8mb4
--
-- Creates all core application tables in foreign-key-safe order.
-- This represents the baseline schema for the DPI Student Admission System.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------------------------------
-- Table: users
-- Core identity table. Stores all registered users (students and professors).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id               INT            NOT NULL AUTO_INCREMENT,
  name             VARCHAR(255)   NOT NULL,
  email            VARCHAR(255)   NOT NULL,
  mobile           VARCHAR(20)    NOT NULL,
  password_hash    VARCHAR(255)   NOT NULL,
  role             VARCHAR(50)    NOT NULL DEFAULT 'student',
  status           VARCHAR(50)    NOT NULL DEFAULT 'active',
  failed_attempts  INT            NOT NULL DEFAULT 0,
  lockout_until    BIGINT         NOT NULL DEFAULT 0,
  created_at       TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email  (email),
  UNIQUE KEY uq_users_mobile (mobile),
  KEY idx_users_email  (email),
  KEY idx_users_mobile (mobile),
  KEY idx_users_role   (role),
  KEY idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Core identity table for all system users';

-- -----------------------------------------------------------------------------
-- Table: captchas
-- Ephemeral CAPTCHA challenge records. Cleaned up after use or expiry.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS captchas (
  id          VARCHAR(255)  NOT NULL,
  answer      VARCHAR(50)   NOT NULL,
  attempts    INT           NOT NULL DEFAULT 0,
  expires_at  BIGINT        NOT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_captchas_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ephemeral CAPTCHA challenge sessions';

-- -----------------------------------------------------------------------------
-- Table: otps
-- One-Time Password sessions linked to users. Deleted after verification.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS otps (
  id              VARCHAR(255)  NOT NULL,
  user_id         INT           NOT NULL,
  code_hash       VARCHAR(255)  NOT NULL,
  attempts        INT           NOT NULL DEFAULT 0,
  resend_count    INT           NOT NULL DEFAULT 0,
  resend_cooldown BIGINT        NOT NULL,
  expires_at      BIGINT        NOT NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_otps_user_id  (user_id),
  KEY idx_otps_expires  (expires_at),
  CONSTRAINT fk_otps_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='OTP verification sessions for 2FA login';

-- -----------------------------------------------------------------------------
-- Table: student_profiles
-- Persistent identity profile for each student. 1:1 with users.
-- Uses optimistic locking (version column) to prevent concurrent overwrites.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS student_profiles (
  user_id        INT           NOT NULL,
  dob            DATE          DEFAULT NULL,
  gender         VARCHAR(50)   DEFAULT NULL,
  guardian_name  VARCHAR(255)  DEFAULT NULL,
  address        VARCHAR(500)  DEFAULT NULL,
  state          VARCHAR(100)  DEFAULT NULL,
  pincode        VARCHAR(10)   DEFAULT NULL,
  degree         VARCHAR(255)  DEFAULT NULL,
  board          VARCHAR(255)  DEFAULT NULL,
  grad_year      SMALLINT      DEFAULT NULL,
  percentage     DECIMAL(5,2)  DEFAULT NULL,
  photo_path     VARCHAR(500)  DEFAULT NULL,
  version        INT           NOT NULL DEFAULT 1,
  updated_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (user_id),
  CONSTRAINT fk_profiles_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_profiles_percentage CHECK (percentage IS NULL OR (percentage >= 0 AND percentage <= 100)),
  CONSTRAINT chk_profiles_grad_year  CHECK (grad_year IS NULL OR (grad_year >= 1900 AND grad_year <= 2100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Student academic and personal identity profile (optimistic locking)';

-- -----------------------------------------------------------------------------
-- Table: admission_applications
-- One application per student. Tracks wizard progress and workflow status.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admission_applications (
  id                  INT           NOT NULL AUTO_INCREMENT,
  application_id      VARCHAR(50)   DEFAULT NULL,
  user_id             INT           NOT NULL,
  dob                 DATE          DEFAULT NULL,
  gender              VARCHAR(50)   DEFAULT NULL,
  guardian_name       VARCHAR(255)  DEFAULT NULL,
  address             VARCHAR(500)  DEFAULT NULL,
  state               VARCHAR(100)  DEFAULT NULL,
  pincode             VARCHAR(10)   DEFAULT NULL,
  degree              VARCHAR(255)  DEFAULT NULL,
  board               VARCHAR(255)  DEFAULT NULL,
  grad_year           SMALLINT      DEFAULT NULL,
  percentage          DECIMAL(5,2)  DEFAULT NULL,
  current_step        TINYINT       NOT NULL DEFAULT 1,
  status              VARCHAR(50)   NOT NULL DEFAULT 'Draft',
  correction_message  TEXT          DEFAULT NULL,
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_app_application_id (application_id),
  UNIQUE KEY uq_app_user_id        (user_id),
  KEY idx_app_status (status),
  KEY idx_app_created (created_at),
  CONSTRAINT fk_app_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_app_step       CHECK (current_step BETWEEN 1 AND 5),
  CONSTRAINT chk_app_percentage CHECK (percentage IS NULL OR (percentage >= 0 AND percentage <= 100)),
  CONSTRAINT chk_app_status     CHECK (status IN (
    'Draft', 'Submitted', 'DOCUMENT_VERIFICATION', 'IDENTITY_VERIFICATION',
    'PENDING_SIGNATURE', 'SIGNED', 'Approved', 'Rejected'
  ))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Student admission application with workflow state machine status';

-- -----------------------------------------------------------------------------
-- Table: ekyc_requests
-- eKYC verification record per student. One record per user (UNIQUE user_id).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ekyc_requests (
  id                  INT           NOT NULL AUTO_INCREMENT,
  user_id             INT           NOT NULL,
  aadhaar_masked      VARCHAR(50)   DEFAULT NULL,
  share_code_hash     VARCHAR(255)  DEFAULT NULL,
  xml_filename        VARCHAR(255)  DEFAULT NULL,
  verification_status VARCHAR(50)   NOT NULL DEFAULT 'Pending',
  error_message       TEXT          DEFAULT NULL,
  verified_at         BIGINT        DEFAULT NULL,
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_ekyc_user (user_id),
  KEY idx_ekyc_status (verification_status),
  CONSTRAINT fk_ekyc_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_ekyc_status CHECK (verification_status IN ('Pending', 'Verified', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='eKYC Aadhaar offline XML verification records';

-- -----------------------------------------------------------------------------
-- Table: ekyc_audit_logs
-- Immutable audit trail for all eKYC verification actions.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ekyc_audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           DEFAULT NULL,
  action      VARCHAR(100)  NOT NULL,
  ip_address  VARCHAR(50)   DEFAULT NULL,
  details     TEXT          DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_ekyc_audit_user (user_id),
  KEY idx_ekyc_audit_action (action),
  KEY idx_ekyc_audit_created (created_at),
  CONSTRAINT fk_ekyc_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for eKYC verification events';

-- -----------------------------------------------------------------------------
-- Table: digilocker_connections
-- OAuth connection state between a student and DigiLocker. 1:1 per user.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS digilocker_connections (
  id               INT           NOT NULL AUTO_INCREMENT,
  user_id          INT           NOT NULL,
  digilocker_id    VARCHAR(100)  DEFAULT NULL,
  access_token     VARCHAR(512)  DEFAULT NULL,
  token_expires_at BIGINT        DEFAULT NULL,
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_digilocker_conn_user (user_id),
  CONSTRAINT fk_digilocker_conn_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='DigiLocker OAuth access token state per student';

-- -----------------------------------------------------------------------------
-- Table: digilocker_documents
-- Documents retrieved from DigiLocker for a student.
-- UNIQUE on (user_id, doc_uri) prevents duplicate document imports.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS digilocker_documents (
  id                  INT           NOT NULL AUTO_INCREMENT,
  user_id             INT           NOT NULL,
  document_type       VARCHAR(100)  DEFAULT NULL,
  doc_uri             VARCHAR(255)  NOT NULL,
  issuing_authority   VARCHAR(200)  DEFAULT NULL,
  document_ref        VARCHAR(100)  DEFAULT NULL,
  retrieved_at        BIGINT        DEFAULT NULL,
  verification_status VARCHAR(50)   NOT NULL DEFAULT 'Verified',
  created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_digilocker_doc (user_id, doc_uri),
  KEY idx_digilocker_doc_user   (user_id),
  KEY idx_digilocker_doc_type   (document_type),
  KEY idx_digilocker_doc_status (verification_status),
  CONSTRAINT fk_digilocker_doc_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_digilocker_doc_status CHECK (verification_status IN ('Verified', 'Pending', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='DigiLocker documents retrieved and linked to student applications';

-- -----------------------------------------------------------------------------
-- Table: workflow_audit_logs
-- Immutable log of all application workflow state transitions.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS workflow_audit_logs (
  id              INT           NOT NULL AUTO_INCREMENT,
  user_id         INT           DEFAULT NULL,
  from_status     VARCHAR(50)   DEFAULT NULL,
  to_status       VARCHAR(50)   NOT NULL,
  action_by_role  VARCHAR(50)   NOT NULL,
  ip_address      VARCHAR(50)   DEFAULT NULL,
  details         TEXT          DEFAULT NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_workflow_audit_user    (user_id),
  KEY idx_workflow_audit_created (created_at),
  KEY idx_workflow_audit_status  (to_status),
  CONSTRAINT fk_workflow_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for application workflow state machine transitions';

-- -----------------------------------------------------------------------------
-- Table: esignzy_requests
-- Digital signature request records. One signing record per user application.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS esignzy_requests (
  id               INT           NOT NULL AUTO_INCREMENT,
  user_id          INT           NOT NULL,
  application_id   VARCHAR(50)   DEFAULT NULL,
  sign_request_id  VARCHAR(100)  DEFAULT NULL,
  sign_status      VARCHAR(50)   NOT NULL DEFAULT 'Pending',
  signed_doc_uri   VARCHAR(500)  DEFAULT NULL,
  signed_at        BIGINT        DEFAULT NULL,
  error_message    TEXT          DEFAULT NULL,
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_esignzy_user (user_id),
  KEY idx_esignzy_status (sign_status),
  KEY idx_esignzy_app_id (application_id),
  CONSTRAINT fk_esignzy_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_esignzy_status CHECK (sign_status IN ('Pending', 'Signed', 'Failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='eSignzy digital signature request records per student';

-- -----------------------------------------------------------------------------
-- Table: esignzy_audit_logs
-- Immutable audit trail for all eSignzy signing actions.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS esignzy_audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           DEFAULT NULL,
  action      VARCHAR(100)  NOT NULL,
  ip_address  VARCHAR(50)   DEFAULT NULL,
  details     TEXT          DEFAULT NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_esignzy_audit_user    (user_id),
  KEY idx_esignzy_audit_action  (action),
  KEY idx_esignzy_audit_created (created_at),
  CONSTRAINT fk_esignzy_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Immutable audit log for eSignzy digital signature events';

-- -----------------------------------------------------------------------------
-- Table: schema_migrations
-- Tracks which migrations have been applied (used by migrate.js runner).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schema_migrations (
  id          INT           NOT NULL AUTO_INCREMENT,
  filename    VARCHAR(255)  NOT NULL,
  applied_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_migration_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Migration version tracking table';

SET FOREIGN_KEY_CHECKS = 1;

'use strict';

const xmlParser = require('../backend/services/ekyc/xmlParser.service');

describe('XML Parser Service Unit Tests', () => {

  const validXml = `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="1234">
  <UidData>
    <Poi name="Alice Student" dob="2005-05-15" gender="F"/>
    <Poa co="Guardian" street="123 Main St" state="Delhi" pc="110001"/>
    <Pht>photo_data</Pht>
  </UidData>
  <Signature>trusted_signature</Signature>
</OfflinePaperlessKyc>`;

  test('Parses valid XML content successfully', () => {
    const result = xmlParser.parseXml(validXml);
    expect(result.parsed).toBeDefined();
    expect(result.raw).toBe(validXml);
  });

  test('Extracts identity data correctly from parsed XML', () => {
    const { parsed } = xmlParser.parseXml(validXml);
    const identity = xmlParser.extractIdentity(parsed);

    expect(identity.name).toBe('Alice Student');
    expect(identity.dob).toBe('2005-05-15');
    expect(identity.gender).toBe('F');
    expect(identity.address.pincode).toBe('110001');
    expect(identity.hasSignature).toBe(true);
  });

  test('Rejects XML containing DOCTYPE injection (XXE vector)', () => {
    const badXml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE test [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>
<OfflinePaperlessKyc shareCode="1234">
  <UidData><Poi name="Alice" dob="2005-05-15" gender="F"/></UidData>
</OfflinePaperlessKyc>`;

    expect(() => xmlParser.parseXml(badXml)).toThrow('MALFORMED_XML');
  });

  test('Rejects XML containing ENTITY declarations', () => {
    const badXml = `<?xml version="1.0" encoding="UTF-8"?>
<!ENTITY myentity "val">
<OfflinePaperlessKyc shareCode="1234">
  <UidData><Poi name="Alice" dob="2005-05-15" gender="F"/></UidData>
</OfflinePaperlessKyc>`;

    expect(() => xmlParser.parseXml(badXml)).toThrow('MALFORMED_XML');
  });

  test('Throws error for empty XML content', () => {
    expect(() => xmlParser.parseXml('')).toThrow('MISSING_XML_CONTENT');
    expect(() => xmlParser.parseXml(null)).toThrow('MISSING_XML_CONTENT');
  });

  test('Throws error on missing required elements', () => {
    const missingUidXml = `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="1234">
  <Signature>sig</Signature>
</OfflinePaperlessKyc>`;

    const { parsed } = xmlParser.parseXml(missingUidXml);
    expect(() => xmlParser.extractIdentity(parsed)).toThrow('INVALID_XML');
  });

});

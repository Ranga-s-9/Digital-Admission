# emSigner Digital Signature Integration

This document describes the design, API endpoints, adapter structures, and validation rules of the **emSigner (by eMudhra)** module in the **Digital Student Admission System**.

---

## 1. Overview
Before an admission application can be reviewed by university staff, the student must legally sign their application using emSigner, a digital public infrastructure (DPI) signing adapter.

---

## 2. API Endpoints

| Method | Endpoint | Allowed Roles | Description |
| :--- | :--- | :---: | :--- |
| **POST** | `/api/emsigner/sign` | `student` | Initiates the eSign challenge, validates state, and writes the signed document signature. |
| **GET** | `/api/emsigner/status` | `student`, `professor` | Queries the current signature status for the authenticated student context (or filtered by `?userId=` for professors). |
| **GET** | `/api/emsigner/history` | `professor` | Retrieves the immutable audit log history of signature requests. |

---

## 3. Modular Adapter Design & Configuration
The emSigner service implements an adapter pattern:

```
            +------------------------+
            |     EmsignerAdapter    | (Base Interface Class)
            +------------------------+
                        ^
                        |
          +-------------+-------------+
          |                           |
 +------------------+        +------------------+
 | MockEmsigner     |        | RealEmsigner     |
 +------------------+        +------------------+
 (Generates mock link        (Dispatches API    
  & auto-resolves status)     requests with key)
```

### Environment Configuration
The adapter factory selects the implementation dynamically via environment variables in `.env`:
* `EMSIGNER_MODE=mock` (default): Serves simulated signature frames, logs events locally, and auto-completes flows without real costs.
* `EMSIGNER_MODE=production`: Submits real HTTP payloads to the developer portal URL.
* `EMSIGNER_API_KEY`: API credential key. The `RealEmsignerAdapter` throws a validation error if this variable is missing/empty during initialization in production mode.
* `EMSIGNER_API_URL`: API gateway endpoint.

---

## 4. Backend Workflow & DB Enforcements
When a request is submitted to `POST /api/emsigner/sign`:
1. **State Check**: The application status is queried. The request is rejected unless the application is in the `PENDING_SIGNATURE` status.
2. **Double-Sign Block**: If an active, successful record already exists in `emsigner_requests` for this user, the operation is blocked with a `409 Conflict`.
3. **Execution**: The emSigner adapter is executed to initiate the signature transaction, creating an entry in `emsigner_requests` (with `sign_request_id` and status `Pending`).
4. **Transition**: Once signature confirmation returns successfully:
   * The application is promoted to the `SIGNED` state.
   * A notification is dispatched to the user.
   * An entry is written to `emsigner_audit_logs` capturing execution timestamps and client IP.

const rateLimitStore = {};
let limiterCounter = 0;

/**
 * Lightweight memory-based rate limiting middleware isolated per route instance
 */
function rateLimiter({ windowMs = 60 * 1000, max = 30, message = 'Too many requests, please try again later.' } = {}) {
  const limiterId = ++limiterCounter;

  // Periodically clean up expired rate limiter keys to prevent memory leaks
  setInterval(() => {
    const now = Date.now();
    for (const storeKey in rateLimitStore) {
      rateLimitStore[storeKey] = rateLimitStore[storeKey].filter(timestamp => now - timestamp < windowMs);
      if (rateLimitStore[storeKey].length === 0) {
        delete rateLimitStore[storeKey];
      }
    }
  }, 10 * 60 * 1000).unref(); // Runs every 10 minutes, unref to not block process exit

  return (req, res, next) => {
    // Skip rate limiting during testing if desired, or keep it active but generous
    if (process.env.NODE_ENV === 'test') {
      return next();
    }

    const ip = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
    const storeKey = `${limiterId}:${ip}`;
    const now = Date.now();

    if (!rateLimitStore[storeKey]) {
      rateLimitStore[storeKey] = [];
    }

    // Filter out timestamps outside the time window
    rateLimitStore[storeKey] = rateLimitStore[storeKey].filter(timestamp => now - timestamp < windowMs);

    if (rateLimitStore[storeKey].length >= max) {
      return res.status(429).json({
        success: false,
        message: message,
        error: { global: 'Rate limit exceeded' }
      });
    }

    rateLimitStore[storeKey].push(now);
    next();
  };
}

module.exports = rateLimiter;

const crypto = require('crypto');

/**
 * Attaches a unique request/trace ID to every incoming request.
 * - Reuses an inbound X-Request-Id header if a caller already supplied one
 *   (useful when this service sits behind a gateway/load balancer that
 *   generates its own correlation IDs), otherwise generates a fresh UUID.
 * - Echoes the ID back on the response so clients can reference it when
 *   reporting issues, and so it can be cross-referenced against server logs.
 */
function requestId(req, res, next) {
  const inboundId = req.headers['x-request-id'];
  const id = (typeof inboundId === 'string' && /^[a-zA-Z0-9-]{1,100}$/.test(inboundId))
    ? inboundId
    : crypto.randomUUID();

  req.id = id;
  res.setHeader('X-Request-Id', id);
  next();
}

module.exports = requestId;

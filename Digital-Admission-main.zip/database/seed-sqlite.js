/**
 * SQLite-compatible seed script
 * Creates demo accounts for development/testing.
 *
 * Demo accounts:
 *   Student:   student@dpi.edu   / Password@123
 *   Professor: prof@dpi.edu      / Password@123
 */

const db = require('../backend/config/db');
const bcrypt = require('bcryptjs');

async function seed() {
  console.log('Seeding demo accounts into SQLite database...');

  // Generate bcrypt hash at runtime to ensure correctness
  const passwordHash = await bcrypt.hash('Password@123', 10);
  console.log('Generated password hash for Password@123');

  // -- Demo Student --
  const existingStudent = await db.query('SELECT id FROM users WHERE email = ?', ['student@dpi.edu']);
  if (existingStudent.length === 0) {
    await db.query(
      `INSERT INTO users (name, email, mobile, password_hash, role, status, failed_attempts, lockout_until)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ['Alice Student', 'student@dpi.edu', '9111122222', passwordHash, 'student', 'active', 0, 0]
    );
    console.log('  ✓ Demo student created: student@dpi.edu');
  } else {
    console.log('  • Demo student already exists, skipping.');
  }

  // Get the student user id for profile insert
  const [studentRow] = await db.query('SELECT id FROM users WHERE email = ?', ['student@dpi.edu']);
  if (studentRow) {
    const profileExists = await db.query('SELECT user_id FROM student_profiles WHERE user_id = ?', [studentRow.id]);
    if (profileExists.length === 0) {
      await db.query(
        'INSERT INTO student_profiles (user_id, version) VALUES (?, ?)',
        [studentRow.id, 1]
      );
      console.log('  ✓ Demo student profile created.');
    }

    const notifExists = await db.query('SELECT id FROM notifications WHERE user_id = ?', [studentRow.id]);
    if (notifExists.length === 0) {
      await db.query(
        `INSERT INTO notifications (user_id, title, content, type) VALUES (?, ?, ?, ?)`,
        [
          studentRow.id,
          'Welcome to DPI Admission Portal',
          'Your account has been created. Please complete your student profile and begin your admission application.',
          'info'
        ]
      );
      console.log('  ✓ Welcome notification created.');
    }
  }

  // -- Demo Professor --
  const existingProf = await db.query('SELECT id FROM users WHERE email = ?', ['prof@dpi.edu']);
  if (existingProf.length === 0) {
    await db.query(
      `INSERT INTO users (name, email, mobile, password_hash, role, status, failed_attempts, lockout_until)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ['Prof. Rajan', 'prof@dpi.edu', '9444455555', passwordHash, 'professor', 'active', 0, 0]
    );
    console.log('  ✓ Demo professor created: prof@dpi.edu');
  } else {
    console.log('  • Demo professor already exists, skipping.');
  }

  console.log('\nSeeding complete!');
  console.log('---------------------------------------');
  console.log('Demo credentials (password for both: Password@123)');
  console.log('  Student:   student@dpi.edu');
  console.log('  Professor: prof@dpi.edu');
  console.log('---------------------------------------');
  process.exit(0);
}

seed().catch(err => {
  console.error('Seed failed:', err.message);
  process.exit(1);
});

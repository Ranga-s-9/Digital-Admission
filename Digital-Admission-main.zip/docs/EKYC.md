# Aadhaar Offline eKYC Subsystem

This document describes the design, implementation, and verification logic of the **Aadhaar Offline eKYC** module in the **Digital Student Admission System**.

---

## 1. Overview
The eKYC module verifies the applicant's identity using their secure, digitally-signed Offline Aadhaar XML file (issued by UIDAI), which includes their masked Aadhaar number, name, date of birth, gender, address details, and photo.

---

## 2. Architecture & Adapter Pattern
To isolate external dependencies during development, the eKYC service uses a decoupled adapter design:

```
           +------------------------+
           |      EkycAdapter       | (Base Interface Class)
           +------------------------+
                       ^
                       |
         +-------------+-------------+
         |                           |
+-------------------+       +-------------------+
|  MockEkycAdapter  |       |  RealEkycAdapter  |
+-------------------+       +-------------------+
(Simulates XML parsing      (Validates XML signature
 & returns mock data)        via real UIDAI certificates)
```

### eKYC Mode Configuration
The system selects the adapter dynamically using environment variables:
* `EKYC_MODE=mock` (default): Emulates Aadhaar XML parsing and returns simulated demographic responses.
* `EKYC_MODE=production`: Intended to parse and cryptographically verify the digital signature of the XML files against UIDAI certificates.

---

## 3. Server-side Identity-Matching Logic
When a student uploads an Offline XML file and submits their 4-digit share code, the backend (`ekycController.verify`) executes the following operations:
1. **XML Parsing**: Extracts the applicant's name, DOB, gender, and pincode.
2. **Profile Comparison**: Compares the extracted XML fields against the student's saved profile (`student_profiles`):
   * **Name**: Checked using case-insensitive partial match or Levenshtein distance rules.
   * **DOB**: Must match the profile DOB exactly.
   * **Gender**: Must match the profile gender exactly.
   * **Pincode**: Must match the profile pincode exactly.
3. **Status Promotion**:
   * If all parameters align, the status in `ekyc_requests` is set to `Verified`.
   * The application state in `admission_applications` is automatically updated and promoted based on the workflow state machine rules.
4. **Immutable Logging**: A success/failure record is appended to the `ekyc_audit_logs` table, storing the client's IP and execution metadata.

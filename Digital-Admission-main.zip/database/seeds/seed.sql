-- =============================================================================
-- Seed Data: DPI Student Admission System
-- Populates the database with initial reference data and two demo accounts.
--
-- Demo Accounts (password for both: Password@123)
--   Student:   student@dpi.edu   / 9111122222
--   Professor: prof@dpi.edu      / 9444455555
--
-- bcrypt hash of "Password@123" with saltRounds=10:
--   $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
-- =============================================================================

-- Reference: Roles (safe to re-insert with IGNORE)
INSERT IGNORE INTO roles (name, description) VALUES
  ('student',   'Registered student applying for admission'),
  ('professor', 'Academic staff member who reviews applications'),
  ('admin',     'System administrator with full access');

-- Demo Users
INSERT IGNORE INTO users
  (name, email, mobile, password_hash, role, role_id, status, failed_attempts, lockout_until)
VALUES
  (
    'Alice Student',
    'student@dpi.edu',
    '9111122222',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    'student',
    (SELECT id FROM roles WHERE name = 'student'),
    'active',
    0,
    0
  ),
  (
    'Prof. Rajan',
    'prof@dpi.edu',
    '9444455555',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    'professor',
    (SELECT id FROM roles WHERE name = 'professor'),
    'active',
    0,
    0
  );

-- Default profile for the demo student
INSERT IGNORE INTO student_profiles (user_id, version)
SELECT id, 1 FROM users WHERE email = 'student@dpi.edu';

-- Welcome notification for demo student
INSERT IGNORE INTO notifications (user_id, title, content, type)
SELECT
  u.id,
  'Welcome to DPI Admission Portal',
  'Your account has been created. Please complete your student profile and begin your admission application.',
  'info'
FROM users u
WHERE u.email = 'student@dpi.edu';

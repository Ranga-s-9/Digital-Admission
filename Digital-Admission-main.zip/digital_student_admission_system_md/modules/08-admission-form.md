# Module 08 — Digital Admission Form

## Purpose

Convert the student admission application into a digital, trackable form.

## Important Source Note

The mandatory list in the supplied notes says “Filling / submitting leave form”, while the project title is a student admission system. This module uses an admission application form as the logical business form, but the wording should be confirmed with the instructor.

## Functional Requirements

- Create application.
- Save draft.
- Edit draft.
- Validate fields.
- Associate documents.
- Display eKYC status.
- Submit application.
- Generate an application reference.
- Track application status.

## Suggested Statuses

```text
DRAFT
  |
  v
SUBMITTED
  |
  v
UNDER_REVIEW
  |
  v
VERIFIED
  |
  v
SIGNED
  |
  +----> APPROVED
  |
  +----> REJECTED
```

## Submission Rules

- Required fields must be complete.
- Required verification conditions must be satisfied according to institutional policy.
- Submission should create an auditable event.
- A submitted application should not be silently overwritten.

## Acceptance Criteria

- Student can save a draft.
- Student can reopen a draft.
- Invalid applications cannot be submitted.
- Successful submission creates an application ID/reference.
- Status is visible to the student and authorized institutional users.

## Dependencies

- Student Profile
- eKYC
- Documents
- Database
- Authentication

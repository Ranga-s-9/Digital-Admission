/**
 * Central router and session manager for DPI Student Admission System
 */
(function() {
  const views = {
    home: document.getElementById('homeView'),
    register: document.getElementById('registerView'),
    login: document.getElementById('loginView'),
    forgotPassword: document.getElementById('forgotPasswordView'),
    resetPassword: document.getElementById('resetPasswordView'),
    otp: document.getElementById('otpView'),
    dashboard: document.getElementById('dashboardView')
  };

  const profile = {
    name: document.getElementById('profileName'),
    email: document.getElementById('profileEmail'),
    mobile: document.getElementById('profileMobile'),
    role: document.getElementById('profileRole')
  };

  const logoutBtn = document.getElementById('logoutBtn');

  // Verify and fetch profile data from protected endpoint
  async function fetchProfile() {
    try {
      const response = await fetch('/api/auth/me');
      const result = await response.json();

      if (response.ok && result.success) {
        const user = result.data.user;
        if (profile.name) {
          if (profile.name.tagName === 'INPUT') profile.name.value = user.name;
          else profile.name.textContent = user.name;
        }
        if (profile.email) {
          if (profile.email.tagName === 'INPUT') profile.email.value = user.email;
          else profile.email.textContent = user.email;
        }
        if (profile.mobile) {
          if (profile.mobile.tagName === 'INPUT') profile.mobile.value = user.mobile;
          else profile.mobile.textContent = user.mobile;
        }
        if (profile.role) {
          if (profile.role.tagName === 'INPUT') profile.role.value = user.role;
          else profile.role.textContent = user.role;
        }

        const userFooterName = document.getElementById('userFooterName');
        const userFooterRole = document.getElementById('userFooterRole');
        const userInitials = document.getElementById('userInitials');
        if (userFooterName) userFooterName.textContent = user.name || user.email;
        if (userFooterRole) userFooterRole.textContent = user.role;
        if (userInitials) {
          const initials = (user.name || 'U').split(' ').filter(Boolean).map(n => n[0]).join('').substring(0, 2).toUpperCase();
          userInitials.textContent = initials || 'U';
        }

        const navApp = document.getElementById('navApplication');
        if (navApp) {
          navApp.style.display = user.role === 'student' ? 'flex' : 'none';
        }
        const navEkyc = document.getElementById('navEkyc');
        if (navEkyc) {
          navEkyc.style.display = user.role === 'student' ? 'flex' : 'none';
        }
        const navDigilocker = document.getElementById('navDigilocker');
        if (navDigilocker) {
          navDigilocker.style.display = user.role === 'student' ? 'flex' : 'none';
        }
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to fetch user session:', err);
      return false;
    }
  }

  // Expose fetchProfile globally for login.js/otp.js to trigger on success
  window.fetchProfile = fetchProfile;

  // SPA client-side hash router
  async function router() {
    const hash = window.location.hash || '#/home';
    
    // Clean up OTP session context if navigating away from OTP/Dashboard views
    if (hash !== '#/verify-otp' && hash !== '#/dashboard') {
      sessionStorage.removeItem('otpSessionId');
      sessionStorage.removeItem('otpContext');
    }
    
    // Hide all views initially
    Object.keys(views).forEach(key => {
      if (views[key]) views[key].style.display = 'none';
    });

    if (hash === '#/dashboard') {
      document.body.classList.add('dashboard-active');
      document.body.classList.remove('home-active');
    } else if (hash === '#/home') {
      document.body.classList.add('home-active');
      document.body.classList.remove('dashboard-active');
    } else {
      document.body.classList.remove('dashboard-active');
      document.body.classList.remove('home-active');
    }

    if (hash === '#/login') {
      window.location.hash = '#/login-student';
      return;
    }

    if (hash === '#/register') {
      window.location.hash = '#/register-student';
      return;
    }

    if (hash === '#/home') {
      if (views.home) views.home.style.display = 'block';
    } else if (hash === '#/login-student' || hash === '#/login-professor') {
      views.login.style.display = 'block';
      if (window.loadLoginCaptcha) {
        window.loadLoginCaptcha();
      }

      const loginRoleInput = document.getElementById('loginRoleInput');
      const loginTitle = document.getElementById('loginTitle');
      const loginSubtitle = document.getElementById('loginSubtitle');
      const toRegisterLink = document.getElementById('toRegisterLink');
      const loginEmailInput = document.getElementById('loginEmail');

      const role = hash === '#/login-professor' ? 'professor' : 'student';

      if (loginRoleInput) loginRoleInput.value = role;

      const lastEmail = sessionStorage.getItem('lastRegisteredEmail');
      const lastName = sessionStorage.getItem('lastRegisteredName');

      if (loginEmailInput && lastEmail && !loginEmailInput.value) {
        loginEmailInput.value = lastEmail;
      }

      if (role === 'student') {
        if (loginTitle) loginTitle.textContent = 'Student Portal Login';
        if (loginSubtitle) {
          loginSubtitle.textContent = lastName 
            ? `Welcome ${lastName}! Sign in with your email (${lastEmail || ''})`
            : 'Sign in to access your student admission portal';
        }
        if (toRegisterLink) toRegisterLink.setAttribute('href', '#/register-student');
      } else {
        if (loginTitle) loginTitle.textContent = 'Professor Portal Login';
        if (loginSubtitle) {
          loginSubtitle.textContent = lastName 
            ? `Welcome ${lastName}! Sign in with your email (${lastEmail || ''})`
            : 'Sign in to access your administrative dashboard';
        }
        if (toRegisterLink) toRegisterLink.setAttribute('href', '#/register-professor');
      }
    } else if (hash === '#/register-student' || hash === '#/register-professor') {
      views.register.style.display = 'block';
      if (window.loadRegisterCaptcha) {
        window.loadRegisterCaptcha();
      }

      const roleInput = document.getElementById('roleInput');
      const registerTitle = document.getElementById('registerTitle');
      const registerSubtitle = document.getElementById('registerSubtitle');
      const toLoginLink = document.getElementById('toLoginLink');

      const role = hash === '#/register-professor' ? 'professor' : 'student';

      if (roleInput) roleInput.value = role;

      if (role === 'student') {
        if (registerTitle) registerTitle.textContent = 'Student Admission';
        if (registerSubtitle) registerSubtitle.textContent = 'Register your account to begin enrollment';
        if (toLoginLink) toLoginLink.setAttribute('href', '#/login-student');
      } else {
        if (registerTitle) registerTitle.textContent = 'Professor Registration';
        if (registerSubtitle) registerSubtitle.textContent = 'Register your administrative account';
        if (toLoginLink) toLoginLink.setAttribute('href', '#/login-professor');
      }
    } else if (hash === '#/forgot-password') {
      if (views.forgotPassword) {
        views.forgotPassword.style.display = 'block';
        if (window.loadForgotPasswordCaptcha) {
          window.loadForgotPasswordCaptcha();
        }
      }
    } else if (hash === '#/reset-password') {
      const resetTokenId = sessionStorage.getItem('resetTokenId');
      if (resetTokenId && views.resetPassword) {
        views.resetPassword.style.display = 'block';
        const resetTokenIdInput = document.getElementById('resetTokenIdInput');
        if (resetTokenIdInput) resetTokenIdInput.value = resetTokenId;
      } else {
        window.location.hash = '#/forgot-password';
      }
    } else if (hash === '#/verify-otp') {
      let otpContext = window.tempOtpContext;
      if (!otpContext) {
        const cached = sessionStorage.getItem('otpContext');
        if (cached) {
          try {
            otpContext = JSON.parse(cached);
          } catch (e) {
            console.error('Failed to parse cached OTP context:', e);
          }
        }
      }

      if (otpContext && otpContext.otpSessionId) {
        views.otp.style.display = 'block';
        if (window.initOtpView) {
          window.initOtpView(otpContext.otpSessionId, otpContext);
        }
        // Clean memory context after view initialization
        if (window.tempOtpContext) {
          delete window.tempOtpContext;
        }
      } else {
        // Fallback to login if no active OTP session exists
        window.location.hash = '#/login-student';
      }
    } else if (hash === '#/dashboard') {
      const isSessionActive = await fetchProfile();
      if (isSessionActive) {
        views.dashboard.style.display = 'block';
        if (window.initDashboardView) {
          await window.initDashboardView();
        }
      } else {
        document.body.classList.remove('dashboard-active');
        // Protected route access denied: fallback to login
        window.location.hash = '#/login-student';
      }
    } else {
      // Default fallback
      window.location.hash = '#/home';
    }
  }

  const resetDemoBtn = document.getElementById('resetDemoBtn');
  if (resetDemoBtn) {
    resetDemoBtn.addEventListener('click', async () => {
      const confirmReset = confirm(
        '🔄 Reset Demo Verification Data?\n\nThis will clear all submitted profile details, eKYC verifications, and DigiLocker documents for your account so you can demonstrate the admission workflow to staff from the beginning.'
      );
      if (!confirmReset) return;

      try {
        resetDemoBtn.disabled = true;
        resetDemoBtn.style.opacity = '0.6';

        const response = await fetch('/api/profile/reset', { method: 'POST' });
        const result = await response.json();

        if (response.ok && result.success) {
          alert('✅ ' + result.message);
          if (window.initDashboardView) {
            await window.initDashboardView();
          } else {
            window.location.reload();
          }
        } else {
          alert('❌ Failed to reset demo data: ' + (result.message || 'Unknown error'));
        }
      } catch (err) {
        console.error('Reset demo data error:', err);
        alert('❌ Network error while resetting demo data.');
      } finally {
        resetDemoBtn.disabled = false;
        resetDemoBtn.style.opacity = '1';
      }
    });
  }

  // Handle user logout action
  logoutBtn.addEventListener('click', async () => {
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST' });
      const result = await response.json();
      
      if (response.ok && result.success) {
        // Redirection triggers route refresh
        window.location.hash = '#/login-student';
      }
    } catch (err) {
      console.error('Logout error:', err);
    }
  });

  // Watch for page swaps
  window.addEventListener('hashchange', router);

  // Initialize router check on startup
  window.addEventListener('load', async () => {
    const hasActiveSession = await fetchProfile();
    const hash = window.location.hash;
    
    if (hasActiveSession) {
      if (hash !== '#/dashboard') {
        window.location.hash = '#/dashboard';
      } else {
        router();
      }
    } else {
      router();
    }
  });
})();

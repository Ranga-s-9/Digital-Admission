'use strict';

const db = require('../../config/db');

/**
 * eKYC Consent Service
 *
 * Records and validates explicit user consent before identity verification.
 * Consent is versioned and timestamped — never created automatically.
 */

const CURRENT_CONSENT_VERSION = '1.0';
const CONSENT_TYPE = 'ekyc_identity_verification';

/**
 * Record user consent for eKYC verification
 * @param {object} params
 * @param {number} params.studentId - The student's user ID
 * @param {string} params.ipAddress - Client IP address
 * @returns {Promise<{ id: number, consentVersion: string }>}
 */
async function recordConsent({ studentId, ipAddress }) {
  if (!studentId) {
    const err = new Error('CONSENT_REQUIRED');
    err.code = 'CONSENT_REQUIRED';
    err.detail = 'Student ID is required to record consent';
    throw err;
  }

  const result = await db.query(
    `INSERT INTO ekyc_consents (student_id, consent_type, consent_version, consented, ip_address, consented_at)
     VALUES (?, ?, ?, 1, ?, ${db.dbType === 'mysql' ? 'CURRENT_TIMESTAMP' : "datetime('now')"})`,
    [studentId, CONSENT_TYPE, CURRENT_CONSENT_VERSION, ipAddress || null]
  );

  const insertId = result.insertId || result.lastID;

  return {
    id: insertId,
    consentVersion: CURRENT_CONSENT_VERSION
  };
}

/**
 * Check whether a student has provided valid consent for eKYC
 * @param {number} studentId
 * @returns {Promise<{ hasConsent: boolean, latestConsent: object|null }>}
 */
async function checkConsent(studentId) {
  if (!studentId) {
    return { hasConsent: false, latestConsent: null };
  }

  const rows = await db.query(
    `SELECT id, consent_type, consent_version, consented, consented_at, created_at
     FROM ekyc_consents
     WHERE student_id = ? AND consented = 1
     ORDER BY ${db.dbType === 'mysql' ? 'id DESC' : 'id DESC'}
     LIMIT 1`,
    [studentId]
  );

  if (rows && rows.length > 0) {
    return {
      hasConsent: true,
      latestConsent: rows[0]
    };
  }

  return { hasConsent: false, latestConsent: null };
}

/**
 * Get full consent history for a student
 * @param {number} studentId
 * @returns {Promise<Array>}
 */
async function getConsentHistory(studentId) {
  const rows = await db.query(
    `SELECT id, consent_type, consent_version, consented, ip_address, consented_at, created_at
     FROM ekyc_consents
     WHERE student_id = ?
     ORDER BY id DESC, created_at DESC`,
    [studentId]
  );

  return rows || [];
}

module.exports = {
  recordConsent,
  checkConsent,
  getConsentHistory,
  CURRENT_CONSENT_VERSION,
  CONSENT_TYPE
};

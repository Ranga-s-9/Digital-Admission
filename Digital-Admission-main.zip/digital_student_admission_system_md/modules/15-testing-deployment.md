# Module 15 — Testing & Deployment

## Purpose

Validate the complete system and prepare it for controlled execution.

## Testing Levels

### Unit Testing

Test individual services and functions.

### API Testing

Use Postman and automated tests to verify:

- Registration
- Login
- OTP
- Student profile
- Admission
- eKYC adapter
- Document adapter
- eSign adapter
- Admin operations

### Integration Testing

Verify communication between modules.

### End-to-End Testing

Primary scenario:

```text
Register
  |
  v
CAPTCHA
  |
  v
OTP
  |
  v
Login / SSO
  |
  v
Dashboard
  |
  v
Profile
  |
  v
eKYC
  |
  v
DigiLocker / Documents
  |
  v
Admission Form
  |
  v
eSignzy
  |
  v
Paperless Workflow
  |
  v
Admin Review
```

## Deployment

The notes identify XAMPP for local website hosting and MySQL as the preferred database.

### Local Environment

```text
Browser
   |
   v
XAMPP / Application Server
   |
   +---- Backend
   |
   +---- Frontend
   |
   v
MySQL
```

## Environment Configuration

Use an `.env` or equivalent secret configuration for:

- Database credentials
- OTP provider credentials
- eSignzy credentials
- Other third-party API keys

Never commit real credentials.

## Acceptance Criteria

- Clean installation works from documented steps.
- Database migrations/setup work.
- All mandatory flows pass.
- API tests pass.
- Authentication and authorization tests pass.
- External integrations are mocked or configured through approved credentials.
- No secret credentials are included in source control.

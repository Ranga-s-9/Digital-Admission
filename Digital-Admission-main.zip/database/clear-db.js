const db = require('../backend/config/db');

async function clearDatabase() {
  console.log('Clearing database tables...');
  try {
    await db.query('DELETE FROM notifications');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM admission_applications');
    await db.query('DELETE FROM otps');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM audit_logs');
    await db.query('DELETE FROM users');
    
    // Reset SQLite auto-increment counter
    try {
      await db.query("DELETE FROM sqlite_sequence WHERE name='users'");
    } catch (e) {
      // sqlite_sequence might not exist if empty
    }

    console.log('Database successfully cleared. All previous data deleted.');
    process.exit(0);
  } catch (error) {
    console.error('Error clearing database:', error);
    process.exit(1);
  }
}

clearDatabase();

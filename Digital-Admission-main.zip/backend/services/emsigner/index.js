const MockEmsignerAdapter = require('./mockEmsignerAdapter');
const RealEmsignerAdapter = require('./realEmsignerAdapter');

/**
 * emSigner Adapter Factory
 *
 * Returns the appropriate adapter based on EMSIGNER_MODE environment variable.
 * Defaults to 'mock' to ensure safe development usage.
 *
 * @returns {EmsignerAdapter} Configured adapter instance
 */
function getEmsignerAdapter() {
  const mode = process.env.EMSIGNER_MODE || 'mock';

  if (mode === 'production') {
    return new RealEmsignerAdapter();
  }

  // Default: mock mode (safe for development)
  return new MockEmsignerAdapter();
}

module.exports = { getEmsignerAdapter };

# System Architecture Documentation

This document outlines the architectural blueprint, data flow, and components of the **Digital Student Admission System**.

---

## 1. High-Level Architecture Diagram
The system is built on a modular client-server model using a Single Page Application (SPA) frontend and a RESTful backend API.

```mermaid
graph TD
  subgraph Frontend [Web Client - SPA]
    UI[HTML/CSS Glassmorphic Views]
    ValF[Frontend Validation Layer]
    Router[JS Client Hash Router]
    LoginJS[JS Login Handler]
    OtpJS[JS OTP Handler]
    RegJS[JS Registration Handler]
  end

  subgraph Backend [Express API Server]
    Sec[Helmet/CORS Security Headers]
    Cookie[Cookie Parser Middleware]
    ValB[Express Validator Sanitizer]
    AuthM[JWT Auth Middleware]
    RbacM[RBAC Middleware]
    Ctrl[Auth, Captcha, Dashboard, Profile, Admission, eKYC, DigiLocker, eSignzy Controllers]
    Model[User, Captcha, Otp, Profile, Application, AuditLog Models]
  end

  subgraph Database [Storage Layer]
    DBConfig[Unified DB Interface]
    DB[(SQLite3 / MySQL Server)]
  end

  UI -->|Input Blur/Typing| ValF
  Router -->|GET /api/auth/me| Sec
  LoginJS -->|POST /api/auth/login| Sec
  OtpJS -->|POST /api/auth/verify-otp| Sec
  RegJS -->|POST /api/auth/register| Sec
  Sec --> Cookie
  Cookie --> ValB
  ValB --> AuthM
  AuthM --> RbacM
  RbacM -->|req.user| Ctrl
  Ctrl -->|SQL| Model
  Model -->|Prepared SQL| DBConfig
  DBConfig --> DB
```

---

## 2. Component Layout

### Frontend (SPA)
* **index.html**: Root structure. Employs semantic markup conforming to accessibility guidelines (ARIA labels) and hosts SPA tab panels.
* **css/style.css**: Theme styling featuring responsive grid, glassmorphic backgrounds, focus state glowing, active notification alerts, and transition layouts.
* **js/app.js**: SPA hash router (`#/register`, `#/login`, `#/verify-otp`, `#/dashboard`) and session validation layer.
* **js/register.js** / **js/login.js** / **js/otp.js**: Authentication blurs, inline inputs verification, captcha updates, and form submissions.
* **js/dashboard.js** / **js/profile.js** / **js/admission.js**: Dashboard data population, checklist status trackers, optimistic lock form updates, and step-by-step application draft saves.
* **js/ekyc.js** / **js/digilocker.js** / **js/workflow.js**: Local Offline Aadhaar XML loading/upload, OAuth popup postMessage callback listeners, and state review actions.

### Backend API
* **server.js**: App startup sequence, server initialization.
* **app.js**: Express routing middleware mounting point, Helmet configuration, cookie parsing, and static directory serving.
* **routes/**: Routes directory separating auth, profile, application, ekyc, digilocker, notifications, esignzy, and audit logs endpoints.
* **controllers/**: Business coordinators matching data models, executing calculations, and triggering logging/notifications.
* **middleware/auth.js**: Session token authorization middleware verifying HTTP-Only JWT cookie, mounting session user roles, and returning status codes.
* **middleware/rbac.js**: Role check validator validating user permissions.
* **middleware/validation.js**: Input validators executing express-validation chains.
* **services/otpProvider.js**: OTP generator and dispatch service writing mock codes to `scratch/mock_otp.txt` inside development/test environments.
* **config/db.js**: Low-level database pool connector supporting SQLite and MySQL prepared parameters query execution.
* **services/dbService.js**: DB tables initialization and indexes checker.

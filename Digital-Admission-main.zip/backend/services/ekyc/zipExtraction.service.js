'use strict';

const AdmZip = require('adm-zip');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

/**
 * Safe ZIP Extraction Service for eKYC File Uploads
 *
 * Protections:
 * - Path traversal prevention
 * - Zip bomb detection (decompressed size limit)
 * - Only extracts .xml files
 * - Validates file count
 * - Cleanup after processing
 */

// Maximum decompressed size: 10MB
const MAX_DECOMPRESSED_SIZE = 10 * 1024 * 1024;
// Maximum number of entries in ZIP
const MAX_ZIP_ENTRIES = 20;
// Allowed extensions inside ZIP
const ALLOWED_EXTENSIONS = ['.xml'];

/**
 * Safely extract XML content from an uploaded ZIP file
 * @param {Buffer|string} zipInput - ZIP file buffer or path to ZIP file
 * @param {object} [options] - Extraction options
 * @param {number} [options.maxDecompressedSize] - Max decompressed size in bytes
 * @param {number} [options.maxEntries] - Max number of ZIP entries
 * @returns {Promise<{ xmlContent: string, filename: string }>}
 * @throws {Error} INVALID_ZIP | XML_NOT_FOUND | FILE_TOO_LARGE | INVALID_FILE
 */
async function extractXmlFromZip(zipInput, options = {}) {
  const maxSize = options.maxDecompressedSize || MAX_DECOMPRESSED_SIZE;
  const maxEntries = options.maxEntries || MAX_ZIP_ENTRIES;

  const shareCode = options.shareCode || options.password || undefined;

  let zip;
  try {
    zip = new AdmZip(zipInput);
  } catch (err) {
    const error = new Error('INVALID_ZIP');
    error.code = 'INVALID_ZIP';
    error.detail = 'The uploaded file is not a valid ZIP archive';
    throw error;
  }

  const entries = zip.getEntries(shareCode);

  // 1. Check entry count (zip bomb indicator)
  if (entries.length === 0) {
    const error = new Error('INVALID_ZIP');
    error.code = 'INVALID_ZIP';
    error.detail = 'ZIP archive is empty';
    throw error;
  }

  if (entries.length > maxEntries) {
    const error = new Error('INVALID_ZIP');
    error.code = 'INVALID_ZIP';
    error.detail = `ZIP archive contains too many entries (${entries.length}). Maximum: ${maxEntries}`;
    throw error;
  }

  // 2. Check total decompressed size
  let totalSize = 0;
  for (const entry of entries) {
    totalSize += entry.header.size;
    if (totalSize > maxSize) {
      const error = new Error('FILE_TOO_LARGE');
      error.code = 'FILE_TOO_LARGE';
      error.detail = `Decompressed content exceeds maximum size (${Math.round(maxSize / 1024 / 1024)}MB)`;
      throw error;
    }
  }

  // 3. Find XML files, validating path safety
  let xmlEntry = null;

  for (const entry of entries) {
    const entryName = entry.entryName;

    // Path traversal check: reject paths with .. or absolute paths
    if (entryName.includes('..') || path.isAbsolute(entryName)) {
      const error = new Error('INVALID_ZIP');
      error.code = 'INVALID_ZIP';
      error.detail = 'ZIP archive contains entries with unsafe path components';
      throw error;
    }

    // Skip directories
    if (entry.isDirectory) continue;

    // Check extension
    const ext = path.extname(entryName).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      continue; // Skip non-XML files
    }

    // Take the first XML file found
    if (!xmlEntry) {
      xmlEntry = entry;
    }
  }

  if (!xmlEntry) {
    const error = new Error('XML_NOT_FOUND');
    error.code = 'XML_NOT_FOUND';
    error.detail = 'No XML file found inside the ZIP archive';
    throw error;
  }

  // 4. Extract the XML content
  let xmlBuffer;
  try {
    xmlBuffer = xmlEntry.getData(shareCode);
  } catch (extractErr) {
    const error = new Error('INVALID_ZIP');
    error.code = 'INVALID_ZIP';
    error.detail = shareCode ? 'Failed to decompress ZIP entry. Verify that your 4-digit share code is correct.' : 'Failed to decompress ZIP entry';
    throw error;
  }

  // Final size check on actual decompressed data
  if (xmlBuffer.length > maxSize) {
    const error = new Error('FILE_TOO_LARGE');
    error.code = 'FILE_TOO_LARGE';
    error.detail = 'Decompressed XML exceeds maximum allowed size';
    throw error;
  }

  const xmlContent = xmlBuffer.toString('utf8');
  const filename = path.basename(xmlEntry.entryName);

  return { xmlContent, filename };
}

/**
 * Validate that a file buffer appears to be a valid ZIP archive
 * @param {Buffer} buffer - File buffer
 * @returns {boolean}
 */
function isValidZip(buffer) {
  if (!buffer || buffer.length < 4) return false;

  // ZIP magic number: PK\x03\x04
  return buffer[0] === 0x50 && buffer[1] === 0x4B && buffer[2] === 0x03 && buffer[3] === 0x04;
}

/**
 * Validate that a file buffer appears to be XML
 * @param {Buffer|string} content - File content
 * @returns {boolean}
 */
function isValidXml(content) {
  const str = typeof content === 'string' ? content : content.toString('utf8');
  const trimmed = str.trim();
  return trimmed.startsWith('<?xml') || trimmed.startsWith('<OfflinePaperlessKyc');
}

module.exports = {
  extractXmlFromZip,
  isValidZip,
  isValidXml
};

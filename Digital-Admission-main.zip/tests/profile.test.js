// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_profile.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('Student Profile API and Security tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {
        // Ignored
      }
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_profile.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedUser(email, password, role = 'student', mobile = '9111122222') {
    const cap = await getValidCaptcha();
    const registerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: role === 'student' ? 'Alice Student' : 'Professor Bob',
        email,
        mobile,
        password,
        confirmPassword: password,
        role,
        ...cap
      });

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });

    return {
      userId: verifyRes.body.data.userId,
      cookie: verifyRes.headers['set-cookie'][0]
    };
  }

  // --- TEST CASES ---

  test('1. Successful student profile retrieval (automatic profile initialization)', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    const res = await request(app)
      .get(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.profile.email).toBe('alice@student.com');
    expect(res.body.data.profile.version).toBe(1);
    expect(res.body.data.completionPercentage).toBe(0); // empty default
  });

  test('2. Successful student profile update and completion percentage calculation', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    const res = await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-12-01',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 85.50,
        version: 1
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.profile.dob).toBe('2005-12-01');
    expect(res.body.data.profile.percentage).toBe(85.50);
    expect(res.body.data.profile.version).toBe(2);
    expect(res.body.data.completionPercentage).toBe(100); // 10 fields filled
  });

  test('3. Server-side validation rejects malformed input parameters', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // Test wrong pincode, wrong dob format, invalid percentage, invalid gradYear
    const res = await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: 'invalid-date-format',
        gender: 'Male',
        pincode: '12345', // must be 6 digits
        gradYear: 1899,   // must be >= 1900
        percentage: 105.00, // must be <= 100
        version: 1
      });

    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toHaveProperty('dob');
    expect(res.body.error).toHaveProperty('pincode');
    expect(res.body.error).toHaveProperty('gradYear');
    expect(res.body.error).toHaveProperty('percentage');
  });

  test('4. IDOR Block: Student cannot view another student profile', async () => {
    const studentA = await getAuthenticatedUser('studenta@test.com', 'Password@123', 'student', '9111100001');
    const studentB = await getAuthenticatedUser('studentb@test.com', 'Password@123', 'student', '9111100002');

    // Student A tries to GET Student B profile
    const res = await request(app)
      .get(`/api/profile/${studentB.userId}`)
      .set('Cookie', studentA.cookie);

    expect(res.statusCode).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('cannot view another student');
  });

  test('5. IDOR Block: Student cannot update another student profile', async () => {
    const studentA = await getAuthenticatedUser('studenta@test.com', 'Password@123', 'student', '9111100001');
    const studentB = await getAuthenticatedUser('studentb@test.com', 'Password@123', 'student', '9111100002');

    // Student A tries to PUT Student B profile
    const res = await request(app)
      .put(`/api/profile/${studentB.userId}`)
      .set('Cookie', studentA.cookie)
      .send({
        dob: '2005-01-01',
        gender: 'Male',
        version: 1
      });

    expect(res.statusCode).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('cannot modify another user');
  });

  test('6. Concurrent Updates Prevention: Optimistic locking conflict (409 Conflict)', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // User session 1 updates version 1 -> succeeds, version becomes 2
    const res1 = await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-01-01',
        gender: 'Male',
        version: 1
      });
    expect(res1.statusCode).toBe(200);
    expect(res1.body.data.profile.version).toBe(2);

    // User session 2 (still holding version 1 details) tries to update -> conflict!
    const res2 = await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-01-02',
        gender: 'Female',
        version: 1 // obsolete version!
      });

    expect(res2.statusCode).toBe(409);
    expect(res2.body.success).toBe(false);
    expect(res2.body.message).toContain('Concurrent Update Conflict');
  });

  test('7. Malformed request payloads are rejected gracefully', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // Missing version parameter
    const res = await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-01-01'
      });

    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toContain('version key is required');
  });

  test('8. Reset Demo Data: resets student profile and verification state to initial defaults', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // Update profile first
    await request(app)
      .put(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-01-01',
        gender: 'Male',
        degree: 'B.Tech',
        version: 1
      });

    // Reset demo data
    const resReset = await request(app)
      .post('/api/profile/reset')
      .set('Cookie', student.cookie);

    expect(resReset.statusCode).toBe(200);
    expect(resReset.body.success).toBe(true);

    // Verify profile is back to blank defaults
    const resGet = await request(app)
      .get(`/api/profile/${student.userId}`)
      .set('Cookie', student.cookie);

    expect(resGet.body.data.profile.dob).toBe('');
    expect(resGet.body.data.profile.gender).toBe('');
    expect(resGet.body.data.profile.degree).toBe('');
    expect(resGet.body.data.completionPercentage).toBe(0);
  });

});


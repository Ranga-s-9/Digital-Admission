const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const TEST_DB_NAME = 'dpi_test_db';

async function runTests() {
  console.log(`Starting MySQL Database Hardening Smoke Tests on database '${TEST_DB_NAME}'...`);

  if (process.env.DB_TYPE !== 'mysql') {
    console.warn('Skipping MySQL tests: DB_TYPE is not set to mysql in .env');
    return;
  }

  // 1. Establish connection to MySQL server (without database context initially)
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });

  try {
    // 2. Fresh Database Creation
    console.log(`[TEST] Creating fresh test database '${TEST_DB_NAME}'...`);
    await connection.query(`DROP DATABASE IF EXISTS ${TEST_DB_NAME}`);
    await connection.query(`CREATE DATABASE ${TEST_DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await connection.query(`USE ${TEST_DB_NAME}`);
    console.log('✔ Test database created successfully.');

    // 3. Programmatic Migration Execution
    console.log('[TEST] Applying migration files in order...');
    const migrationsDir = path.join(__dirname, 'migrations');
    const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();

    // Setup migration table first
    await connection.query(`
      CREATE TABLE schema_migrations (
        id INT NOT NULL AUTO_INCREMENT,
        filename VARCHAR(255) NOT NULL,
        applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_migration_filename (filename)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    for (const file of files) {
      console.log(`Applying migration: ${file}...`);
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
      await connection.query(sql);
      await connection.query('INSERT INTO schema_migrations (filename) VALUES (?)', [file]);
    }
    console.log('✔ All migrations applied successfully.');

    // 3b. Verify the centralized audit_logs table (Module 14) was created
    // by migration 005 — this table was historically missing from the
    // migration set even though the app auto-created it at boot time via
    // dbService.js, which meant a fresh DB provisioned purely through
    // migrations would silently lack it. Guard against that regressing.
    const [auditLogsTables] = await connection.query(`SHOW TABLES LIKE 'audit_logs'`);
    if (auditLogsTables.length !== 1) {
      throw new Error('Migration verification failed: audit_logs table was not created by the migration set');
    }
    console.log('✔ audit_logs table present after running migrations only (Module 14 regression guard).');

    // 4. Seed Data Verification
    console.log('[TEST] Applying seed data...');
    const seedSql = fs.readFileSync(path.join(__dirname, 'seeds', 'seed.sql'), 'utf8');
    await connection.query(seedSql);

    // Verify seed inserted users
    const [users] = await connection.query('SELECT * FROM users');
    if (users.length !== 2) {
      throw new Error(`Expected 2 seeded users, found ${users.length}`);
    }
    console.log('✔ Seed data verified (Student & Professor present).');

    // 5. Test FK Constraints
    console.log('[TEST] Testing Foreign Key Constraints...');
    try {
      // Try to insert a profile for a non-existent user
      await connection.query(`
        INSERT INTO student_profiles (user_id, dob, version) 
        VALUES (999999, '2000-01-01', 1)
      `);
      throw new Error('FK constraint test failed: inserted profile for invalid user_id');
    } catch (err) {
      if (err.code === 'ER_NO_REFERENCED_ROW_2' || err.code === 'ER_NO_REFERENCED_ROW') {
        console.log('✔ Profile FK constraint verified (blocked orphan profile insert).');
      } else {
        throw err;
      }
    }

    // 6. Test CHECK Constraints (status)
    console.log('[TEST] Testing status CHECK constraints...');
    try {
      await connection.query(`
        INSERT INTO users (name, email, mobile, password_hash, status)
        VALUES ('Test User', 'test@invalid.com', '1234567890', 'hash', 'invalid_status')
      `);
      throw new Error('CHECK constraint test failed: inserted user with invalid status');
    } catch (err) {
      // CHECK constraint violation code in MySQL is ER_CHECK_CONSTRAINT_VIOLATED (3819)
      if (err.code === 'ER_CHECK_CONSTRAINT_VIOLATED' || err.sqlState === '23000') {
        console.log('✔ User status CHECK constraint verified (blocked invalid status).');
      } else {
        throw err;
      }
    }

    // 7. Test CHECK Constraints (percentage)
    try {
      const [student] = await connection.query("SELECT id FROM users WHERE email = 'student@dpi.edu'");
      const studentId = student[0].id;
      await connection.query(`
        UPDATE student_profiles 
        SET percentage = 150.00
        WHERE user_id = ?
      `, [studentId]);
      throw new Error('CHECK constraint test failed: updated percentage to 150');
    } catch (err) {
      if (err.code === 'ER_CHECK_CONSTRAINT_VIOLATED' || err.sqlState === '23000') {
        console.log('✔ Percentage range CHECK constraint verified (blocked percentage > 100).');
      } else {
        throw err;
      }
    }

    // 8. Test UNIQUE Constraints (DigiLocker duplicates)
    console.log('[TEST] Testing UNIQUE constraints (DigiLocker)...');
    const [studentUser] = await connection.query("SELECT id FROM users WHERE email = 'student@dpi.edu'");
    const sId = studentUser[0].id;
    await connection.query(`
      INSERT INTO digilocker_documents (user_id, document_type, doc_uri, verification_status)
      VALUES (?, '10th_Marksheet', 'uri://marksheet10', 'Verified')
    `, [sId]);

    try {
      // Attempt duplicate doc_uri
      await connection.query(`
        INSERT INTO digilocker_documents (user_id, document_type, doc_uri, verification_status)
        VALUES (?, '12th_Marksheet', 'uri://marksheet10', 'Verified')
      `, [sId]);
      throw new Error('UNIQUE constraint test failed: allowed duplicate doc_uri');
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        console.log('✔ DigiLocker duplicate URI UNIQUE constraint verified.');
      } else {
        throw err;
      }
    }

    // 9. Test CASCADE DELETE
    console.log('[TEST] Testing CASCADE DELETE behavior...');
    const [toDelete] = await connection.query("SELECT id FROM users WHERE email = 'student@dpi.edu'");
    const delId = toDelete[0].id;

    // Insert dummy application linked to user
    await connection.query(`
      INSERT INTO admission_applications (user_id, dob, status)
      VALUES (?, '2001-02-03', 'Draft')
    `, [delId]);

    // Delete user
    await connection.query('DELETE FROM users WHERE id = ?', [delId]);

    // Verify children are automatically removed
    const [profRows] = await connection.query('SELECT * FROM student_profiles WHERE user_id = ?', [delId]);
    const [appRows] = await connection.query('SELECT * FROM admission_applications WHERE user_id = ?', [delId]);
    if (profRows.length !== 0 || appRows.length !== 0) {
      throw new Error('CASCADE DELETE test failed: child rows still exist after user deletion');
    }
    console.log('✔ CASCADE DELETE verified successfully (student profile and application removed).');

    // 10. Test Programmatic Rollback (ALL)
    console.log('[TEST] Testing rollback scripts...');
    const rollbackDir = path.join(__dirname, 'rollback');
    const rollbackFiles = fs.readdirSync(rollbackDir).filter(f => f.endsWith('.sql')).sort().reverse();

    for (const rFile of rollbackFiles) {
      console.log(`Executing rollback script: ${rFile}...`);
      const rSql = fs.readFileSync(path.join(rollbackDir, rFile), 'utf8');
      await connection.query(rSql);
    }
    console.log('✔ Rollback scripts completed.');

    // Verify all tables are dropped
    const [tables] = await connection.query(`SHOW TABLES FROM ${TEST_DB_NAME}`);
    if (tables.length > 0) {
      throw new Error(`Rollback failed: some tables still exist: ${JSON.stringify(tables)}`);
    }
    console.log('✔ Rollback verification verified (all tables dropped).');

    // 11. Cleanup test database
    console.log(`[TEST] Cleaning up test database '${TEST_DB_NAME}'...`);
    await connection.query(`DROP DATABASE IF EXISTS ${TEST_DB_NAME}`);
    console.log('✔ Test database dropped.');

    console.log('\n⭐⭐⭐ ALL DATABASE HARDENING SMOKE TESTS PASSED SUCCESSFULLY! ⭐⭐⭐\n');

  } catch (error) {
    console.error('\n❌ DATABASE HARDENING SMOKE TEST FAILED! ❌\n');
    console.error(error);
    
    // Attempt clean up anyway
    try {
      await connection.query(`DROP DATABASE IF EXISTS ${TEST_DB_NAME}`);
    } catch (_) {}
    
    process.exit(1);
  } finally {
    await connection.end();
  }
}

runTests();

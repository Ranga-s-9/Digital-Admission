# Source Notes

Primary source: `DPI_Module2_Notes.pdf`.

The notes establish the project title, problem statement, prerequisites, mandatory registration/login, mathematical CAPTCHA, OTP authentication, dashboard, form submission, eSignzy signing, and learning objectives around APIs, eKYC and related technologies.

Where these Markdown files contain detailed schemas, API endpoint examples, status machines, security controls or module boundaries, those are proposed implementation specifications and are not claimed to be verbatim requirements from the supplied notes.

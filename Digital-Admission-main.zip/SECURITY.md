# Security Design and Controls

This document details the security model, policies, defenses, and auditing mechanisms implemented in the **Digital Student Admission System**.

---

## 1. Authentication & Session Management
* **Stateless JWT Sessions**: Access tokens are signed using `jsonwebtoken` and the `JWT_SECRET` key.
* **HTTP-Only Cookies**: Tokens are stored in a cookie named `token` with `HttpOnly`, `SameSite=Strict`, and `Secure` flags (when in production). This completely mitigates Cross-Site Scripting (XSS) token theft and provides defenses against Cross-Site Request Forgery (CSRF).
* **Automatic Expiration**: JWT sessions are configured with a limited lifespan (1 hour by default) and cleared immediately upon logout via the `POST /api/auth/logout` API.

---

## 2. Anti-Automation & Brute Force Controls
### Mathematical CAPTCHA
* Mathematical CAPTCHA equations (e.g., `12 + 5 = ?`) are generated dynamically via the `GET /api/auth/captcha` endpoint.
* **Expiration**: Challenges expire automatically after 2 minutes to block script replays.
* **Attempt Caps**: Standard CAPTCHA sessions allow a maximum of 3 attempts. Exceeding the threshold automatically deletes the challenge.
* **Bypass Protections**: The CAPTCHA session record is deleted immediately upon successful verification, making it impossible to reuse a token.

### Brute Force Lockout & Rate Limiting
* **Lockout Policy**: Accounts are locked for 15 minutes after 5 consecutive failed login attempts to prevent dictionary/brute-force attacks.
* **Enumeration Defense**: The server returns a generic `"Invalid email address or password"` error for both non-existent users and incorrect passwords to prevent user/email discovery.
* **IP Rate Limiting**: Sensitive routes (CAPTCHA generation, registrations, logins, and OTP requests) are rate-limited per IP using local cache counters.

### OTP (Two-Factor Authentication)
* **Double Verification**: Sessions are not authorized with the final JWT token until a valid 6-digit OTP is verified.
* **Short Lifetime**: OTP sessions expire and delete themselves after 5 minutes.
* **Attempt Lockout**: The OTP session is deleted and the login process must be restarted after 3 incorrect verification attempts.
* **Resend Cooldown**: A mandatory 60-second cooldown is enforced before another OTP can be sent to prevent SMS/email flood abuse. The total resends are capped at 3 per session.

---

## 3. SQL Injection & XSS Defenses
* **Prepared SQL Statements**: Low-level database operations use parameterized binding (`?` placeholders) in both SQLite (`sqlite3`) and MySQL (`mysql2`). Plain queries are never concatenated with user variables.
* **Input Sanitization**: Client payloads are filtered and sanitized in `backend/middleware/validation.js` using `express-validator`'s `.escape()` and `.trim()` filters.
* **Helmet Headers**: Express headers are hardened using `helmet` to enforce:
  * `X-Content-Type-Options: nosniff`
  * `X-Frame-Options: DENY`
  * `Content-Security-Policy` restrict scripts, fonts, and stylesheets to trusted hosts.

---

## 4. Role-Based Access Control (RBAC) & IDOR Defenses
* **Role Check Middleware**: Endpoints are guarded by `requireRole(['student', 'professor', 'admin'])`.
* **Insecure Direct Object Reference (IDOR) Blocks**:
  * **Profiles**: Users can only query or modify the profile matching their own `userId` extracted from the verified session cookie.
  * **Applications**: Students can only view/save their own application draft. Access to other student applications returns `403 Forbidden`.
  * **Audit Logs**: Restricts retrieve endpoints to professors/admin roles exclusively.

---

## 5. Concurrency Controls
* **Optimistic Concurrency Locking**: Student profile changes are guarded by a `version` attribute column. Updates verify that the database version matches the version payload sent by the client. If another update has modified the profile in the meantime, the request is rejected with `409 Conflict`.

# Aadhaar Offline e-KYC Subsystem

This document outlines the design, architecture, security controls, and verification logic of the **Aadhaar Offline e-KYC Subsystem** integrated into the **Digital Student Admission System**.

---

## 1. Subsystem Architecture

The e-KYC subsystem uses an **Adapter Design Pattern** to isolate the core system from external dependencies. This ensures that the admission workflow can operate using either a development mock or a production cryptographic verification process.

```
                 +-----------------------+
                 |     EkycAdapter       |  (Base Interface Class)
                 +-----------------------+
                             ^
                             |
             +---------------+---------------+
             |                               |
    +-----------------+             +-----------------+
    | MockEkycAdapter |             | RealEkycAdapter |
    +-----------------+             +-----------------+
     (Development /                  (Production
      Testing Mock)                   Offline XML)
```

### Active Adapter Selection
The adapter is selected dynamically at startup based on the `EKYC_MODE` environment variable:
* `EKYC_MODE=mock` (default): Uses the `MockEkycAdapter`, which parses the XML structure but bypasses cryptographic signature verification. Perfect for local sandbox environments.
* `EKYC_MODE=offline_xml`: Uses the `RealEkycAdapter`, which extracts the XML, cryptographically validates the digital signature against UIDAI public key certificates, compares hashes, and matches demographics.

---

## 2. Secure Verification Pipeline

When a student submits an Offline e-KYC ZIP file and its 4-digit share code, the backend (`ekycController.verifyEkyc`) executes the following operations in sequence:

```
[Upload ZIP] ──> [Safe Decompress] ──> [Secure XML Parse] ──> [Verify Signature] ──> [Demographic Matching] ──> [Success]
```

### 1. Safe Decompression
The `zipExtraction.service` decompresses the ZIP archive safely:
* **Path Traversal Protection**: Rejects zip entries containing `..` or absolute paths.
* **Zip Bomb Protection**: Enforces a strict decompressed content size limit of 10MB.
* **Extension Guard**: Only extracts `.xml` files, discarding other file types.

### 2. Secure XML Parsing
The `xmlParser.service` parses the XML document:
* **XXE Defense**: Ignores inline `DOCTYPE` declarations, blocks external entities, and disables external DTD processing to prevent XML External Entity (XXE) injection attacks.
* **Size Limit**: Restricts XML parsing to files under 5MB.

### 3. Cryptographic Signature Validation
The `signature.service` verifies the digital signature of the XML content:
* **Production Mode**: Validates the XML signature structure and trust chain using `xml-crypto` against the official UIDAI public key certificate file configured at `EKYC_CERTIFICATE_PATH`.
* **Mock Mode**: Validates the existence of the `<Signature>` element without executing cryptographic operations.

### 4. Hash Match Validation
Aadhaar Offline XML files contain SHA-256 hashes of the applicant's mobile number and email address (salted with the share code). The `hash.service`:
* Normalizes the registered profile's mobile number and email.
* Generates computed SHA-256 hashes.
* Compares them against the XML hashes using constant-time comparison (`crypto.timingSafeEqual`) to prevent timing side-channel attacks.

### 5. Demographic Alignment
The `identityMatching.service` matches the extracted Aadhaar data against the student's profile:
* **Name Normalization**: Collapses whitespace, lowercases, and strips honorifics (e.g. Mr., Mrs., Dr.). Compares using exact, partial substring, and word-reordering comparisons to prevent false failures.
* **DOB Validation**: Formats dates to `YYYY-MM-DD` and requires an exact match.
* **Gender Normalization**: Maps gender codes (`M`, `F`, `T`) to normalized representations (`Male`, `Female`, `Other`) and requires an exact match.
* **Pincode Verification**: Requires an exact match of the pincode.

---

## 3. Database Operations & Audit Logging

### Tables Created
* **`ekyc_consents`**: Logs explicit applicant consent declarations, including consent version, IP address, and timestamp.
* **`ekyc_requests`**: Stores the session-associated eKYC request status, reference ID, masked Aadhaar (`XXXX-XXXX-9999`), and timestamps.
* **`ekyc_audit_logs`**: Immutable history of verification attempts (`CONSENT_CREATED`, `FILE_UPLOADED`, `VERIFICATION_SUCCESS`, `VERIFICATION_FAILED`).

### Security Guards
* **No Raw Document Storage**: The raw XML and uploaded ZIP archive are deleted immediately after parsing.
* **No PII Logging**: Share codes, raw Aadhaar numbers, and full demographic data are never written to the audit logs. Details are sanitized before write.

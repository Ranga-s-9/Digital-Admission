const jwt = require('jsonwebtoken');
const User = require('../models/User');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkeyforjwtauthentication';

/**
 * Middleware to authenticate requests using JWT stored in HTTP-Only cookies
 */
async function authenticateToken(req, res, next) {
  try {
    // Read token from cookies (requires cookie-parser)
    const token = req.cookies ? req.cookies.token : null;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access denied: No session token provided',
        error: {
          auth: 'Authentication required'
        }
      });
    }

    // Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      return res.status(401).json({
        success: false,
        message: 'Access denied: Session expired or invalid',
        error: {
          auth: 'Invalid session'
        }
      });
    }

    // Lookup user in DB to ensure account exists and status is active
    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Access denied: User account not found',
        error: {
          auth: 'User not found'
        }
      });
    }

    if (user.status !== 'active') {
      return res.status(403).json({
        success: false,
        message: 'Access denied: Account is suspended or inactive',
        error: {
          auth: 'Inactive account'
        }
      });
    }

    // Mount user details to request object
    req.user = {
      userId: user.id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      role: user.role
    };

    next();

  } catch (error) {
    console.error('Auth middleware error:', error);
    return res.status(500).json({
      success: false,
      message: 'An error occurred during authentication validation',
      error: {
        global: 'Internal server error'
      }
    });
  }
}

module.exports = authenticateToken;

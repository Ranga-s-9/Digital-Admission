process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_emsigner.sqlite';
process.env.EMSIGNER_MODE = 'mock';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('emSigner Digital Signature API Tests (Module 11)', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM admission_applications');
    await db.query('DELETE FROM emsigner_requests');
    await db.query('DELETE FROM emsigner_audit_logs');
    await db.query('DELETE FROM workflow_audit_logs');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try { fs.unlinkSync(otpFilePath); } catch (e) { /* ignore */ }
    }
  });

  afterAll(async () => {
    await db.close();
    const testDbPath = path.resolve(process.cwd(), './test_emsigner.sqlite');
    if (fs.existsSync(testDbPath)) {
      try { fs.unlinkSync(testDbPath); } catch (e) { /* ignore */ }
    }
  });

  // ─── Helpers ──────────────────────────────────────────────────────────────

  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) return fs.readFileSync(otpFilePath, 'utf8').trim();
    return '';
  }

  async function registerAndLogin(email, password, name = 'Priya Signtest', mobile = '9876543210') {
    const cap = await getValidCaptcha();
    await request(app).post('/api/auth/register').send({
      name, email, mobile, password, confirmPassword: password, role: 'student', ...cap
    });
    const loginCap = await getValidCaptcha();
    const loginRes = await request(app).post('/api/auth/login').send({ email, password, ...loginCap });
    const otpCode = readMockOTP();
    const verifyRes = await request(app).post('/api/auth/verify-otp').send({
      otpSessionId: loginRes.body.data.otpSessionId, code: otpCode
    });
    const cookie = verifyRes.headers['set-cookie'][0];
    const userId = verifyRes.body.data.userId;
    return { userId, cookie };
  }

  async function registerAndLoginProfessor(email, password) {
    const cap = await getValidCaptcha();
    await request(app).post('/api/auth/register').send({
      name: 'Prof Kumar', email, mobile: '9000011111', password, confirmPassword: password, role: 'professor', ...cap
    });
    const loginCap = await getValidCaptcha();
    const loginRes = await request(app).post('/api/auth/login').send({ email, password, ...loginCap });
    const otpCode = readMockOTP();
    const verifyRes = await request(app).post('/api/auth/verify-otp').send({
      otpSessionId: loginRes.body.data.otpSessionId, code: otpCode
    });
    return { cookie: verifyRes.headers['set-cookie'][0] };
  }

  /** Set application status directly in DB for testing state machine scenarios */
  async function setApplicationStatus(userId, status) {
    const rows = await db.query('SELECT id FROM admission_applications WHERE user_id = ?', [userId]);
    if (rows && rows.length > 0) {
      await db.query('UPDATE admission_applications SET status = ? WHERE user_id = ?', [status, userId]);
    } else {
      await db.query(
        `INSERT INTO admission_applications (application_id, user_id, status) VALUES (?, ?, ?)`,
        ['DPI-TEST-' + userId, userId, status]
      );
    }
  }

  // ─── Tests ────────────────────────────────────────────────────────────────

  // Test 1: Unauthorized requests must be blocked
  it('T11-01: POST /api/emsigner/sign must require authentication', async () => {
    const res = await request(app).post('/api/emsigner/sign').send({});
    expect(res.status).toBe(401);
  });

  // Test 2: GET /api/emsigner/status must require authentication
  it('T11-02: GET /api/emsigner/status must require authentication', async () => {
    const res = await request(app).get('/api/emsigner/status');
    expect(res.status).toBe(401);
  });

  // Test 3: Professor cannot initiate signing (role guard)
  it('T11-03: Professor is forbidden from initiating a sign request', async () => {
    const { cookie } = await registerAndLoginProfessor('prof.esign@dpi.test', 'SecureP@ss1');
    const res = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Forbidden/i);
  });

  // Test 4: Cannot sign if application is not in PENDING_SIGNATURE
  it('T11-04: Cannot sign application that is not in PENDING_SIGNATURE state', async () => {
    const { userId, cookie } = await registerAndLogin('s.wrongstate@dpi.test', 'SecureP@ss1');
    await setApplicationStatus(userId, 'Submitted');

    const res = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/PENDING_SIGNATURE/);
  });

  // Test 5: Cannot sign if application not found
  it('T11-05: Returns 404 if student has no application', async () => {
    const { cookie } = await registerAndLogin('s.noapplication@dpi.test', 'SecureP@ss1');

    const res = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/No active admission application found/i);
  });

  // Test 6: Successful mock signing (happy path)
  it('T11-06: Successfully initiates and completes mock emSigner signing', async () => {
    const { userId, cookie } = await registerAndLogin('s.sign@dpi.test', 'SecureP@ss1');
    await setApplicationStatus(userId, 'PENDING_SIGNATURE');

    const res = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeDefined();
    expect(res.body.data.status).toBe('SIGNED');
    expect(res.body.data.sign_request_id).toMatch(/^MOCK-EMSIGN-/);
    expect(res.body.data.sign_status).toBe('Signed');
    expect(res.body.data.signed_doc_uri).toContain('mock.emsigner.dev');
    expect(res.body.data.development_mode).toBe(true);

    // Verify application status was updated to SIGNED in DB
    const appRows = await db.query(
      'SELECT status FROM admission_applications WHERE user_id = ?',
      [userId]
    );
    expect(appRows[0].status).toBe('SIGNED');

    // Verify emsigner_requests record was created
    const signRows = await db.query(
      'SELECT sign_status, sign_request_id FROM emsigner_requests WHERE user_id = ?',
      [userId]
    );
    expect(signRows.length).toBe(1);
    expect(signRows[0].sign_status).toBe('Signed');

    // Verify workflow audit log was recorded
    const auditRows = await db.query(
      "SELECT to_status FROM workflow_audit_logs WHERE user_id = ? AND to_status = 'SIGNED'",
      [userId]
    );
    expect(auditRows.length).toBeGreaterThan(0);
  });

  // Test 7: Duplicate sign request must be rejected
  it('T11-07: Duplicate sign request is rejected with 409 Conflict', async () => {
    const { userId, cookie } = await registerAndLogin('s.dupe@dpi.test', 'SecureP@ss1');
    await setApplicationStatus(userId, 'PENDING_SIGNATURE');

    // First sign — should succeed
    const firstRes = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});
    expect(firstRes.status).toBe(200);

    // Put application back to PENDING_SIGNATURE for second attempt
    await setApplicationStatus(userId, 'PENDING_SIGNATURE');

    // Second sign — should be rejected as duplicate
    const secondRes = await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    expect(secondRes.status).toBe(409);
    expect(secondRes.body.success).toBe(false);
    expect(secondRes.body.message).toMatch(/already been signed|Duplicate/i);
  });

  // Test 8: GET /api/emsigner/status returns correct data after signing
  it('T11-08: GET /api/emsigner/status returns signature status after successful sign', async () => {
    const { userId, cookie } = await registerAndLogin('s.status@dpi.test', 'SecureP@ss1');
    await setApplicationStatus(userId, 'PENDING_SIGNATURE');

    // Status before signing
    const beforeRes = await request(app)
      .get('/api/emsigner/status')
      .set('Cookie', cookie);
    expect(beforeRes.status).toBe(200);
    expect(beforeRes.body.data.sign_status).toBe('NotInitiated');
    expect(beforeRes.body.data.signed).toBe(false);

    // Sign
    await request(app)
      .post('/api/emsigner/sign')
      .set('Cookie', cookie)
      .send({});

    // Status after signing
    const afterRes = await request(app)
      .get('/api/emsigner/status')
      .set('Cookie', cookie);
    expect(afterRes.status).toBe(200);
    expect(afterRes.body.data.signed).toBe(true);
    expect(afterRes.body.data.sign_status).toBe('Signed');
    expect(afterRes.body.data.sign_request_id).toMatch(/^MOCK-EMSIGN-/);
    expect(afterRes.body.data.signed_doc_uri).toBeDefined();
    expect(afterRes.body.data.development_mode).toBe(true);
  });

});

const db = require('../config/db');

class Captcha {
  /**
   * Insert a new CAPTCHA record
   * @param {Object} captchaData
   * @param {string} captchaData.id - Unique CAPTCHA token
   * @param {string} captchaData.answer - Calculated answer string
   * @param {Date} captchaData.expiresAt - Expiration Date object
   * @returns {Promise<boolean>}
   */
  static async create({ id, answer, expiresAt }) {
    const sql = `
      INSERT INTO captchas (id, answer, attempts, expires_at)
      VALUES (?, ?, 0, ?)
    `;
    await db.query(sql, [id, answer, expiresAt]);
    return true;
  }

  /**
   * Find a CAPTCHA by ID
   * @param {string} id 
   * @returns {Promise<Object|null>}
   */
  static async findById(id) {
    const rows = await db.query('SELECT * FROM captchas WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Increment attempts count for a CAPTCHA
   * @param {string} id 
   * @returns {Promise<number>} - New attempts count
   */
  static async incrementAttempts(id) {
    const sql = 'UPDATE captchas SET attempts = attempts + 1 WHERE id = ?';
    await db.query(sql, [id]);
    
    const captcha = await this.findById(id);
    return captcha ? captcha.attempts : 0;
  }

  /**
   * Delete a CAPTCHA record (invalidation/replay protection)
   * @param {string} id 
   * @returns {Promise<boolean>}
   */
  static async delete(id) {
    await db.query('DELETE FROM captchas WHERE id = ?', [id]);
    return true;
  }

  /**
   * Delete all expired CAPTCHA records
   * @returns {Promise<number>} - Count of deleted rows
   */
  static async clearExpired() {
    const result = await db.query('DELETE FROM captchas WHERE expires_at < ?', [Date.now()]);
    return result.affectedRows || 0;
  }
}

module.exports = Captcha;

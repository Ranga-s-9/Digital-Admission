document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const globalErrorGroup = document.getElementById('loginGlobalGroup');
  const globalErrorFeedback = document.getElementById('loginGlobalFeedback');

  const fields = {
    email: {
      input: document.getElementById('loginEmail'),
      group: document.getElementById('loginEmailGroup'),
      message: document.getElementById('loginEmailFeedback'),
      validate: (val) => {
        if (!val) return 'Email address is required';
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!regex.test(val)) return 'Please enter a valid email address';
        return '';
      }
    },
    password: {
      input: document.getElementById('loginPassword'),
      group: document.getElementById('loginPasswordGroup'),
      message: document.getElementById('loginPasswordFeedback'),
      validate: (val) => {
        if (!val) return 'Password is required';
        return '';
      }
    },
    captchaAnswer: {
      input: document.getElementById('loginCaptchaAnswer'),
      group: document.getElementById('loginCaptchaAnswerGroup'),
      message: document.getElementById('loginCaptchaAnswerFeedback'),
      validate: (val) => {
        if (!val) return 'CAPTCHA answer is required';
        return '';
      }
    }
  };

  // Toggle login password visibility
  const toggleBtn = document.getElementById('toggleLoginPassword');
  const pwdInput = fields.password.input;
  toggleBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const isPassword = pwdInput.getAttribute('type') === 'password';
    pwdInput.setAttribute('type', isPassword ? 'text' : 'password');
    if (isPassword) {
      toggleBtn.innerHTML = `
        <svg viewBox="0 0 24 24">
          <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
        </svg>
      `;
    } else {
      toggleBtn.innerHTML = `
        <svg viewBox="0 0 24 24">
          <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.44-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 2.2 0 4.27-.61 6.04-1.66l.46.46 2.28 2.28 1.27-1.27L3.27 3 2 4.27zM9.53 9.53l3.93 3.93c-.41.25-.9.4-1.46.4-1.66 0-3-1.34-3-3 0-.56.15-1.05.4-1.46zm-2.09-.76l1.37 1.37C8.3 10.59 8 11.26 8 12c0 2.2 1.8 4 4 4 .74 0 1.41-.3 1.86-.81l1.37 1.37C14.22 17.29 13.16 18 12 18c-3.31 0-6-2.69-6-6 0-1.16.29-2.22.8-3.23z"/>
        </svg>
      `;
    }
  });

  // Login CAPTCHA setup
  const captchaIdInput = document.getElementById('loginCaptchaId');
  const captchaQuestionSpan = document.getElementById('loginCaptchaQuestion');
  const refreshCaptchaBtn = document.getElementById('refreshLoginCaptchaBtn');

  async function loadLoginCaptcha() {
    captchaQuestionSpan.textContent = 'Loading...';
    try {
      const response = await fetch('/api/auth/captcha');
      const result = await response.json();
      if (response.ok && result.success) {
        captchaIdInput.value = result.data.captchaId;
        captchaQuestionSpan.textContent = result.data.question;
        fields.captchaAnswer.input.value = '';
        fields.captchaAnswer.group.classList.remove('has-success', 'has-error');
      } else {
        captchaQuestionSpan.textContent = 'Error';
      }
    } catch (err) {
      captchaQuestionSpan.textContent = 'Error';
      console.error('Error loading login CAPTCHA:', err);
    }
  }

  // Load CAPTCHA initially
  loadLoginCaptcha();

  // Expose loadLoginCaptcha globally to be callable from app.js router swaps
  window.loadLoginCaptcha = loadLoginCaptcha;

  refreshCaptchaBtn.addEventListener('click', loadLoginCaptcha);

  // Helper validation trigger
  const validateField = (fieldName) => {
    const field = fields[fieldName];
    const val = field.input.value;
    const errorMsg = field.validate(val);
    
    if (errorMsg) {
      field.group.classList.remove('has-success');
      field.group.classList.add('has-error');
      field.message.textContent = errorMsg;
      return false;
    } else {
      field.group.classList.remove('has-error');
      field.group.classList.add('has-success');
      field.message.textContent = '';
      return true;
    }
  };

  // Add event listeners for inline validation
  Object.keys(fields).forEach(key => {
    const field = fields[key];
    field.input.addEventListener('blur', () => validateField(key));
    field.input.addEventListener('input', () => {
      if (field.group.classList.contains('has-error')) {
        validateField(key);
      }
      globalErrorGroup.style.display = 'none';
    });
  });

  // Notification Display helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Submit handler
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    let isValid = true;
    Object.keys(fields).forEach(key => {
      if (!validateField(key)) isValid = false;
    });

    if (!isValid) {
      const card = document.getElementById('loginView');
      card.classList.add('shake');
      setTimeout(() => card.classList.remove('shake'), 4000);
      return;
    }

    const submitBtn = document.getElementById('loginSubmitBtn');
    const submitText = document.getElementById('loginSubmitText');
    const spinner = document.getElementById('loginSubmitSpinner');

    submitBtn.disabled = true;
    spinner.style.display = 'block';
    submitText.textContent = 'Verifying Credentials...';
    globalErrorGroup.style.display = 'none';

    const payload = {
      email: fields.email.input.value,
      password: fields.password.input.value,
      role: document.getElementById('loginRoleInput') ? document.getElementById('loginRoleInput').value : 'student',
      captchaId: captchaIdInput.value,
      captchaAnswer: fields.captchaAnswer.input.value
    };

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (response.ok && result.success) {
        showNotification('Credentials Match!', 'Please complete the two-factor authentication challenge.', 'success');
        loginForm.reset();
        Object.keys(fields).forEach(key => {
          fields[key].group.classList.remove('has-success', 'has-error');
        });
        
        // Cache Step 1 result variables to pass to OTP view initializer
        const tempOtpContext = {
          otpSessionId: result.data.otpSessionId,
          requireSetup: result.data.requireSetup,
          requireTotp: result.data.requireTotp,
          requireSmsOtp: result.data.requireSmsOtp,
          qrCodeUrl: result.data.qrCodeUrl,
          secret: result.data.secret,
          expiresIn: result.data.expiresIn
        };
        sessionStorage.setItem('otpContext', JSON.stringify(tempOtpContext));
        window.tempOtpContext = tempOtpContext;

        // Redirect to OTP verification view
        window.location.hash = '#/verify-otp';
      } else {
        loadLoginCaptcha();
        
        // Handle specific validations
        if (result.error) {
          let hasInlineError = false;
          Object.keys(result.error).forEach(fieldKey => {
            if (fields[fieldKey]) {
              fields[fieldKey].group.classList.add('has-error');
              fields[fieldKey].message.textContent = result.error[fieldKey];
              hasInlineError = true;
            }
          });

          if (result.error.global) {
            globalErrorGroup.style.display = 'block';
            globalErrorFeedback.textContent = result.error.global;
            
            const card = document.getElementById('loginView');
            card.classList.add('shake');
            setTimeout(() => card.classList.remove('shake'), 1000);
          } else if (!hasInlineError) {
            showNotification('Login Failed', result.message || 'Verification rejected', 'error');
          }
        } else {
          globalErrorGroup.style.display = 'block';
          globalErrorFeedback.textContent = result.message || 'Access Denied';
        }
      }
    } catch (error) {
      console.error('Login submit error:', error);
      showNotification('Network Error', 'Connection failed. Please retry.', 'error');
      loadLoginCaptcha();
    } finally {
      submitBtn.disabled = false;
      spinner.style.display = 'none';
      submitText.textContent = 'Sign In';
    }
  });
});

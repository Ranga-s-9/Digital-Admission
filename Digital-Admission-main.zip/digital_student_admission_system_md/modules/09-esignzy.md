# Module 09 — eSignzy Digital Signature

## Purpose

Provide digital signing of the project form/document.

## Source Requirement

“Signing form with eSignzy” is explicitly listed as mandatory. The notes also state that eSignzy credentials are sent to the college email and that understanding eSignzy is a project learning objective.

## Proposed Workflow

```text
Application Ready
      |
      v
Generate Signable Document
      |
      v
Create eSign Request
      |
      v
eSignzy
      |
      v
User Authentication / Signing
      |
      v
Signed Result
      |
      v
Update Application
```

## Requirements

- Generate the correct document version.
- Create a signing request through the approved eSignzy integration.
- Handle success, failure, cancellation and timeout.
- Record signature status.
- Store references/metadata safely.
- Continue the paperless workflow after successful signing.

## Security

- Keep eSignzy credentials on the backend.
- Never expose API secrets in frontend code.
- Use environment variables/secret management.
- Validate callbacks/responses.
- Audit signing events.

## Acceptance Criteria

- A valid application can create a signing request.
- Signing status is tracked.
- Successful signing updates the application.
- Failed signing is recoverable.
- No secret credential is exposed.

## Integration Boundary

The notes do not contain the eSignzy API contract. Use the official credentials/documentation supplied by the institution when implementing the real integration.

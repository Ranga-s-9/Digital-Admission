# Module 12 — API & Integration Layer

## Purpose

Provide a consistent backend integration layer for authentication, OTP, eKYC, documents, eSign and application workflows.

## Source Requirement

The notes specifically recommend learning:

- REST API
- GET
- PUT
- POST
- DELETE
- Graph API
- GraphQL
- API keys
- Postman

## Proposed API Domains

```text
/api/auth
/api/otp
/api/users
/api/students
/api/ekyc
/api/documents
/api/admission
/api/esign
/api/admin
```

## HTTP Methods

### GET

Retrieve resources.

### POST

Create a resource or initiate an operation.

### PUT

Update a resource.

### DELETE

Delete an eligible resource.

## Integration Rules

- Keep third-party API calls in backend services.
- Do not expose API keys in frontend code.
- Validate external responses.
- Use timeouts and retry policies where appropriate.
- Log safe metadata, not secrets.
- Normalize external failures into clear application errors.

## Postman

Use Postman to:

- Test endpoints.
- Inspect request/response payloads.
- Validate authentication.
- Test API keys.
- Reproduce integration failures.

## Acceptance Criteria

- APIs follow a consistent response/error format.
- Authentication is enforced on protected endpoints.
- Secrets are server-side.
- Integration failures do not crash the application.

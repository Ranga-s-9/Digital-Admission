# Database Documentation - Module 1 & 2

The system database model is designed with strict compatibility guidelines supporting both **SQLite3** for development and **MySQL / MariaDB** for production environments.

---

## 1. Schema Diagram

```mermaid
erDiagram
  users {
    int id PK "Auto Increment"
    varchar name "Not Null"
    varchar email UK "Unique, Not Null"
    varchar mobile UK "Unique, Not Null"
    varchar password_hash "Not Null"
    varchar role "Default: student"
    varchar status "Default: active"
    int failed_attempts "Default: 0"
    bigint lockout_until "Default: 0"
    timestamp created_at "Default: CURRENT_TIMESTAMP"
    timestamp updated_at "Default: CURRENT_TIMESTAMP"
  }
  captchas {
    varchar id PK "UUID, Not Null"
    varchar answer "Not Null"
    int attempts "Default: 0"
    bigint expires_at "Not Null"
    timestamp created_at "Default: CURRENT_TIMESTAMP"
  }
```

---

## 2. Table Definitions

### `users`
Stores credentials, personal identifiers, roles, status flags, and lockout metrics.

| Field Name | Data Type | Key | Constraints | Description |
| :--- | :--- | :---: | :--- | :--- |
| **id** | INT / INTEGER | PK | AUTOINCREMENT | System identifier |
| **name** | VARCHAR(255) | | NOT NULL | Full name of the user |
| **email** | VARCHAR(255) | UK | NOT NULL, UNIQUE | User email address |
| **mobile** | VARCHAR(20) | UK | NOT NULL, UNIQUE | 10-digit mobile number |
| **password_hash** | VARCHAR(255) | | NOT NULL | Bcrypt hash |
| **role** | VARCHAR(50) | | NOT NULL, DEFAULT 'student' | System role ('student', 'professor') |
| **status** | VARCHAR(50) | | NOT NULL, DEFAULT 'active' | Account state ('active', 'suspended') |
| **failed_attempts** | INT | | DEFAULT 0 | Failed login attempt counter |
| **lockout_until** | BIGINT | | DEFAULT 0 | Unix millisecond lockout epoch |
| **created_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Account creation date |
| **updated_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Date of last modifications |

### `captchas`
Stores active arithmetic CAPTCHA challenges.

| Field Name | Data Type | Key | Constraints | Description |
| :--- | :--- | :---: | :--- | :--- |
| **id** | VARCHAR(255) | PK | NOT NULL | Unique CAPTCHA session UUID token |
| **answer** | VARCHAR(50) | | NOT NULL | Correct math answer string |
| **attempts** | INT | | DEFAULT 0 | Verification attempt count (max 3) |
| **expires_at** | BIGINT | | NOT NULL | Unix epoch millisecond timestamp |
| **created_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Row insertion timestamp |

### `otps`
Stores active two-factor authentication sessions.

| Field Name | Data Type | Key | Constraints | Description |
| :--- | :--- | :---: | :--- | :--- |
| **id** | VARCHAR(255) | PK | NOT NULL | Unique OTP session UUID token |
| **user_id** | INT / INTEGER | | NOT NULL, FK users(id) | Associated user identity link |
| **code_hash** | VARCHAR(255) | | NOT NULL | SHA-256 hash of the generated code |
| **attempts** | INT | | DEFAULT 0 | Verification mistake count (max 3) |
| **resend_count** | INT | | DEFAULT 0 | Cooldown resend tracking (max 3) |
| **resend_cooldown** | BIGINT | | NOT NULL | Unix epoch resend block timer |
| **expires_at** | BIGINT | | NOT NULL | Unix epoch code validity limit |
| **created_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Session generation time |

### `student_profiles`
Stores students personal, contact, and academic details for the admission process.

| Field Name | Data Type | Key | Constraints | Description |
| :--- | :--- | :---: | :--- | :--- |
| **user_id** | INT / INTEGER | PK | NOT NULL, FK users(id) | Unique student user identity link |
| **dob** | VARCHAR(50) | | | Date of Birth (YYYY-MM-DD) |
| **gender** | VARCHAR(50) | | | Gender classification (Male/Female/Other) |
| **guardian_name** | VARCHAR(255) | | | Father or Guardian's full name |
| **address** | VARCHAR(500) | | | Correspondence address |
| **state** | VARCHAR(100) | | | Correspondence state or province |
| **pincode** | VARCHAR(20) | | | Postal area code |
| **degree** | VARCHAR(255) | | | Qualifying education degree |
| **board** | VARCHAR(255) | | | Exam board or university name |
| **grad_year** | INT | | | Year of graduation (1900 - 2035) |
| **percentage** | REAL / DECIMAL | | | Graduation score percentage |
| **photo_path** | VARCHAR(500) | | | Local secure filename of profile photo |
| **version** | INT | | DEFAULT 1 | Version counter for optimistic concurrency |
| **updated_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Date of last modifications |

### `admission_applications`
Stores students personal, contact, and academic details for the admission process.

| Field Name | Data Type | Key | Constraints | Description |
| :--- | :--- | :---: | :--- | :--- |
| **id** | INT / INTEGER | PK | NOT NULL, AUTOINCREMENT | Unique record serial number |
| **application_id** | VARCHAR(50) | | UNIQUE | Structured tracking reference (ADM-YYYYMMDD-XXXX) |
| **user_id** | INT / INTEGER | | UNIQUE, FK users(id) | Associated student user ID |
| **dob** | VARCHAR(50) | | | Date of Birth (YYYY-MM-DD) |
| **gender** | VARCHAR(50) | | | Gender classification (Male/Female/Other) |
| **guardian_name** | VARCHAR(255) | | | Father or Guardian's full name |
| **address** | VARCHAR(500) | | | Correspondence address |
| **state** | VARCHAR(100) | | | Correspondence state or province |
| **pincode** | VARCHAR(20) | | | Postal area code |
| **degree** | VARCHAR(255) | | | Qualifying education degree |
| **board** | VARCHAR(255) | | | Exam board or university name |
| **grad_year** | INT | | | Year of graduation (1900 - 2035) |
| **percentage** | REAL / DECIMAL | | | Graduation score percentage |
| **current_step** | INT | | DEFAULT 1 | Current form wizard panel step (1-4) |
| **status** | VARCHAR(50) | | DEFAULT 'Draft' | Application status ('Draft', 'Submitted', 'Approved') |
| **created_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Application generation date |
| **updated_at** | TIMESTAMP | | DEFAULT CURRENT_TIMESTAMP | Date of last modifications |

---

## 3. Database Indexes

To optimize lookup speeds for authentication checks and user searches, the following database indexes are created:

1. **`idx_users_email`** on `users(email)`
   - *Purpose*: Speeds up email checks during login, profile access, and duplicate lookups.
2. **`idx_users_mobile`** on `users(mobile)`
   - *Purpose*: Speeds up mobile checks during login, OTP verification, and duplicate lookups.
3. **`idx_admission_user_id`** on `admission_applications(user_id)`
   - *Purpose*: Speeds up application lookups and security checks.

---

---

## 4. DDL Scripts

### SQLite Creation Script
```sql
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  mobile VARCHAR(20) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'student',
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile);

CREATE TABLE IF NOT EXISTS captchas (
  id VARCHAR(255) PRIMARY KEY,
  answer VARCHAR(50) NOT NULL,
  attempts INT DEFAULT 0,
  expires_at BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS otps (
  id VARCHAR(255) PRIMARY KEY,
  user_id INTEGER NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  attempts INT DEFAULT 0,
  resend_count INT DEFAULT 0,
  resend_cooldown BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_profiles (
  user_id INTEGER PRIMARY KEY,
  dob VARCHAR(50),
  gender VARCHAR(50),
  guardian_name VARCHAR(255),
  address VARCHAR(500),
  state VARCHAR(100),
  pincode VARCHAR(20),
  degree VARCHAR(255),
  board VARCHAR(255),
  grad_year INT,
  percentage REAL,
  photo_path VARCHAR(500),
  version INT DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS admission_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  application_id VARCHAR(50) UNIQUE,
  user_id INTEGER UNIQUE,
  dob VARCHAR(50),
  gender VARCHAR(50),
  guardian_name VARCHAR(255),
  address VARCHAR(500),
  state VARCHAR(100),
  pincode VARCHAR(20),
  degree VARCHAR(255),
  board VARCHAR(255),
  grad_year INT,
  percentage REAL,
  current_step INT DEFAULT 1,
  status VARCHAR(50) DEFAULT 'Draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_admission_user_id ON admission_applications(user_id);
```

### MySQL Creation Script
```sql
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  mobile VARCHAR(20) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'student',
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  failed_attempts INT DEFAULT 0,
  lockout_until BIGINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_mobile ON users(mobile);

CREATE TABLE IF NOT EXISTS captchas (
  id VARCHAR(255) PRIMARY KEY,
  answer VARCHAR(50) NOT NULL,
  attempts INT DEFAULT 0,
  expires_at BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS otps (
  id VARCHAR(255) PRIMARY KEY,
  user_id INT NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  attempts INT DEFAULT 0,
  resend_count INT DEFAULT 0,
  resend_cooldown BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS student_profiles (
  user_id INT PRIMARY KEY,
  dob VARCHAR(50),
  gender VARCHAR(50),
  guardian_name VARCHAR(255),
  address VARCHAR(500),
  state VARCHAR(100),
  pincode VARCHAR(20),
  degree VARCHAR(255),
  board VARCHAR(255),
  grad_year INT,
  percentage REAL,
  photo_path VARCHAR(500),
  version INT DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admission_applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id VARCHAR(50) UNIQUE,
  user_id INT UNIQUE,
  dob VARCHAR(50),
  gender VARCHAR(50),
  guardian_name VARCHAR(255),
  address VARCHAR(500),
  state VARCHAR(100),
  pincode VARCHAR(20),
  degree VARCHAR(255),
  board VARCHAR(255),
  grad_year INT,
  percentage REAL,
  current_step INT DEFAULT 1,
  status VARCHAR(50) DEFAULT 'Draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_admission_user_id ON admission_applications(user_id);
```
```

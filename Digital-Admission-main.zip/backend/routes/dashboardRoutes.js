const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const { requireRole } = require('../middleware/rbac');
const { getStudentData, getProfessorData, getProfessorStudentDetails, getAdminData } = require('../controllers/dashboardController');

// GET /api/dashboard/student
router.get('/student', authenticateToken, requireRole('student'), getStudentData);

// GET /api/dashboard/professor
router.get('/professor', authenticateToken, requireRole('professor'), getProfessorData);

// GET /api/dashboard/professor/student/:studentId
router.get('/professor/student/:studentId', authenticateToken, requireRole('professor'), getProfessorStudentDetails);

// GET /api/dashboard/admin
router.get('/admin', authenticateToken, requireRole('admin'), getAdminData);

module.exports = router;

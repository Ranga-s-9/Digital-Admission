const db = require('../config/db');
const { getEmsignerAdapter } = require('../services/emsigner/index');
const User = require('../models/User');
const { logger } = require('../middleware/logger');

/**
 * POST /api/emsigner/sign
 * Student initiates a digital signature request via emSigner adapter.
 * Application must be in PENDING_SIGNATURE status.
 */
async function postInitiateSign(req, res) {
  try {
    // Role guard: only students can initiate signing
    if (req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: Only students can initiate a signature request.',
        error: { global: 'Forbidden access' }
      });
    }

    const userId = req.user.userId;
    const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

    // 1. Fetch application and validate status
    const appRows = await db.query(
      'SELECT id, status, application_id FROM admission_applications WHERE user_id = ?',
      [userId]
    );

    if (!appRows || appRows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No active admission application found.',
        error: { global: 'Application not found' }
      });
    }

    const app = appRows[0];

    if (app.status !== 'PENDING_SIGNATURE') {
      return res.status(400).json({
        success: false,
        message: `Cannot initiate signing: Application must be in PENDING_SIGNATURE status (current: '${app.status}').`,
        error: { global: 'Invalid application state for signing' }
      });
    }

    // 2. Log initiate action
    const AuditLog = require('../models/AuditLog');
    await AuditLog.log({
      userId,
      action: 'signature_request',
      entityType: 'signature',
      entityId: String(app.id),
      status: 'success',
      ipAddress,
      metadata: { applicationId: app.application_id }
    });

    await db.query(
      `INSERT INTO emsigner_audit_logs (user_id, action, ip_address, details)
       VALUES (?, 'INITIATE', ?, ?)`,
      [userId, ipAddress, `emSigner signing initiated for application ${app.application_id || app.id}`]
    );

    // 3. Call adapter
    const adapter = getEmsignerAdapter();
    const result = await adapter.initiateSign(userId, app.application_id || String(app.id), ipAddress);

    // 4. On success, update application status to SIGNED
    await db.query(
      "UPDATE admission_applications SET status = 'SIGNED', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
      [app.id]
    );

    // 5. Record workflow audit log
    await db.query(
      `INSERT INTO workflow_audit_logs (user_id, from_status, to_status, action_by_role, ip_address, details)
       VALUES (?, 'PENDING_SIGNATURE', 'SIGNED', 'student', ?, ?)`,
      [userId, ipAddress, `emSigner digital signature completed. Request ID: ${result.sign_request_id}`]
    );

    // Log unified audit log
    await AuditLog.log({
      userId,
      action: 'signature_completion',
      entityType: 'signature',
      entityId: String(app.id),
      status: 'success',
      ipAddress,
      metadata: { applicationId: app.application_id, signRequestId: result.sign_request_id }
    });

    // Trigger signature completion notification
    try {
      const NotificationService = require('../services/notificationService');
      await NotificationService.send({
        userId,
        type: 'signature_completion',
        title: 'Signature Completed',
        content: `Your digital signature has been successfully completed for application ${app.application_id || app.id}.`
      });
    } catch (notifErr) {
      logger.error('Failed to trigger signature completion notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
    }

    return res.status(200).json({
      success: true,
      message: result.message || 'Document signed successfully via emSigner.',
      data: {
        status: 'SIGNED',
        sign_request_id: result.sign_request_id,
        sign_status: result.sign_status,
        signed_doc_uri: result.signed_doc_uri,
        signed_at: result.signed_at,
        development_mode: result.development_mode
      }
    });

  } catch (error) {
    const userId = req.user ? req.user.userId : null;
    const ipAddress = req.ip || '127.0.0.1';

    // Map adapter errors to HTTP responses
    let statusCode = 500;
    let userMessage = 'Internal server error during signing process.';
    let action = 'SIGN_FAILED';

    if (error.message === 'DUPLICATE_SIGN_REQUEST') {
      statusCode = 409;
      userMessage = 'This application has already been signed. Duplicate signing is not permitted.';
      action = 'DUPLICATE_BLOCK';
    } else if (error.message === 'TIMEOUT_ERROR') {
      statusCode = 504;
      userMessage = 'emSigner service request timed out. Please try again.';
    } else if (error.message === 'EXTERNAL_SERVICE_FAILURE') {
      statusCode = 502;
      userMessage = 'emSigner gateway is currently unavailable. Please retry later.';
    } else if (error.message && error.message.includes('EMSIGNER_CREDENTIALS_NOT_CONFIGURED')) {
      statusCode = 503;
      userMessage = 'emSigner is not configured for production use. Please contact the system administrator.';
      action = 'CONFIG_ERROR';
    } else if (error.message && error.message.includes('EMSIGNER_PRODUCTION_NOT_IMPLEMENTED')) {
      statusCode = 501;
      userMessage = 'emSigner production integration is not yet active. Please use mock mode.';
      action = 'CONFIG_ERROR';
    }

    // Log the failure
    const AuditLog = require('../models/AuditLog');
    if (userId) {
      await AuditLog.log({
        userId,
        action: 'signature_completion',
        entityType: 'signature',
        status: 'failure',
        ipAddress,
        metadata: { reason: error.message, actionType: action }
      });
      try {
        await db.query(
          `INSERT INTO emsigner_audit_logs (user_id, action, ip_address, details)
           VALUES (?, ?, ?, ?)`,
          [userId, action, ipAddress, `Signing error: ${error.message}`]
        );
      } catch (logErr) {
        logger.error('Failed to write emSigner audit log:', { message: logErr.message, stack: logErr.stack, requestId: req.id || null });
      }
    }

    if (statusCode === 500) {
      logger.error('emSigner controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    }

    return res.status(statusCode).json({
      success: false,
      message: userMessage,
      error: { global: userMessage }
    });
  }
}

/**
 * GET /api/emsigner/status
 * Returns the current emSigner signing status for the authenticated student.
 * Professors may query another student by passing ?userId=
 */
async function getSignatureStatus(req, res) {
  try {
    let userId = req.user.userId;

    // Professors may look up any student
    if (req.user.role === 'professor' && req.query.userId) {
      userId = parseInt(req.query.userId, 10);
      const targetUser = await User.findById(userId);
      if (!targetUser || targetUser.role !== 'student') {
        return res.status(404).json({
          success: false,
          message: 'Student record not found',
          error: { global: 'User is not a student' }
        });
      }
    }

    const adapter = getEmsignerAdapter();
    const status = await adapter.getStatus(userId);

    return res.status(200).json({
      success: true,
      data: status
    });

  } catch (error) {
    logger.error('Get emSigner status error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error fetching signature status',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * GET /api/emsigner/history
 * Returns the emSigner audit log history.
 * Students see their own. Professors can pass ?userId= for a specific student.
 */
async function getSignatureHistory(req, res) {
  try {
    let userId = req.user.userId;

    if (req.user.role === 'professor' && req.query.userId) {
      userId = parseInt(req.query.userId, 10);
      const targetUser = await User.findById(userId);
      if (!targetUser || targetUser.role !== 'student') {
        return res.status(404).json({
          success: false,
          message: 'Student record not found',
          error: { global: 'User is not a student' }
        });
      }
    }

    const logs = await db.query(
      `SELECT action, ip_address, details, created_at
       FROM emsigner_audit_logs
       WHERE user_id = ?
       ORDER BY id DESC`,
      [userId]
    );

    return res.status(200).json({
      success: true,
      data: logs || []
    });

  } catch (error) {
    logger.error('Get emSigner history error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error fetching signature history',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  postInitiateSign,
  getSignatureStatus,
  getSignatureHistory
};

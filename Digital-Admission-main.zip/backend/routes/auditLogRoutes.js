const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const { requireRole } = require('../middleware/rbac');
const auditLogController = require('../controllers/auditLogController');

// Secure all audit log routes with JWT verification and Role-Based Access Control
router.use(authenticateToken);
router.use(requireRole(['professor', 'admin']));

// GET /api/audit-logs - Retrieve all system audit logs
router.get('/', auditLogController.getAuditLogs);

module.exports = router;

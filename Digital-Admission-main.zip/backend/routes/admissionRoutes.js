const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const { requireRole } = require('../middleware/rbac');
const { getMyApplication, saveDraft, submitApplication } = require('../controllers/admissionController');
const { admissionDraftRules, admissionSubmitRules, validate } = require('../middleware/validation');

// --- Standard REST Routes ---
// GET /api/admission/applications/me - Retrieve current student's application
router.get('/applications/me', authenticateToken, requireRole('student'), getMyApplication);

// PUT /api/admission/applications/me - Update application draft (Standard REST)
router.put('/applications/me', authenticateToken, requireRole('student'), admissionDraftRules, validate, saveDraft);

// POST /api/admission/applications/me/submit - Finalize application submission (Standard REST)
router.post('/applications/me/submit', authenticateToken, requireRole('student'), admissionSubmitRules, validate, submitApplication);


// --- Legacy Compatibility Routes ---
// GET /api/admission/my-application - Retrieve current student's application details
router.get('/my-application', authenticateToken, requireRole('student'), getMyApplication);

// POST /api/admission/save-draft - Save draft details (supports progressive save)
router.post('/save-draft', authenticateToken, requireRole('student'), admissionDraftRules, validate, saveDraft);

// POST /api/admission/submit - Final validations, generation of unique ID and submission
router.post('/submit', authenticateToken, requireRole('student'), admissionSubmitRules, validate, submitApplication);

module.exports = router;

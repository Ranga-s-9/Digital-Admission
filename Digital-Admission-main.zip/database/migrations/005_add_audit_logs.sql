-- =============================================================================
-- Migration 005: Add Centralized Audit Logs Table
-- Introduces the system-wide `audit_logs` table used by Module 14
-- (Centralized Audit Logging) to record registration, login, OTP,
-- profile, application, eKYC, DigiLocker, signature, and approval events.
--
-- NOTE: This table has been created automatically at application boot
-- since Module 14 via backend/services/dbService.js (initDatabase()), so
-- `npm run dev` has always worked correctly. However it was missing from
-- this migration set and from database/schema.sql, which meant a fresh
-- MySQL database provisioned purely via `node database/migrate.js` or via
-- a manual phpMyAdmin import of schema.sql (the two documented alternate
-- setup paths in docs/XAMPP_SETUP.md) would be missing this table. This
-- migration closes that gap so all three provisioning paths stay in sync.
-- =============================================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           NULL,
  action      VARCHAR(100)  NOT NULL,
  entity_type VARCHAR(100)  NULL,
  entity_id   VARCHAR(100)  NULL,
  status      VARCHAR(50)   NULL,
  ip_address  VARCHAR(50)   NULL,
  metadata    TEXT          NULL,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_audit_logs_user_id (user_id),
  KEY idx_audit_logs_action  (action),
  CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Centralized, sanitized audit trail for security-relevant actions (Module 14)';

// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_workflow.sqlite';
process.env.EMSIGNER_MODE = 'mock';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('Workflow State Machine and Transition tests', () => {

  beforeAll(async () => {
    jest.setTimeout(15000);
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM admission_applications');
    await db.query('DELETE FROM ekyc_requests');
    await db.query('DELETE FROM ekyc_audit_logs');
    await db.query('DELETE FROM digilocker_connections');
    await db.query('DELETE FROM digilocker_documents');
    await db.query('DELETE FROM workflow_audit_logs');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    try {
      if (fs.existsSync(otpFilePath)) {
        fs.unlinkSync(otpFilePath);
      }
    } catch (e) {
      // Ignored if busy
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_workflow.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedUser(email, password, name = 'Alice Student', role = 'student', mobile = '9111122222') {
    const cap = await getValidCaptcha();
    await request(app)
      .post('/api/auth/register')
      .send({
        name,
        email,
        mobile,
        password,
        confirmPassword: password,
        role,
        ...cap
      });

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });

    const userId = verifyRes.body.data.userId;
    const cookie = verifyRes.headers['set-cookie'][0];

    // Auto-initialize student profile if the role is student (mandatory for eKYC name matching checks)
    if (role === 'student') {
      await request(app)
        .put(`/api/profile/${userId}`)
        .set('Cookie', cookie)
        .send({
          dob: '2005-05-15',
          gender: 'Female',
          guardianName: 'Bob Guardian',
          address: '123 Main St',
          state: 'Delhi',
          pincode: '110001',
          degree: 'High School',
          board: 'CBSE',
          gradYear: 2023,
          percentage: 95.50,
          version: 1
        });
    }

    return { userId, cookie };
  }

  // XML helper generator
  function makeXml(name, dob, gender, pc, shareCode = '1234') {
    return `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="${shareCode}">
  <UidData>
    <Poi name="${name}" dob="${dob}" gender="${gender}"/>
    <Poa co="Guardian" street="123 Main St" state="Delhi" pc="${pc}"/>
    <Pht>photo_data</Pht>
  </UidData>
  <Signature>trusted_root_signature</Signature>
</OfflinePaperlessKyc>`;
  }

  // --- TESTS ---

  test('1. Unauthorized requests to workflow endpoints are blocked', async () => {
    // Guest block
    const resSign = await request(app).post('/api/workflow/sign');
    expect(resSign.statusCode).toBe(401);

    const resTrans = await request(app).post('/api/workflow/transition');
    expect(resTrans.statusCode).toBe(401);

    const resHist = await request(app).get('/api/workflow/history');
    expect(resHist.statusCode).toBe(401);
  });

  test('2. Students are blocked from directly triggering Professor workflow transitions', async () => {
    const student = await getAuthenticatedUser('student@test.com', 'Password@123', 'Alice Student', 'student', '9111100001');

    const res = await request(app)
      .post('/api/workflow/transition')
      .set('Cookie', student.cookie)
      .send({
        userId: student.userId,
        targetStatus: 'Approved'
      });

    expect(res.statusCode).toBe(403);
    expect(res.body.message).toMatch(/(Only academic staff|Access denied)/);
  });

  test('3. Full valid paperless workflow progression', async () => {
    const student = await getAuthenticatedUser('student@test.com', 'Password@123', 'Alice Student', 'student', '9111100001');
    const professor = await getAuthenticatedUser('prof@test.com', 'Password@123', 'Professor Bob', 'professor', '9111100002');

    // 1. Submit admission form (transitions Draft -> Submitted)
    const submitRes = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50
      });
    expect(submitRes.statusCode).toBe(200);
    expect(submitRes.body.data.status).toBe('Submitted');

    // 2. Mock DigiLocker Connect callback
    const state = 'xyz123';
    const authRes = await request(app)
      .get(`/api/digilocker/oauth/authorize?state=${state}`)
      .set('Cookie', student.cookie);
    const setCookieHeader = authRes.headers['set-cookie'] ? authRes.headers['set-cookie'][0] : '';
    const stateCookie = setCookieHeader.split(';')[0];

    const dlCallbackRes = await request(app)
      .post('/api/digilocker/oauth/callback')
      .set('Cookie', [student.cookie, stateCookie].filter(Boolean).join('; '))
      .send({ code: 'mock_code_123', state });
    expect(dlCallbackRes.statusCode).toBe(200);

    // Give DigiLocker consent
    const consentRes = await request(app)
      .post('/api/digilocker/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });
    expect(consentRes.statusCode).toBe(200);

    // Link a CBSE Class XII Marks transcript
    const linkRes = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });
    expect(linkRes.statusCode).toBe(200);

    // 3. Complete eKYC Verification
    const mockXml = makeXml('Alice Student', '2005-05-15', 'Female', '110001');
    const verifyRes = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent: mockXml,
        shareCode: '1234',
        consent: true
      });
    expect(verifyRes.statusCode).toBe(200);

    // 4. Fetch dashboard -> status should automatically promote to PENDING_SIGNATURE
    const dashRes = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', student.cookie);
    expect(dashRes.body.data.widgets.admissionApplication).toBe('PENDING_SIGNATURE');

    // 5. eSign the document (transitions PENDING_SIGNATURE -> SIGNED)
    const signRes = await request(app)
      .post('/api/workflow/sign')
      .set('Cookie', student.cookie);
    expect(signRes.statusCode).toBe(200);
    expect(signRes.body.data.status).toBe('SIGNED');

    // 6. Professor Approves application (transitions SIGNED -> Approved)
    const approveRes = await request(app)
      .post('/api/workflow/transition')
      .set('Cookie', professor.cookie)
      .send({
        userId: student.userId,
        targetStatus: 'Approved'
      });
    expect(approveRes.statusCode).toBe(200);
    expect(approveRes.body.data.status).toBe('Approved');

    // Verify history contains entries
    const histRes = await request(app)
      .get('/api/workflow/history')
      .set('Cookie', student.cookie);
    expect(histRes.statusCode).toBe(200);
    expect(histRes.body.data.length).toBeGreaterThanOrEqual(2);
  }, 15000);

  test('4. Reject invalid state transitions in state machine', async () => {
    const student = await getAuthenticatedUser('student@test.com', 'Password@123', 'Alice Student', 'student', '9111100001');
    const professor = await getAuthenticatedUser('prof@test.com', 'Password@123', 'Professor Bob', 'professor', '9111100002');

    // Save a draft first
    await request(app)
      .post('/api/admission/save-draft')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        currentStep: 1
      });

    // Draft cannot be signed (now delegated to emSigner controller)
    const signRes = await request(app)
      .post('/api/workflow/sign')
      .set('Cookie', student.cookie);
    expect(signRes.statusCode).toBe(400);
    expect(signRes.body.message).toContain('PENDING_SIGNATURE');

    // Initialize application to Submitted
    await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50
      });

    // Professor cannot approve if status is not SIGNED
    const approveRes = await request(app)
      .post('/api/workflow/transition')
      .set('Cookie', professor.cookie)
      .send({
        userId: student.userId,
        targetStatus: 'Approved'
      });
    expect(approveRes.statusCode).toBe(400);
    expect(approveRes.body.message).toContain('Cannot transition');
  });

  test('5. Correction Loop: Professor requests corrections, student corrects and re-submits', async () => {
    const student = await getAuthenticatedUser('student@test.com', 'Password@123', 'Alice Student', 'student', '9111100001');
    const professor = await getAuthenticatedUser('prof@test.com', 'Password@123', 'Professor Bob', 'professor', '9111100002');

    // Submit admission form
    await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50
      });

    // Professor requests revisions
    const reviseRes = await request(app)
      .post('/api/workflow/transition')
      .set('Cookie', professor.cookie)
      .send({
        userId: student.userId,
        targetStatus: 'Draft',
        message: 'Qualifying board name is incorrect.'
      });
    expect(reviseRes.statusCode).toBe(200);
    expect(reviseRes.body.data.status).toBe('Draft');

    // Fetch dashboard -> should see correctionMessage
    const dashRes = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', student.cookie);
    expect(dashRes.body.data.widgets.correctionMessage).toBe('Qualifying board name is incorrect.');

    // Edit draft should now be UNLOCKED (status is Draft)
    const saveRes = await request(app)
      .post('/api/admission/save-draft')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        currentStep: 1
      });
    expect(saveRes.statusCode).toBe(200);
    
    // Re-submit application -> should succeed and clear correction_message
    const resubmitRes = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'ICSE', // corrected board name
        gradYear: 2023,
        percentage: 95.50
      });
    expect(resubmitRes.statusCode).toBe(200);
    expect(resubmitRes.body.data.status).toBe('Submitted');

    // Check dashboard again -> correctionMessage is cleared
    const dashRes2 = await request(app)
      .get('/api/dashboard/student')
      .set('Cookie', student.cookie);
    expect(dashRes2.body.data.widgets.correctionMessage).toBeNull();
  });

  test('6. Strict Role-Based Access Control and Unauthorized Access Check', async () => {
    const student = await getAuthenticatedUser('student_auth@test.com', 'Password@123', 'Alice Student', 'student', '9111100003');
    const professor = await getAuthenticatedUser('prof_auth@test.com', 'Password@123', 'Professor Bob', 'professor', '9111100004');

    // 1. Student attempts to call professor dashboard stats -> 403 Forbidden
    const profDashRes = await request(app)
      .get('/api/dashboard/professor')
      .set('Cookie', student.cookie);
    expect(profDashRes.statusCode).toBe(403);

    // 2. Student attempts to get student packet via professor endpoint -> 403 Forbidden
    const studentPacketRes = await request(app)
      .get(`/api/dashboard/professor/student/${student.userId}`)
      .set('Cookie', student.cookie);
    expect(studentPacketRes.statusCode).toBe(403);

    // 3. Student attempts to transition workflow -> 403 Forbidden
    const transRes = await request(app)
      .post('/api/workflow/transition')
      .set('Cookie', student.cookie)
      .send({
        userId: student.userId,
        targetStatus: 'Approved'
      });
    expect(transRes.statusCode).toBe(403);

    // 4. Professor successfully fetches student details
    const profGetStudentPacketRes = await request(app)
      .get(`/api/dashboard/professor/student/${student.userId}`)
      .set('Cookie', professor.cookie);
    expect(profGetStudentPacketRes.statusCode).toBe(200);
    expect(profGetStudentPacketRes.body.success).toBe(true);
    expect(profGetStudentPacketRes.body.data.student.name).toBe('Alice Student');
  });

});

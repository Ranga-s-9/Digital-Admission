document.addEventListener('DOMContentLoaded', () => {
  // Navigation elements
  const tabHome = document.getElementById('portalHomeTab');
  const tabEkyc = document.getElementById('portalEkycTab');
  const tabDigilocker = document.getElementById('portalDigilockerTab');
  const navHome = document.getElementById('navHome');
  const navEkyc = document.getElementById('navEkyc');
  const navDigilocker = document.getElementById('navDigilocker');

  // Sub-view Panels (Steps)
  const stepIntro = document.getElementById('ekycStepIntro');
  const stepConsent = document.getElementById('ekycStepConsent');
  const stepUpload = document.getElementById('ekycStepUpload');
  const stepProgress = document.getElementById('ekycStepProgress');
  const stepResult = document.getElementById('ekycStepResult');

  // Step Badge Indicators
  const badgeIntro = document.getElementById('badgeIntro');
  const badgeConsent = document.getElementById('badgeConsent');
  const badgeUpload = document.getElementById('badgeUpload');
  const badgeProgress = document.getElementById('badgeProgress');
  const badgeResult = document.getElementById('badgeResult');

  // Interactive buttons
  const btnStartEkyc = document.getElementById('btnStartEkyc');
  const btnIntroBack = document.getElementById('btnIntroBack');
  const btnConsentSubmit = document.getElementById('btnConsentSubmit');
  const btnConsentBack = document.getElementById('btnConsentBack');
  const btnVerifySubmit = document.getElementById('btnVerifySubmit');
  const btnUploadBack = document.getElementById('btnUploadBack');
  const btnContinueToDigilocker = document.getElementById('btnContinueToDigilocker');
  const btnRetryEkyc = document.getElementById('btnRetryEkyc');
  const btnFailureBack = document.getElementById('btnFailureBack');

  // Consent elements
  const consentCheckbox = document.getElementById('ekycConsentCheckbox');

  // Upload elements
  const dropZone = document.getElementById('ekycDropZone');
  const fileInput = document.getElementById('ekycFileInput');
  const selectedFileBox = document.getElementById('ekycSelectedFileBox');
  const fileNameDisplay = document.getElementById('ekycFileNameDisplay');
  const btnRemoveFile = document.getElementById('btnRemoveFile');
  const progressContainer = document.getElementById('ekycUploadProgressContainer');
  const progressBar = document.getElementById('ekycUploadProgressBar');
  const fileFeedback = document.getElementById('ekycFileFeedback');

  // Share Code elements
  const shareCodeInput = document.getElementById('ekycShareCodeInput');
  const toggleShareCodeBtn = document.getElementById('ekycToggleShareCode');
  const eyeIcon = document.getElementById('ekycToggleEyeIcon');
  const shareCodeFeedback = document.getElementById('ekycShareCodeFeedback');

  // Processing elements
  const progressStepText = document.getElementById('ekycProgressStep');

  // Result elements
  const resultSuccess = document.getElementById('ekycResultSuccess');
  const resultFailure = document.getElementById('ekycResultFailure');
  const resRefIdDisplay = document.getElementById('resRefId');
  const resVerifiedAtDisplay = document.getElementById('resVerifiedAt');
  const failureMessageDisplay = document.getElementById('ekycFailureMessage');

  // Mock Generator pre-fill elements (Left side panel)
  const genName = document.getElementById('genName');
  const genDob = document.getElementById('genDob');
  const genGender = document.getElementById('genGender');
  const genPincode = document.getElementById('genPincode');
  const mockBanner = document.getElementById('ekycMockBanner');
  const statusBadge = document.getElementById('ekycStatusBadge');
  const statusText = document.getElementById('ekycStatusText');

  // State Variables
  let selectedFile = null;
  let uploadVerificationId = null;
  let profileAddress = '123 Main St';
  let profileState = 'Delhi';

  // Notification helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    if (!notify) return;

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `<svg viewBox="0 0 24 24" width="24" height="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>`;
    } else {
      notifyIcon.innerHTML = `<svg viewBox="0 0 24 24" width="24" height="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>`;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Navigate between sub-steps
  function showStep(stepName) {
    // Hide all step panels
    [stepIntro, stepConsent, stepUpload, stepProgress, stepResult].forEach(panel => {
      if (panel) panel.classList.remove('active');
    });

    // Reset step badges
    [badgeIntro, badgeConsent, badgeUpload, badgeProgress, badgeResult].forEach(badge => {
      if (badge) {
        badge.classList.remove('active', 'completed');
      }
    });

    // Activate corresponding panel and style badges
    if (stepName === 'intro') {
      if (stepIntro) stepIntro.classList.add('active');
      if (badgeIntro) badgeIntro.classList.add('active');
    } else if (stepName === 'consent') {
      if (stepConsent) stepConsent.classList.add('active');
      if (badgeIntro) badgeIntro.classList.add('completed');
      if (badgeConsent) badgeConsent.classList.add('active');
    } else if (stepName === 'upload') {
      if (stepUpload) stepUpload.classList.add('active');
      if (badgeIntro) badgeIntro.classList.add('completed');
      if (badgeConsent) badgeConsent.classList.add('completed');
      if (badgeUpload) badgeUpload.classList.add('active');
    } else if (stepName === 'progress') {
      if (stepProgress) stepProgress.classList.add('active');
      if (badgeIntro) badgeIntro.classList.add('completed');
      if (badgeConsent) badgeConsent.classList.add('completed');
      if (badgeUpload) badgeUpload.classList.add('completed');
      if (badgeProgress) badgeProgress.classList.add('active');
    } else if (stepName === 'result') {
      if (stepResult) stepResult.classList.add('active');
      if (badgeIntro) badgeIntro.classList.add('completed');
      if (badgeConsent) badgeConsent.classList.add('completed');
      if (badgeUpload) badgeUpload.classList.add('completed');
      if (badgeProgress) badgeProgress.classList.add('completed');
      if (badgeResult) badgeResult.classList.add('active');
    }
  }

  // Clear input fields and errors
  function clearErrors() {
    if (fileFeedback) fileFeedback.textContent = '';
    if (shareCodeFeedback) shareCodeFeedback.textContent = '';
    if (dropZone) dropZone.classList.remove('has-error');
  }

  function resetUploadState() {
    selectedFile = null;
    uploadVerificationId = null;
    if (shareCodeInput) shareCodeInput.value = '';
    if (fileInput) fileInput.value = '';
    if (selectedFileBox) selectedFileBox.style.display = 'none';
    if (dropZone) dropZone.style.display = 'flex';
    if (progressContainer) progressContainer.style.display = 'none';
    if (progressBar) progressBar.style.width = '0%';
    clearErrors();
  }

  // 1. Fetch current eKYC verification status & prefill mock XML generator
  async function loadEkycView() {
    resetUploadState();
    showStep('upload');

    try {
      // Fetch user identity first (needed for profile URL)
      const meRes = await fetch('/api/auth/me');
      const meResult = await meRes.json();
      if (!meRes.ok || !meResult.success) return;

      const user = meResult.data.user;
      if (genName) genName.value = user.name;

      // Fetch profile and eKYC status in parallel
      const [profRes, statusRes] = await Promise.all([
        fetch(`/api/profile/${user.userId}`),
        fetch('/api/ekyc/status')
      ]);

      const [profResult, statusResult] = await Promise.all([
        profRes.json(),
        statusRes.json()
      ]);

      // Apply profile data
      if (profRes.ok && profResult.success && profResult.data.profile) {
        const profile = profResult.data.profile;
        if (genDob) genDob.value = profile.dob || '';
        if (genGender) genGender.value = profile.gender || '';
        if (genPincode) genPincode.value = profile.pincode || '';
        if (profile.address) profileAddress = profile.address;
        if (profile.state) profileState = profile.state;
      }

      // Apply eKYC status
      if (statusRes.ok && statusResult.success) {
        const kyc = statusResult.data;

        // Toggle Mock Mode warning banner
        if (mockBanner) {
          mockBanner.style.display = kyc.development_mode ? 'flex' : 'none';
        }

        if (kyc.status === 'VERIFIED' || kyc.status === 'Verified') {
          // If already verified, jump directly to Success Result screen
          if (statusBadge) {
            statusBadge.className = 'badge badge-success';
            statusBadge.textContent = 'Verified';
          }
          if (statusText) {
            statusText.textContent = 'Identity details successfully verified via Aadhaar Offline XML.';
          }

          showStep('result');
          if (resultSuccess) resultSuccess.style.display = 'flex';
          if (resultFailure) resultFailure.style.display = 'none';

          if (resRefIdDisplay) resRefIdDisplay.textContent = kyc.verificationId || 'direct_xml_upload';
          if (resVerifiedAtDisplay) {
            resVerifiedAtDisplay.textContent = kyc.verifiedAt ? new Date(kyc.verifiedAt).toLocaleString() : '-';
          }
        } else {
          // Status Pending or Failed
          if (statusBadge) {
            statusBadge.className = kyc.status === 'Failed' || kyc.status === 'FAILED' ? 'badge badge-danger' : 'badge badge-warning';
            statusBadge.textContent = kyc.status;
          }
          if (statusText) {
            statusText.textContent = kyc.status === 'Failed' || kyc.status === 'FAILED'
              ? `Verification Failed: ${kyc.errorMessage || 'Details mismatch'}. Correct details and retry.`
              : 'Your identity has not been verified yet. Complete verification to proceed.';
          }
        }
      }
    } catch (err) {
      console.error('Load ekyc view error:', err);
      showNotification('Fetch Error', 'Failed to retrieve identity verification details.', 'error');
    }
  }

  // --- Step 1 Events ---
  if (btnStartEkyc) {
    btnStartEkyc.addEventListener('click', () => {
      consentCheckbox.checked = false;
      btnConsentSubmit.disabled = true;
      showStep('consent');
    });
  }

  if (btnIntroBack) {
    btnIntroBack.addEventListener('click', () => {
      // Go back to Home dashboard tab
      if (navHome) navHome.click();
    });
  }

  // --- Step 2 Consent Events ---
  if (consentCheckbox) {
    consentCheckbox.addEventListener('change', () => {
      btnConsentSubmit.disabled = !consentCheckbox.checked;
    });
  }

  if (btnConsentBack) {
    btnConsentBack.addEventListener('click', () => {
      showStep('intro');
    });
  }

  if (btnConsentSubmit) {
    btnConsentSubmit.addEventListener('click', async () => {
      btnConsentSubmit.disabled = true;
      try {
        const res = await fetch('/api/ekyc/consent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ consent: true })
        });
        const result = await res.json();
        
        if (res.ok && result.success) {
          showNotification('Consent Recorded', 'Consent declaration securely logged.', 'success');
          resetUploadState();
          showStep('upload');
        } else {
          showNotification('Consent Error', result.message || 'Failed to record consent.', 'error');
          btnConsentSubmit.disabled = false;
        }
      } catch (err) {
        console.error('Consent submit error:', err);
        showNotification('Connection Error', 'Network error while recording consent.', 'error');
        btnConsentSubmit.disabled = false;
      }
    });
  }

  // --- Step 3 Message listener for iframe eKYC Verification ---
  window.addEventListener('message', async (event) => {
    // Intercept EKYC_VERIFIED event from external iframe
    if (event.data && event.data.type === 'EKYC_VERIFIED') {
      const ekycPayload = event.data.data;
      const method = event.data.method || 'external';
      
      // Transitions to verifying step pane
      showStep('progress');
      if (progressStepText) progressStepText.textContent = 'Verifying demographic parameters against your profile...';
      
      try {
        const res = await fetch('/api/ekyc/verify-external', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: ekycPayload.name,
            dob: ekycPayload.dob,
            gender: ekycPayload.gender,
            pincode: ekycPayload.address?.pincode,
            photo: ekycPayload.photo,
            method: method
          })
        });
        
        const result = await res.json();
        
        // Brief visual feedback before showing result
        await new Promise(resolve => setTimeout(resolve, 300));
        
        if (res.ok && result.success) {
          showNotification('Identity Verified', 'eKYC verification completed successfully!', 'success');
          // Reload status and jump to result step
          loadEkycView();
        } else {
          showNotification('Verification Mismatch', result.message || 'Details mismatch.', 'error');
          showStep('result');
          if (resultSuccess) resultSuccess.style.display = 'none';
          if (resultFailure) resultFailure.style.display = 'flex';
          if (failureMessageDisplay) {
            failureMessageDisplay.textContent = result.message || 'Identity demographic mismatch.';
          }
        }
      } catch (err) {
        console.error('External verification save error:', err);
        showNotification('Save Error', 'Connection failed while recording verification.', 'error');
        showStep('result');
        if (resultSuccess) resultSuccess.style.display = 'none';
        if (resultFailure) resultFailure.style.display = 'flex';
        if (failureMessageDisplay) {
          failureMessageDisplay.textContent = 'Connection failed while saving verification.';
        }
      }
    }
  });

  // --- Step 3 Upload Events (Drag & Drop + Share Code) ---
  // Trigger file browse when clicking on drag-drop zone
  if (dropZone) {
    dropZone.addEventListener('click', () => {
      fileInput.click();
    });

    // Drag-over styling
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
      }, false);
    });

    // Handle dropped ZIP
    dropZone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        handleFileSelection(files[0]);
      }
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files.length > 0) {
        handleFileSelection(fileInput.files[0]);
      }
    });
  }

  // Validate ZIP extension and size
  function handleFileSelection(file) {
    clearErrors();
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    
    if (ext !== '.zip') {
      fileFeedback.textContent = 'Invalid file type. Only Aadhaar eKYC ZIP archives (.zip) are accepted.';
      fileFeedback.style.opacity = '1';
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      fileFeedback.textContent = 'File is too large. Maximum ZIP file size allowed is 5MB.';
      fileFeedback.style.opacity = '1';
      return;
    }

    selectedFile = file;
    fileNameDisplay.textContent = file.name;
    dropZone.style.display = 'none';
    selectedFileBox.style.display = 'flex';
  }

  if (btnRemoveFile) {
    btnRemoveFile.addEventListener('click', () => {
      resetUploadState();
    });
  }

  if (btnUploadBack) {
    btnUploadBack.addEventListener('click', () => {
      showStep('intro');
    });
  }

  // Toggle Share Code input visibility
  if (toggleShareCodeBtn) {
    toggleShareCodeBtn.addEventListener('click', () => {
      const type = shareCodeInput.getAttribute('type') === 'password' ? 'text' : 'password';
      shareCodeInput.setAttribute('type', type);
      
      // Update eye icon state visually if required
      if (type === 'text') {
        eyeIcon.style.fill = 'var(--primary)';
      } else {
        eyeIcon.style.fill = 'var(--text-muted)';
      }
    });
  }

  // Submit and verify file
  if (btnVerifySubmit) {
    btnVerifySubmit.addEventListener('click', async () => {
      clearErrors();
      let isValid = true;

      if (!selectedFile) {
        fileFeedback.textContent = 'Please select a valid Aadhaar Offline eKYC ZIP file.';
        fileFeedback.style.opacity = '1';
        isValid = false;
      }

      const shareCode = shareCodeInput.value.trim();
      if (!shareCode || !/^\d{4}$/.test(shareCode)) {
        shareCodeFeedback.textContent = 'Please enter a valid 4-digit share code.';
        shareCodeFeedback.style.opacity = '1';
        isValid = false;
      }

      if (!isValid) return;

      // Lock buttons
      btnVerifySubmit.disabled = true;
      btnUploadBack.disabled = true;

      // A. POST ZIP file to /upload via XHR (to track upload progress bar)
      try {
        const formData = new FormData();
        formData.append('ekycZip', selectedFile);

        progressContainer.style.display = 'block';
        progressBar.style.width = '0%';

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/ekyc/upload', true);

        // Track upload progress
        xhr.upload.addEventListener('progress', (e) => {
          if (e.lengthComputable) {
            const percentage = Math.round((e.loaded / e.total) * 100);
            progressBar.style.width = `${percentage}%`;
          }
        });

        xhr.onload = async () => {
          if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            uploadVerificationId = response.data.verificationId;

            // Clear Share Code from memory and inputs immediately
            shareCodeInput.value = '';

            // B. Proceed to verify phase
            triggerVerificationProcess(uploadVerificationId, shareCode);
          } else {
            let errorMsg = 'Failed to upload document.';
            let isConsentRequired = false;
            try {
              const errResponse = JSON.parse(xhr.responseText);
              errorMsg = errResponse.message || errorMsg;
              if (errResponse.error && errResponse.error.global === 'CONSENT_REQUIRED') {
                isConsentRequired = true;
              }
            } catch (e) { /* ignore */ }

            btnVerifySubmit.disabled = false;
            btnUploadBack.disabled = false;
            progressContainer.style.display = 'none';

            if (isConsentRequired) {
              showNotification('Consent Required', 'Please accept the consent terms to proceed with eKYC verification.', 'error');
              showStep('consent');
            } else {
              showNotification('Upload Failed', errorMsg, 'error');
              fileFeedback.textContent = errorMsg;
              fileFeedback.style.opacity = '1';
            }
          }
        };

        xhr.onerror = () => {
          showNotification('Upload Error', 'Network error during file upload.', 'error');
          btnVerifySubmit.disabled = false;
          btnUploadBack.disabled = false;
          progressContainer.style.display = 'none';
        };

        xhr.send(formData);

      } catch (err) {
        console.error('File upload error:', err);
        showNotification('Connection Error', 'Failed to communicate with upload server.', 'error');
        btnVerifySubmit.disabled = false;
        btnUploadBack.disabled = false;
      }
    });
  }

  // --- Step 4 Verification Progress Simulation ---
  async function triggerVerificationProcess(verificationId, shareCode) {
    showStep('progress');
    clearErrors();

    // Step-by-step verification progress texts
    const steps = [
      'Extracting files from secure archive...',
      'Validating XML structure and schemas...',
      'Verifying UIDAI digital certificate trust chain...',
      'Comparing demographic information against registered profile...'
    ];

    for (let i = 0; i < steps.length; i++) {
      if (progressStepText) progressStepText.textContent = steps[i];
      await new Promise(resolve => setTimeout(resolve, 150));
    }

    // Call /verify API
    try {
      const res = await fetch('/api/ekyc/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          verificationId,
          shareCode
        })
      });

      // Securely clear shareCode reference
      shareCode = null;

      const result = await res.json();

      showStep('result');
      if (res.ok && result.success) {
        // Success
        showNotification('Identity Verified', 'eKYC verification completed successfully!', 'success');
        if (resultSuccess) resultSuccess.style.display = 'flex';
        if (resultFailure) resultFailure.style.display = 'none';

        if (resRefIdDisplay) resRefIdDisplay.textContent = verificationId;
        if (resVerifiedAtDisplay) {
          resVerifiedAtDisplay.textContent = new Date(result.data.verifiedAt).toLocaleString();
        }

        // Refresh Student dashboard stepper list
        if (window.loadStudentDashboard) {
          window.loadStudentDashboard();
        }
      } else {
        // Failure
        if (resultSuccess) resultSuccess.style.display = 'none';
        if (resultFailure) resultFailure.style.display = 'flex';

        if (failureMessageDisplay) {
          failureMessageDisplay.textContent = result.message || 'Demographic data did not match your student profile (Name, DOB, Gender, or Pincode).';
        }
      }

    } catch (err) {
      console.error('Verification connection error:', err);
      showStep('result');
      if (resultSuccess) resultSuccess.style.display = 'none';
      if (resultFailure) resultFailure.style.display = 'flex';
      if (failureMessageDisplay) {
        failureMessageDisplay.textContent = 'A connection error occurred during cryptographic signature checks. Please retry.';
      }
    }
  }

  // --- Step 5 Result Page Events ---
  if (btnContinueToDigilocker) {
    btnContinueToDigilocker.addEventListener('click', () => {
      // Navigate to DigiLocker tab cleanly
      if (navDigilocker) {
        navDigilocker.click();
      }
    });
  }

  if (btnRetryEkyc) {
    btnRetryEkyc.addEventListener('click', () => {
      resetUploadState();
      showStep('upload');
    });
  }

  if (btnFailureBack) {
    btnFailureBack.addEventListener('click', () => {
      if (navHome) navHome.click();
    });
  }

  // --- Mock XML Generator Event Handlers ---
  const generatorForm = document.getElementById('ekycGeneratorForm');
  if (generatorForm) {
    generatorForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const aadhaar = document.getElementById('genAadhaar').value.trim();
      const shareCode = document.getElementById('genShareCode').value.trim();
      const name = document.getElementById('genName').value.trim();
      const dob = document.getElementById('genDob').value.trim();
      const gender = document.getElementById('genGender').value;
      const pincode = document.getElementById('genPincode').value.trim();

      // Client-side validations
      if (!/^\d{12}$/.test(aadhaar)) {
        showNotification('Validation Error', 'Aadhaar must be exactly 12 digits.', 'error');
        return;
      }
      if (!/^\d{4}$/.test(shareCode)) {
        showNotification('Validation Error', 'Share code must be exactly 4 digits.', 'error');
        return;
      }
      if (!name || !dob || !gender || !/^\d{6}$/.test(pincode)) {
        showNotification('Validation Error', 'Please fill all fields correctly.', 'error');
        return;
      }

      const btn = document.getElementById('btnGenerateXml');
      const originalText = btn ? btn.textContent : '';
      if (btn) {
        btn.disabled = true;
        btn.textContent = 'Generating...';
      }

      try {
        const response = await fetch('/api/ekyc/generate-mock-xml', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            aadhaar,
            shareCode,
            name,
            dob,
            gender,
            pincode,
            address: profileAddress || '123 Main St',
            state: profileState || 'Delhi'
          })
        });

        const result = await response.json();

        if (response.ok && result.success) {
          const { filename, xmlContent } = result.data;

          // Trigger browser download of XML file
          const blob = new Blob([xmlContent], { type: 'text/xml' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);

          showNotification('Success', 'Mock XML downloaded! Please ZIP this file and upload it.', 'success');
        } else {
          showNotification('Error', result.message || 'Failed to generate mock XML.', 'error');
        }
      } catch (err) {
        console.error('XML Generation error:', err);
        showNotification('Network Failure', 'Failed to connect to generator service.', 'error');
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.textContent = originalText;
        }
      }
    });
  }

  // Expose global initializer
  window.loadEkycView = loadEkycView;
});

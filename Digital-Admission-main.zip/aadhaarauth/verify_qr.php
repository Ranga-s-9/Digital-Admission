<?php
/**
 * verify_qr.php
 * REST API endpoint for Aadhaar Secure QR Code decoding.
 */

header('Content-Type: application/json');

require_once 'qrCodeDecoder.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method Not Allowed. Use POST.'
    ]);
    exit;
}

try {
    // Read JSON payload or standard POST field
    $rawInput = file_get_contents('php://input');
    $jsonData = json_decode($rawInput, true);
    
    $qrData = '';
    if (isset($jsonData['qr_data'])) {
        $qrData = $jsonData['qr_data'];
    } elseif (isset($_POST['qr_data'])) {
        $qrData = $_POST['qr_data'];
    }

    if (empty($qrData)) {
        throw new Exception("No QR Code data payload was provided.");
    }

    // Decode QR Code
    $result = qrCodeDecoder::decode($qrData);

    echo json_encode([
        'success' => true,
        'message' => 'Aadhaar Secure QR Code parsed successfully.',
        'data' => $result
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

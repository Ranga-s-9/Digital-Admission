'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('../config/db');
const { logger } = require('../middleware/logger');
const { getEkycAdapter, isMockMode } = require('../services/ekyc');
const consentService = require('../services/ekyc/consent.service');
const auditService = require('../services/ekyc/audit.service');
const zipExtractionService = require('../services/ekyc/zipExtraction.service');
const NotificationService = require('../services/notificationService');

// Get temp directory from env or default
const TEMP_UPLOAD_DIR = path.resolve(process.cwd(), process.env.TEMP_UPLOAD_DIRECTORY || './uploads/ekyc_temp');

// Ensure directory exists
if (!fs.existsSync(TEMP_UPLOAD_DIR)) {
  fs.mkdirSync(TEMP_UPLOAD_DIR, { recursive: true });
}

/**
 * Technical to user friendly error mapping
 */
const ERROR_MAP = {
  'CONSENT_REQUIRED': {
    status: 400,
    message: 'Consent is mandatory to perform identity verification.'
  },
  'INVALID_FILE': {
    status: 400,
    message: 'The uploaded file is invalid. Please upload a valid ZIP file.'
  },
  'FILE_TOO_LARGE': {
    status: 400,
    message: 'The uploaded file exceeds the maximum size limit.'
  },
  'INVALID_ZIP': {
    status: 400,
    message: 'The uploaded ZIP archive is invalid or tampered with.'
  },
  'XML_NOT_FOUND': {
    status: 400,
    message: 'No Offline e-KYC XML document was found in the uploaded ZIP.'
  },
  'INVALID_XML': {
    status: 400,
    message: 'Malformed XML uploaded. Please upload a valid Aadhaar Offline XML file.'
  },
  'MALFORMED_XML': {
    status: 400,
    message: 'Malformed XML uploaded. Please upload a valid Aadhaar Offline XML file.'
  },
  'SIGNATURE_INVALID': {
    status: 400,
    message: 'The uploaded identity document could not be authenticated. Please generate a new Offline e-KYC document and try again.'
  },
  'CERTIFICATE_INVALID': {
    status: 400,
    message: 'A certificate authentication failure occurred. Please retry later.'
  },
  'HASH_MISMATCH': {
    status: 400,
    message: 'Verification failed: Hashed mobile or email did not match registered account.'
  },
  'IDENTITY_MISMATCH': {
    status: 400,
    message: 'eKYC verification failed: Identity details mismatched your registered profile.'
  },
  'VERIFICATION_FAILED': {
    status: 400,
    message: 'eKYC verification failed. Please check details and try again.'
  },
  'UNAUTHORIZED': {
    status: 401,
    message: 'Unauthorized access to verify identity.'
  },
  'FORBIDDEN': {
    status: 403,
    message: 'Access denied: You are not authorized to view this eKYC record.'
  },
  'PROCESSING_ERROR': {
    status: 500,
    message: 'An error occurred while processing the verification.'
  },
  'TIMEOUT_ERROR': {
    status: 504,
    message: 'eKYC verification timed out. Please try again.'
  },
  'EXTERNAL_SERVICE_FAILURE': {
    status: 502,
    message: 'eKYC external gateway service is currently unavailable. Please retry later.'
  },
  'PRODUCTION_EKYC_OFFLINE': {
    status: 503,
    message: 'Real eKYC production services are offline.'
  },
  'DUPLICATE_VERIFICATION': {
    status: 400,
    message: 'Identity verification has already been successfully completed.'
  },
  'PROFILE_NOT_INITIALIZED': {
    status: 400,
    message: 'Please complete your Student Profile first to verify eKYC.'
  },
  'AADHAAR_MISMATCH': {
    status: 400,
    message: 'Verification failed: The Aadhaar number verified via e-KYC does not match the Aadhaar number connected to DigiLocker.'
  }
};

/**
 * Helper to format error response
 */
function sendError(res, errCode, customDetails = null) {
  const errConfig = ERROR_MAP[errCode] || { status: 500, message: 'An internal system error occurred during verification.' };
  return res.status(errConfig.status).json({
    success: false,
    message: customDetails ? `${errConfig.message} (${customDetails})` : errConfig.message,
    error: { global: errCode }
  });
}

/**
 * POST /api/ekyc/consent
 * Record student consent for eKYC identity verification
 */
async function recordConsent(req, res) {
  try {
    const studentId = req.user.userId;
    const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

    // 1. Record consent
    const consentResult = await consentService.recordConsent({ studentId, ipAddress });

    // 2. Log event
    await auditService.logEvent({
      studentId,
      event: auditService.EVENTS.CONSENT_CREATED,
      status: 'CONSENTED',
      ipAddress,
      details: `version=${consentResult.consentVersion}`
    });

    // 3. Update ekyc_requests if it exists to CONSENTED status
    const existing = await db.query('SELECT id, verification_status FROM ekyc_requests WHERE user_id = ?', [studentId]);
    if (existing && existing.length > 0) {
      if (existing[0].verification_status !== 'VERIFIED') {
        await db.query(
          `UPDATE ekyc_requests SET verification_status = 'CONSENTED', updated_at = CURRENT_TIMESTAMP WHERE user_id = ?`,
          [studentId]
        );
      }
    } else {
      await db.query(
        `INSERT INTO ekyc_requests (user_id, verification_status) VALUES (?, 'CONSENTED')`,
        [studentId]
      );
    }

    return res.status(200).json({
      success: true,
      message: 'Consent successfully recorded.',
      data: {
        consentVersion: consentResult.consentVersion
      }
    });

  } catch (error) {
    logger.error('Record consent error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * POST /api/ekyc/upload
 * Handles ZIP file upload and registers FILE_UPLOADED request
 */
async function uploadFile(req, res) {
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
  const studentId = req.user.userId;

  try {
    // 1. Verify consent exists
    const consentCheck = await consentService.checkConsent(studentId);
    if (!consentCheck.hasConsent) {
      return sendError(res, 'CONSENT_REQUIRED');
    }

    // 2. File existence check (via multer)
    if (!req.file) {
      return sendError(res, 'INVALID_FILE', 'No file was uploaded');
    }

    const zipBuffer = req.file.buffer;

    // 3. Validate ZIP magic numbers
    if (!zipExtractionService.isValidZip(zipBuffer)) {
      return sendError(res, 'INVALID_ZIP');
    }

    // 4. Generate unique verification ID and temporary ZIP file name
    const verificationId = crypto.randomUUID();
    const tempFilePath = path.join(TEMP_UPLOAD_DIR, `${verificationId}.zip`);

    // Write buffer to temp file securely
    fs.writeFileSync(tempFilePath, zipBuffer);

    // 5. Create or update ekyc_requests record
    const existing = await db.query('SELECT id, verification_status FROM ekyc_requests WHERE user_id = ?', [studentId]);
    
    if (existing && existing.length > 0) {
      if (existing[0].verification_status === 'VERIFIED') {
        // Clean up temp file
        if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
        return sendError(res, 'DUPLICATE_VERIFICATION');
      }

      await db.query(
        `UPDATE ekyc_requests 
         SET verification_id = ?, xml_filename = ?, verification_status = 'FILE_UPLOADED', error_message = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [verificationId, req.file.originalname, studentId]
      );
    } else {
      await db.query(
        `INSERT INTO ekyc_requests (user_id, verification_id, xml_filename, verification_status)
         VALUES (?, ?, ?, 'FILE_UPLOADED')`,
        [studentId, verificationId, req.file.originalname]
      );
    }

    // 6. Log audit event
    await auditService.logEvent({
      studentId,
      verificationId,
      event: auditService.EVENTS.FILE_UPLOADED,
      status: 'FILE_UPLOADED',
      ipAddress,
      details: `filename=${req.file.originalname}`
    });

    return res.status(200).json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        verificationId
      }
    });

  } catch (error) {
    logger.error('Upload file error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * POST /api/ekyc/verify
 * Orchestrates Offline XML eKYC verification pipeline
 */
async function verifyEkyc(req, res) {
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
  const userId = req.user.userId;
  const { verificationId, shareCode, xmlContent, consent } = req.body;

  let tempZipPath = null;

  try {
    let finalXmlContent = xmlContent;
    let originalFilename = 'aadhaar_offline_ekyc.xml';

    // A. New Flow: If verificationId is provided, extract XML from temporary ZIP on disk
    if (verificationId) {
      // 1. Fetch verification request details
      const rows = await db.query(
        'SELECT xml_filename, verification_status FROM ekyc_requests WHERE user_id = ? AND verification_id = ?',
        [userId, verificationId]
      );

      if (!rows || rows.length === 0) {
        return sendError(res, 'FORBIDDEN', 'Invalid verification reference');
      }

      if (rows[0].verification_status === 'VERIFIED') {
        return sendError(res, 'DUPLICATE_VERIFICATION');
      }

      originalFilename = rows[0].xml_filename || originalFilename;
      tempZipPath = path.join(TEMP_UPLOAD_DIR, `${verificationId}.zip`);

      // 2. Validate zip file existence on disk
      if (!fs.existsSync(tempZipPath)) {
        return sendError(res, 'INVALID_ZIP', 'Uploaded ZIP file was lost or expired');
      }

      // 3. Safe ZIP extraction
      try {
        await db.query(
          `UPDATE ekyc_requests SET verification_status = 'PROCESSING', updated_at = CURRENT_TIMESTAMP WHERE user_id = ?`,
          [userId]
        );

        const extractionResult = await zipExtractionService.extractXmlFromZip(tempZipPath, { shareCode });
        finalXmlContent = extractionResult.xmlContent;
        originalFilename = extractionResult.filename;

      } catch (zipErr) {
        // Safe deletion of tampered/bomb ZIPs
        _safeDeleteFile(tempZipPath);
        return sendError(res, zipErr.code || 'INVALID_ZIP', zipErr.detail);
      }

      // Safe deletion of ZIP after successful XML extraction
      _safeDeleteFile(tempZipPath);
    } else {
      // B. Backward-compatible Flow: direct XML content validation (used by old tests)
      if (consent !== true && consent !== 'true') {
        return sendError(res, 'CONSENT_REQUIRED');
      }
    }

    // 4. Log verification start
    await auditService.logEvent({
      studentId: userId,
      verificationId,
      event: auditService.EVENTS.VERIFICATION_STARTED,
      status: 'PROCESSING',
      ipAddress
    });

    // 5. Perform validation & demographic verification via active adapter (mock or real)
    const adapter = getEkycAdapter();
    const result = await adapter.verify(userId, finalXmlContent, shareCode, ipAddress);

    if (!result.success) {
      await auditService.logEvent({
        studentId: userId,
        verificationId,
        event: auditService.EVENTS.VERIFICATION_FAILED,
        status: 'FAILED',
        ipAddress,
        failureReason: 'IDENTITY_MISMATCH',
        details: result.error
      });

      return sendError(res, 'IDENTITY_MISMATCH', result.error);
    }

    // 6. Complete ekyc_requests update (already done in adapter, but we ensure columns match)
    const verifiedAt = Date.now();
    await db.query(
      `UPDATE ekyc_requests 
       SET verification_status = 'VERIFIED', error_message = NULL, verified_at = ?, reference_id = ?, updated_at = CURRENT_TIMESTAMP
       WHERE user_id = ?`,
      [verifiedAt, verificationId || 'direct_xml_upload', userId]
    );

    // 7. Log success audit logs
    await auditService.logEvent({
      studentId: userId,
      verificationId,
      event: auditService.EVENTS.VERIFICATION_SUCCESS,
      status: 'VERIFIED',
      ipAddress,
      details: `mode=${result.development_mode ? 'development' : 'production'}`
    });

    // 8. Trigger notification
    try {
      await NotificationService.send({
        userId,
        type: 'document_verification',
        title: 'Identity Verified (eKYC)',
        content: 'Your identity has been successfully verified via Aadhaar Offline XML.'
      });
    } catch (notifErr) {
      logger.error('Failed to trigger eKYC notification:', notifErr);
    }

    return res.status(200).json({
      success: true,
      message: 'Identity successfully verified via eKYC.',
      data: {
        status: 'VERIFIED',
        verifiedAt,
        development_mode: result.development_mode
      }
    });

  } catch (err) {
    // Make sure we delete zip file in case of any failures
    if (tempZipPath) _safeDeleteFile(tempZipPath);

    let errCode = 'VERIFICATION_FAILED';
    const msg = err.message;

    if (msg === 'MISSING_XML_CONTENT') errCode = 'MISSING_XML_CONTENT';
    else if (msg === 'MALFORMED_XML') errCode = 'MALFORMED_XML';
    else if (msg === 'INVALID_XML') errCode = 'INVALID_XML';
    else if (msg === 'INVALID_SHARE_CODE') errCode = 'SIGNATURE_INVALID'; // Map to signature/security error
    else if (msg === 'MISSING_IDENTITY_FIELDS') errCode = 'MISSING_IDENTITY_FIELDS';
    else if (msg === 'UNAUTHORIZED_ACCESS') errCode = 'UNAUTHORIZED';
    else if (msg === 'PROFILE_NOT_INITIALIZED') errCode = 'PROFILE_NOT_INITIALIZED';
    else if (msg === 'DUPLICATE_VERIFICATION') errCode = 'DUPLICATE_VERIFICATION';
    else if (msg === 'TIMEOUT_ERROR') errCode = 'TIMEOUT_ERROR';
    else if (msg === 'EXTERNAL_SERVICE_FAILURE') errCode = 'EXTERNAL_SERVICE_FAILURE';
    else if (msg.includes('PRODUCTION_EKYC_OFFLINE')) errCode = 'PRODUCTION_EKYC_OFFLINE';
    else if (msg === 'SIGNATURE_INVALID') errCode = 'SIGNATURE_INVALID';
    else if (msg === 'HASH_MISMATCH') errCode = 'HASH_MISMATCH';
    else if (msg === 'AADHAAR_MISMATCH') errCode = 'AADHAAR_MISMATCH';

    // Record DB failure state
    try {
      await db.query(
        `UPDATE ekyc_requests 
         SET verification_status = 'FAILED', error_message = ?, updated_at = CURRENT_TIMESTAMP 
         WHERE user_id = ?`,
        [msg, userId]
      );
    } catch (dbErr) { /* ignore */ }

    await auditService.logEvent({
      studentId: userId,
      verificationId,
      event: auditService.EVENTS.VERIFICATION_FAILED,
      status: 'FAILED',
      ipAddress,
      failureReason: errCode,
      details: msg
    });

    return sendError(res, errCode, msg);
  }
}

/**
 * GET /api/ekyc/status/:verificationId
 * Retrieve student eKYC status details by verification ID
 */
async function getEkycStatusById(req, res) {
  try {
    const studentId = req.user.userId;
    const { verificationId } = req.params;

    const rows = await db.query(
      `SELECT verification_status, error_message, verified_at, aadhaar_masked, xml_filename, user_id
       FROM ekyc_requests WHERE verification_id = ?`,
      [verificationId]
    );

    if (!rows || rows.length === 0) {
      return sendError(res, 'FORBIDDEN', 'eKYC record not found');
    }

    // Security check: Student A must not access Student B's eKYC record
    if (rows[0].user_id !== studentId && req.user.role !== 'admin' && req.user.role !== 'professor') {
      return sendError(res, 'FORBIDDEN');
    }

    const reqRecord = rows[0];
    return res.status(200).json({
      success: true,
      message: 'eKYC status retrieved successfully',
      data: {
        verified: reqRecord.verification_status === 'VERIFIED' || reqRecord.verification_status === 'Verified',
        status: reqRecord.verification_status,
        errorMessage: reqRecord.error_message || '',
        verifiedAt: reqRecord.verified_at || null,
        aadhaarMasked: reqRecord.aadhaar_masked || '',
        xmlFilename: reqRecord.xml_filename || '',
        development_mode: isMockMode()
      }
    });

  } catch (error) {
    logger.error('Get status by ID error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * GET /api/ekyc/result/:verificationId
 * Retrieve final eKYC result details by verification ID
 */
async function getEkycResultById(req, res) {
  try {
    const studentId = req.user.userId;
    const { verificationId } = req.params;

    const rows = await db.query(
      `SELECT verification_status, error_message, verified_at, aadhaar_masked, xml_filename, user_id
       FROM ekyc_requests WHERE verification_id = ?`,
      [verificationId]
    );

    if (!rows || rows.length === 0) {
      return sendError(res, 'FORBIDDEN', 'eKYC record not found');
    }

    // Security check: Student A must not access Student B's eKYC record
    if (rows[0].user_id !== studentId && req.user.role !== 'admin' && req.user.role !== 'professor') {
      return sendError(res, 'FORBIDDEN');
    }

    const reqRecord = rows[0];
    if (reqRecord.verification_status !== 'VERIFIED' && reqRecord.verification_status !== 'Verified') {
      return res.status(400).json({
        success: false,
        message: 'No verified eKYC result available for this reference.',
        error: { global: 'VERIFICATION_FAILED' }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'eKYC result retrieved successfully',
      data: {
        status: reqRecord.verification_status,
        method: 'Offline e-KYC',
        referenceId: verificationId,
        verifiedAt: reqRecord.verified_at,
        aadhaarMasked: reqRecord.aadhaar_masked
      }
    });

  } catch (error) {
    logger.error('Get result by ID error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * GET /api/ekyc/history
 * Retrieves full verification audit trail and history for logged-in user
 */
async function getEkycHistory(req, res) {
  try {
    const studentId = req.user.userId;

    const rows = await db.query(
      `SELECT verification_id, verification_status, error_message, verified_at, xml_filename, created_at, updated_at
       FROM ekyc_requests WHERE user_id = ? ORDER BY created_at DESC`,
      [studentId]
    );

    return res.status(200).json({
      success: true,
      message: 'Verification history retrieved successfully',
      data: rows || []
    });

  } catch (error) {
    logger.error('Get history error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * GET /api/ekyc/status
 * Retrieves current latest eKYC status (Backward-compatible dashboard endpoint)
 */
async function getEkycStatus(req, res) {
  try {
    const userId = req.user.userId;
    const rows = await db.query(
      `SELECT verification_status, error_message, verified_at, aadhaar_masked, xml_filename, verification_id
       FROM ekyc_requests WHERE user_id = ?`,
      [userId]
    );

    const mode = process.env.EKYC_MODE || 'mock';

    if (rows && rows.length > 0) {
      const reqRecord = rows[0];
      const isVerified = reqRecord.verification_status === 'VERIFIED' || reqRecord.verification_status === 'Verified';
      return res.status(200).json({
        success: true,
        message: 'eKYC status retrieved successfully',
        data: {
          verified: isVerified,
          status: reqRecord.verification_status,
          errorMessage: reqRecord.error_message || '',
          verifiedAt: reqRecord.verified_at || null,
          aadhaarMasked: reqRecord.aadhaar_masked || '',
          xmlFilename: reqRecord.xml_filename || '',
          verificationId: reqRecord.verification_id || '',
          development_mode: mode === 'mock'
        }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'No eKYC verification request found.',
      data: {
        verified: false,
        status: 'Not Started',
        errorMessage: '',
        verifiedAt: null,
        aadhaarMasked: '',
        xmlFilename: '',
        verificationId: '',
        development_mode: mode === 'mock'
      }
    });

  } catch (error) {
    logger.error('Get default status error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * Generates a mock Aadhaar Offline XML document
 */
async function generateMockXml(req, res) {
  try {
    const { name, dob, gender, address, state, pincode, shareCode, aadhaar } = req.body;

    // Validate parameters
    if (!name || !dob || !gender || !address || !state || !pincode || !shareCode || !aadhaar) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required to generate the mock eKYC XML.',
        error: { global: 'All fields are required' }
      });
    }

    if (!/^\d{12}$/.test(aadhaar)) {
      return res.status(400).json({
        success: false,
        message: 'Aadhaar number must be exactly 12 digits.',
        error: { aadhaar: 'Aadhaar must be 12 digits' }
      });
    }

    if (!/^\d{4}$/.test(shareCode)) {
      return res.status(400).json({
        success: false,
        message: 'Share code must be exactly 4 digits.',
        error: { shareCode: 'Share code must be 4 digits' }
      });
    }

    if (!/^\d{6}$/.test(pincode)) {
      return res.status(400).json({
        success: false,
        message: 'Pincode must be exactly 6 digits.',
        error: { pincode: 'Pincode must be 6 digits' }
      });
    }

    // Generate Aadhaar Offline Secure XML structure
    const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="${shareCode}" aadhaar="${aadhaar}">
  <UidData>
    <Poi name="${name}" dob="${dob}" gender="${gender}"/>
    <Poa co="Guardian Name" street="${address}" state="${state}" pc="${pincode}"/>
    <Pht>MOCK_BASE64_PHOTO_DATA_HERE</Pht>
  </UidData>
  <Signature>MOCK_TRUSTED_UIDAI_DIGITAL_SIGNATURE_HASH</Signature>
</OfflinePaperlessKyc>`;

    return res.status(200).json({
      success: true,
      message: 'Mock Aadhaar Offline XML generated successfully',
      data: {
        filename: 'aadhaar_offline_ekyc.xml',
        xmlContent
      }
    });

  } catch (error) {
    logger.error('Generate mock XML error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error during XML generation',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * POST /api/ekyc/verify-external
 * Orchestrates external Aadhaar verification result validation and matching
 */
async function verifyExternalEkyc(req, res) {
  const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
  const userId = req.user.userId;
  const { name, dob, gender, pincode, photo, method } = req.body;

  try {
    // 1. Fetch user and profile details from DB
    const users = await db.query('SELECT name, email, mobile FROM users WHERE id = ?', [userId]);
    if (!users || users.length === 0) {
      return sendError(res, 'UNAUTHORIZED');
    }

    const profiles = await db.query('SELECT dob, gender, pincode FROM student_profiles WHERE user_id = ?', [userId]);
    let profile = profiles && profiles.length > 0 ? profiles[0] : null;
    if (!profile) {
      profile = { dob: dob || '2005-05-15', gender: gender || 'Male', pincode: pincode || '110001' };
      await db.query(
        'INSERT INTO student_profiles (user_id, dob, gender, pincode) VALUES (?, ?, ?, ?)',
        [userId, profile.dob, profile.gender, profile.pincode]
      );
    }

    // 2. Perform demographic matching
    const identityMatchingService = require('../services/ekyc/identityMatching.service');
    const matchResult = identityMatchingService.matchIdentity({
      name,
      dob,
      gender,
      address: { pincode }
    }, {
      name: users[0].name,
      dob: profile.dob,
      gender: profile.gender,
      pincode: profile.pincode
    });

    const isMatch = matchResult.result === 'MATCH' || matchResult.result === 'REVIEW_REQUIRED';

    const verifiedStatus = isMatch ? 'VERIFIED' : 'FAILED';
    const errorMessage = isMatch ? null : `Identity mismatch: ${matchResult.mismatches.join(', ')} did not match profile`;
    const verifiedAt = isMatch ? Date.now() : null;

    // 3. Save to database (ekyc_requests)
    const existing = await db.query('SELECT id, verification_status FROM ekyc_requests WHERE user_id = ?', [userId]);
    const referenceId = crypto.randomUUID();
    const aadhaarMasked = 'XXXX-XXXX-8888';

    if (existing && existing.length > 0) {
      if (existing[0].verification_status === 'VERIFIED') {
        return sendError(res, 'DUPLICATE_VERIFICATION');
      }

      await db.query(
        `UPDATE ekyc_requests 
         SET verification_id = ?, aadhaar_masked = ?, verification_status = ?, error_message = ?, verified_at = ?, reference_id = ?, verification_method = ?, updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [referenceId, aadhaarMasked, verifiedStatus, errorMessage, verifiedAt, referenceId, method || 'external_aadhaar', userId]
      );
    } else {
      await db.query(
        `INSERT INTO ekyc_requests (user_id, verification_id, aadhaar_masked, reference_id, verification_status, error_message, verified_at, verification_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [userId, referenceId, aadhaarMasked, referenceId, verifiedStatus, errorMessage, verifiedAt, method || 'external_aadhaar']
      );
    }

    // 4. Log audit log
    const action = isMatch ? 'VERIFY_SUCCESS' : 'VERIFY_FAILED';
    const logDetails = isMatch
      ? `Identity details verified successfully via external Aadhaar integration (${method || 'external'}).`
      : `Verification failed: ${errorMessage}`;

    await db.query(
      `INSERT INTO ekyc_audit_logs (user_id, action, ip_address, details)
       VALUES (?, ?, ?, ?)`,
      [userId, action, ipAddress, logDetails]
    );

    // 5. Trigger notification
    if (isMatch) {
      try {
        await NotificationService.send({
          userId,
          type: 'document_verification',
          title: 'Identity Verified (eKYC)',
          content: 'Your identity has been successfully verified via external Aadhaar integration.'
        });
      } catch (notifErr) {
        logger.error('Failed to trigger eKYC notification:', notifErr);
      }
    }

    if (!isMatch) {
      return sendError(res, 'IDENTITY_MISMATCH', errorMessage);
    }

    return res.status(200).json({
      success: true,
      message: 'Identity successfully verified via external eKYC.',
      data: {
        status: 'VERIFIED',
        verifiedAt,
        referenceId
      }
    });

  } catch (error) {
    logger.error('External verify error:', { message: error.message, stack: error.stack });
    return sendError(res, 'PROCESSING_ERROR');
  }
}

/**
 * Safe file deletion helper
 */
function _safeDeleteFile(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (e) {
    logger.error('File cleanup failed:', { path: filePath, error: e.message });
  }
}

module.exports = {
  generateMockXml,
  recordConsent,
  uploadFile,
  verifyEkyc,
  getEkycStatusById,
  getEkycResultById,
  getEkycHistory,
  getEkycStatus,
  verifyExternalEkyc
};

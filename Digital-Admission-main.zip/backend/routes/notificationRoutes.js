const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const notificationController = require('../controllers/notificationController');

// All notification routes require authenticated session
router.use(authenticateToken);

// GET /api/notifications - retrieve user notifications & unread count
router.get('/', notificationController.getUserNotifications);

// POST /api/notifications/:id/read - mark notification as read
router.post('/:id/read', notificationController.markNotificationAsRead);

// POST /api/notifications/:id/unread - mark notification as unread
router.post('/:id/unread', notificationController.markNotificationAsUnread);

// POST /api/notifications/read-all - mark all notifications as read
router.post('/read-all', notificationController.markAllNotificationsAsRead);

module.exports = router;

# Module 01 — User Registration

## Purpose

Provide a registration workflow for Student and Professor users.

## Source Requirement

The DPI notes begin the workflow with Student / Professor registration, collection of necessary details, mathematical CAPTCHA and OTP authentication.

## Functional Requirements

- Provide a registration page.
- Allow selection of user role where applicable.
- Collect required registration details.
- Validate mandatory fields.
- Display a mathematical CAPTCHA.
- Verify CAPTCHA before continuing.
- Trigger OTP authentication.
- Create the account only after successful verification.
- Provide clear success and failure messages.

## Suggested Flow

```text
Open Registration
      |
      v
Select User Type
      |
      v
Enter Required Details
      |
      v
Mathematical CAPTCHA
      |
      v
Validate
      |
      v
OTP Verification
      |
      v
Create Account
```

## Validation

- Required fields must not be empty.
- Email format must be validated.
- Password rules should be enforced.
- CAPTCHA must expire/reset appropriately.
- OTP must have an expiry and retry policy.
- Duplicate accounts should be handled safely.

## Acceptance Criteria

- A valid user can register successfully.
- Invalid CAPTCHA blocks registration.
- Invalid/expired OTP blocks registration.
- Duplicate registration is rejected safely.
- Registration creates a usable account.
- Sensitive values are not logged.

## Dependencies

- Database
- OTP service
- CAPTCHA service

## Notes

The supplied notes do not define the exact registration fields or password policy. Those are implementation decisions.

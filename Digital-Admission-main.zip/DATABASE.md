# Database Schema & Definitions

The system utilizes a dual database interface supporting **SQLite3** for development/testing and **MySQL / MariaDB** (compatible with standard XAMPP servers) for production environments.

---

## 1. Entity Relationship (ER) Diagram

```mermaid
erDiagram
  users ||--o| student_profiles : "user_id (1:1)"
  users ||--o| admission_applications : "user_id (1:1)"
  users ||--o{ otps : "user_id (1:N)"
  users ||--o{ ekyc_requests : "user_id (1:1)"
  users ||--o{ digilocker_connections : "user_id (1:1)"
  users ||--o{ digilocker_documents : "user_id (1:N)"
  users ||--o{ esignzy_requests : "user_id (1:1)"
  users ||--o{ notifications : "user_id (1:N)"

  roles ||--o{ users : "role_id (1:N)"
```

---

## 2. Table Schemas

### `users`
Stores credentials, roles, and account lockout metrics.
* `id` INT AUTO_INCREMENT PRIMARY KEY
* `name` VARCHAR(255) NOT NULL
* `email` VARCHAR(255) UNIQUE NOT NULL
* `mobile` VARCHAR(20) UNIQUE NOT NULL
* `password_hash` VARCHAR(255) NOT NULL
* `role` VARCHAR(50) DEFAULT 'student' (values: 'student', 'professor', 'admin')
* `status` VARCHAR(50) DEFAULT 'active' (values: 'active', 'locked', 'suspended')
* `failed_attempts` INT DEFAULT 0
* `lockout_until` BIGINT DEFAULT 0

### `student_profiles`
Stores students personal, contact, and academic details.
* `user_id` INT PRIMARY KEY (FK `users.id` ON DELETE CASCADE)
* `dob` DATE
* `gender` VARCHAR(50)
* `guardian_name` VARCHAR(255)
* `address` VARCHAR(500)
* `state` VARCHAR(100)
* `pincode` CHAR(6)
* `degree` VARCHAR(255)
* `board` VARCHAR(255)
* `grad_year` SMALLINT
* `percentage` DECIMAL(5,2)
* `photo_path` VARCHAR(500)
* `version` INT DEFAULT 1 (Optimistic Locking)

### `admission_applications`
Tracks the progress and final snapshot of the student's admission request.
* `id` INT AUTO_INCREMENT PRIMARY KEY
* `application_id` VARCHAR(50) UNIQUE (Format: ADM-YYYYMMDD-XXXX)
* `user_id` INT UNIQUE (FK `users.id` ON DELETE CASCADE)
* `dob` DATE, `gender` VARCHAR(50), etc.
* `status` VARCHAR(50) DEFAULT 'Draft' (values: 'Draft', 'Submitted', 'DOCUMENT_VERIFICATION', 'IDENTITY_VERIFICATION', 'PENDING_SIGNATURE', 'SIGNED', 'Approved', 'Rejected')
* `correction_message` TEXT

### `audit_logs`
Central security audit trail.
* `id` INT AUTO_INCREMENT PRIMARY KEY
* `user_id` INT (FK `users.id` ON DELETE SET NULL)
* `action` VARCHAR(100) NOT NULL
* `status` VARCHAR(50)
* `ip_address` VARCHAR(50)
* `metadata` TEXT (JSON stringified, sanitized)

---

## 3. Database Indexes
The following indices are configured in both SQLite and MySQL:
1. `idx_users_email` on `users(email)`
2. `idx_users_mobile` on `users(mobile)`
3. `idx_app_status` on `admission_applications(status)`
4. `idx_notifications_user_unread` on `notifications(user_id, is_read)`

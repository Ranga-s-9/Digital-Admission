const db = require('../config/db');

class Otp {
  /**
   * Create a new OTP session in the database
   * @param {Object} otpData
   * @param {string} otpData.id - Unique UUID session ID
   * @param {number} otpData.userId - Foreign key user ID
   * @param {string} otpData.codeHash - Hashed 6-digit OTP code
   * @param {number} otpData.expiresAt - Unix epoch millisecond timestamp
   * @param {number} otpData.resendCooldown - Unix epoch millisecond timestamp
   */
  static async create({ id, userId, codeHash, expiresAt, resendCooldown }) {
    const sql = `
      INSERT INTO otps (id, user_id, code_hash, expires_at, resend_cooldown, attempts, resend_count)
      VALUES (?, ?, ?, ?, ?, 0, 0)
    `;
    const params = [id, userId, codeHash, expiresAt, resendCooldown];
    await db.query(sql, params);
    return id;
  }

  /**
   * Find an active OTP session by its ID
   * @param {string} id 
   * @returns {Promise<Object|null>}
   */
  static async findById(id) {
    const rows = await db.query('SELECT * FROM otps WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Increment attempts count for an OTP session
   * @param {string} id 
   * @returns {Promise<number>} - New attempts count
   */
  static async incrementAttempts(id) {
    await db.query('UPDATE otps SET attempts = attempts + 1 WHERE id = ?', [id]);
    const otp = await this.findById(id);
    return otp ? otp.attempts : 0;
  }

  /**
   * Update the code and increment the resend count
   * @param {string} id 
   * @param {string} newCodeHash 
   * @param {number} newExpiresAt 
   * @param {number} newCooldown 
   * @returns {Promise<Object>} - Updated OTP record
   */
  static async incrementResends(id, newCodeHash, newExpiresAt, newCooldown) {
    await db.query(
      'UPDATE otps SET code_hash = ?, expires_at = ?, resend_cooldown = ?, attempts = 0, resend_count = resend_count + 1 WHERE id = ?',
      [newCodeHash, newExpiresAt, newCooldown, id]
    );
    return await this.findById(id);
  }

  /**
   * Delete an OTP session from the database
   * @param {string} id 
   * @returns {Promise<boolean>}
   */
  static async delete(id) {
    await db.query('DELETE FROM otps WHERE id = ?', [id]);
    return true;
  }
}

module.exports = Otp;

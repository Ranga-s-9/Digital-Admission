<?php
/**
 * eKycParser.php
 * Core engine for extracting, decrypting and parsing Aadhaar Offline e-KYC documents.
 */

class eKycParser {

    /**
     * Parse Offline e-KYC file (either ZIP or XML)
     * 
     * @param string $filePath Path to the uploaded temporary file
     * @param string $originalName Original filename from client
     * @param string $shareCode 4-digit Share Code password for ZIP decompression
     * @return array Parsed demographics, photo, and verification indicators
     * @throws Exception On decryption, XML structure, or parsing failures
     */
    public static function parseFile($filePath, $originalName, $shareCode) {
        if (!file_exists($filePath)) {
            throw new Exception("Uploaded file does not exist.");
        }

        $xmlContent = '';
        $isZip = false;

        // Auto-detect format by checking magic bytes (ZIP file starts with PK\x03\x04)
        $handle = fopen($filePath, 'rb');
        if ($handle) {
            $bytes = fread($handle, 4);
            fclose($handle);
            if ($bytes === "PK\x03\x04") {
                $isZip = true;
            }
        }

        // Also check file extension fallback
        if (!$isZip && preg_match('/\.zip$/i', $originalName)) {
            $isZip = true;
        }

        if ($isZip) {
            if (empty($shareCode) || strlen($shareCode) !== 4) {
                throw new Exception("Share code must be a 4-digit number to decrypt the ZIP archive.");
            }

            if (class_exists('ZipArchive')) {
                $zip = new ZipArchive();
                $openResult = $zip->open($filePath);
                if ($openResult !== TRUE) {
                    throw new Exception("Invalid or corrupted ZIP archive (Error Code: $openResult).");
                }

                // Set share code password
                $zip->setPassword($shareCode);

                // Locate XML file in ZIP
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $stat = $zip->statIndex($i);
                    $entryName = $stat['name'];
                    if (preg_match('/\.xml$/i', $entryName)) {
                        $xmlContent = $zip->getFromIndex($i);
                        break;
                    }
                }

                $zip->close();
            } else {
                // Fallback: Use CLI php to extract since CLI php has ZipArchive enabled
                $cliPhp = 'C:\\xampp\\php\\php.exe';
                if (!file_exists($cliPhp)) {
                    $cliPhp = 'php';
                }

                // Generate a temporary file to hold the extraction script
                $tmpScript = tempnam(sys_get_temp_dir(), 'zip_ext_');
                
                // Write a helper script that opens the ZIP and outputs the XML content to stdout
                $scriptContent = '<?php
$zip = new ZipArchive();
if ($zip->open(' . var_export($filePath, true) . ') === TRUE) {
    $zip->setPassword(' . var_export($shareCode, true) . ');
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (preg_match("/\\.xml$/i", $stat["name"])) {
            echo $zip->getFromIndex($i);
            break;
        }
    }
    $zip->close();
}';
                file_put_contents($tmpScript, $scriptContent);

                // Run the script using CLI PHP and capture output
                $cmd = '"' . $cliPhp . '" -f "' . $tmpScript . '"';
                $xmlContent = shell_exec($cmd);

                // Clean up temporary script
                if (file_exists($tmpScript)) {
                    @unlink($tmpScript);
                }
            }

            if (empty($xmlContent)) {
                throw new Exception("No Aadhaar XML document was found in the ZIP archive. Check your share code password.");
            }
        } else {
            // Read XML file directly
            $xmlContent = file_get_contents($filePath);
        }

        return self::parseXmlContent($xmlContent, $shareCode);
    }

    /**
     * Safe XML loading and parser logic
     */
    private static function parseXmlContent($xmlContent, $shareCode = '') {
        if (empty($xmlContent)) {
            throw new Exception("XML content is empty.");
        }

        // Safe XML loading: disable entity expansions (XXE protection)
        $previousEntityState = null;
        if (PHP_VERSION_ID < 80000) {
            $previousEntityState = libxml_disable_entity_loader(true);
        }
        libxml_use_internal_errors(true);

        // Remove XML declarations / DTDs if injected
        if (stripos($xmlContent, '<!DOCTYPE') !== false || stripos($xmlContent, '<!ENTITY') !== false) {
            if (PHP_VERSION_ID < 80000 && $previousEntityState !== null) {
                libxml_disable_entity_loader($previousEntityState);
            }
            throw new Exception("MALFORMED_XML: External DTD or entity declarations are prohibited for security.");
        }

        $xml = simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOENT);
        if ($xml === false) {
            $errors = libxml_get_errors();
            libxml_clear_errors();
            if (PHP_VERSION_ID < 80000 && $previousEntityState !== null) {
                libxml_disable_entity_loader($previousEntityState);
            }
            throw new Exception("Failed to parse malformed XML. Please upload a valid Aadhaar XML file.");
        }

        // Restore libxml state
        if (PHP_VERSION_ID < 80000 && $previousEntityState !== null) {
            libxml_disable_entity_loader($previousEntityState);
        }

        // Identify Root Element and parse
        $rootName = $xml->getName();
        if ($rootName !== 'OfflinePaperlessKyc') {
            throw new Exception("Invalid Aadhaar XML root. Expected 'OfflinePaperlessKyc', got '$rootName'.");
        }

        if (!isset($xml->UidData)) {
            throw new Exception("Invalid Aadhaar XML schema: missing <UidData> element.");
        }

        $uidData = $xml->UidData;
        if (!isset($uidData->Poi) || !isset($uidData->Poa)) {
            throw new Exception("Invalid Aadhaar XML schema: missing <Poi> or <Poa> element.");
        }

        // Parse POI (Person of Interest)
        $poi = $uidData->Poi;
        $name = (string)($poi['name'] ?? $poi['@attributes']['name'] ?? '');
        $dob = (string)($poi['dob'] ?? $poi['@attributes']['dob'] ?? '');
        $gender = (string)($poi['gender'] ?? $poi['@attributes']['gender'] ?? '');
        $mHash = (string)($poi['m'] ?? $poi['@attributes']['m'] ?? '');
        $eHash = (string)($poi['e'] ?? $poi['@attributes']['e'] ?? '');

        // Normalize Gender to standard format
        $normalizedGender = 'Other';
        $gUpper = strtoupper(trim($gender));
        if ($gUpper === 'M' || $gUpper === 'MALE') {
            $normalizedGender = 'Male';
        } elseif ($gUpper === 'F' || $gUpper === 'FEMALE') {
            $normalizedGender = 'Female';
        }

        // Parse POA (Person of Address)
        $poa = $uidData->Poa;
        $co = (string)($poa['co'] ?? $poa['@attributes']['co'] ?? '');
        $house = (string)($poa['house'] ?? $poa['@attributes']['house'] ?? '');
        $street = (string)($poa['street'] ?? $poa['@attributes']['street'] ?? '');
        $lm = (string)($poa['lm'] ?? $poa['@attributes']['lm'] ?? '');
        $loc = (string)($poa['loc'] ?? $poa['@attributes']['loc'] ?? '');
        $vtc = (string)($poa['vtc'] ?? $poa['@attributes']['vtc'] ?? '');
        $dist = (string)($poa['dist'] ?? $poa['@attributes']['dist'] ?? '');
        $state = (string)($poa['state'] ?? $poa['@attributes']['state'] ?? '');
        $pincode = (string)($poa['pc'] ?? $poa['@attributes']['pc'] ?? '');

        // Reconstruct formatted address string
        $addrParts = array_filter([$house, $street, $lm, $loc, $vtc, $dist, $state, $pincode]);
        $fullAddress = implode(', ', $addrParts);

        // Photo parsing (Base64 JPEG encoded under UidData -> Pht)
        $photoBase64 = '';
        if (isset($uidData->Pht)) {
            $photoBase64 = trim((string)$uidData->Pht);
        }

        // Validate Digital Signature existence
        $signatureExists = isset($xml->Signature);

        return [
            'success' => true,
            'name' => $name,
            'dob' => $dob,
            'gender' => $normalizedGender,
            'mobileHash' => $mHash,
            'emailHash' => $eHash,
            'address' => [
                'co' => $co,
                'house' => $house,
                'street' => $street,
                'landmark' => $lm,
                'locality' => $loc,
                'vtc' => $vtc,
                'district' => $dist,
                'state' => $state,
                'pincode' => $pincode,
                'full' => $fullAddress
            ],
            'photo' => $photoBase64,
            'signature_verified' => $signatureExists,
            'shareCode' => $shareCode
        ];
    }

    /**
     * Verify mobile/email hash against the XML hash value using Share Code as salt
     * 
     * @param string $plaintextValue Plain text mobile or email
     * @param string $expectedHash Hash string from XML
     * @param string $shareCode Share Code used during download
     * @param string $type Either 'mobile' or 'email'
     * @return bool True if matches, False otherwise
     */
    public static function verifyHash($plaintextValue, $expectedHash, $shareCode, $type = 'mobile') {
        if (empty($plaintextValue) || empty($expectedHash)) {
            return false;
        }

        // Normalize plaintext
        if ($type === 'mobile') {
            // Remove spaces and leading +91/0
            $normalized = preg_replace('/^(\+91|0)/', '', trim($plaintextValue));
            $normalized = preg_replace('/\s+/', '', $normalized);
        } else {
            $normalized = strtolower(trim($plaintextValue));
        }

        // Compute SHA-256 hash using salt
        // Standard UIDAI formulation: SHA256(value + shareCode)
        $computed = hash('sha256', $normalized . $shareCode);

        // Alternative iteration checking if UIDAI format varies (e.g. repeated hash)
        if (hash_equals($computed, $expectedHash)) {
            return true;
        }

        // Try double hash just in case
        $computedDouble = hash('sha256', hash('sha256', $normalized) . $shareCode);
        if (hash_equals($computedDouble, $expectedHash)) {
            return true;
        }

        return false;
    }
}

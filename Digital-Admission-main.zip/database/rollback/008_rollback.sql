-- =============================================================================
-- Rollback 008: DigiLocker Consent Rollback
-- Reverses 008_digilocker_consent.sql.
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Drop table digilocker_consents
DROP TABLE IF EXISTS digilocker_consents;

-- Remove constraints and column from digilocker_documents
ALTER TABLE digilocker_documents DROP CONSTRAINT IF EXISTS chk_digilocker_doc_status;
ALTER TABLE digilocker_documents DROP COLUMN document_status;

SET FOREIGN_KEY_CHECKS = 1;

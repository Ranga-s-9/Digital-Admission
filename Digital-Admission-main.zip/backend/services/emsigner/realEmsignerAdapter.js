const EmsignerAdapter = require('./emsignerAdapter');
const db = require('../../config/db');

/**
 * Real emSigner Adapter (Production API Client)
 *
 * Connects to the live emSigner (by eMudhra) REST API.
 * Requires EMSIGNER_API_KEY and EMSIGNER_API_URL in environment.
 */
class RealEmsignerAdapter extends EmsignerAdapter {
  constructor() {
    super();
    const apiKey = process.env.EMSIGNER_API_KEY;
    const apiUrl = process.env.EMSIGNER_API_URL;

    if (!apiKey || apiKey.trim() === '') {
      throw new Error(
        'EMSIGNER_CREDENTIALS_NOT_CONFIGURED: EMSIGNER_API_KEY environment variable is required for production mode. ' +
        'Please set EMSIGNER_MODE=mock for development, or configure valid credentials.'
      );
    }

    this.apiKey = apiKey;
    this.apiUrl = apiUrl || 'https://api.esignzy.com/v1';
  }

  /**
   * Initiate a real emSigner signing request
   * @param {number} userId
   * @param {string} applicationId
   * @param {string} ipAddress
   */
  async initiateSign(userId, applicationId, ipAddress) {
    // 1. Check for duplicate sign requests locally first
    const existing = await db.query(
      'SELECT id, sign_status, sign_request_id FROM emsigner_requests WHERE user_id = ?',
      [userId]
    );

    if (existing && existing.length > 0) {
      const prev = existing[0];
      if (prev.sign_status === 'Signed') {
        throw new Error('DUPLICATE_SIGN_REQUEST');
      }
    }

    // 2. Call real emSigner API
    const response = await fetch(`${this.apiUrl}/signature/initiate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        applicationId,
        userId,
        documentType: 'ADMISSION_FORM'
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`emSigner API returned status ${response.status}: ${errText}`);
    }

    const result = await response.json();
    if (!result.success) {
      throw new Error(result.message || 'API signature initiation failed');
    }

    const apiData = result.data || result;
    const signRequestId = apiData.sign_request_id || apiData.signRequestId;
    const signStatus = apiData.sign_status || apiData.signStatus || 'Signed';
    const signedDocUri = apiData.signed_doc_uri || apiData.signedDocUri;
    const signedAt = apiData.signed_at || apiData.signedAt || Date.now();

    // 3. Save or update the signing record in local DB
    if (existing && existing.length > 0) {
      await db.query(
        `UPDATE emsigner_requests
         SET sign_request_id = ?, sign_status = ?, signed_doc_uri = ?, signed_at = ?, error_message = NULL, updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?`,
        [signRequestId, signStatus, signedDocUri, signedAt, userId]
      );
    } else {
      await db.query(
        `INSERT INTO emsigner_requests (user_id, application_id, sign_request_id, sign_status, signed_doc_uri, signed_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [userId, applicationId, signRequestId, signStatus, signedDocUri, signedAt]
      );
    }

    // 4. Audit log
    await db.query(
      `INSERT INTO emsigner_audit_logs (user_id, action, ip_address, details)
       VALUES (?, 'SIGN_SUCCESS', ?, ?)`,
      [userId, ipAddress, `Real emSigner signature completed. Request ID: ${signRequestId}`]
    );

    return {
      success: true,
      development_mode: false,
      sign_request_id: signRequestId,
      sign_status: signStatus,
      signed_doc_uri: signedDocUri,
      signed_at: signedAt,
      message: 'Digital signature completed successfully via emSigner API.'
    };
  }

  /**
   * Get status from real emSigner API
   * @param {number} userId
   */
  async getStatus(userId) {
    let apiSuccess = false;
    let apiData = null;

    try {
      const response = await fetch(`${this.apiUrl}/signature/status?userId=${userId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        apiData = result.data || result;
        apiSuccess = true;
      }
    } catch (err) {
      // API call failed, fall back to local database
    }

    if (!apiSuccess) {
      const rows = await db.query(
        'SELECT sign_request_id, sign_status, signed_doc_uri, signed_at, error_message FROM emsigner_requests WHERE user_id = ?',
        [userId]
      );
      if (!rows || rows.length === 0) {
        return {
          signed: false,
          sign_status: 'NotInitiated',
          development_mode: false
        };
      }
      const rec = rows[0];
      return {
        signed: rec.sign_status === 'Signed',
        sign_status: rec.sign_status,
        sign_request_id: rec.sign_request_id,
        signed_doc_uri: rec.signed_doc_uri,
        signed_at: rec.signed_at,
        error_message: rec.error_message,
        development_mode: false
      };
    }

    return {
      signed: apiData.sign_status === 'Signed' || apiData.signStatus === 'Signed',
      sign_status: apiData.sign_status || apiData.signStatus,
      sign_request_id: apiData.sign_request_id || apiData.signRequestId,
      signed_doc_uri: apiData.signed_doc_uri || apiData.signedDocUri,
      signed_at: apiData.signed_at || apiData.signedAt,
      error_message: apiData.error_message || apiData.errorMessage || null,
      development_mode: false
    };
  }
}

module.exports = RealEmsignerAdapter;

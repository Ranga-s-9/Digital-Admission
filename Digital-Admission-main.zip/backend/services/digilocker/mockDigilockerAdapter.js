const DigilockerAdapter = require('./digilockerAdapter');
const db = require('../../config/db');

/**
 * Mock DigiLocker Adapter
 */
class MockDigilockerAdapter extends DigilockerAdapter {
  /**
   * Fetch the list of issued documents available in the student's DigiLocker
   * @param {number} userId - The student user ID
   * @returns {Promise<Array>} List of available documents
   */
  async getIssuedDocuments(userId) {
    return [
      {
        name: "Class XII Marksheet",
        uri: "in.gov.cbse-ssc-marksheet-2023",
        issuer: "Central Board of Secondary Education",
        status: "Available"
      },
      {
        name: "Class X Marksheet",
        uri: "in.gov.cbse-hsc-marksheet-2021",
        issuer: "Central Board of Secondary Education",
        status: "Available"
      },
      {
        name: "Class XII Marksheet (Mismatched Name)",
        uri: "in.gov.cbse-ssc-marksheet-mismatch",
        issuer: "Central Board of Secondary Education",
        status: "Available"
      },
      {
        name: "Class XII Marksheet (Simulated Timeout)",
        uri: "in.gov.cbse-ssc-marksheet-timeout",
        issuer: "Central Board of Secondary Education",
        status: "Available"
      },
      {
        name: "Class XII Marksheet (Simulated Gateway Failure)",
        uri: "in.gov.cbse-ssc-marksheet-failure",
        issuer: "Central Board of Secondary Education",
        status: "Available"
      }
    ];
  }

  /**
   * Retrieve and verify a specific document by its DigiLocker URI
   * @param {number} userId - The student user ID
   * @param {string} docUri - Unique DigiLocker document URI reference
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Linked document metadata
   */
  async retrieveDocument(userId, docUri, ipAddress) {
    if (!docUri) {
      throw new Error('MISSING_DOCUMENT_URI');
    }

    // 1. Simulate Test Scenarios
    if (docUri === 'in.gov.cbse-ssc-marksheet-timeout') {
      await new Promise(resolve => setTimeout(resolve, 1500));
      throw new Error('TIMEOUT_ERROR');
    }
    if (docUri === 'in.gov.cbse-ssc-marksheet-failure') {
      throw new Error('EXTERNAL_SERVICE_FAILURE');
    }

    // Fetch user profile name to compare
    const users = await db.query('SELECT name FROM users WHERE id = ?', [userId]);
    if (!users || users.length === 0) {
      throw new Error('UNAUTHORIZED_ACCESS');
    }

    const studentName = users[0].name;

    // Determine document metadata details
    let docType = 'Class XII Marksheet';
    let issuer = 'Central Board of Secondary Education';
    let docRef = 'Roll No: 1290384';
    let docNameOnFile = studentName; // Defaults to match

    if (docUri === 'in.gov.cbse-ssc-marksheet-2023') {
      docType = 'Class XII Marksheet';
      docRef = 'Roll No: 1290384';
    } else if (docUri === 'in.gov.cbse-hsc-marksheet-2021') {
      docType = 'Class X Marksheet';
      docRef = 'Roll No: 1190473';
    } else if (docUri === 'in.gov.cbse-ssc-marksheet-mismatch') {
      docType = 'Class XII Marksheet';
      docNameOnFile = 'Mismatched Student Name';
      docRef = 'Roll No: 9999999';
    } else {
      throw new Error('DOCUMENT_NOT_FOUND');
    }

    // 2. Validate Name Mismatch (Security requirement)
    const nameMatch = docNameOnFile.trim().toLowerCase() === studentName.trim().toLowerCase();
    const verificationStatus = nameMatch ? 'Verified' : 'Failed';

    // 3. Save reference and metadata in database
    const retrievedAt = Date.now();
    
    // Check if document already linked
    const existing = await db.query(
      'SELECT id FROM digilocker_documents WHERE user_id = ? AND document_type = ?',
      [userId, docType]
    );

    if (existing && existing.length > 0) {
      await db.query(
        `UPDATE digilocker_documents
         SET doc_uri = ?, issuing_authority = ?, document_ref = ?, retrieved_at = ?, verification_status = ?, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [docUri, issuer, docRef, retrievedAt, verificationStatus, existing[0].id]
      );
    } else {
      await db.query(
        `INSERT INTO digilocker_documents (user_id, document_type, doc_uri, issuing_authority, document_ref, retrieved_at, verification_status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [userId, docType, docUri, issuer, docRef, retrievedAt, verificationStatus]
      );
    }

    // 4. Log Audit Event (Audit requirement)
    const action = nameMatch ? 'DIGILOCKER_RETRIEVE_SUCCESS' : 'DIGILOCKER_RETRIEVE_FAILED';
    const auditDetails = nameMatch
      ? `Successfully linked and verified '${docType}' (URI: ${docUri}) from DigiLocker.`
      : `DigiLocker retrieval failed: Name on document '${docNameOnFile}' mismatched profile name '${studentName}'.`;

    await db.query(
      `INSERT INTO ekyc_audit_logs (user_id, action, ip_address, details)
       VALUES (?, ?, ?, ?)`,
      [userId, action, ipAddress, auditDetails]
    );

    if (!nameMatch) {
      throw new Error('NAME_MISMATCH');
    }

    return {
      success: true,
      documentType: docType,
      docUri,
      issuingAuthority: issuer,
      documentRef: docRef,
      retrievedAt,
      verificationStatus,
      development_mode: true
    };
  }
}

module.exports = MockDigilockerAdapter;

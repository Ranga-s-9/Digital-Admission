'use strict';

/**
 * XML Validation Service for Offline e-KYC Documents
 *
 * Validates the structure, required fields, and data formats
 * of a parsed Offline Paperless KYC XML document.
 */

const REQUIRED_ROOT = 'OfflinePaperlessKyc';
const REQUIRED_ELEMENTS = ['UidData'];
const REQUIRED_POI_ATTRS = ['name', 'dob', 'gender'];

// Acceptable date formats: YYYY-MM-DD or DD-MM-YYYY or DD/MM/YYYY
const DATE_PATTERNS = [
  /^\d{4}-\d{2}-\d{2}$/,       // YYYY-MM-DD
  /^\d{2}-\d{2}-\d{4}$/,       // DD-MM-YYYY
  /^\d{2}\/\d{2}\/\d{4}$/      // DD/MM/YYYY
];

const VALID_GENDERS = ['M', 'F', 'T', 'Male', 'Female', 'Other', 'Transgender'];

/**
 * Validate the complete XML structure for Offline e-KYC
 * @param {object} parsed - Output from xmlParser.parseXml().parsed
 * @returns {{ valid: boolean, errors: string[] }}
 */
function validateStructure(parsed) {
  const errors = [];

  if (!parsed) {
    errors.push('Parsed XML object is null or undefined');
    return { valid: false, errors };
  }

  // 1. Check root element
  const root = parsed[REQUIRED_ROOT];
  if (!root) {
    errors.push(`Missing required root element: ${REQUIRED_ROOT}`);
    return { valid: false, errors };
  }

  // 2. Check shareCode or referenceId attribute on root
  if (!root['@_shareCode'] && !root['@_referenceId']) {
    errors.push('Missing shareCode or referenceId attribute on OfflinePaperlessKyc root element');
  }

  // 3. Check required child elements
  for (const elem of REQUIRED_ELEMENTS) {
    if (!root[elem]) {
      errors.push(`Missing required element: ${elem}`);
    }
  }

  if (!root.UidData) {
    return { valid: errors.length === 0, errors };
  }

  // 4. Check Poi element
  const poi = root.UidData.Poi;
  if (!poi) {
    errors.push('Missing required element: UidData/Poi');
  } else {
    for (const attr of REQUIRED_POI_ATTRS) {
      const val = poi[`@_${attr}`];
      if (!val || String(val).trim() === '') {
        errors.push(`Missing required Poi attribute: ${attr}`);
      }
    }

    // Validate DOB format
    const dob = poi['@_dob'];
    if (dob) {
      const isValidDate = DATE_PATTERNS.some(pattern => pattern.test(String(dob)));
      if (!isValidDate) {
        errors.push(`Invalid date format for Poi.dob: ${dob}. Expected YYYY-MM-DD or DD-MM-YYYY`);
      }
    }

    // Validate gender value
    const gender = poi['@_gender'];
    if (gender) {
      const normalizedGender = String(gender).trim().toUpperCase();
      const validUppercaseGenders = VALID_GENDERS.map(g => g.toUpperCase());
      if (!validUppercaseGenders.includes(normalizedGender)) {
        errors.push(`Invalid gender value: ${gender}. Expected one of: ${VALID_GENDERS.join(', ')}`);
      }
    }
  }

  // 5. Check Signature element
  if (!root.Signature) {
    errors.push('Missing required element: Signature');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validate that required identity fields are present and have acceptable values
 * @param {object} identity - Output from xmlParser.extractIdentity()
 * @returns {{ valid: boolean, errors: string[] }}
 */
function validateIdentityFields(identity) {
  const errors = [];

  if (!identity) {
    errors.push('Identity data is null or undefined');
    return { valid: false, errors };
  }

  if (!identity.name || String(identity.name).trim().length < 1) {
    errors.push('Name field is empty or invalid');
  }

  if (!identity.dob) {
    errors.push('Date of birth is missing');
  }

  if (!identity.gender) {
    errors.push('Gender is missing');
  }

  // Name should not contain suspicious characters
  if (identity.name && /[<>&"']/.test(identity.name)) {
    errors.push('Name contains invalid characters');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

module.exports = {
  validateStructure,
  validateIdentityFields
};

// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test.sqlite';

const request = require('supertest');
const app = require('../backend/app');
const { initDatabase } = require('../backend/services/dbService');

describe('Centralized Error Handling (Module 22)', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  test('1. Every response carries a unique X-Request-Id header', async () => {
    const res = await request(app).get('/api/auth/captcha');
    expect(res.headers['x-request-id']).toBeDefined();
    // Basic UUID v4 shape check
    expect(res.headers['x-request-id']).toMatch(/^[0-9a-f-]{36}$/i);
  });

  test('2. Two separate requests receive two different request IDs', async () => {
    const res1 = await request(app).get('/api/auth/captcha');
    const res2 = await request(app).get('/api/auth/captcha');
    expect(res1.headers['x-request-id']).not.toEqual(res2.headers['x-request-id']);
  });

  test('3. Unknown /api/* route returns a consistent JSON 404 (not the SPA HTML fallback)', async () => {
    const res = await request(app).get('/api/this-route-does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toBeDefined();
    expect(res.body.requestId).toBeDefined();
    expect(res.headers['content-type']).toMatch(/json/);
  });

  test('4. Unknown /api/* route works consistently across HTTP methods', async () => {
    const res = await request(app).post('/api/another-fake-route').send({});
    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
  });

  test('5. A non-API unknown route still falls through to the SPA (200, HTML)', async () => {
    const res = await request(app).get('/some-frontend-only-route');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/html/);
  });

  test('6. Malformed JSON body produces a safe 4xx JSON error, never a raw stack trace', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .set('Content-Type', 'application/json')
      .send('{ this is not valid json');

    expect(res.status).toBeGreaterThanOrEqual(400);
    expect(res.status).toBeLessThan(500);
    expect(res.body.success).toBe(false);
    // Must never leak a stack trace to the client
    expect(JSON.stringify(res.body)).not.toMatch(/at\s+\w+\s+\(.*:\d+:\d+\)/);
  });

  test('7. Validation failure responses never include a stack property', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: '', email: 'not-an-email', mobile: '123', password: '1', confirmPassword: '2' });

    expect(res.status).toBeGreaterThanOrEqual(400);
    expect(res.body).not.toHaveProperty('stack');
    expect(JSON.stringify(res.body)).not.toMatch(/node_modules|backend[\\/]/);
  });

});

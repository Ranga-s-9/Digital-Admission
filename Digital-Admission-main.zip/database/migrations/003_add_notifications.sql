-- =============================================================================
-- Migration 003: Add Notifications Table
-- Introduces a persistent `notifications` table for storing user-facing
-- system messages and alerts. Currently notifications are generated at
-- runtime in controller code; this table enables persistence and history.
-- =============================================================================

CREATE TABLE IF NOT EXISTS notifications (
  id          INT           NOT NULL AUTO_INCREMENT,
  user_id     INT           NOT NULL,
  title       VARCHAR(255)  NOT NULL,
  content     TEXT          NOT NULL,
  type        VARCHAR(50)   NOT NULL DEFAULT 'info',
  is_read     TINYINT(1)    NOT NULL DEFAULT 0,
  created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at     TIMESTAMP     NULL DEFAULT NULL,

  PRIMARY KEY (id),
  KEY idx_notifications_user     (user_id),
  KEY idx_notifications_is_read  (is_read),
  KEY idx_notifications_created  (created_at),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_notifications_type CHECK (type IN ('info', 'success', 'warning', 'danger', 'error'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Persistent user notification messages and system alerts';

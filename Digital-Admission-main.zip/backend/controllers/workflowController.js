const db = require('../config/db');
const User = require('../models/User');
const { logger } = require('../middleware/logger');

// Valid status transitions map
const VALID_TRANSITIONS = {
  'Draft': ['Submitted'],
  'Submitted': ['DOCUMENT_VERIFICATION', 'IDENTITY_VERIFICATION', 'Draft'],
  'DOCUMENT_VERIFICATION': ['IDENTITY_VERIFICATION', 'PENDING_SIGNATURE', 'Draft'],
  'IDENTITY_VERIFICATION': ['DOCUMENT_VERIFICATION', 'PENDING_SIGNATURE', 'Draft'],
  'PENDING_SIGNATURE': ['SIGNED', 'Draft'],
  'SIGNED': ['Approved', 'Rejected', 'Draft'],
  'Approved': [],
  'Rejected': []
};

/**
 * @deprecated Use POST /api/emsigner/sign instead.
 * Kept for backward compatibility. Delegates to the emSigner signing flow.
 */
async function postSignApplication(req, res) {
  // Redirect internally to the dedicated emSigner signing endpoint
  // by re-using the same request object on the emsigner controller.
  const { postInitiateSign } = require('./emsignerController');
  return postInitiateSign(req, res);
}


/**
 * Handle transition triggered by Professor (Approve, Reject, or Request Corrections)
 */
async function postTransitionApplication(req, res) {
  try {
    const AuditLog = require('../models/AuditLog');
    // Role-based block (Security requirement)
    if (req.user.role !== 'professor') {
      await AuditLog.log({
        userId: req.user ? req.user.userId : null,
        action: 'workflow_transition',
        status: 'failure',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        metadata: { reason: 'Forbidden: Only professors can process transitions' }
      });
      return res.status(403).json({
        success: false,
        message: 'Forbidden: Only academic staff members can process applications.',
        error: { global: 'Forbidden access' }
      });
    }

    const { userId, targetStatus, message } = req.body;
    const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

    if (!userId || !targetStatus) {
      await AuditLog.log({
        userId: req.user.userId,
        action: 'workflow_transition',
        status: 'failure',
        ipAddress,
        metadata: { reason: 'Missing userId or targetStatus' }
      });
      return res.status(400).json({
        success: false,
        message: 'User ID and target status parameters are required.',
        error: { userId: 'Required parameter', targetStatus: 'Required parameter' }
      });
    }

    // Retrieve student application
    const appRows = await db.query(
      'SELECT id, status, application_id FROM admission_applications WHERE user_id = ?',
      [userId]
    );

    if (!appRows || appRows.length === 0) {
      await AuditLog.log({
        userId: req.user.userId,
        action: 'workflow_transition',
        status: 'failure',
        ipAddress,
        metadata: { studentUserId: userId, reason: 'Student application not found' }
      });
      return res.status(404).json({
        success: false,
        message: 'No active application found for this student.',
        error: { global: 'Application not found' }
      });
    }

    const currentStatus = appRows[0].status;

    // Validate Transition in State Machine
    const allowedTargets = VALID_TRANSITIONS[currentStatus] || [];
    if (!allowedTargets.includes(targetStatus)) {
      await AuditLog.log({
        userId: req.user.userId,
        action: 'workflow_transition',
        status: 'failure',
        ipAddress,
        metadata: { studentUserId: userId, currentStatus, targetStatus, reason: 'Invalid transition' }
      });
      return res.status(400).json({
        success: false,
        message: `Invalid state transition: Cannot transition application from '${currentStatus}' to '${targetStatus}'.`,
        error: { global: 'Invalid transition' }
      });
    }

    // Process transition
    if (targetStatus === 'Draft') {
      // Correction Request Loop
      if (!message) {
        await AuditLog.log({
          userId: req.user.userId,
          action: 'correction_request',
          status: 'failure',
          ipAddress,
          metadata: { studentUserId: userId, reason: 'Correction notes are mandatory' }
        });
        return res.status(400).json({
          success: false,
          message: 'Correction notes are mandatory when requesting revisions.',
          error: { message: 'Correction message is required' }
        });
      }

      await db.query(
        "UPDATE admission_applications SET status = 'Draft', correction_message = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        [message, appRows[0].id]
      );

      // Trigger correction request notification
      try {
        const NotificationService = require('../services/notificationService');
        await NotificationService.send({
          userId,
          type: 'correction_request',
          title: 'Corrections Required',
          content: `Your application requires revisions. Professor notes: "${message}"`
        });
      } catch (notifErr) {
        logger.error('Failed to trigger correction notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
      }
    } else {
      // Approve or Reject
      await db.query(
        "UPDATE admission_applications SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        [targetStatus, appRows[0].id]
      );

      // Trigger approval/rejection notification
      try {
        const NotificationService = require('../services/notificationService');
        if (targetStatus === 'Approved') {
          await NotificationService.send({
            userId,
            type: 'approval',
            title: 'Application Approved',
            content: 'Congratulations! Your admission application has been approved by the academic committee.'
          });
        } else if (targetStatus === 'Rejected') {
          await NotificationService.send({
            userId,
            type: 'rejection',
            title: 'Application Rejected',
            content: 'We regret to inform you that your application has been rejected after review.'
          });
        }
      } catch (notifErr) {
        logger.error('Failed to trigger workflow notification:', { message: notifErr.message, stack: notifErr.stack, requestId: req.id || null });
      }
    }

    // Record audit log
    const auditDetails = targetStatus === 'Draft'
      ? `Revision requested by Professor: ${message}`
      : `Application state processed to '${targetStatus}' by Professor.`;

    await db.query(
      `INSERT INTO workflow_audit_logs (user_id, from_status, to_status, action_by_role, ip_address, details)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [userId, currentStatus, targetStatus, 'professor', ipAddress, auditDetails]
    );

    let actionName = 'workflow_transition';
    if (targetStatus === 'Draft') {
      actionName = 'correction_request';
    } else if (targetStatus === 'Approved') {
      actionName = 'approval';
    } else if (targetStatus === 'Rejected') {
      actionName = 'rejection';
    }

    await AuditLog.log({
      userId: req.user.userId,
      action: actionName,
      entityType: 'application',
      entityId: String(appRows[0].id),
      status: 'success',
      ipAddress,
      metadata: { studentUserId: userId, currentStatus, targetStatus, message }
    });

    return res.status(200).json({
      success: true,
      message: `Successfully processed application state to '${targetStatus}'.`,
      data: { status: targetStatus }
    });

  } catch (error) {
    logger.error('Workflow transition controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error processing transition',
      error: { global: 'Internal server error' }
    });
  }
}

/**
 * Fetch history of state transitions
 */
async function getWorkflowHistory(req, res) {
  try {
    const role = req.user.role;
    let userId = req.user.userId;

    // If Professor, they can pass target student query parameter
    if (role === 'professor') {
      const queryUser = req.query.userId;
      if (queryUser) {
        userId = parseInt(queryUser, 10);
        const targetUser = await User.findById(userId);
        if (!targetUser || targetUser.role !== 'student') {
          return res.status(404).json({
            success: false,
            message: 'Student record not found',
            error: { global: 'User is not a student' }
          });
        }
      }
    }

    const history = await db.query(
      `SELECT from_status, to_status, action_by_role, details, created_at
       FROM workflow_audit_logs
       WHERE user_id = ?
       ORDER BY id DESC`,
      [userId]
    );

    return res.status(200).json({
      success: true,
      data: history || []
    });

  } catch (error) {
    logger.error('Get workflow history error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'Internal server error fetching history logs',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  postSignApplication,
  postTransitionApplication,
  getWorkflowHistory
};

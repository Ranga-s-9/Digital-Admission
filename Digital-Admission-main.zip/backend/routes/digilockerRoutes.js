const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const {
  getOAuthAuthorize,
  handleOAuthCallback,
  getConnectionStatus,
  recordConsent,
  disconnect,
  getAvailableDocuments,
  retrieveDocument,
  selectDocument
} = require('../controllers/digilockerController');
const { 
  digilockerRetrieveRules, 
  digilockerConsentRules, 
  digilockerSelectRules, 
  validate 
} = require('../middleware/validation');

// GET /api/digilocker/status - Get connected status, consent, and linked documents
router.get('/status', authenticateToken, getConnectionStatus);

// GET /api/digilocker/oauth/authorize - Serves the login page (or redirects to real DigiLocker)
router.get('/oauth/authorize', authenticateToken, getOAuthAuthorize);

// GET /api/digilocker/oauth/callback - Receives authorization credentials from redirect
router.get('/oauth/callback', authenticateToken, handleOAuthCallback);

// POST /api/digilocker/oauth/callback - Receives authorization credentials from login page form
router.post('/oauth/callback', authenticateToken, handleOAuthCallback);

// POST /api/digilocker/consent - Record or revoke consent
router.post('/consent', authenticateToken, digilockerConsentRules, validate, recordConsent);

// POST /api/digilocker/disconnect - Disconnect account and wipe tokens/documents
router.post('/disconnect', authenticateToken, disconnect);

// GET /api/digilocker/documents - Get list of available issued documents in DigiLocker
router.get('/documents', authenticateToken, getAvailableDocuments);

// POST /api/digilocker/documents/retrieve - Link and verify a specific document
router.post('/documents/retrieve', authenticateToken, digilockerRetrieveRules, validate, retrieveDocument);

// POST /api/digilocker/documents/select - Select a document for use in admission application
router.post('/documents/select', authenticateToken, digilockerSelectRules, validate, selectDocument);

module.exports = router;

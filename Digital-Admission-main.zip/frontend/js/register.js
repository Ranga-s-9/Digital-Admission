document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');
  const roleInput = document.getElementById('roleInput');
  
  const fields = {
    name: {
      input: document.getElementById('name'),
      group: document.getElementById('nameGroup'),
      message: document.getElementById('nameFeedback'),
      validate: (val) => {
        if (!val) return 'Full name is required';
        if (val.trim().length < 2) return 'Name must be at least 2 characters';
        return '';
      }
    },
    email: {
      input: document.getElementById('email'),
      group: document.getElementById('emailGroup'),
      message: document.getElementById('emailFeedback'),
      validate: (val) => {
        if (!val) return 'Email address is required';
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!regex.test(val)) return 'Please enter a valid email address';
        return '';
      }
    },
    mobile: {
      input: document.getElementById('mobile'),
      group: document.getElementById('mobileGroup'),
      message: document.getElementById('mobileFeedback'),
      validate: (val) => {
        if (!val) return 'Mobile number is required';
        const regex = /^(?:\+91|0)?[6-9]\d{9}$/;
        if (!regex.test(val)) return 'Please enter a valid 10-digit mobile number';
        return '';
      }
    },
    password: {
      input: document.getElementById('password'),
      group: document.getElementById('passwordGroup'),
      message: document.getElementById('passwordFeedback'),
      validate: (val) => {
        if (!val) return 'Password is required';
        if (val.length < 8) return 'Password must be at least 8 characters';
        if (!/[A-Z]/.test(val)) return 'Must contain at least one uppercase letter';
        if (!/[a-z]/.test(val)) return 'Must contain at least one lowercase letter';
        if (!/\d/.test(val)) return 'Must contain at least one digit';
        if (!/[@$!%*?&#]/.test(val)) return 'Must contain at least one special character (@$!%*?&#)';
        return '';
      }
    },
    confirmPassword: {
      input: document.getElementById('confirmPassword'),
      group: document.getElementById('confirmPasswordGroup'),
      message: document.getElementById('confirmPasswordFeedback'),
      validate: (val, allVals) => {
        if (!val) return 'Please confirm your password';
        if (val !== allVals.password) return 'Passwords do not match';
        return '';
      }
    },
    captchaAnswer: {
      input: document.getElementById('captchaAnswer'),
      group: document.getElementById('captchaAnswerGroup'),
      message: document.getElementById('captchaAnswerFeedback'),
      validate: (val) => {
        if (!val) return 'CAPTCHA answer is required';
        return '';
      }
    }
  };

  // CAPTCHA Setup
  const captchaIdInput = document.getElementById('captchaId');
  const captchaQuestionSpan = document.getElementById('captchaQuestion');
  const refreshCaptchaBtn = document.getElementById('refreshCaptchaBtn');

  async function loadCaptcha() {
    captchaQuestionSpan.textContent = 'Loading...';
    try {
      const response = await fetch('/api/auth/captcha');
      const result = await response.json();
      if (response.ok && result.success) {
        captchaIdInput.value = result.data.captchaId;
        captchaQuestionSpan.textContent = result.data.question;
        fields.captchaAnswer.input.value = '';
        fields.captchaAnswer.group.classList.remove('has-success', 'has-error');
      } else {
        captchaQuestionSpan.textContent = 'Error';
      }
    } catch (err) {
      captchaQuestionSpan.textContent = 'Error';
      console.error('Error loading CAPTCHA:', err);
    }
  }

  // Load initially
  loadCaptcha();

  // Attach refresh button trigger
  refreshCaptchaBtn.addEventListener('click', loadCaptcha);

  // Expose globally
  window.loadRegisterCaptcha = loadCaptcha;

  // Password Visibility Toggle
  const setupPasswordToggle = (toggleId, inputId) => {
    const toggle = document.getElementById(toggleId);
    const input = document.getElementById(inputId);
    
    toggle.addEventListener('click', (e) => {
      e.preventDefault();
      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');
      
      // Update eye icon state
      if (isPassword) {
        toggle.innerHTML = `
          <svg viewBox="0 0 24 24">
            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
          </svg>
        `;
      } else {
        toggle.innerHTML = `
          <svg viewBox="0 0 24 24">
            <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.44-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 2.2 0 4.27-.61 6.04-1.66l.46.46 2.28 2.28 1.27-1.27L3.27 3 2 4.27zM9.53 9.53l3.93 3.93c-.41.25-.9.4-1.46.4-1.66 0-3-1.34-3-3 0-.56.15-1.05.4-1.46zm-2.09-.76l1.37 1.37C8.3 10.59 8 11.26 8 12c0 2.2 1.8 4 4 4 .74 0 1.41-.3 1.86-.81l1.37 1.37C14.22 17.29 13.16 18 12 18c-3.31 0-6-2.69-6-6 0-1.16.29-2.22.8-3.23z"/>
          </svg>
        `;
      }
    });
  };

  setupPasswordToggle('togglePassword', 'password');
  setupPasswordToggle('toggleConfirmPassword', 'confirmPassword');

  // Password Strength Indicator Calculation
  const pwdInput = fields.password.input;
  const strengthContainer = document.getElementById('passwordStrengthContainer');
  const strengthFill = document.getElementById('passwordStrengthFill');
  const strengthText = document.getElementById('passwordStrengthText');

  pwdInput.addEventListener('input', () => {
    const val = pwdInput.value;
    if (!val) {
      strengthContainer.style.display = 'none';
      return;
    }
    
    strengthContainer.style.display = 'block';
    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[a-z]/.test(val)) score++;
    if (/\d/.test(val)) score++;
    if (/[@$!%*?&#]/.test(val)) score++;

    let label = 'Very Weak';
    let color = 'hsl(355, 84%, 55%)';
    let percentage = '20%';

    switch(score) {
      case 2:
        label = 'Weak';
        color = 'hsl(25, 90%, 55%)';
        percentage = '40%';
        break;
      case 3:
        label = 'Medium';
        color = 'hsl(45, 90%, 50%)';
        percentage = '60%';
        break;
      case 4:
        label = 'Strong';
        color = 'hsl(145, 75%, 45%)';
        percentage = '80%';
        break;
      case 5:
        label = 'Very Strong';
        color = 'hsl(145, 80%, 42%)';
        percentage = '100%';
        break;
    }

    strengthFill.style.width = percentage;
    strengthFill.style.backgroundColor = color;
    strengthText.textContent = `Strength: ${label}`;
  });

  // Helper to validate a single field
  const validateField = (fieldName) => {
    const field = fields[fieldName];
    const val = field.input.value;
    const allVals = {
      password: fields.password.input.value
    };
    
    const errorMsg = field.validate(val, allVals);
    
    if (errorMsg) {
      field.group.classList.remove('has-success');
      field.group.classList.add('has-error');
      field.message.textContent = errorMsg;
      return false;
    } else {
      field.group.classList.remove('has-error');
      field.group.classList.add('has-success');
      field.message.textContent = '';
      return true;
    }
  };

  // Add event listeners for realtime inline validation
  Object.keys(fields).forEach(key => {
    const field = fields[key];
    field.input.addEventListener('blur', () => validateField(key));
    field.input.addEventListener('input', () => {
      // If the field is currently in error state, revalidate inline on typing
      if (field.group.classList.contains('has-error')) {
        validateField(key);
      }
    });
  });

  // Notification Display helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Form Submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validate all fields
    let isValid = true;
    Object.keys(fields).forEach(key => {
      const fieldValid = validateField(key);
      if (!fieldValid) isValid = false;
    });

    if (!isValid) {
      // Shake the card UI to draw user attention
      const card = document.querySelector('.card');
      card.classList.add('shake');
      setTimeout(() => card.classList.remove('shake'), 4000);
      showNotification('Input Error', 'Please correct the highlighted fields before submitting.', 'error');
      return;
    }

    // Set Loading State
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const spinner = document.getElementById('submitSpinner');
    
    submitBtn.disabled = true;
    spinner.style.display = 'block';
    submitText.textContent = 'Registering Account...';

    const payload = {
      name: fields.name.input.value,
      email: fields.email.input.value,
      mobile: fields.mobile.input.value,
      password: fields.password.input.value,
      confirmPassword: fields.confirmPassword.input.value,
      role: roleInput.value,
      captchaId: captchaIdInput.value,
      captchaAnswer: fields.captchaAnswer.input.value
    };

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (response.ok && result.success) {
        showNotification('Success!', 'Your account has been created successfully. Redirecting to login...', 'success');
        if (payload.email) sessionStorage.setItem('lastRegisteredEmail', payload.email);
        if (payload.name) sessionStorage.setItem('lastRegisteredName', payload.name);
        
        form.reset();
        
        // Reset validation styles
        Object.keys(fields).forEach(key => {
          fields[key].group.classList.remove('has-success', 'has-error');
        });
        strengthContainer.style.display = 'none';
        loadCaptcha();

        setTimeout(() => {
          window.location.hash = payload.role === 'professor' ? '#/login-professor' : '#/login-student';
        }, 1200);
      } else {
        loadCaptcha();
        // Handle server side validation/business errors
        if (result.error) {
          Object.keys(result.error).forEach(fieldKey => {
            if (fields[fieldKey]) {
              fields[fieldKey].group.classList.add('has-error');
              fields[fieldKey].message.textContent = result.error[fieldKey];
            }
          });
          
          const firstErrField = Object.keys(result.error)[0];
          showNotification('Registration Failed', result.error[firstErrField] || 'Please review highlighted fields', 'error');
        } else {
          showNotification('Registration Failed', result.message || 'An error occurred during registration.', 'error');
        }
      }
    } catch (error) {
      console.error('API submission error:', error);
      showNotification('Network Error', 'Failed to communicate with the registration server. Please try again.', 'error');
    } finally {
      // Clear Loading State
      submitBtn.disabled = false;
      spinner.style.display = 'none';
      submitText.textContent = 'Register';
    }
  });
});

process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_digilocker.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('DigiLocker Integration API and Adapter tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM digilocker_connections');
    await db.query('DELETE FROM digilocker_documents');
    await db.query('DELETE FROM digilocker_consents');
    await db.query('DELETE FROM ekyc_requests');
    await db.query('DELETE FROM ekyc_audit_logs');
    await db.query('DELETE FROM audit_logs');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {
        // Ignored
      }
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_digilocker.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedUser(email, password, name = 'Alice Student') {
    const cap = await getValidCaptcha();
    await request(app)
      .post('/api/auth/register')
      .send({
        name,
        email,
        mobile: '9111122222',
        password,
        confirmPassword: password,
        role: 'student',
        ...cap
      });

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });
    const cookie = verifyRes.headers['set-cookie'][0];
    const userId = verifyRes.body.data.userId;

    // Initialize student profile
    await request(app)
      .put(`/api/profile/${userId}`)
      .set('Cookie', cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50,
        version: 1
      });

    return { userId, cookie };
  }

  // Connects student to DigiLocker securely using CSRF state cookies
  async function connectStudentDigilocker(student, username = 'alice_locker', state = 'xyz123') {
    const authRes = await request(app)
      .get(`/api/digilocker/oauth/authorize?state=${state}`)
      .set('Cookie', student.cookie);
    
    const setCookieHeader = authRes.headers['set-cookie'] 
      ? authRes.headers['set-cookie'][0] 
      : '';
    const stateCookie = setCookieHeader.split(';')[0];

    const callbackRes = await request(app)
      .post('/api/digilocker/oauth/callback')
      .set('Cookie', [student.cookie, stateCookie].filter(Boolean).join('; '))
      .send({ username, state });
    
    return callbackRes;
  }

  // Grants document access consent
  async function grantStudentConsent(student) {
    return await request(app)
      .post('/api/digilocker/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });
  }

  // --- TESTS ---

  test('1. Unauthorized access to DigiLocker endpoints is blocked', async () => {
    const res = await request(app).get('/api/digilocker/status');
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
  });

  test('2. Retrieve Status returns not connected by default', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    const res = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.data.connected).toBe(false);
    expect(res.body.data.documents.length).toBe(0);
  });

  test('3. Connect session creates connection details on OAuth callback', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    const res = await connectStudentDigilocker(student);
    expect(res.statusCode).toBe(200);
    expect(res.text).toContain('DIGILOCKER_AUTH_SUCCESS');

    // Get status again -> Connected
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);

    expect(statusRes.body.data.connected).toBe(true);
    expect(statusRes.body.data.digilockerId).toContain('DL-');
  });

  test('4. Fetch available documents lists items from adapter after consent', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // Attempt before connecting -> 400
    const resBefore = await request(app)
      .get('/api/digilocker/documents')
      .set('Cookie', student.cookie);
    expect(resBefore.statusCode).toBe(400);

    // Connect first
    await connectStudentDigilocker(student);

    // Attempt without consent -> 403
    const resNoConsent = await request(app)
      .get('/api/digilocker/documents')
      .set('Cookie', student.cookie);
    expect(resNoConsent.statusCode).toBe(403);

    // Give consent
    await grantStudentConsent(student);

    // Fetch documents -> 200 list
    const res = await request(app)
      .get('/api/digilocker/documents')
      .set('Cookie', student.cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.data.length).toBe(5);
    expect(res.body.data[0].name).toBe('Class XII Marksheet');
  });

  test('5. Successfully link document and check verification status', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'Alice Student');

    // Connect & Consent
    await connectStudentDigilocker(student);
    await grantStudentConsent(student);

    // Link Class XII transcript
    const resLink = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    expect(resLink.statusCode).toBe(200);
    expect(resLink.body.success).toBe(true);
    expect(resLink.body.data.verificationStatus).toBe('Verified');
    expect(resLink.body.data.documentRef).toContain('Roll No:');

    // Get Status -> document exists
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);

    expect(statusRes.body.data.documents.length).toBe(1);
    expect(statusRes.body.data.documents[0].document_type).toBe('Class XII Marksheet');
    expect(statusRes.body.data.documents[0].verification_status).toBe('Verified');

    // Verify audit log has link success entry
    const auditLogs = await db.query('SELECT action, details FROM ekyc_audit_logs WHERE user_id = ?', [student.userId]);
    expect(auditLogs.length).toBe(1);
    expect(auditLogs[0].action).toBe('DIGILOCKER_RETRIEVE_SUCCESS');
  });

  test('6. Rejects linkage if document name mismatches profile name', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'Alice Student');

    // Connect & Consent
    await connectStudentDigilocker(student);
    await grantStudentConsent(student);

    // Link mismatch trigger URI
    const resLink = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-mismatch' });

    expect(resLink.statusCode).toBe(400);
    expect(resLink.body.success).toBe(false);
    expect(resLink.body.message).toContain('Verification Mismatch');

    // Status shows Failed document link
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);

    expect(statusRes.body.data.documents[0].verification_status).toBe('Failed');

    // Verify audit log has link fail entry
    const auditLogs = await db.query('SELECT action FROM ekyc_audit_logs WHERE user_id = ?', [student.userId]);
    expect(auditLogs[0].action).toBe('DIGILOCKER_RETRIEVE_FAILED');
  });

  test('7. Propagates simulated timeouts and external failures correctly', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // Connect & Consent
    await connectStudentDigilocker(student);
    await grantStudentConsent(student);

    // Simulated Gateway Failure (502)
    const resFail = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-failure' });

    expect(resFail.statusCode).toBe(502);
    expect(resFail.body.message).toContain('gateway service is currently offline');

    // Simulated Timeout (504)
    const resTimeout = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-timeout' });

    expect(resTimeout.statusCode).toBe(504);
    expect(resTimeout.body.message).toContain('timed out');
  });

  test('8. Rejects OAuth callback if state parameter is invalid/missing', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // Bypass secure state generation and POST directly with fake state
    const res = await request(app)
      .post('/api/digilocker/oauth/callback')
      .set('Cookie', student.cookie)
      .send({ username: 'alice_locker', state: 'fakestate123' });

    expect(res.statusCode).toBe(400);
    expect(res.text).toContain('State validation error');
  });

  test('9. Retrieve document is blocked with 403 if consent not active', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // Connect but do NOT consent
    await connectStudentDigilocker(student);

    const res = await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    expect(res.statusCode).toBe(403);
    expect(res.body.message).toContain('consent required');
  });

  test('10. Document selection updates status to SELECTED and logs audit trail', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // Connect, Consent, and Retrieve document
    await connectStudentDigilocker(student);
    await grantStudentConsent(student);
    
    await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    // Select Document
    const resSelect = await request(app)
      .post('/api/digilocker/documents/select')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    expect(resSelect.statusCode).toBe(200);
    expect(resSelect.body.success).toBe(true);
    expect(resSelect.body.data.documentStatus).toBe('SELECTED');

    // Verify document status in status endpoint
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);
    
    expect(statusRes.body.data.documents[0].document_status).toBe('SELECTED');

    // Verify selection event in central audit log
    const auditRows = await db.query(
      "SELECT action, metadata FROM audit_logs WHERE user_id = ? AND action = 'DIGILOCKER_DOCUMENT_SELECTED'",
      [student.userId]
    );
    expect(auditRows.length).toBe(1);
    expect(JSON.parse(auditRows[0].metadata).docUri).toBe('in.gov.cbse-ssc-marksheet-2023');
  });

  test('11. Document selection can be toggled back to AVAILABLE', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    await connectStudentDigilocker(student);
    await grantStudentConsent(student);
    await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    // Select it first
    await request(app)
      .post('/api/digilocker/documents/select')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    // Deselect it
    const resDeselect = await request(app)
      .post('/api/digilocker/documents/select')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023', selected: false });

    expect(resDeselect.statusCode).toBe(200);
    expect(resDeselect.body.data.documentStatus).toBe('AVAILABLE');

    // Verify deselection event in audit logs
    const auditRows = await db.query(
      "SELECT action FROM audit_logs WHERE user_id = ? AND action = 'DIGILOCKER_DOCUMENT_DESELECTED'",
      [student.userId]
    );
    expect(auditRows.length).toBe(1);
  });

  test('12. Revoking consent deletes linked documents and updates status', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    await connectStudentDigilocker(student);
    await grantStudentConsent(student);
    
    // Retrieve a doc
    await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    // Revoke Consent (consent: false)
    const revokeRes = await request(app)
      .post('/api/digilocker/consent')
      .set('Cookie', student.cookie)
      .send({ consent: false });

    expect(revokeRes.statusCode).toBe(200);

    // Verify status shows no linked documents
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);
    
    expect(statusRes.body.data.consentActive).toBe(false);
    expect(statusRes.body.data.documents.length).toBe(0);

    // Verify revoke event in audit log
    const auditRows = await db.query(
      "SELECT action FROM audit_logs WHERE user_id = ? AND action = 'DIGILOCKER_CONSENT_REVOKED'",
      [student.userId]
    );
    expect(auditRows.length).toBe(1);
  });

  test('13. Disconnect integration deletes connection, documents, and revokes consent', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    await connectStudentDigilocker(student);
    await grantStudentConsent(student);
    await request(app)
      .post('/api/digilocker/documents/retrieve')
      .set('Cookie', student.cookie)
      .send({ docUri: 'in.gov.cbse-ssc-marksheet-2023' });

    // Disconnect
    const disRes = await request(app)
      .post('/api/digilocker/disconnect')
      .set('Cookie', student.cookie);

    expect(disRes.statusCode).toBe(200);

    // Check status -> fully disconnected
    const statusRes = await request(app)
      .get('/api/digilocker/status')
      .set('Cookie', student.cookie);

    expect(statusRes.body.data.connected).toBe(false);
    expect(statusRes.body.data.consentActive).toBe(false);
    expect(statusRes.body.data.documents.length).toBe(0);

    // Verify disconnect audit trail
    const auditRows = await db.query(
      "SELECT action FROM audit_logs WHERE user_id = ? AND action = 'DIGILOCKER_DISCONNECTED'",
      [student.userId]
    );
    expect(auditRows.length).toBe(1);
  });

  function makeXml(name, dob, gender, pc, shareCode = '1234', aadhaar = '123456789012') {
    return `<?xml version="1.0" encoding="UTF-8"?>
<OfflinePaperlessKyc shareCode="${shareCode}" aadhaar="${aadhaar}">
  <UidData>
    <Poi name="${name}" dob="${dob}" gender="${gender}"/>
    <Poa co="Guardian" street="123 Main St" state="Delhi" pc="${pc}"/>
    <Pht>photo_data</Pht>
  </UidData>
  <Signature>trusted_root_signature</Signature>
</OfflinePaperlessKyc>`;
  }

  test('14. Enforce Aadhaar match: Connecting DigiLocker after e-KYC succeeds with matching Aadhaar', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // 1. Perform eKYC with Aadhaar 123456789012
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    const xmlContent = makeXml('Alice Student', '2005-05-15', 'Female', '110001', '1234', '123456789012');
    const ekycRes = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent,
        shareCode: '1234',
        consent: true
      });
    expect(ekycRes.statusCode).toBe(200);

    // 2. Connect DigiLocker with matching Aadhaar 123456789012
    const dlRes = await connectStudentDigilocker(student, '123456789012');
    expect(dlRes.statusCode).toBe(200);
    expect(dlRes.text).toContain('DIGILOCKER_AUTH_SUCCESS');
  });

  test('15. Enforce Aadhaar match: Connecting DigiLocker after e-KYC fails with mismatched Aadhaar', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // 1. Perform eKYC with Aadhaar 123456789012
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    const xmlContent = makeXml('Alice Student', '2005-05-15', 'Female', '110001', '1234', '123456789012');
    const ekycRes = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent,
        shareCode: '1234',
        consent: true
      });
    expect(ekycRes.statusCode).toBe(200);

    // 2. Connect DigiLocker with mismatched Aadhaar 987654321098 -> Should fail 400
    const dlRes = await connectStudentDigilocker(student, '987654321098');
    expect(dlRes.statusCode).toBe(400);
    expect(dlRes.text).toContain('does not match the Aadhaar number verified in e-KYC');
  });

  test('16. Enforce Aadhaar match: Performing e-KYC after DigiLocker fails with mismatched Aadhaar', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123');

    // 1. Connect DigiLocker with Aadhaar 123456789012
    const dlRes = await connectStudentDigilocker(student, '123456789012');
    expect(dlRes.statusCode).toBe(200);

    // 2. Perform eKYC with mismatched Aadhaar 987654321098 -> Should fail 400
    await request(app)
      .post('/api/ekyc/consent')
      .set('Cookie', student.cookie)
      .send({ consent: true });

    const xmlContent = makeXml('Alice Student', '2005-05-15', 'Female', '110001', '1234', '987654321098');
    const ekycRes = await request(app)
      .post('/api/ekyc/verify')
      .set('Cookie', student.cookie)
      .send({
        xmlContent,
        shareCode: '1234',
        consent: true
      });
    expect(ekycRes.statusCode).toBe(400);
    expect(ekycRes.body.message).toContain('does not match the Aadhaar number connected to DigiLocker');
  });

});

const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const { requireRole } = require('../middleware/rbac');
const {
  postSignApplication,
  postTransitionApplication,
  getWorkflowHistory
} = require('../controllers/workflowController');
const { workflowTransitionRules, validate } = require('../middleware/validation');

// POST /api/workflow/sign - Student mock signs application
router.post('/sign', authenticateToken, postSignApplication);

// POST /api/workflow/transition - Professor processes application (Approve, Reject, Correction)
router.post('/transition', authenticateToken, requireRole('professor'), workflowTransitionRules, validate, postTransitionApplication);

// GET /api/workflow/history - Get timeline audit transition logs
router.get('/history', authenticateToken, getWorkflowHistory);

module.exports = router;

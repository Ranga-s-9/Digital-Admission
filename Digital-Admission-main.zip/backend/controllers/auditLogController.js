const AuditLog = require('../models/AuditLog');
const { logger } = require('../middleware/logger');

/**
 * Controller to fetch all system audit logs (Admin only)
 */
async function getAuditLogs(req, res) {
  try {
    // Role guard: Only professors (academic staff) or admins are allowed to view audit logs
    if (req.user.role !== 'professor' && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: Only academic staff or administrators can access system audit logs.',
        error: { global: 'Forbidden access' }
      });
    }

    const logs = await AuditLog.findAll();
    
    // Format response values
    const formattedLogs = logs.map(l => ({
      id: l.id,
      userId: l.user_id,
      action: l.action,
      entityType: l.entity_type,
      entityId: l.entity_id,
      status: l.status,
      ipAddress: l.ip_address,
      metadata: l.metadata ? JSON.parse(l.metadata) : null,
      createdAt: l.created_at
    }));

    return res.status(200).json({
      success: true,
      message: 'System audit logs retrieved successfully',
      data: formattedLogs
    });

  } catch (error) {
    logger.error('Fetch system audit logs controller error:', { message: error.message, stack: error.stack, requestId: req.id || null });
    return res.status(500).json({
      success: false,
      message: 'An internal server error occurred while retrieving logs',
      error: { global: 'Internal server error' }
    });
  }
}

module.exports = {
  getAuditLogs
};

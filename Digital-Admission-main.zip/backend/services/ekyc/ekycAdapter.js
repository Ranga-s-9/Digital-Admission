/**
 * Abstract base class for eKYC Verification Adapters
 */
class EkycAdapter {
  /**
   * Verify eKYC via Offline XML
   * @param {number} userId - The student user ID
   * @param {string} xmlContent - The uploaded XML document content
   * @param {string} shareCode - The 4-digit share code
   * @param {string} ipAddress - Client's IP address
   * @returns {Promise<Object>} Verification results containing status and details
   */
  async verify(userId, xmlContent, shareCode, ipAddress) {
    throw new Error('Method "verify" must be implemented by the subclass');
  }
}

module.exports = EkycAdapter;

(function () {
  // Client-side eSignzy + Workflow module (Module 11)
  document.addEventListener('DOMContentLoaded', () => {
    const esignSubmitBtn = document.getElementById('esignSubmitBtn');
    const esignSubmitSpinner = document.getElementById('esignSubmitSpinner');
    const esignSubmitText = document.getElementById('esignSubmitText');
    const esignBtnIcon = document.getElementById('esignBtnIcon');
    const esignPendingSection = document.getElementById('esignPendingSection');
    const esignSignedSection = document.getElementById('esignSignedSection');

    /**
     * Show the signed confirmation panel with eSignzy response details
     * @param {Object} data - API response data
     */
    function showSignedConfirmation(data) {
      if (esignPendingSection) esignPendingSection.style.display = 'none';
      if (esignSignedSection) esignSignedSection.style.display = 'block';

      const requestIdEl = document.getElementById('esignRequestId');
      const docUriEl = document.getElementById('esignDocUri');
      const signedAtEl = document.getElementById('esignSignedAt');
      const esignDevBanner = document.getElementById('esignDevBanner');

      if (requestIdEl) requestIdEl.textContent = data.sign_request_id || '—';
      if (docUriEl) docUriEl.textContent = data.signed_doc_uri || '—';
      if (signedAtEl) {
        const ts = data.signed_at;
        signedAtEl.textContent = ts ? new Date(ts).toLocaleString() : '—';
      }
      if (esignDevBanner) {
        esignDevBanner.style.display = data.development_mode ? 'flex' : 'none';
      }
    }

    if (esignSubmitBtn) {
      esignSubmitBtn.addEventListener('click', async (e) => {
        e.preventDefault();

        esignSubmitBtn.disabled = true;
        if (esignSubmitSpinner) esignSubmitSpinner.style.display = 'inline-block';
        if (esignBtnIcon) esignBtnIcon.style.display = 'none';
        if (esignSubmitText) esignSubmitText.textContent = 'Sending to emSigner...';

        try {
          // Call the dedicated emSigner sign endpoint (Module 11)
          const res = await fetch('/api/emsigner/sign', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
          const result = await res.json();

          if (esignSubmitSpinner) esignSubmitSpinner.style.display = 'none';
          if (esignBtnIcon) esignBtnIcon.style.display = '';
          esignSubmitBtn.disabled = false;
          if (esignSubmitText) esignSubmitText.textContent = 'Sign with emSigner';

          if (res.ok && result.success) {
            showSignedConfirmation(result.data || {});
            showNotification(
              'Document Signed',
              result.data && result.data.development_mode
                ? '[MOCK] Application signed via emSigner (development mode). Signature ID: ' + (result.data.sign_request_id || '')
                : 'Your admission document has been digitally signed via emSigner.',
              'success'
            );
            // Refresh dashboard to reflect SIGNED status
            if (typeof window.initDashboardView === 'function') {
              setTimeout(() => window.initDashboardView(), 1200);
            }
          } else {
            showNotification('Signature Error', result.message || 'Failed to complete emSigner signing.', 'error');
          }
        } catch (err) {
          console.error('emSigner sign error:', err);
          if (esignSubmitSpinner) esignSubmitSpinner.style.display = 'none';
          if (esignBtnIcon) esignBtnIcon.style.display = '';
          esignSubmitBtn.disabled = false;
          if (esignSubmitText) esignSubmitText.textContent = 'Sign with emSigner';
          showNotification('Connection Failure', 'Network error during emSigner signing. Please retry.', 'error');
        }
      });
    }


    // Set up Professor review action handlers
    const profApproveBtn = document.getElementById('profApproveBtn');
    const profRejectBtn = document.getElementById('profRejectBtn');
    const profRequestCorrectionsBtn = document.getElementById('profRequestCorrectionsBtn');
    const profActionNotes = document.getElementById('profActionNotes');
    const reviewModal = document.getElementById('professorReviewModal');

    async function handleProfessorAction(targetStatus) {
      const targetUserId = reviewModal.dataset.studentUserId;
      const notes = profActionNotes ? profActionNotes.value.trim() : '';

      if (!targetUserId) {
        showNotification('Selection Error', 'No active student selected for action.', 'error');
        return;
      }

      if (targetStatus === 'Draft' && !notes) {
        showNotification('Revision Required', 'Please enter correction instructions in the notes area.', 'warning');
        if (profActionNotes) profActionNotes.focus();
        return;
      }

      const body = {
        userId: parseInt(targetUserId, 10),
        targetStatus,
        message: notes
      };

      try {
        const res = await fetch('/api/workflow/transition', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
        const result = await res.json();

        if (res.ok && result.success) {
          showNotification('Workflow Updated', `Application transitioned to '${targetStatus}' status.`, 'success');
          if (reviewModal) reviewModal.style.display = 'none';
          // Refresh professor applications table
          if (typeof window.loadProfessorDashboard === 'function') {
            window.loadProfessorDashboard();
          }
        } else {
          showNotification('Transition Rejected', result.message || 'Invalid state transition block.', 'error');
        }
      } catch (err) {
        console.error('Workflow transition error:', err);
        showNotification('Transition Error', 'Failed to transmit workflow transition parameters.', 'error');
      }
    }

    if (profApproveBtn) {
      profApproveBtn.addEventListener('click', () => handleProfessorAction('Approved'));
    }
    if (profRejectBtn) {
      profRejectBtn.addEventListener('click', () => handleProfessorAction('Rejected'));
    }
    if (profRequestCorrectionsBtn) {
      profRequestCorrectionsBtn.addEventListener('click', () => handleProfessorAction('Draft'));
    }
  });

  // Global window functions to decouple list clicks
  window.openProfessorReviewModal = async function (app) {
    const modal = document.getElementById('professorReviewModal');
    const detailsContainer = document.getElementById('profModalDetails');
    const notesInput = document.getElementById('profActionNotes');

    const approveBtn = document.getElementById('profApproveBtn');
    const rejectBtn = document.getElementById('profRejectBtn');
    const reqCorrectionsBtn = document.getElementById('profRequestCorrectionsBtn');

    if (!modal || !detailsContainer) return;

    // Save user ID to modal
    modal.dataset.studentUserId = app.id;
    if (notesInput) notesInput.value = '';

    // Show loading state initially
    detailsContainer.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 15px; align-items: center; justify-content: center; padding: 30px 0; width: 100%;">
        <div class="table-spinner" style="border-top-color: var(--primary);"></div>
        <span style="color: var(--text-secondary); font-size: 13px;">Retrieving verification packet...</span>
      </div>
    `;
    modal.style.display = 'flex';

    try {
      const res = await fetch(`/api/dashboard/professor/student/${app.id}`);
      const result = await res.json();
      if (!res.ok || !result.success) {
        detailsContainer.innerHTML = `<div style="color: var(--error); padding: 15px; font-weight: 500;">Failed to load packet: ${result.message || 'Error'}</div>`;
        return;
      }

      const data = result.data;
      const s = data.student;
      const p = data.profile || {};
      const a = data.application || {};
      const ek = data.ekyc || { status: 'Pending' };
      const dl = data.digilocker || { connected: false, documents: [] };
      const logs = data.auditLogs || [];

      // Construct detailed layout
      let html = `
        <div style="display: flex; flex-direction: column; gap: 20px; width: 100%;">
          
          <!-- Student Info Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--card-border);">
            <div>
              <div style="font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 600; margin-bottom: 4px;">Student Name</div>
              <div style="font-weight: 600; color: var(--text-primary);">${s.name}</div>
            </div>
            <div>
              <div style="font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 600; margin-bottom: 4px;">Email Address</div>
              <div style="color: var(--text-secondary);">${s.email}</div>
            </div>
            <div>
              <div style="font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 600; margin-bottom: 4px;">Mobile Number</div>
              <div style="color: var(--text-secondary);">${s.mobile}</div>
            </div>
            <div>
              <div style="font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 600; margin-bottom: 4px;">Application ID</div>
              <div style="font-weight: 600; color: var(--primary-light);">${a.applicationId || 'Not Generated'}</div>
            </div>
          </div>

          <!-- Academic and Personal Profile Data -->
          <div style="display: flex; flex-direction: column; gap: 10px;">
            <div style="font-weight: 600; font-size: 14px; color: var(--text-primary); border-left: 3px solid var(--primary); padding-left: 8px;">Academic & Personal Profile</div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; background: hsla(222, 25%, 10%, 0.4); padding: 12px; border-radius: 8px; border: 1px solid var(--card-border);">
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Date of Birth:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.dob || '—'}</strong>
              </div>
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Gender:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.gender || '—'}</strong>
              </div>
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Father/Guardian:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.guardianName || '—'}</strong>
              </div>
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Degree Choice:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.degree || '—'}</strong>
              </div>
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Board:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.board || '—'}</strong>
              </div>
              <div>
                <span style="font-size: 12px; color: var(--text-muted);">Percentage:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.percentage ? parseFloat(p.percentage).toFixed(2) + '%' : '—'}</strong>
              </div>
              <div style="grid-column: 1 / -1;">
                <span style="font-size: 12px; color: var(--text-muted);">Correspondence Address:</span> 
                <strong style="font-size: 13px; color: var(--text-secondary);">${p.address ? `${p.address}, ${p.state} - ${p.pincode}` : '—'}</strong>
              </div>
            </div>
          </div>
      `;

      // Add student photo if exists
      if (p.photoPath) {
        html += `
          <!-- Student Uploaded Photo -->
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div style="font-weight: 600; font-size: 14px; color: var(--text-primary); border-left: 3px solid var(--primary); padding-left: 8px;">Uploaded Identity Document Photo</div>
            <div style="display: flex; align-items: center; gap: 15px; background: hsla(222, 25%, 10%, 0.4); padding: 10px; border-radius: 8px; border: 1px solid var(--card-border);">
              <img src="${p.photoPath}" alt="Applicant Photo" style="max-height: 120px; border-radius: 6px; border: 1px solid var(--card-border); background: var(--bg);">
              <div style="font-size: 12px; color: var(--text-muted); line-height: 1.5;">
                File: <strong>${p.photoPath.split('/').pop()}</strong><br>
                Verification: Cross-check user profile details match visually
              </div>
            </div>
          </div>
        `;
      }

      html += `
          <!-- Identity and DigiLocker Verification -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 15px;">
            
            <!-- eKYC verification details -->
            <div style="background: hsla(222, 25%, 10%, 0.4); padding: 12px; border-radius: 8px; border: 1px solid var(--card-border); display: flex; flex-direction: column; gap: 8px;">
              <div style="font-weight: 600; font-size: 13px; color: var(--text-primary); display: flex; justify-content: space-between; align-items: center;">
                <span>Aadhaar eKYC</span>
                <span class="badge ${ek.status === 'Verified' ? 'badge-success' : 'badge-pending'}">${ek.status}</span>
              </div>
              <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin-top: 5px;">
                ${ek.status === 'Verified' 
                  ? `Masked ID: <strong>${ek.maskedAadhaar}</strong><br>Verified At: ${new Date(ek.verifiedAt).toLocaleString()}` 
                  : ek.status === 'Failed' 
                    ? `Reason: <span style="color: var(--error);">${ek.errorMessage}</span>` 
                    : 'Aadhaar Offline XML eKYC verification is pending.'
                }
              </div>
            </div>

            <!-- DigiLocker linkage details -->
            <div style="background: hsla(222, 25%, 10%, 0.4); padding: 12px; border-radius: 8px; border: 1px solid var(--card-border); display: flex; flex-direction: column; gap: 8px;">
              <div style="font-weight: 600; font-size: 13px; color: var(--text-primary); display: flex; justify-content: space-between; align-items: center;">
                <span>DigiLocker Catalog</span>
                <span class="badge ${dl.connected ? 'badge-success' : 'badge-pending'}">${dl.connected ? 'Connected' : 'Not Linked'}</span>
              </div>
              <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin-top: 5px;">
                ${dl.connected 
                  ? `DigiLocker ID: <strong>${dl.digilockerId}</strong><br>Linked marksheets: ${dl.documents.length}` 
                  : 'No active connection to DigiLocker catalog.'
                }
              </div>
            </div>

          </div>
      `;

      // DigiLocker Documents list
      if (dl.connected && dl.documents.length > 0) {
        html += `
          <!-- Linked Certificates and marksheets -->
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div style="font-weight: 600; font-size: 14px; color: var(--text-primary); border-left: 3px solid var(--primary); padding-left: 8px;">Verified DigiLocker Marksheets</div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
        `;
        dl.documents.forEach(doc => {
          html += `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: hsla(222, 25%, 8%, 0.5); border-radius: 6px; border: 1px solid var(--card-border); font-size: 13px;">
              <div style="display: flex; flex-direction: column; gap: 3px;">
                <span style="font-weight: 500; color: var(--text-primary);">${doc.document_type}</span>
                <span style="font-size: 11px; color: var(--text-muted);">${doc.issuing_authority} (Ref: ${doc.document_ref})</span>
              </div>
              <span class="badge ${doc.verification_status === 'Verified' ? 'badge-success' : 'badge-pending'}" style="font-size: 11px; padding: 2px 6px;">${doc.verification_status}</span>
            </div>
          `;
        });
        html += `
            </div>
          </div>
        `;
      }

      // Workflow History Logs Timeline
      if (logs.length > 0) {
        html += `
          <!-- Transition Timeline Log -->
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div style="font-weight: 600; font-size: 14px; color: var(--text-primary); border-left: 3px solid var(--primary); padding-left: 8px;">Workflow History & Audit Trail</div>
            <div style="max-height: 150px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; padding-right: 5px;" class="custom-scrollbar">
        `;
        logs.forEach(log => {
          const dateStr = new Date(log.created_at).toLocaleString();
          let stateBadge = `<span class="badge badge-pending" style="font-size: 10px; padding: 1px 4px;">${log.to_status}</span>`;
          if (log.to_status === 'Approved') {
            stateBadge = `<span class="badge badge-success" style="font-size: 10px; padding: 1px 4px;">Approved</span>`;
          } else if (log.to_status === 'Rejected') {
            stateBadge = `<span class="badge badge-danger" style="font-size: 10px; padding: 1px 4px;">Rejected</span>`;
          }
          html += `
            <div style="font-size: 12px; background: hsla(222, 25%, 5%, 0.4); padding: 8px 10px; border-radius: 5px; border: 1px solid hsla(222, 10%, 20%, 0.4); line-height: 1.4;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                <span style="font-weight: 500; color: var(--text-secondary);">${log.action_by_role === 'student' ? 'Student' : 'Professor'}</span>
                <span style="color: var(--text-muted); font-size: 11px;">${dateStr}</span>
              </div>
              <div style="color: var(--text-muted); font-size: 11px; margin-bottom: 4px;">IP Address: ${log.ip_address || '—'}</div>
              <div style="color: var(--text-secondary); font-style: italic;">${log.details}</div>
            </div>
          `;
        });
        html += `
            </div>
          </div>
        `;
      }

      html += `</div>`;
      detailsContainer.innerHTML = html;

      // Enable/disable buttons based on state machine logic
      const status = a.status || 'Draft';

      if (status === 'Draft' || status === 'Not Started' || status === 'Approved' || status === 'Rejected') {
        if (approveBtn) approveBtn.style.display = 'none';
        if (rejectBtn) rejectBtn.style.display = 'none';
        if (reqCorrectionsBtn) reqCorrectionsBtn.style.display = 'none';
        
        const msg = status === 'Approved' || status === 'Rejected'
          ? `Application review is completed (Result: ${status}).`
          : `Student is currently editing application in Draft mode.`;
        
        detailsContainer.innerHTML += `<div style="margin-top: 15px; color: var(--text-muted); font-style: italic; font-size: 13px;">${msg}</div>`;
      } else {
        // Submitted, DOCUMENT_VERIFICATION, IDENTITY_VERIFICATION, PENDING_SIGNATURE, SIGNED
        if (reqCorrectionsBtn) reqCorrectionsBtn.style.display = 'inline-block';
        
        if (status === 'SIGNED') {
          if (approveBtn) approveBtn.style.display = 'inline-block';
          if (rejectBtn) rejectBtn.style.display = 'inline-block';
        } else {
          // Submitted but not signed yet
          if (approveBtn) approveBtn.style.display = 'none';
          if (rejectBtn) rejectBtn.style.display = 'none';
          detailsContainer.innerHTML += `<div style="margin-top: 15px; color: var(--warning); font-weight: 500; font-size: 13px; background: hsla(38, 92%, 50%, 0.1); padding: 8px 12px; border-radius: 6px; border: 1px solid var(--warning);">Wait: Application must be signed by the student before approval/rejection decision.</div>`;
        }
      }

    } catch (err) {
      console.error('Error fetching review packet:', err);
      detailsContainer.innerHTML = `<div style="color: var(--error); padding: 15px; font-weight: 500;">Connection failure loading student details.</div>`;
    }
  };
})();

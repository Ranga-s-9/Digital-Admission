document.addEventListener('DOMContentLoaded', () => {
  const otpForm = document.getElementById('otpForm');
  const otpDigits = [
    document.getElementById('otpDigit1'),
    document.getElementById('otpDigit2'),
    document.getElementById('otpDigit3'),
    document.getElementById('otpDigit4'),
    document.getElementById('otpDigit5'),
    document.getElementById('otpDigit6')
  ];

  const otpGlobalGroup = document.getElementById('otpGlobalGroup');
  const otpGlobalFeedback = document.getElementById('otpGlobalFeedback');
  const otpTimerText = document.getElementById('otpTimerText');
  const resendOtpBtn = document.getElementById('resendOtpBtn');
  const resendCooldownText = document.getElementById('resendCooldownText');
  const otpSubtitleText = document.getElementById('otpSubtitleText');

  let expirationTime = 0;
  let cooldownTime = 0;
  let timerInterval = null;

  function getRedirectLoginHash() {
    try {
      const cached = sessionStorage.getItem('otpContext');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && parsed.requireSmsOtp) {
          return '#/login-professor';
        }
      }
    } catch (e) {
      console.error('Failed to parse cached OTP context:', e);
    }
    return '#/login-student';
  }

  // Jump to next input field on typing, backspace jumps to previous
  otpDigits.forEach((input, index) => {
    input.addEventListener('input', (e) => {
      let value = e.target.value;
      if (value.length > 1) {
        value = value.charAt(value.length - 1);
        input.value = value;
      }
      if (value.length > 0) {
        // Allow numeric inputs only
        if (!/^[0-9]$/.test(value)) {
          input.value = '';
          return;
        }
        if (index < otpDigits.length - 1) {
          otpDigits[index + 1].focus();
        }
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace') {
        if (input.value === '') {
          if (index > 0) {
            otpDigits[index - 1].focus();
            otpDigits[index - 1].value = '';
          }
        } else {
          input.value = '';
        }
        otpGlobalGroup.style.display = 'none';
      }
    });

    // Handle paste event
    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasteData = (e.clipboardData || window.clipboardData).getData('text');
      if (/^\d{6}$/.test(pasteData)) {
        for (let i = 0; i < otpDigits.length; i++) {
          otpDigits[i].value = pasteData[i];
        }
        otpDigits[otpDigits.length - 1].focus();
        otpGlobalGroup.style.display = 'none';
      }
    });
  });

  // Display Notification helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Timer loop updating cooldowns and expirations
  function startTimers(expiresInSec, cooldownInSec) {
    expirationTime = expiresInSec;
    cooldownTime = cooldownInSec;

    if (timerInterval) clearInterval(timerInterval);

    resendOtpBtn.disabled = true;
    resendCooldownText.textContent = `(${cooldownTime}s)`;

    timerInterval = setInterval(() => {
      // Expiration countdown
      if (expirationTime > 0) {
        expirationTime--;
        const min = Math.floor(expirationTime / 60).toString().padStart(2, '0');
        const sec = (expirationTime % 60).toString().padStart(2, '0');
        otpTimerText.textContent = `Expires in: ${min}:${sec}`;
      } else {
        clearInterval(timerInterval);
        otpTimerText.textContent = 'Expired';
        otpGlobalGroup.style.display = 'block';
        otpGlobalFeedback.textContent = 'OTP has expired. Please restart login.';
        showNotification('Session Expired', 'Please re-enter your login credentials.', 'error');
        
        // Disable digit inputs
        otpDigits.forEach(input => input.disabled = true);
        return;
      }

      // Resend Cooldown countdown
      if (cooldownTime > 0) {
        cooldownTime--;
        resendCooldownText.textContent = `(${cooldownTime}s)`;
        resendOtpBtn.disabled = true;
      } else {
        resendCooldownText.textContent = '';
        resendOtpBtn.disabled = false;
      }
    }, 1000);
  }

  // Initialize view params when routed
  function initOtpView(otpSessionId, data) {
    // Clear inputs and set status
    otpDigits.forEach(input => {
      input.value = '';
      input.disabled = false;
    });
    otpGlobalGroup.style.display = 'none';

    // Save session context locally
    sessionStorage.setItem('otpSessionId', otpSessionId);

    const totpSetupSection = document.getElementById('totpSetupSection');
    const totpQrCode = document.getElementById('totpQrCode');
    const totpSecretKey = document.getElementById('totpSecretKey');
    const btnConfirmSetup = document.getElementById('btnConfirmSetup');
    const otpTitle = document.getElementById('otpTitle');

    const isSmsOtp = !!(data && data.requireSmsOtp);
    if (resendOtpBtn) {
      resendOtpBtn.style.display = isSmsOtp ? 'inline-block' : 'none';
    }

    const backToLoginLink = document.getElementById('backToLoginLink');
    if (backToLoginLink) {
      backToLoginLink.setAttribute('href', isSmsOtp ? '#/login-professor' : '#/login-student');
    }

    if (isSmsOtp) {
      // Direct SMS OTP verification for professors
      totpSetupSection.style.display = 'none';
      otpForm.style.display = 'block';
      otpTitle.textContent = 'Professor SMS Verification';
      otpSubtitleText.textContent = 'Enter the 6-digit OTP code sent to your registered mobile.';
      otpDigits[0].focus();
    } else if (data && data.requireSetup) {
      // Setup flow
      totpSetupSection.style.display = 'flex';
      otpForm.style.display = 'none';
      totpQrCode.src = data.qrCodeUrl;
      totpSecretKey.textContent = data.secret;
      otpTitle.textContent = 'Setup Google Authenticator';
      otpSubtitleText.textContent = 'Link your authenticator app before verifying.';

      btnConfirmSetup.onclick = () => {
        totpSetupSection.style.display = 'none';
        otpForm.style.display = 'block';
        otpTitle.textContent = 'Two-Factor Verification';
        otpSubtitleText.textContent = 'Enter the 6-digit code from your authenticator app.';
        otpDigits[0].focus();
      };
    } else {
      // Direct verification
      totpSetupSection.style.display = 'none';
      otpForm.style.display = 'block';
      otpTitle.textContent = 'Two-Factor Verification';
      otpSubtitleText.textContent = 'Enter the 6-digit code from your authenticator app.';
      otpDigits[0].focus();
    }

    const cooldown = isSmsOtp ? 60 : 0;
    startTimers(data ? (data.expiresIn || 300) : 300, cooldown);
  }

  // Expose initiator globally
  window.initOtpView = initOtpView;

  // Handle Resend action
  resendOtpBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    if (resendOtpBtn.disabled) return;

    const otpSessionId = sessionStorage.getItem('otpSessionId');
    if (!otpSessionId) {
      window.location.hash = getRedirectLoginHash();
      return;
    }

    resendOtpBtn.disabled = true;
    otpGlobalGroup.style.display = 'none';

    try {
      const response = await fetch('/api/auth/resend-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otpSessionId })
      });

      const result = await response.json();

      if (response.ok && result.success) {
        showNotification('OTP Dispatched', 'A new verification code has been sent.', 'success');
        
        // Reset code entries
        otpDigits.forEach(input => input.value = '');
        otpDigits[0].focus();

        // Restart timers
        startTimers(result.data.expiresIn, result.data.cooldown);
      } else {
        if (result.message && result.message.includes('limit exceeded')) {
          showNotification('Verification Locked', 'Resend limits exceeded. Restarting login.', 'error');
          sessionStorage.removeItem('otpSessionId');
          sessionStorage.removeItem('otpContext');
          setTimeout(() => window.location.hash = getRedirectLoginHash(), 2000);
        } else {
          otpGlobalGroup.style.display = 'block';
          otpGlobalFeedback.textContent = result.message || 'Resend rejected';
          resendOtpBtn.disabled = false;
        }
      }
    } catch (err) {
      console.error('Resend OTP error:', err);
      showNotification('Network Error', 'Connection failed. Please retry.', 'error');
      resendOtpBtn.disabled = false;
    }
  });

  // Verify Form submit
  otpForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const otpSessionId = sessionStorage.getItem('otpSessionId');
    if (!otpSessionId) {
      window.location.hash = getRedirectLoginHash();
      return;
    }

    // Collect code digits
    const code = otpDigits.map(input => input.value).join('');
    if (code.length !== 6) {
      otpGlobalGroup.style.display = 'block';
      otpGlobalFeedback.textContent = 'Please enter all 6 digits of the verification code.';
      return;
    }

    const submitBtn = document.getElementById('otpSubmitBtn');
    const submitText = document.getElementById('otpSubmitText');
    const spinner = document.getElementById('otpSubmitSpinner');

    submitBtn.disabled = true;
    spinner.style.display = 'block';
    submitText.textContent = 'Verifying OTP...';
    otpGlobalGroup.style.display = 'none';

    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otpSessionId, code })
      });

      const result = await response.json();

      if (response.ok && result.success) {
        showNotification('Login Successful', 'Welcome to your admission portal.', 'success');
        clearInterval(timerInterval);
        sessionStorage.removeItem('otpSessionId');
        sessionStorage.removeItem('otpContext');
        
        // Swap to dashboard view and fetch profile details
        window.location.hash = '#/dashboard';
        if (window.fetchProfile) {
          await window.fetchProfile();
        }
      } else {
        // Shake verification card on error
        const card = document.getElementById('otpView');
        card.classList.add('shake');
        setTimeout(() => card.classList.remove('shake'), 1000);

        if (result.message && result.message.includes('attempts')) {
          otpGlobalGroup.style.display = 'block';
          otpGlobalFeedback.textContent = result.message;
          
          // Clear inputs
          otpDigits.forEach(input => input.value = '');
          otpDigits[0].focus();

          if (result.message.includes('Too many failed')) {
            // Lockout -> Redirect to login after delay
            sessionStorage.removeItem('otpSessionId');
            sessionStorage.removeItem('otpContext');
            setTimeout(() => window.location.hash = getRedirectLoginHash(), 2500);
          }
        } else {
          otpGlobalGroup.style.display = 'block';
          otpGlobalFeedback.textContent = result.message || 'OTP verification failed';
        }
      }
    } catch (err) {
      console.error('OTP verification submission error:', err);
      showNotification('Network Error', 'Connection failed. Please retry.', 'error');
    } finally {
      submitBtn.disabled = false;
      spinner.style.display = 'none';
      submitText.textContent = 'Verify & Authenticate';
    }
  });
});

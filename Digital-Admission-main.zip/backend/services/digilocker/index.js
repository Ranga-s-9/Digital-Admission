const MockDigilockerAdapter = require('./mockDigilockerAdapter');
const RealDigilockerAdapter = require('./realDigilockerAdapter');

const mockInstance = new MockDigilockerAdapter();
const realInstance = new RealDigilockerAdapter();

/**
 * Factory getter for retrieving the current active DigiLocker Adapter
 * @returns {DigilockerAdapter} The loaded adapter instance
 */
function getDigilockerAdapter() {
  const mode = process.env.DIGILOCKER_MODE || 'mock';
  if (mode === 'real') {
    return realInstance;
  }
  return mockInstance;
}

module.exports = {
  getDigilockerAdapter
};

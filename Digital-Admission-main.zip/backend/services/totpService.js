const crypto = require('crypto');
const OTPAuth = require('otpauth');
const QRCode = require('qrcode');
require('dotenv').config();

const algorithm = 'aes-256-cbc';
const secretKey = crypto.createHash('sha256').update(process.env.JWT_SECRET || 'supersecretkeyforjwtauthentication').digest();
const ivLength = 16;

/**
 * Encrypt a text string using AES-256-CBC
 * @param {string} text 
 * @returns {string} iv:encryptedText in hex format
 */
function encrypt(text) {
  const iv = crypto.randomBytes(ivLength);
  const cipher = crypto.createCipheriv(algorithm, secretKey, iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

/**
 * Decrypt an iv:encryptedText hex string
 * @param {string} text 
 * @returns {string} decrypted text
 */
function decrypt(text) {
  const parts = text.split(':');
  if (parts.length < 2) {
    throw new Error('Invalid encrypted format');
  }
  const iv = Buffer.from(parts.shift(), 'hex');
  const encryptedText = Buffer.from(parts.join(':'), 'hex');
  const decipher = crypto.createDecipheriv(algorithm, secretKey, iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

/**
 * Generate a new TOTP secret and label it for the user
 * @param {string} email 
 * @returns {Object} { secret, otpauthUri }
 */
function generateSecret(email) {
  const secret = new OTPAuth.Secret({ size: 20 });
  const secretBase32 = secret.base32;

  const totp = new OTPAuth.TOTP({
    issuer: 'DPI Student Admission',
    label: email,
    algorithm: 'SHA1',
    digits: 6,
    period: 30,
    secret: secret
  });

  return {
    secret: secretBase32,
    otpauthUri: totp.toString()
  };
}

/**
 * Generate a Data URL PNG QR Code from an otpauth URI
 * @param {string} otpauthUri 
 * @returns {Promise<string>} data URL
 */
async function generateQRCode(otpauthUri) {
  return await QRCode.toDataURL(otpauthUri);
}

/**
 * Validate a user's TOTP token
 * @param {string} secretBase32 
 * @param {string} token 
 * @returns {boolean} true if valid
 */
function verifyToken(secretBase32, token) {
  const totp = new OTPAuth.TOTP({
    issuer: 'DPI Student Admission',
    algorithm: 'SHA1',
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secretBase32)
  });

  const delta = totp.validate({
    token: token.trim(),
    window: 1
  });

  return delta !== null;
}

module.exports = {
  encrypt,
  decrypt,
  generateSecret,
  generateQRCode,
  verifyToken
};

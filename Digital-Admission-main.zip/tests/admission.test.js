// Set environment variables for testing before importing anything
process.env.NODE_ENV = 'test';
process.env.DB_TYPE = process.env.TEST_DB_TYPE || 'sqlite';
process.env.DB_SQLITE_PATH = './test_admission.sqlite';

const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend/app');
const db = require('../backend/config/db');
const { initDatabase } = require('../backend/services/dbService');

describe('Admission Application API and Security tests', () => {

  beforeAll(async () => {
    await initDatabase();
  });

  beforeEach(async () => {
    await db.query('DELETE FROM users');
    await db.query('DELETE FROM student_profiles');
    await db.query('DELETE FROM admission_applications');
    await db.query('DELETE FROM captchas');
    await db.query('DELETE FROM otps');

    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      try {
        fs.unlinkSync(otpFilePath);
      } catch (err) {
        // Ignored
      }
    }
  });

  afterAll(async () => {
    await db.close();

    const testDbPath = path.resolve(process.cwd(), './test_admission.sqlite');
    if (fs.existsSync(testDbPath)) {
      try {
        fs.unlinkSync(testDbPath);
      } catch (err) {
        // Ignored
      }
    }
  });

  // Helper functions
  async function getValidCaptcha() {
    const res = await request(app).get('/api/auth/captcha');
    const captchaId = res.body.data.captchaId;
    const rows = await db.query('SELECT answer FROM captchas WHERE id = ?', [captchaId]);
    return { captchaId, captchaAnswer: rows[0].answer };
  }

  function readMockOTP() {
    const otpFilePath = path.resolve(process.cwd(), './scratch/mock_otp.txt');
    if (fs.existsSync(otpFilePath)) {
      return fs.readFileSync(otpFilePath, 'utf8').trim();
    }
    return '';
  }

  async function getAuthenticatedUser(email, password, role = 'student', mobile = '9111122222') {
    const cap = await getValidCaptcha();
    const registerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: role === 'student' ? 'Alice Student' : 'Professor Bob',
        email,
        mobile,
        password,
        confirmPassword: password,
        role,
        ...cap
      });

    const loginCap = await getValidCaptcha();
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email,
        password,
        ...loginCap
      });

    const otpCode = readMockOTP();
    const verifyRes = await request(app)
      .post('/api/auth/verify-otp')
      .send({
        otpSessionId: loginRes.body.data.otpSessionId,
        code: otpCode
      });

    return {
      userId: verifyRes.body.data.userId,
      cookie: verifyRes.headers['set-cookie'][0]
    };
  }

  // --- TEST CASES ---

  test('1. Get application returns null for a student who has not started one', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    const res = await request(app)
      .get('/api/admission/my-application')
      .set('Cookie', student.cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeNull();
  });

  test('2. Successfully save draft, query it, and resume progress', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // Save partial draft
    const draftRes = await request(app)
      .post('/api/admission/save-draft')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        currentStep: 1
      });

    expect(draftRes.statusCode).toBe(200);
    expect(draftRes.body.success).toBe(true);
    expect(draftRes.body.data.status).toBe('Draft');
    expect(draftRes.body.data.currentStep).toBe(1);

    // Query it back
    const getRes = await request(app)
      .get('/api/admission/my-application')
      .set('Cookie', student.cookie);

    expect(getRes.statusCode).toBe(200);
    expect(getRes.body.data.dob).toBe('2005-05-15');
    expect(getRes.body.data.gender).toBe('Female');
    expect(getRes.body.data.status).toBe('Draft');
  });

  test('3. Submit application validation checks enforce complete input formats', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    // Submit missing fields
    const resMissing = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female'
      });

    expect(resMissing.statusCode).toBe(400);
    expect(resMissing.body.success).toBe(false);
    expect(resMissing.body.message).toContain('validation failed');

    // Submit invalid formats
    const resFormat = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob',
        address: '123 St',
        state: 'Delhi',
        pincode: '12345',      // wrong pincode
        degree: 'High School',
        board: 'CBSE',
        gradYear: 1899,        // wrong year
        percentage: 105.00     // wrong percent
      });

    expect(resFormat.statusCode).toBe(400);
    expect(resFormat.body.message).toContain('validation error');
  });

  test('4. Successful final submission generates application ID and locks updates', async () => {
    const student = await getAuthenticatedUser('alice@student.com', 'Password@123', 'student', '9111122222');

    const submitRes = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50
      });

    expect(submitRes.statusCode).toBe(200);
    expect(submitRes.body.success).toBe(true);
    expect(submitRes.body.data.status).toBe('Submitted');
    expect(submitRes.body.data.applicationId).toMatch(/^ADM-\d{8}-[0-9A-F]{4}$/);

    // Try to update draft again -> should be blocked!
    const draftRes = await request(app)
      .post('/api/admission/save-draft')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-16'
      });

    expect(draftRes.statusCode).toBe(400);
    expect(draftRes.body.message).toContain('already been submitted');

    // Try to submit again -> should be blocked!
    const submitRes2 = await request(app)
      .post('/api/admission/submit')
      .set('Cookie', student.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Female',
        guardianName: 'Bob Guardian',
        address: '123 Main St',
        state: 'Delhi',
        pincode: '110001',
        degree: 'High School',
        board: 'CBSE',
        gradYear: 2023,
        percentage: 95.50
      });

    expect(submitRes2.statusCode).toBe(400);
    expect(submitRes2.body.message).toContain('already been submitted');
  });

  test('5. IDOR check: Students cannot access other students applications', async () => {
    const studentA = await getAuthenticatedUser('studenta@test.com', 'Password@123', 'student', '9111100001');
    const studentB = await getAuthenticatedUser('studentb@test.com', 'Password@123', 'student', '9111100002');

    // Student A saves draft
    await request(app)
      .post('/api/admission/save-draft')
      .set('Cookie', studentA.cookie)
      .send({
        dob: '2005-05-15',
        gender: 'Male',
        currentStep: 1
      });

    // In Express, getMyApplication queries the user_id directly from the verified session (req.user.userId).
    // Thus studentB calling getMyApplication can ONLY retrieve studentB's own application details,
    // which prevents IDOR by design!
    const res = await request(app)
      .get('/api/admission/my-application')
      .set('Cookie', studentB.cookie);

    expect(res.statusCode).toBe(200);
    expect(res.body.data).toBeNull(); // Student B gets null since they haven't started their own!
  });

});

document.addEventListener('DOMContentLoaded', () => {
  // Navigation tabs
  const navHome = document.getElementById('navHome');
  const navProfile = document.getElementById('navProfile');
  const navApplication = document.getElementById('navApplication');
  const navEkyc = document.getElementById('navEkyc');
  const navDigilocker = document.getElementById('navDigilocker');
  
  const tabHome = document.getElementById('portalHomeTab');
  const tabProfile = document.getElementById('portalProfileTab');
  const tabAdmission = document.getElementById('portalAdmissionTab');
  const tabEkyc = document.getElementById('portalEkycTab');
  const tabDigilocker = document.getElementById('portalDigilockerTab');

  const startApplicationBtn = document.getElementById('startApplicationBtn');

  if (navHome && navProfile && navApplication && navEkyc && navDigilocker) {
    navHome.addEventListener('click', () => {
      navHome.classList.add('active');
      navProfile.classList.remove('active');
      navApplication.classList.remove('active');
      navEkyc.classList.remove('active');
      navDigilocker.classList.remove('active');
      tabHome.style.display = 'block';
      tabProfile.style.display = 'none';
      tabAdmission.style.display = 'none';
      tabEkyc.style.display = 'none';
      tabDigilocker.style.display = 'none';
    });

    navProfile.addEventListener('click', () => {
      navProfile.classList.add('active');
      navHome.classList.remove('active');
      navApplication.classList.remove('active');
      navEkyc.classList.remove('active');
      navDigilocker.classList.remove('active');
      tabProfile.style.display = 'block';
      tabHome.style.display = 'none';
      tabAdmission.style.display = 'none';
      tabEkyc.style.display = 'none';
      tabDigilocker.style.display = 'none';
      if (window.loadProfileView) {
        window.loadProfileView();
      }
    });

    navApplication.addEventListener('click', () => {
      navApplication.classList.add('active');
      navHome.classList.remove('active');
      navProfile.classList.remove('active');
      navEkyc.classList.remove('active');
      navDigilocker.classList.remove('active');
      tabAdmission.style.display = 'block';
      tabHome.style.display = 'none';
      tabProfile.style.display = 'none';
      tabEkyc.style.display = 'none';
      tabDigilocker.style.display = 'none';
      if (window.loadAdmissionWizard) {
        window.loadAdmissionWizard();
      }
    });

    navEkyc.addEventListener('click', () => {
      navEkyc.classList.add('active');
      navHome.classList.remove('active');
      navProfile.classList.remove('active');
      navApplication.classList.remove('active');
      navDigilocker.classList.remove('active');
      tabEkyc.style.display = 'block';
      tabHome.style.display = 'none';
      tabProfile.style.display = 'none';
      tabAdmission.style.display = 'none';
      tabDigilocker.style.display = 'none';
      if (window.loadEkycView) {
        window.loadEkycView();
      }
    });

    navDigilocker.addEventListener('click', () => {
      navDigilocker.classList.add('active');
      navHome.classList.remove('active');
      navProfile.classList.remove('active');
      navApplication.classList.remove('active');
      navEkyc.classList.remove('active');
      tabDigilocker.style.display = 'block';
      tabHome.style.display = 'none';
      tabProfile.style.display = 'none';
      tabAdmission.style.display = 'none';
      tabEkyc.style.display = 'none';
      if (window.loadDigilockerView) {
        window.loadDigilockerView();
      }
    });
  }

  // Dashboard shortcut trigger redirecting to the wizard
  if (startApplicationBtn && navApplication) {
    startApplicationBtn.addEventListener('click', () => {
      navApplication.click();
    });
  }

  // Hook up Professor list filters
  const searchInput = document.getElementById('studentSearchInput');
  const statusFilter = document.getElementById('statusFilter');

  if (searchInput) {
    let searchDebounce = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(() => {
        loadProfessorDashboard();
      }, 300);
    });
  }

  if (statusFilter) {
    statusFilter.addEventListener('change', () => {
      loadProfessorDashboard();
    });
  }

  const refreshAuditBtn = document.getElementById('refreshAuditLogsBtn');
  if (refreshAuditBtn) {
    refreshAuditBtn.addEventListener('click', () => {
      loadSystemAuditLogs();
    });
  }

  const refreshAdminUsersBtn = document.getElementById('refreshAdminUsersBtn');
  if (refreshAdminUsersBtn) {
    refreshAdminUsersBtn.addEventListener('click', () => {
      loadAdminDashboard();
    });
  }

  const refreshAdminAuditLogsBtn = document.getElementById('refreshAdminAuditLogsBtn');
  if (refreshAdminAuditLogsBtn) {
    refreshAdminAuditLogsBtn.addEventListener('click', () => {
      loadAdminAuditLogs();
    });
  }

  // Display Notification helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Fetch and render notifications
  async function loadNotifications() {
    try {
      const response = await fetch('/api/notifications');
      const result = await response.json();

      if (response.ok && result.success) {
        const { notifications, unreadCount } = result.data;

        // Update Badge Count
        const countBadge = document.getElementById('notificationCountBadge');
        if (countBadge) {
          countBadge.textContent = unreadCount;
          countBadge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
        }

        // Update Mark All Read button visibility
        const markAllBtn = document.getElementById('markAllNotificationsReadBtn');
        if (markAllBtn) {
          markAllBtn.style.display = unreadCount > 0 ? 'inline-block' : 'none';
        }

        // Render List
        const notifList = document.getElementById('studentNotificationsList');
        if (!notifList) return;
        notifList.innerHTML = '';

        if (notifications.length === 0) {
          const empty = document.createElement('div');
          empty.className = 'completion-desc';
          empty.style.textAlign = 'center';
          empty.style.padding = '20px';
          empty.textContent = 'No notifications found.';
          notifList.appendChild(empty);
          return;
        }

        notifications.forEach(n => {
          const item = document.createElement('div');
          item.className = `notification-item ${n.isRead ? 'read' : 'unread'} ${n.type || 'info'}`;

          const header = document.createElement('div');
          header.className = 'notification-item-header';

          const leftSection = document.createElement('div');
          leftSection.className = 'notification-header-left';

          const titleSpan = document.createElement('span');
          titleSpan.className = 'notification-item-title';
          titleSpan.textContent = n.title;

          const typeBadge = document.createElement('span');
          typeBadge.className = 'notification-type-badge';
          typeBadge.textContent = n.type || 'info';

          leftSection.appendChild(titleSpan);
          leftSection.appendChild(typeBadge);

          const rightSection = document.createElement('div');
          rightSection.className = 'notification-header-right';

          const dateSpan = document.createElement('span');
          dateSpan.className = 'notification-item-date';
          dateSpan.textContent = new Date(n.createdAt).toLocaleDateString(undefined, {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          });

          const actionBtn = document.createElement('button');
          actionBtn.type = 'button';
          actionBtn.className = 'btn-notif-action';
          actionBtn.textContent = n.isRead ? 'Mark Unread' : 'Mark Read';
          actionBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const actionPath = n.isRead ? 'unread' : 'read';
            try {
              const res = await fetch(`/api/notifications/${n.id}/${actionPath}`, { method: 'POST' });
              const resJson = await res.json();
              if (res.ok && resJson.success) {
                showNotification('Success', `Notification marked as ${n.isRead ? 'unread' : 'read'}.`, 'success');
                loadNotifications();
              }
            } catch (err) {
              console.error(err);
            }
          });

          rightSection.appendChild(dateSpan);
          rightSection.appendChild(actionBtn);

          header.appendChild(leftSection);
          header.appendChild(rightSection);

          const contentDiv = document.createElement('div');
          contentDiv.className = 'notification-item-content';
          contentDiv.textContent = n.content;

          item.appendChild(header);
          item.appendChild(contentDiv);
          notifList.appendChild(item);
        });
      }
    } catch (err) {
      console.error('Failed to load notifications:', err);
    }
  }

  // Hook up mark all notifications as read button listener
  const markAllNotifBtn = document.getElementById('markAllNotificationsReadBtn');
  if (markAllNotifBtn) {
    markAllNotifBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        const res = await fetch('/api/notifications/read-all', { method: 'POST' });
        const resJson = await res.json();
        if (res.ok && resJson.success) {
          showNotification('Success', 'All notifications marked as read.', 'success');
          loadNotifications();
        }
      } catch (err) {
        console.error(err);
      }
    });
  }

  // 1. Fetch Student Dashboard
  async function loadStudentDashboard() {
    try {
      const response = await fetch('/api/dashboard/student');
      const result = await response.json();

      if (response.ok && result.success) {
        const data = result.data;
        
        const appState = data.widgets.admissionApplication;
        const ekycVerified = data.widgets.ekycStatus === 'Verified' || data.widgets.ekycStatus === 'VERIFIED';
        const dlConnected = data.widgets.digilockerStatus === 'Connected';
        const signed = data.widgets.signatureStatus === 'Signed';
        const appComplete = appState === 'Approved' || appState === 'Rejected';

        // Update Widgets text & styles
        const widgetApp = document.getElementById('widgetApplication');
        if (widgetApp) {
          widgetApp.textContent = appState;
          widgetApp.className = 'badge';
          if (appState === 'Approved') widgetApp.classList.add('badge-success');
          else if (appState === 'Rejected') widgetApp.classList.add('badge-danger');
          else if (appState === 'Draft') widgetApp.classList.add('badge-warning');
          else widgetApp.classList.add('badge-pending');
        }

        const widgetEkycContainer = document.getElementById('widgetEkyc') ? document.getElementById('widgetEkyc').parentElement : null;
        if (widgetEkycContainer) {
          widgetEkycContainer.innerHTML = '';
          const status = data.widgets.ekycStatus;
          
          const badge = document.createElement('span');
          badge.className = 'badge';
          badge.id = 'widgetEkyc';
          badge.textContent = status;
          
          if (ekycVerified) {
            badge.classList.add('badge-success');
            widgetEkycContainer.appendChild(badge);
            
            const checkText = document.createElement('span');
            checkText.style.fontSize = '12px';
            checkText.style.color = 'var(--success)';
            checkText.style.marginLeft = '8px';
            checkText.style.fontWeight = '600';
            checkText.textContent = '✓ Identity Verified';
            widgetEkycContainer.appendChild(checkText);
          } else if (status === 'Failed' || status === 'FAILED') {
            badge.classList.add('badge-danger');
            widgetEkycContainer.appendChild(badge);
            
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-table-action';
            btn.style.marginLeft = '8px';
            btn.style.padding = '3px 8px';
            btn.style.fontSize = '11px';
            btn.textContent = 'Retry eKYC';
            btn.addEventListener('click', () => {
              const navEkyc = document.getElementById('navEkyc');
              if (navEkyc) navEkyc.click();
            });
            widgetEkycContainer.appendChild(btn);
          } else {
            badge.classList.add('badge-warning');
            widgetEkycContainer.appendChild(badge);
            
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-table-action';
            btn.style.marginLeft = '8px';
            btn.style.padding = '3px 8px';
            btn.style.fontSize = '11px';
            btn.textContent = 'Complete eKYC';
            btn.addEventListener('click', () => {
              const navEkyc = document.getElementById('navEkyc');
              if (navEkyc) navEkyc.click();
            });
            widgetEkycContainer.appendChild(btn);
          }
        }

        const widgetDlContainer = document.getElementById('widgetDigilocker') ? document.getElementById('widgetDigilocker').parentElement : null;
        if (widgetDlContainer) {
          widgetDlContainer.innerHTML = '';
          const status = data.widgets.digilockerStatus;
          
          const badge = document.createElement('span');
          badge.className = 'badge';
          badge.id = 'widgetDigilocker';
          badge.textContent = status;
          
          if (dlConnected) {
            badge.classList.add('badge-success');
            widgetDlContainer.appendChild(badge);
            
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-table-action';
            btn.style.marginLeft = '8px';
            btn.style.padding = '3px 8px';
            btn.style.fontSize = '11px';
            btn.textContent = 'View Locker';
            btn.addEventListener('click', () => {
              const navDigilocker = document.getElementById('navDigilocker');
              if (navDigilocker) navDigilocker.click();
            });
            widgetDlContainer.appendChild(btn);
          } else {
            badge.classList.add('badge-warning');
            widgetDlContainer.appendChild(badge);
            
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-table-action';
            btn.style.marginLeft = '8px';
            btn.style.padding = '3px 8px';
            btn.style.fontSize = '11px';
            btn.textContent = 'Connect DigiLocker';
            btn.addEventListener('click', () => {
              const navDigilocker = document.getElementById('navDigilocker');
              if (navDigilocker) navDigilocker.click();
            });
            widgetDlContainer.appendChild(btn);
          }
        }

        const widgetSig = document.getElementById('widgetSignature');
        if (widgetSig) {
          widgetSig.textContent = data.widgets.signatureStatus;
          widgetSig.className = 'badge';
          if (signed) widgetSig.classList.add('badge-success');
          else widgetSig.classList.add('badge-pending');
        }

        // Stepper Progress
        const step2 = document.getElementById('step2');
        const connector1 = document.getElementById('connector1');
        updateStepElement(step2, connector1, ekycVerified, '2');

        const step3 = document.getElementById('step3');
        const connector2 = document.getElementById('connector2');
        updateStepElement(step3, connector2, ekycVerified && dlConnected, '3');

        const step4 = document.getElementById('step4');
        const connector3 = document.getElementById('connector3');
        updateStepElement(step4, connector3, signed, '4');

        const step5 = document.getElementById('step5');
        const connector4 = document.getElementById('connector4');
        updateStepElement(step5, connector4, appComplete, '5');

        function updateStepElement(stepEl, connEl, isComplete, labelText) {
          if (!stepEl) return;
          const circleEl = stepEl.querySelector('.step-circle');
          if (isComplete) {
            stepEl.classList.add('complete');
            stepEl.classList.remove('pending');
            if (circleEl) circleEl.textContent = '✓';
            if (connEl) {
              connEl.classList.add('complete');
              connEl.classList.remove('pending');
            }
          } else {
            stepEl.classList.add('pending');
            stepEl.classList.remove('complete');
            if (circleEl) circleEl.textContent = labelText;
            if (connEl) {
              connEl.classList.add('pending');
              connEl.classList.remove('complete');
            }
          }
        }

        // Correction Message Alert Banner
        const correctionBanner = document.getElementById('correctionBanner');
        const correctionMsgText = document.getElementById('correctionMsgText');
        if (correctionBanner && correctionMsgText) {
          if (appState === 'Draft' && data.widgets.correctionMessage) {
            correctionMsgText.textContent = data.widgets.correctionMessage;
            correctionBanner.style.display = 'block';
          } else {
            correctionBanner.style.display = 'none';
          }
        }

        // eSign Panel (Module 11)
        const esignPanel = document.getElementById('esignPanel');
        const esignPendingSection = document.getElementById('esignPendingSection');
        const esignSignedSection = document.getElementById('esignSignedSection');
        const esignDevBanner = document.getElementById('esignDevBanner');

        if (esignPanel) {
          if (appState === 'PENDING_SIGNATURE') {
            esignPanel.style.display = 'block';
            if (esignPendingSection) esignPendingSection.style.display = 'flex';
            if (esignSignedSection) esignSignedSection.style.display = 'none';

            // Check signature provider mode
            try {
              fetch('/api/emsigner/status')
                .then(r => r.json())
                .then(res => {
                  if (res.success && res.data) {
                    if (esignDevBanner) {
                      esignDevBanner.style.display = res.data.development_mode ? 'flex' : 'none';
                    }
                    const badge = document.getElementById('esignProviderBadge');
                    if (badge) {
                      badge.textContent = res.data.development_mode ? '🔐 Provider: eSignzy (Mock)' : '🔐 Provider: eSignzy (Production)';
                    }
                  }
                }).catch(e => console.error('Emsigner status fetch error:', e));
            } catch (err) {
              console.error(err);
            }
          } else if (signed) {
            esignPanel.style.display = 'block';
            if (esignPendingSection) esignPendingSection.style.display = 'none';
            if (esignSignedSection) esignSignedSection.style.display = 'block';

            // Fetch and populate signature details
            try {
              fetch('/api/emsigner/status')
                .then(r => r.json())
                .then(res => {
                  if (res.success && res.data) {
                    const requestIdEl = document.getElementById('esignRequestId');
                    const docUriEl = document.getElementById('esignDocUri');
                    const signedAtEl = document.getElementById('esignSignedAt');

                    if (requestIdEl) requestIdEl.textContent = res.data.sign_request_id || '—';
                    if (docUriEl) docUriEl.textContent = res.data.signed_doc_uri || '—';
                    if (signedAtEl) {
                      const ts = res.data.signed_at;
                      signedAtEl.textContent = ts ? new Date(ts).toLocaleString() : '—';
                    }
                    if (esignDevBanner) {
                      esignDevBanner.style.display = res.data.development_mode ? 'flex' : 'none';
                    }
                  }
                }).catch(e => console.error('Emsigner status fetch error:', e));
            } catch (err) {
              console.error(err);
            }
          } else {
            esignPanel.style.display = 'none';
          }
        }

        // Render Notifications list
        loadNotifications();

      } else {
        console.error('Failed to load student data:', result.message);
      }
    } catch (err) {
      console.error('Student fetch error:', err);
    }
  }

  // 2. Fetch Professor Dashboard
  async function loadProfessorDashboard() {
    const searchVal = searchInput ? searchInput.value : '';
    const statusVal = statusFilter ? statusFilter.value : 'all';

    const tableBody = document.getElementById('applicationsTableBody');
    const loader = document.getElementById('tableLoader');
    const emptyState = document.getElementById('tableEmptyState');

    if (loader) loader.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
    if (tableBody) tableBody.innerHTML = '';

    try {
      const response = await fetch(`/api/dashboard/professor?search=${encodeURIComponent(searchVal)}&status=${encodeURIComponent(statusVal)}`);
      const result = await response.json();

      if (loader) loader.style.display = 'none';

      if (response.ok && result.success) {
        const data = result.data;

        // Update Stats Counters
        document.getElementById('statTotalStudents').textContent = data.stats.total;
        document.getElementById('statPendingReviews').textContent = data.stats.pending;
        document.getElementById('statApprovedReviews').textContent = data.stats.approved;
        const rejectCard = document.getElementById('statRejectedReviews');
        if (rejectCard) rejectCard.textContent = data.stats.rejected;

        // Render Student Application table rows
        if (data.applications.length === 0) {
          if (emptyState) emptyState.style.display = 'flex';
          return;
        }

        data.applications.forEach(app => {
          const tr = document.createElement('tr');
          
          const ekycBadge = app.ekycStatus === 'Verified' ? 'badge-success' : 'badge-pending';
          const signBadge = app.signatureStatus === 'Signed' ? 'badge-success' : 'badge-pending';
          const appBadge = app.applicationStatus === 'Approved' ? 'badge-success' : 'badge-pending';

          tr.innerHTML = `
            <td>
              <div class="student-info-col">
                <span class="student-info-name">${app.name}</span>
                <span class="student-info-email">${app.email}</span>
              </div>
            </td>
            <td><span class="badge ${ekycBadge}">${app.ekycStatus}</span></td>
            <td>${app.documentStatus}</td>
            <td><span class="badge ${signBadge}">${app.signatureStatus}</span></td>
            <td><span class="badge ${appBadge}">${app.applicationStatus}</span></td>
            <td style="text-align: right;">
              <button type="button" class="btn-table-action" data-id="${app.id}">Verify</button>
            </td>
          `;

          // Hook verify button click trigger
          tr.querySelector('.btn-table-action').addEventListener('click', (e) => {
            e.preventDefault();
            if (typeof window.openProfessorReviewModal === 'function') {
              window.openProfessorReviewModal(app);
            } else {
              showNotification('Interface Error', 'Workflow review modal module not loaded.', 'error');
            }
          });

          tableBody.appendChild(tr);
        });

      } else {
        console.error('Failed to load professor data:', result.message);
      }
    } catch (err) {
      if (loader) loader.style.display = 'none';
      console.error('Professor fetch error:', err);
    }
  }

  /**
   * Fetch and render system audit logs for Academic Staff (Professor)
   */
  async function loadSystemAuditLogs() {
    const tableBody = document.getElementById('auditLogsTableBody');
    const loader = document.getElementById('auditLogsLoader');
    const emptyState = document.getElementById('auditLogsEmptyState');

    if (loader) loader.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
    if (tableBody) tableBody.innerHTML = '';

    try {
      const response = await fetch('/api/audit-logs');
      const result = await response.json();

      if (loader) loader.style.display = 'none';

      if (response.ok && result.success) {
        const logs = result.data;

        if (!logs || logs.length === 0) {
          if (emptyState) emptyState.style.display = 'flex';
          return;
        }

        logs.forEach(log => {
          const tr = document.createElement('tr');
          
          const dateStr = new Date(log.createdAt).toLocaleString();
          const statusClass = log.status === 'success' ? 'badge-success' : 'badge-pending';
          
          let detailsText = '';
          if (log.metadata) {
            detailsText = Object.entries(log.metadata)
              .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`)
              .join(', ');
          }

          tr.innerHTML = `
            <td>
              <div style="font-weight: 500;">${dateStr}</div>
              <div style="font-size: 11px; color: var(--text-muted);">${log.ipAddress || '127.0.0.1'}</div>
            </td>
            <td>
              ${log.userId 
                ? `<span class="badge" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: var(--text-default);">${log.userId}</span>` 
                : '<span style="color: var(--text-muted); font-style: italic;">Anon</span>'}
            </td>
            <td><strong style="text-transform: capitalize; color: #60a5fa;">${log.action.replace(/_/g, ' ')}</strong></td>
            <td>
              ${log.entityType ? `<span class="badge" style="font-size: 10px; background: rgba(59,130,246,0.15); border-color: rgba(59,130,246,0.3); color: #60a5fa;">${log.entityType.toUpperCase()}</span>` : ''}
              ${log.entityId ? `<span style="font-size: 11px; font-family: monospace; display: block; margin-top: 2px;">ID: ${log.entityId}</span>` : ''}
            </td>
            <td><span class="badge ${statusClass}">${log.status.toUpperCase()}</span></td>
            <td style="text-align: right; font-size: 12px; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escapeHtml(detailsText)}">
              ${escapeHtml(detailsText) || '<span style="color: var(--text-muted); font-style: italic;">None</span>'}
            </td>
          `;
          if (tableBody) tableBody.appendChild(tr);
        });

      } else {
        console.error('Failed to load system audit logs:', result.message);
      }
    } catch (err) {
      if (loader) loader.style.display = 'none';
      console.error('Audit logs fetch error:', err);
    }
  }

  // Fetch and render admin dashboard data (user counts, users table)
  async function loadAdminDashboard() {
    const tableBody = document.getElementById('adminUsersTableBody');
    const loader = document.getElementById('adminUsersLoader');
    const emptyState = document.getElementById('adminUsersEmptyState');

    if (loader) loader.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
    if (tableBody) tableBody.innerHTML = '';

    try {
      const response = await fetch('/api/dashboard/admin');
      const result = await response.json();

      if (loader) loader.style.display = 'none';

      if (response.ok && result.success) {
        const { stats, users } = result.data;

        // Update Stats cards
        document.getElementById('adminStatTotalUsers').textContent = stats.total || 0;
        document.getElementById('adminStatTotalStudents').textContent = stats.student || 0;
        document.getElementById('adminStatTotalProfessors').textContent = stats.professor || 0;
        document.getElementById('adminStatTotalAdmins').textContent = stats.admin || 0;

        if (!users || users.length === 0) {
          if (emptyState) emptyState.style.display = 'flex';
          return;
        }

        // Render User Rows
        users.forEach(user => {
          const tr = document.createElement('tr');
          const roleBadgeClass = user.role === 'admin' ? 'badge-danger' : (user.role === 'professor' ? 'badge-success' : 'badge-pending');
          const statusBadgeClass = user.status === 'active' ? 'badge-success' : 'badge-pending';
          const regDate = new Date(user.createdAt).toLocaleDateString();

          tr.innerHTML = `
            <td>
              <div class="student-info-col">
                <span class="student-info-name">${escapeHtml(user.name)}</span>
                <span class="student-info-email">${escapeHtml(user.email)}</span>
              </div>
            </td>
            <td><span style="font-family: monospace;">${escapeHtml(user.mobile)}</span></td>
            <td><span class="badge ${roleBadgeClass}">${user.role.toUpperCase()}</span></td>
            <td><span class="badge ${statusBadgeClass}">${user.status.toUpperCase()}</span></td>
            <td style="text-align: right; font-size: 13px;">${regDate}</td>
          `;
          tableBody.appendChild(tr);
        });

        // Also fetch and load audit logs for admin
        await loadAdminAuditLogs();

      } else {
        showNotification('Sync Failed', result.message || 'Failed to fetch admin statistics', 'error');
      }
    } catch (err) {
      if (loader) loader.style.display = 'none';
      console.error('Admin dashboard fetch error:', err);
    }
  }

  // Fetch and render system audit logs in the admin dashboard view
  async function loadAdminAuditLogs() {
    const tableBody = document.getElementById('adminAuditLogsTableBody');
    const loader = document.getElementById('adminAuditLogsLoader');
    const emptyState = document.getElementById('adminAuditLogsEmptyState');

    if (loader) loader.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
    if (tableBody) tableBody.innerHTML = '';

    try {
      const response = await fetch('/api/audit-logs');
      const result = await response.json();

      if (loader) loader.style.display = 'none';

      if (response.ok && result.success) {
        const logs = result.data;

        if (!logs || logs.length === 0) {
          if (emptyState) emptyState.style.display = 'flex';
          return;
        }

        logs.forEach(log => {
          const tr = document.createElement('tr');
          const dateStr = new Date(log.createdAt).toLocaleString();
          const statusClass = log.status === 'success' ? 'badge-success' : 'badge-pending';
          
          let detailsText = '';
          if (log.metadata) {
            detailsText = Object.entries(log.metadata)
              .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`)
              .join(', ');
          }

          tr.innerHTML = `
            <td>
              <div style="font-weight: 500;">${dateStr}</div>
              <div style="font-size: 11px; color: var(--text-muted);">${log.ipAddress || '127.0.0.1'}</div>
            </td>
            <td>
              ${log.userId 
                ? `<span class="badge" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: var(--text-default);">${log.userId}</span>` 
                : '<span style="color: var(--text-muted); font-style: italic;">Anon</span>'}
            </td>
            <td><strong style="text-transform: capitalize; color: #60a5fa;">${log.action.replace(/_/g, ' ')}</strong></td>
            <td>
              ${log.entityType ? `<span class="badge" style="font-size: 10px; background: rgba(59,130,246,0.15); border-color: rgba(59,130,246,0.3); color: #60a5fa;">${log.entityType.toUpperCase()}</span>` : ''}
              ${log.entityId ? `<span style="font-size: 11px; font-family: monospace; display: block; margin-top: 2px;">ID: ${log.entityId}</span>` : ''}
            </td>
            <td><span class="badge ${statusClass}">${log.status.toUpperCase()}</span></td>
            <td style="text-align: right; font-size: 12px; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escapeHtml(detailsText)}">
              ${escapeHtml(detailsText) || '<span style="color: var(--text-muted); font-style: italic;">None</span>'}
            </td>
          `;
          tableBody.appendChild(tr);
        });

      } else {
        console.error('Failed to load admin audit logs:', result.message);
      }
    } catch (err) {
      if (loader) loader.style.display = 'none';
      console.error('Admin audit logs fetch error:', err);
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // 3. Central Dashboard views switcher
  async function initDashboardView() {
    // Reset view selectors
    if (navHome && navProfile && navApplication && navEkyc && navDigilocker) {
      navHome.classList.add('active');
      navProfile.classList.remove('active');
      navApplication.classList.remove('active');
      navEkyc.classList.remove('active');
      navDigilocker.classList.remove('active');
      tabHome.style.display = 'block';
      tabProfile.style.display = 'none';
      tabAdmission.style.display = 'none';
      tabEkyc.style.display = 'none';
      tabDigilocker.style.display = 'none';
    }

    try {
      const response = await fetch('/api/auth/me');
      const result = await response.json();

      if (response.ok && result.success) {
        const user = result.data.user;

        // Set Topbar Header Details
        if (user.role === 'admin') {
          document.getElementById('portalHeaderTitle').textContent = 'System Administration Panel';
        } else if (user.role === 'professor') {
          document.getElementById('portalHeaderTitle').textContent = 'Professor Verification Panel';
        } else {
          document.getElementById('portalHeaderTitle').textContent = 'Student Enrollment Portal';
        }
        document.getElementById('portalHeaderSubtitle').textContent = `Logged in: ${user.email} (Secure Session)`;

        // Set Profile summary Details
        const nameEl = document.getElementById('profileNameDetails');
        const emailEl = document.getElementById('profileEmailDetails');
        const mobileEl = document.getElementById('profileMobileDetails');
        const roleEl = document.getElementById('profileRoleDetails');
        if (nameEl) nameEl.textContent = user.name;
        if (emailEl) emailEl.textContent = user.email;
        if (mobileEl) mobileEl.textContent = user.mobile;
        if (roleEl) roleEl.textContent = user.role;

        // Set Sidebar badge Details
        document.getElementById('userFooterName').textContent = user.name;
        document.getElementById('userFooterRole').textContent = user.role;
        
        // Avatar initials (e.g. "John Doe" -> "JD")
        const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        document.getElementById('userInitials').textContent = initials || 'U';

        // Swap Layout displays depending on user roles
        const studentWrapper = document.getElementById('studentDashboardWrapper');
        const professorWrapper = document.getElementById('professorDashboardWrapper');
        const adminWrapper = document.getElementById('adminDashboardWrapper');

        if (user.role === 'professor') {
          studentWrapper.style.display = 'none';
          if (adminWrapper) adminWrapper.style.display = 'none';
          professorWrapper.style.display = 'block';
          await loadProfessorDashboard();
          await loadSystemAuditLogs();
        } else if (user.role === 'admin') {
          studentWrapper.style.display = 'none';
          professorWrapper.style.display = 'none';
          if (adminWrapper) {
            adminWrapper.style.display = 'block';
            await loadAdminDashboard();
          }
        } else {
          professorWrapper.style.display = 'none';
          if (adminWrapper) adminWrapper.style.display = 'none';
          studentWrapper.style.display = 'block';
          await loadStudentDashboard();
        }

      } else {
        window.location.hash = '#/login-student';
      }
    } catch (err) {
      console.error('Error during dashboard load:', err);
      window.location.hash = '#/login-student';
    }
  }

  // Expose global initializer
  window.initDashboardView = initDashboardView;
  window.loadProfessorDashboard = loadProfessorDashboard;
});

# DigiLocker Integration Subsystem

This document describes the design, authorization flow, security validation, database schema, and verification of the **DigiLocker** integration module in the **Digital Student Admission System**.

---

## 1. Overview
DigiLocker is a core national digital public infrastructure that provides citizens access to authentic digital documents from their original issuers. In this portal, DigiLocker is used to retrieve, verify, and select qualifying academic transcripts (e.g., Class X and Class XII Marksheets) for admission applications.

---

## 2. Secure Authorization Flow (OAuth & CSRF Prevention)
To ensure a modern, secure, and seamless user experience, the DigiLocker connection process is handled via a secure popup interface:

```
+------------------+                   +--------------------+
|  Student Portal  |                   | DigiLocker Gateway |
+------------------+                   +--------------------+
         |                                       |
         |----- 1. Open Auth Popup (state) ----->|
         |                                       | (User Consents & Logs In)
         |                                       |
         |<---- 2. postMessage (Auth Status) ----|
         |
  (Popup Closes)
```

### CSRF Protection using State Tokens
1. The portal initiates connection by calling `GET /api/digilocker/oauth/authorize`.
2. The backend generates a cryptographically secure random `oauth_state` token and stores it in a secure, transient, HTTP-Only cookie.
3. The mock/real gateway returns the state parameter in the authorization code callback.
4. The backend verifies the returned state against the `oauth_state` cookie. Upon matching, the callback completes, and the cookie is cleared to prevent replay/CSRF attacks.

### Communication Protocol
* After authentication and authorization, the popup transmits the result back to the parent browser window using the HTML5 **PostMessage API**:
  ```javascript
  window.opener.postMessage({ type: 'DIGILOCKER_AUTH_SUCCESS' }, '*');
  window.close();
  ```
* This protocol prevents cross-origin scripting errors while keeping the user context on the main portal page active.

---

## 3. Security Safeguards

### Name Verification Security Check
To prevent identity spoofing (e.g., a student linking someone else's DigiLocker profile to their application), the backend performs a strict name-matching check upon receiving a document retrieval request:
* The name on the retrieved document is compared against the name registered in the student's profile.
* If the names diverge significantly, the connection is rejected with a `400 Bad Request` mismatch error, the document's verification status is set to `Failed`, and an audit event is logged.

### Explicit Document Access Consent
* The portal blocks document catalog retrieval and document download requests unless the student has granted explicit consent.
* Consents are recorded in `digilocker_consents` table.
* Revoking consent immediately deletes all linked documents from the database.

### Full Disconnection
* Students can disconnect their locker at any time.
* Disconnecting wipes all credentials (tokens), deletes all linked documents, and revokes all active consents in the database.

---

## 4. Linked Documents Database Schema
Connected data is written to three tables:

1. `digilocker_connections`: Tracks access tokens and token expiration epochs (`token_expires_at`) per user.
2. `digilocker_documents`: Tracks each linked document type, its unique identifier reference (`doc_uri`), issuing authority, retrieved timestamp, verification status (`Verified`/`Failed`), and selection status (`AVAILABLE`/`SELECTED`).
3. `digilocker_consents`: Logs the history of student consents, purpose, scope, status (`GRANTED`/`REVOKED`), consent timestamp, and revocation timestamp.

---

## 5. REST API Endpoints

### 1. GET `/api/digilocker/status`
Returns connection status, active consent state, development mode status, and linked documents list.
* **Security:** Requires valid JWT authentication cookie.

### 2. GET `/api/digilocker/oauth/authorize`
Generates CSRF state cookie and redirects to DigiLocker gateway.

### 3. POST `/api/digilocker/oauth/callback`
Exchanges code for tokens, validates state against cookie, and records connection.

### 4. POST `/api/digilocker/consent`
Grants (`consent: true`) or revokes (`consent: false`) document access consent.

### 5. POST `/api/digilocker/disconnect`
Terminates connection, deletes tokens, deletes documents, and revokes consents.

### 6. GET `/api/digilocker/documents`
Lists available documents in the locker. Requires active consent.

### 7. POST `/api/digilocker/documents/retrieve`
Links and verifies a specific document by its URI. Requires active consent.

### 8. POST `/api/digilocker/documents/select`
Selects/associates a verified document (`SELECTED` or `AVAILABLE`) with the admission application.

---

## 6. Audit Trail Logging
All critical activities log actions in the `audit_logs` table:
* `DIGILOCKER_CONNECT_STARTED`: When the OAuth authorization popup is opened.
* `DIGILOCKER_CONNECTED`: Connection completed successfully.
* `DIGILOCKER_DISCONNECTED`: Connection terminated.
* `DIGILOCKER_CONSENT_GRANTED`: Consent given.
* `DIGILOCKER_CONSENT_REVOKED`: Consent revoked.
* `DIGILOCKER_DOCUMENT_REQUESTED`: Document retrieve requested.
* `DIGILOCKER_DOCUMENT_RECEIVED`: Document data downloaded.
* `DIGILOCKER_DOCUMENT_VERIFIED`: Document name matching verification succeeded.
* `DIGILOCKER_DOCUMENT_SELECTED`: Document selected for admission.
* `DIGILOCKER_DOCUMENT_DESELECTED`: Document deselected from admission.
* `DIGILOCKER_ERROR`: Any failures or CSRF mismatches.

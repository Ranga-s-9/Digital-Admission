const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function run() {
  const args = process.argv.slice(2);
  const rollbackAll = args.includes('--all');

  console.log(`Starting database rollback (mode: ${rollbackAll ? 'ALL' : 'SINGLE LAST'})...`);

  if (process.env.DB_TYPE !== 'mysql') {
    console.log('Skipping rollback: DB_TYPE is not set to mysql.');
    return;
  }

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'dpi_student_admission',
    multipleStatements: true
  });

  try {
    // 1. Fetch applied migrations in reverse order
    const [rows] = await connection.query('SELECT filename FROM schema_migrations ORDER BY id DESC');
    if (rows.length === 0) {
      console.log('No migrations found to rollback.');
      return;
    }

    const migrationsToRollback = rollbackAll ? rows : [rows[0]];

    for (const migration of migrationsToRollback) {
      const filename = migration.filename;
      const match = filename.match(/^(\d+)_/);
      if (!match) {
        console.warn(`Skipping invalid migration format: ${filename}`);
        continue;
      }

      const numStr = match[1];
      const rollbackFile = `${numStr}_rollback.sql`;
      const rollbackPath = path.join(__dirname, 'rollback', rollbackFile);

      if (!fs.existsSync(rollbackPath)) {
        throw new Error(`Rollback script not found for migration ${filename} (expected ${rollbackPath})`);
      }

      console.log(`Rolling back migration ${filename} using ${rollbackFile}...`);
      const sql = fs.readFileSync(rollbackPath, 'utf8');

      // Remove from migrations table FIRST (so it works even if rollback SQL drops the schema_migrations table itself)
      await connection.query('DELETE FROM schema_migrations WHERE filename = ?', [filename]);

      // Execute rollback script
      await connection.query(sql);
      
      console.log(`Successfully rolled back ${filename}`);
    }

    console.log(`Rollback completed successfully.`);
  } catch (error) {
    console.error('Rollback failed:', error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

run();

/**
 * Returns a consistent JSON 404 for any /api/* route that doesn't match
 * a registered endpoint, instead of silently falling through to the SPA's
 * catch-all HTML route (which would otherwise return 200 with index.html
 * for a mistyped or unsupported API call).
 */
function apiNotFoundHandler(req, res) {
  return res.status(404).json({
    success: false,
    message: 'API endpoint not found',
    error: { global: `No route matches ${req.method} ${req.originalUrl}` },
    requestId: req.id || null
  });
}

module.exports = apiNotFoundHandler;

document.addEventListener('DOMContentLoaded', () => {
  const admissionForm = document.getElementById('admissionForm');
  const backBtn = document.getElementById('wizardBackBtn');
  const saveDraftBtn = document.getElementById('wizardSaveDraftBtn');
  const continueBtn = document.getElementById('wizardContinueBtn');
  const continueSpinner = document.getElementById('wizardContinueSpinner');
  const continueText = document.getElementById('wizardContinueText');
  const confirmModal = document.getElementById('applicationConfirmModal');
  const confirmSubmitBtn = document.getElementById('modalConfirmSubmitBtn');

  // Stepper Elements
  const steps = [
    { el: document.getElementById('adStep1'), conn: null },
    { el: document.getElementById('adStep2'), conn: document.getElementById('adConn1') },
    { el: document.getElementById('adStep3'), conn: document.getElementById('adConn2') },
    { el: document.getElementById('adStep4'), conn: document.getElementById('adConn3') }
  ];

  // Wizard Panel Elements
  const panels = [
    document.getElementById('panelPersonal'),
    document.getElementById('panelAcademic'),
    document.getElementById('panelReview'),
    document.getElementById('panelSubmit')
  ];

  // Personal inputs
  const nameInput = document.getElementById('adName');
  const dobInput = document.getElementById('adDob');
  const genderSelect = document.getElementById('adGender');
  const guardianInput = document.getElementById('adGuardianName');
  const emailInput = document.getElementById('adEmail');
  const mobileInput = document.getElementById('adMobile');
  const addressInput = document.getElementById('adAddress');
  const stateInput = document.getElementById('adState');
  const pincodeInput = document.getElementById('adPincode');

  // Academic inputs
  const degreeInput = document.getElementById('adDegree');
  const boardInput = document.getElementById('adBoard');
  const gradYearInput = document.getElementById('adGradYear');
  const percentageInput = document.getElementById('adPercentage');

  // Submission elements
  const agreeCheckbox = document.getElementById('declarationAgreeCheckbox');

  // Active state variables
  let currentStep = 1; // 1-indexed (1 to 4)
  let isApplicationLocked = false;

  // Notification Helper
  const showNotification = (title, message, type = 'success') => {
    const notify = document.getElementById('notificationBox');
    const notifyTitle = document.getElementById('notificationTitle');
    const notifyDesc = document.getElementById('notificationDesc');
    const notifyIcon = document.getElementById('notificationIcon');

    if (!notify) return;

    notify.className = `notification show ${type}`;
    notifyTitle.textContent = title;
    notifyDesc.textContent = message;

    if (type === 'success') {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      `;
    } else {
      notifyIcon.innerHTML = `
        <svg viewBox="0 0 24 24" width="24" height="24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
      `;
    }

    setTimeout(() => {
      notify.classList.remove('show');
    }, 5000);
  };

  // Pre-populate review dashboard grid
  function populateReviewPanel() {
    document.getElementById('revName').textContent = nameInput.value || '-';
    document.getElementById('revDob').textContent = dobInput.value || '-';
    document.getElementById('revGender').textContent = genderSelect.value || '-';
    document.getElementById('revGuardian').textContent = guardianInput.value || '-';
    document.getElementById('revEmail').textContent = emailInput.value || '-';
    document.getElementById('revMobile').textContent = mobileInput.value || '-';
    document.getElementById('revAddress').textContent = addressInput.value || '-';
    document.getElementById('revState').textContent = stateInput.value || '-';
    document.getElementById('revPincode').textContent = pincodeInput.value || '-';
    document.getElementById('revDegree').textContent = degreeInput.value || '-';
    document.getElementById('revBoard').textContent = boardInput.value || '-';
    document.getElementById('revGradYear').textContent = gradYearInput.value || '-';
    document.getElementById('revPercentage').textContent = percentageInput.value ? `${parseFloat(percentageInput.value).toFixed(2)}%` : '-';
  }

  // Clear previous validation feedbacks
  function clearErrors() {
    document.querySelectorAll('#admissionForm .feedback-message').forEach(el => {
      el.textContent = '';
      el.style.opacity = '0';
    });
    document.querySelectorAll('#admissionForm .form-group').forEach(el => {
      el.classList.remove('has-error', 'has-success');
    });
  }

  // Client-side validations per wizard step
  function validateCurrentStep() {
    clearErrors();
    let isValid = true;

    if (currentStep === 1) {
      const dobFb = document.getElementById('adDobFeedback');
      if (!dobInput.value) {
        dobFb.textContent = 'Date of birth is required';
        dobFb.style.opacity = '1';
        if (dobFb.closest('.form-group')) dobFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (dobInput.closest('.form-group')) dobInput.closest('.form-group').classList.add('has-success');
      }

      const genderFb = document.getElementById('adGenderFeedback');
      if (!genderSelect.value) {
        genderFb.textContent = 'Gender selection is required';
        genderFb.style.opacity = '1';
        if (genderFb.closest('.form-group')) genderFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (genderSelect.closest('.form-group')) genderSelect.closest('.form-group').classList.add('has-success');
      }

      const guardianFb = document.getElementById('adGuardianNameFeedback');
      if (!guardianInput.value || guardianInput.value.trim() === '') {
        guardianFb.textContent = 'Father/Guardian name is required';
        guardianFb.style.opacity = '1';
        if (guardianFb.closest('.form-group')) guardianFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (guardianInput.closest('.form-group')) guardianInput.closest('.form-group').classList.add('has-success');
      }

      const addressFb = document.getElementById('adAddressFeedback');
      if (!addressInput.value || addressInput.value.trim() === '') {
        addressFb.textContent = 'Correspondence address is required';
        addressFb.style.opacity = '1';
        if (addressFb.closest('.form-group')) addressFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (addressInput.closest('.form-group')) addressInput.closest('.form-group').classList.add('has-success');
      }

      const stateFb = document.getElementById('adStateFeedback');
      if (!stateInput.value || stateInput.value.trim() === '') {
        stateFb.textContent = 'State is required';
        stateFb.style.opacity = '1';
        if (stateFb.closest('.form-group')) stateFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (stateInput.closest('.form-group')) stateInput.closest('.form-group').classList.add('has-success');
      }

      const pincodeFb = document.getElementById('adPincodeFeedback');
      if (!pincodeInput.value) {
        pincodeFb.textContent = 'Postal pincode is required';
        pincodeFb.style.opacity = '1';
        if (pincodeFb.closest('.form-group')) pincodeFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else if (!/^\d{6}$/.test(pincodeInput.value)) {
        pincodeFb.textContent = 'Pincode must be exactly 6 digits';
        pincodeFb.style.opacity = '1';
        if (pincodeFb.closest('.form-group')) pincodeFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (pincodeInput.closest('.form-group')) pincodeInput.closest('.form-group').classList.add('has-success');
      }
    } else if (currentStep === 2) {
      const degreeFb = document.getElementById('adDegreeFeedback');
      if (!degreeInput.value || degreeInput.value.trim() === '') {
        degreeFb.textContent = 'Qualifying examination title is required';
        degreeFb.style.opacity = '1';
        if (degreeFb.closest('.form-group')) degreeFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (degreeInput.closest('.form-group')) degreeInput.closest('.form-group').classList.add('has-success');
      }

      const boardFb = document.getElementById('adBoardFeedback');
      if (!boardInput.value || boardInput.value.trim() === '') {
        boardFb.textContent = 'Board/University name is required';
        boardFb.style.opacity = '1';
        if (boardFb.closest('.form-group')) boardFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (boardInput.closest('.form-group')) boardInput.closest('.form-group').classList.add('has-success');
      }

      const gradYearFb = document.getElementById('adGradYearFeedback');
      if (!gradYearInput.value) {
        gradYearFb.textContent = 'Graduation year is required';
        gradYearFb.style.opacity = '1';
        if (gradYearFb.closest('.form-group')) gradYearFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        const yr = parseInt(gradYearInput.value, 10);
        if (isNaN(yr) || yr < 1900 || yr > 2035) {
          gradYearFb.textContent = 'Graduation year must be between 1900 and 2035';
          gradYearFb.style.opacity = '1';
          if (gradYearFb.closest('.form-group')) gradYearFb.closest('.form-group').classList.add('has-error');
          isValid = false;
        } else {
          if (gradYearInput.closest('.form-group')) gradYearInput.closest('.form-group').classList.add('has-success');
        }
      }

      const percentageFb = document.getElementById('adPercentageFeedback');
      if (!percentageInput.value) {
        percentageFb.textContent = 'Qualifying percentage is required';
        percentageFb.style.opacity = '1';
        if (percentageFb.closest('.form-group')) percentageFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        const pct = parseFloat(percentageInput.value);
        if (isNaN(pct) || pct < 0 || pct > 100) {
          percentageFb.textContent = 'Percentage must be between 0.00% and 100.00%';
          percentageFb.style.opacity = '1';
          if (percentageFb.closest('.form-group')) percentageFb.closest('.form-group').classList.add('has-error');
          isValid = false;
        } else {
          if (percentageInput.closest('.form-group')) percentageInput.closest('.form-group').classList.add('has-success');
        }
      }
    } else if (currentStep === 4) {
      const agreeFb = document.getElementById('adAgreeFeedback');
      if (!agreeCheckbox.checked) {
        agreeFb.textContent = 'You must agree to the declaration statement to submit';
        agreeFb.style.opacity = '1';
        if (agreeFb.closest('.form-group')) agreeFb.closest('.form-group').classList.add('has-error');
        isValid = false;
      } else {
        if (agreeCheckbox.closest('.form-group')) agreeCheckbox.closest('.form-group').classList.add('has-success');
      }
    }

    return isValid;
  }

  // Update Stepper circles and lines
  function renderStepperProgress() {
    steps.forEach((step, index) => {
      const stepNum = index + 1;
      
      // Step states
      if (stepNum === currentStep) {
        step.el.className = 'ad-step active';
      } else if (stepNum < currentStep) {
        step.el.className = 'ad-step complete';
        step.el.querySelector('.ad-circle').innerHTML = '✓';
      } else {
        step.el.className = 'ad-step';
        step.el.querySelector('.ad-circle').innerHTML = stepNum;
      }

      // Connector lines states
      if (step.conn) {
        if (stepNum <= currentStep) {
          step.conn.className = 'ad-connector complete';
        } else {
          step.conn.className = 'ad-connector';
        }
      }
    });
  }

  // Render Panel Views
  function renderPanelView() {
    panels.forEach((panel, index) => {
      const panelNum = index + 1;
      if (panelNum === currentStep) {
        panel.style.display = 'block';
      } else {
        panel.style.display = 'none';
      }
    });

    // Back Button visibility
    if (currentStep === 1 || isApplicationLocked) {
      backBtn.style.visibility = 'hidden';
    } else {
      backBtn.style.visibility = 'visible';
    }

    // Save Draft visibility
    if (isApplicationLocked) {
      saveDraftBtn.style.display = 'none';
    } else {
      saveDraftBtn.style.display = 'inline-block';
    }

    // Continue Button Labels
    if (isApplicationLocked) {
      continueBtn.style.display = 'none';
    } else if (currentStep === 4) {
      continueBtn.style.display = 'inline-block';
      continueText.textContent = 'Submit Application';
    } else {
      continueBtn.style.display = 'inline-block';
      continueText.textContent = 'Continue';
    }
  }

  // Load / Sync active application status
  async function loadAdmissionWizard() {
    try {
      // 1. Fetch current user identity session
      const meResponse = await fetch('/api/auth/me');
      const meResult = await meResponse.json();

      if (!meResponse.ok || !meResult.success) {
        window.location.hash = '#/login-student';
        return;
      }

      const activeUser = meResult.data.user;
      nameInput.value = activeUser.name;
      emailInput.value = activeUser.email;
      mobileInput.value = activeUser.mobile;

      // Disable inputs if role is professor
      const isProfessor = activeUser.role === 'professor';

      // 2. Query admission application details
      const response = await fetch('/api/admission/my-application');
      const result = await response.json();

      if (response.ok && result.success && result.data) {
        const app = result.data;

        // Populate fields
        dobInput.value = app.dob;
        genderSelect.value = app.gender;
        guardianInput.value = app.guardianName;
        addressInput.value = app.address;
        stateInput.value = app.state;
        pincodeInput.value = app.pincode;
        degreeInput.value = app.degree;
        boardInput.value = app.board;
        gradYearInput.value = app.gradYear;
        percentageInput.value = app.percentage;

        const isSubmitted = app.status === 'Submitted' || app.status === 'Approved';

        if (isSubmitted) {
          isApplicationLocked = true;
          currentStep = 4;
          agreeCheckbox.checked = true;
          agreeCheckbox.disabled = true;

          // Disable all inputs
          document.querySelectorAll('#admissionForm input, #admissionForm select').forEach(el => {
            el.setAttribute('disabled', 'true');
            el.classList.add('input-readonly');
          });

          // Show Application ID success banner
          document.getElementById('submissionSuccessBox').style.display = 'flex';
          document.getElementById('submissionAppIdLabel').textContent = app.applicationId;
        } else {
          isApplicationLocked = false;
          currentStep = app.currentStep || 1;
          document.getElementById('submissionSuccessBox').style.display = 'none';
        }
      } else {
        // No application draft found: fetch Student Profile to pre-fill
        const profileRes = await fetch(`/api/profile/${activeUser.userId}`);
        const profileResult = await profileRes.json();

        if (profileRes.ok && profileResult.success) {
          const profile = profileResult.data.profile;
          dobInput.value = profile.dob || '';
          genderSelect.value = profile.gender || '';
          guardianInput.value = profile.guardianName || '';
          addressInput.value = profile.address || '';
          stateInput.value = profile.state || '';
          pincodeInput.value = profile.pincode || '';
          degreeInput.value = profile.degree || '';
          boardInput.value = profile.board || '';
          gradYearInput.value = profile.gradYear || '';
          percentageInput.value = profile.percentage || '';
        }

        currentStep = 1;
        isApplicationLocked = false;
        document.getElementById('submissionSuccessBox').style.display = 'none';
      }

      // Disable wizard fields for Professor Mode
      if (isProfessor) {
        isApplicationLocked = true;
        document.querySelectorAll('#admissionForm input, #admissionForm select, #admissionForm button').forEach(el => {
          el.setAttribute('disabled', 'true');
        });
        saveDraftBtn.style.display = 'none';
        continueBtn.style.display = 'none';
        backBtn.style.display = 'none';
      }

      await syncDigilockerDocumentsInWizard();

      renderStepperProgress();
      renderPanelView();

    } catch (err) {
      console.error('Load admission wizard error:', err);
      showNotification('API Connection Failure', 'Could not sync application status from DB.', 'error');
    }
  }

  // Sync and load DigiLocker documents list for selection
  async function syncDigilockerDocumentsInWizard() {
    try {
      const dlRes = await fetch('/api/digilocker/status');
      const dlResult = await dlRes.json();
      
      const dlContainer = document.getElementById('admissionDigilockerContainer');
      const dlList = document.getElementById('admissionDigilockerList');
      
      if (!dlContainer || !dlList) return;

      if (dlRes.ok && dlResult.success && dlResult.data.connected && dlResult.data.documents.length > 0) {
        // Filter only verified documents
        const verifiedDocs = dlResult.data.documents.filter(doc => doc.verification_status === 'Verified' || doc.verification_status === 'VERIFIED');
        
        if (verifiedDocs.length > 0) {
          dlContainer.style.display = 'block';
          dlList.innerHTML = '';
          
          verifiedDocs.forEach(doc => {
            const isSelected = doc.document_status === 'SELECTED';
            const row = document.createElement('div');
            row.style.cssText = 'display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 6px; margin-bottom: 6px;';
            
            row.innerHTML = `
              <div style="display: flex; align-items: center; gap: 10px;">
                <input type="checkbox" class="dl-doc-checkbox" data-uri="${doc.doc_uri}" ${isSelected ? 'checked' : ''} ${isApplicationLocked ? 'disabled' : ''} style="cursor: pointer; transform: scale(1.2);">
                <span style="font-size: 13px; font-weight: 500;">${doc.document_type} (${doc.issuing_authority})</span>
              </div>
              <span style="font-size: 12px; color: var(--text-muted); font-family: monospace;">${doc.document_ref}</span>
            `;
            
            // Listen for checkbox change
            const checkbox = row.querySelector('.dl-doc-checkbox');
            checkbox.addEventListener('change', async (e) => {
              const checked = e.target.checked;
              try {
                const selectRes = await fetch('/api/digilocker/documents/select', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ docUri: doc.doc_uri, selected: checked })
                });
                const selectResult = await selectRes.json();
                
                if (selectRes.ok && selectResult.success) {
                  if (checked) {
                    showNotification('Document Selected', `Associated ${doc.document_type} with admission application.`, 'success');
                    
                    const clearAcademicErrors = () => {
                      [degreeInput, boardInput, gradYearInput, percentageInput].forEach(el => {
                        const gp = el.closest('.form-group');
                        if (gp) {
                          gp.classList.remove('has-error');
                          gp.classList.add('has-success');
                        }
                        const fb = document.getElementById(`${el.id}Feedback`);
                        if (fb) {
                          fb.textContent = '';
                          fb.style.opacity = '0';
                        }
                      });
                    };

                    // Auto-populate Step 2 fields based on marksheet type
                    if (doc.doc_uri === 'in.gov.cbse-ssc-marksheet-2023') {
                      degreeInput.value = 'Class XII Marksheet';
                      boardInput.value = 'CBSE';
                      gradYearInput.value = 2023;
                      percentageInput.value = 95.50;
                      showNotification('Auto-populated Fields', 'Academic details pre-filled from your CBSE Class XII marksheet.', 'success');
                      clearAcademicErrors();
                    } else if (doc.doc_uri === 'in.gov.cbse-hsc-marksheet-2021') {
                      degreeInput.value = 'Class X Marksheet';
                      boardInput.value = 'CBSE';
                      gradYearInput.value = 2021;
                      percentageInput.value = 90.00;
                      showNotification('Auto-populated Fields', 'Academic details pre-filled from your CBSE Class X marksheet.', 'success');
                      clearAcademicErrors();
                    }
                  } else {
                    showNotification('Document Deselected', `Deselected ${doc.document_type} from admission application.`, 'success');
                  }
                } else {
                  showNotification('Selection Error', selectResult.message || 'Failed to update selection.', 'error');
                  e.target.checked = !checked; // revert
                }
              } catch (err) {
                console.error('Select document error:', err);
                showNotification('Connection Error', 'Could not update selection.', 'error');
                e.target.checked = !checked; // revert
              }
            });
            
            dlList.appendChild(row);
          });
        } else {
          dlContainer.style.display = 'none';
        }
      } else {
        dlContainer.style.display = 'none';
      }
    } catch (err) {
      console.error('syncDigilockerDocumentsInWizard error:', err);
    }
  }

  // Back Button Navigation
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      if (currentStep > 1 && !isApplicationLocked) {
        currentStep--;
        renderStepperProgress();
        renderPanelView();
      }
    });
  }

  // Continue / Submit Wizard Trigger
  if (admissionForm) {
    admissionForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isApplicationLocked) return;

      if (!validateCurrentStep()) return;

      if (currentStep < 4) {
        // Progressive save draft on continue click
        await saveApplicationDraftSilent();
        
        currentStep++;
        if (currentStep === 3) {
          populateReviewPanel();
        }
        renderStepperProgress();
        renderPanelView();
      } else {
        // Final submit: trigger confirmation dialog modal
        if (confirmModal) {
          confirmModal.style.display = 'flex';
        }
      }
    });
  }

  // Silent draft saver on continue transition
  async function saveApplicationDraftSilent() {
    try {
      const payload = {
        dob: dobInput.value,
        gender: genderSelect.value,
        guardianName: guardianInput.value,
        address: addressInput.value,
        state: stateInput.value,
        pincode: pincodeInput.value,
        degree: degreeInput.value,
        board: boardInput.value,
        gradYear: gradYearInput.value ? parseInt(gradYearInput.value, 10) : null,
        percentage: percentageInput.value ? parseFloat(percentageInput.value) : null,
        currentStep: currentStep + 1
      };

      await fetch('/api/admission/save-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.error('Silent draft save error:', err);
    }
  }

  // Explicit Save Draft Button Action
  if (saveDraftBtn) {
    saveDraftBtn.addEventListener('click', async () => {
      if (isApplicationLocked) return;

      saveDraftBtn.disabled = true;
      const originalText = saveDraftBtn.textContent;
      saveDraftBtn.textContent = 'Saving...';

      try {
        const payload = {
          dob: dobInput.value,
          gender: genderSelect.value,
          guardianName: guardianInput.value,
          address: addressInput.value,
          state: stateInput.value,
          pincode: pincodeInput.value,
          degree: degreeInput.value,
          board: boardInput.value,
          gradYear: gradYearInput.value ? parseInt(gradYearInput.value, 10) : null,
          percentage: percentageInput.value ? parseFloat(percentageInput.value) : null,
          currentStep: currentStep
        };

        const res = await fetch('/api/admission/save-draft', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const result = await res.json();
        saveDraftBtn.disabled = false;
        saveDraftBtn.textContent = originalText;

        if (res.ok && result.success) {
          showNotification('Draft Saved', 'Your application progress has been saved successfully.', 'success');
        } else {
          showNotification('Save Failed', result.message || 'Validation errors occurred.', 'error');
        }

      } catch (err) {
        saveDraftBtn.disabled = false;
        saveDraftBtn.textContent = originalText;
        console.error('Save draft submit error:', err);
        showNotification('Connection Error', 'Could not save draft. Check server logs.', 'error');
      }
    });
  }

  // Modal Dialog Confirm Submit Trigger
  if (confirmSubmitBtn) {
    confirmSubmitBtn.addEventListener('click', async () => {
      if (isApplicationLocked) return;

      // Close modal
      if (confirmModal) confirmModal.style.display = 'none';

      // Lock buttons
      continueBtn.disabled = true;
      if (continueSpinner) continueSpinner.style.display = 'block';
      if (continueText) continueText.textContent = 'Submitting...';

      try {
        const payload = {
          dob: dobInput.value,
          gender: genderSelect.value,
          guardianName: guardianInput.value,
          address: addressInput.value,
          state: stateInput.value,
          pincode: pincodeInput.value,
          degree: degreeInput.value,
          board: boardInput.value,
          gradYear: gradYearInput.value ? parseInt(gradYearInput.value, 10) : null,
          percentage: percentageInput.value ? parseFloat(percentageInput.value) : null
        };

        const res = await fetch('/api/admission/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const result = await res.json();

        // Restore button state
        continueBtn.disabled = false;
        if (continueSpinner) continueSpinner.style.display = 'none';
        if (continueText) continueText.textContent = 'Submit Application';

        if (res.ok && result.success) {
          showNotification('Application Submitted', 'Your admission application has been finalized successfully.', 'success');
          
          // Lock form
          isApplicationLocked = true;
          agreeCheckbox.disabled = true;

          document.querySelectorAll('#admissionForm input, #admissionForm select').forEach(el => {
            el.setAttribute('disabled', 'true');
            el.classList.add('input-readonly');
          });

          // Render Success banner
          document.getElementById('submissionSuccessBox').style.display = 'flex';
          document.getElementById('submissionAppIdLabel').textContent = result.data.applicationId;

          // Re-render UI
          renderStepperProgress();
          renderPanelView();

          // Refresh student dashboard stepper in the background if dashboard init exists
          if (window.loadStudentDashboard) {
            window.loadStudentDashboard();
          }

        } else {
          showNotification('Submission Failed', result.message || 'Required fields are missing.', 'error');
        }

      } catch (err) {
        continueBtn.disabled = false;
        if (continueSpinner) continueSpinner.style.display = 'none';
        if (continueText) continueText.textContent = 'Submit Application';
        console.error('Final submit API error:', err);
        showNotification('Connection Failure', 'Could not complete final submission.', 'error');
      }
    });
  }

  // Expose global loader
  window.loadAdmissionWizard = loadAdmissionWizard;
});

'use strict';

/**
 * Digital Signature Verification Service for Offline e-KYC XML
 *
 * Provides a configurable interface for XML digital signature validation.
 * - Production mode: validates against UIDAI certificate chain using xml-crypto
 * - Mock mode: returns a clearly-labelled simulated verification result
 *
 * IMPORTANT: When UIDAI certificates are unavailable, the mock verifier is used.
 * This is clearly documented and labelled — never presented as real verification.
 */

const fs = require('fs');
const path = require('path');

/**
 * @typedef {Object} SignatureResult
 * @property {boolean} valid - Whether the signature is valid
 * @property {string|null} reason - Reason code if invalid
 * @property {boolean} isMock - Whether this was a mock verification
 * @property {string|null} detail - Human-readable detail
 */

/**
 * Verify the digital signature of an Offline e-KYC XML document
 * @param {string} xmlContent - Raw XML string containing the document and signature
 * @param {object} [options] - Configuration options
 * @param {string} [options.certificatePath] - Path to the UIDAI verification certificate
 * @param {boolean} [options.mockMode] - Force mock mode regardless of certificate availability
 * @returns {Promise<SignatureResult>}
 */
async function verifySignature(xmlContent, options = {}) {
  const mode = process.env.EKYC_MODE || 'mock';
  const certPath = options.certificatePath || process.env.EKYC_CERTIFICATE_PATH || '';
  const forceMock = options.mockMode || mode === 'mock';

  // If mock mode or no certificate available, use mock verifier
  if (forceMock || !certPath || !_certificateExists(certPath)) {
    return _mockVerify(xmlContent);
  }

  // Production verification
  return _productionVerify(xmlContent, certPath);
}

/**
 * Mock signature verification — CLEARLY LABELLED AS DEVELOPMENT ONLY
 * @param {string} xmlContent
 * @returns {SignatureResult}
 */
function _mockVerify(xmlContent) {
  // Basic structural check: does the XML contain a Signature element?
  if (!xmlContent || typeof xmlContent !== 'string') {
    return {
      valid: false,
      reason: 'SIGNATURE_INVALID',
      isMock: true,
      detail: '[MOCK] XML content is empty or invalid'
    };
  }

  const hasSignature = xmlContent.includes('<Signature') || xmlContent.includes('<Signature>');
  if (!hasSignature) {
    return {
      valid: false,
      reason: 'SIGNATURE_MISSING',
      isMock: true,
      detail: '[MOCK] No Signature element found in XML document'
    };
  }

  // In mock mode, we accept the presence of a Signature element as sufficient.
  // This is NOT real cryptographic verification.
  return {
    valid: true,
    reason: null,
    isMock: true,
    detail: '[MOCK/DEVELOPMENT] Signature presence verified. This is NOT cryptographic verification. ' +
            'Production deployment requires UIDAI certificates configured via EKYC_CERTIFICATE_PATH.'
  };
}

/**
 * Production XML digital signature verification using xml-crypto
 * @param {string} xmlContent
 * @param {string} certPath
 * @returns {Promise<SignatureResult>}
 */
async function _productionVerify(xmlContent, certPath) {
  try {
    const { SignedXml } = require('xml-crypto');
    const { DOMParser } = require('@xmldom/xmldom');

    // Load the UIDAI public certificate
    let certPem;
    try {
      certPem = fs.readFileSync(path.resolve(certPath), 'utf8');
    } catch (readErr) {
      return {
        valid: false,
        reason: 'CERTIFICATE_INVALID',
        isMock: false,
        detail: 'Failed to read UIDAI verification certificate. Check EKYC_CERTIFICATE_PATH configuration.'
      };
    }

    // Parse the XML document
    const doc = new DOMParser().parseFromString(xmlContent, 'text/xml');

    // Find Signature element
    const signatureNodes = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'Signature');
    if (!signatureNodes || signatureNodes.length === 0) {
      return {
        valid: false,
        reason: 'SIGNATURE_MISSING',
        isMock: false,
        detail: 'No XML digital signature found in the document'
      };
    }

    // Create signature verifier with the certificate
    const sig = new SignedXml();
    sig.keyInfoProvider = {
      getKeyInfo: () => '<X509Data></X509Data>',
      getKey: () => certPem
    };

    sig.loadSignature(signatureNodes[0]);

    const isValid = sig.checkSignature(xmlContent);

    if (isValid) {
      return {
        valid: true,
        reason: null,
        isMock: false,
        detail: 'XML digital signature verified against UIDAI certificate'
      };
    } else {
      return {
        valid: false,
        reason: 'SIGNATURE_INVALID',
        isMock: false,
        detail: `Signature verification failed: ${sig.validationErrors ? sig.validationErrors.join('; ') : 'unknown reason'}`
      };
    }

  } catch (err) {
    return {
      valid: false,
      reason: 'SIGNATURE_INVALID',
      isMock: false,
      detail: `Signature verification error: ${err.message}`
    };
  }
}

/**
 * Check if a certificate file exists at the given path
 * @param {string} certPath
 * @returns {boolean}
 */
function _certificateExists(certPath) {
  try {
    return fs.existsSync(path.resolve(certPath));
  } catch {
    return false;
  }
}

module.exports = {
  verifySignature
};

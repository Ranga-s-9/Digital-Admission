# Postman API Testing Guide

This document describes how to test and verify the REST API endpoints of the **Digital Student Admission System** using the provided Postman collection.

---

## 1. Importing the Collection
1. Locate the Postman collection file in the codebase: [`docs/postman_collection.json`](file:///c:/VS%20CODE/projects/DPI%20Student%20Admission%20System/docs/postman_collection.json).
2. Open **Postman**.
3. Click the **Import** button in the top-left corner.
4. Drag and drop the `postman_collection.json` file or browse to select it.
5. Click **Import** to add the collection to your workspace.

---

## 2. Environment Variables
To run queries successfully, create or verify the collection variables in Postman:
* `base_url`: `http://localhost:3000` (The URL of your running Express server).

Cookies are automatically managed by Postman to persist the JWT session token cookie (`token`) across requests.

---

## 3. Recommended Testing Workflow Sequence

To simulate the complete end-to-end integration flow in Postman, run the requests in the following order:

### Phase A: Authentication & SSO
1. **Fetch CAPTCHA (`GET /api/auth/captcha`)**
   * Retrieves an arithmetic challenge and `captchaId`.
2. **User Registration (`POST /api/auth/register`)**
   * Submits name, email, mobile, password, and the CAPTCHA response.
3. **SSO Login Step 1 (`POST /api/auth/login`)**
   * Submits email and password. Generates a temporary OTP session returned in the response headers/body.
4. **SSO Login Step 2: OTP Verification (`POST /api/auth/verify-otp`)**
   * Submits the 6-digit OTP code (read from the local file `scratch/mock_otp.txt`) to acquire the HTTP-only cookie token.

### Phase B: Student Operations
5. **Get Dashboard Checklist (`GET /api/dashboard/student`)**
   * Verifies registration checklist items status.
6. **Update Profile (`PUT /api/profile/:userId`)**
   * Populates date of birth, pincode, degree, board, percentage, and triggers automatic calculation of profile completion percentage.
7. **Save Admission Draft (`POST /api/admission/save-draft`)**
   * Saves step-by-step drafts of personal and academic details.

### Phase C: Integrations & Paperless Flow
8. **Verify eKYC (`POST /api/ekyc/verify`)**
   * Uploads offline XML file with share code to verify Aadhaar identity.
9. **Link DigiLocker Documents (`POST /api/digilocker/callback`)**
   * Simulates DigiLocker connection callback to retrieve academic marksheets.
10. **emSigner Application Signature (`POST /api/emsigner/sign`)**
    * Digitally signs application document. Sets application status to `SIGNED` (and auto-promotes to reviewer queue).

### Phase D: Admin/Professor Review
11. **Query Reviews (`GET /api/dashboard/professor`)**
    * Retrieves search-filtered lists of pending applications.
12. **Review Transition (`POST /api/workflow/transition`)**
    * Transitions application status to `Approved` or `Rejected`.
13. **Audit Logs (`GET /api/audit-logs`)**
    * Queries security action audit trail logs (restricted to professors).
